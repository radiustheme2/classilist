<?php

namespace RtclStore\Controllers;

use Rtcl\Helpers\Functions;
use Rtcl\Helpers\Page;
use Rtcl\Resources\Options;
use RtclStore\Helpers\Functions as StoreFunctions;

class Script {

	function __construct() {
		add_action( 'admin_init', [ $this, 'register_script_for_both' ], 100 );
		add_action( 'admin_init', [ $this, 'register_script_backend' ], 200 );
		add_action( 'admin_enqueue_scripts', [ $this, 'load_admin_script_for_store_post_type' ], 300 );
		add_action( 'admin_enqueue_scripts', [ $this, 'load_admin_script_for_pricing_post_type' ], 300 );
		add_action( 'admin_enqueue_scripts', [ $this, 'load_admin_script_for_settings' ], 300 );
		add_action( 'admin_enqueue_scripts', [ $this, 'load_admin_script_for_manage_membership' ], 300 );
		add_action( 'wp_enqueue_scripts', [ $this, 'register_script_for_both' ], 1 );
		add_action( 'wp_enqueue_scripts', [ $this, 'register_script_frontend' ], 2 );
		add_action( 'wp_enqueue_scripts', [ $this, 'load_script' ], 5 );
	}

	function register_script_for_both() {
		wp_register_script( 'bootstrap-timepicker', RTCL_STORE_URL . '/assets/vendor/bootstrap-timepicker.min.js', [ 'jquery' ], '0.5.2', true );
	}

	function register_script_backend() {
		$version = ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? time() : RTCL_STORE_VERSION;
		wp_register_style( 'rtcl-store-admin', RTCL_STORE_URL . '/assets/css/admin.css', '', $version );
		wp_register_script( 'rtcl-store-admin', RTCL_STORE_URL . '/assets/js/admin.js', [
			'jquery',
			'bootstrap-timepicker',
		], $version, true );
		wp_register_script( 'rtcl-admin-pricing', RTCL_STORE_URL . '/assets/js/admin-pricing.js', [ 'jquery' ], $version, true );

		wp_register_style( 'rtcl-membership-app', RTCL_STORE_URL . '/assets/css/membership.app.css', [
			'rtcl-admin',
		], $version );
		wp_register_script( 'rtcl-membership-app', RTCL_STORE_URL . '/assets/js/membership.app.js', [
			'wp-i18n',
			'jquery',
		], $version, true );

		$max_image_size = Functions::get_max_upload();
		global $post;
		wp_localize_script( 'rtcl-store-admin', 'rtcl_store', apply_filters( 'rtcl_store_admin_localize', [
			"ajaxurl"               => admin_url( "admin-ajax.php" ),
			"store_time_options"    => apply_filters( 'rtcl_store_time_options', [
				"icons" => [
					"up"   => 'rtcl-icon-up-open',
					"down" => 'rtcl-icon-down-open',
				],
				"showMeridian" => ! StoreFunctions::is_24_hour_format(),
			] ),
			'confirm_text'          => __( "Are You sure to delete?", 'classified-listing-store' ),
			rtcl()->nonceId         => wp_create_nonce( rtcl()->nonceText ),
			"max_image_size"        => $max_image_size,
			'store_id'              => is_object( $post ) ? $post->ID : 0,
			"image_allowed_type"    => (array) Functions::get_option_item( 'rtcl_misc_media_settings', 'image_allowed_type', [
				'png',
				'jpeg',
				'jpg',
			] ),
			"error_common"          => __( "Error while upload image", "classified-listing-store" ),
			"error_image_size"      => sprintf( __( "Image size is more then %s.", "classified-listing-store" ), Functions::formatBytes( $max_image_size ) ),
			"error_image_extension" => __( "File extension not supported.", "classified-listing-store" ),
			"server_error"          => __( "Server Error.", "classified-listing-store" ),
		] ) );

		wp_localize_script( 'rtcl-membership-app', 'rtcl_store', [
			"ajaxurl"             => admin_url( "admin-ajax.php" ),
			'confirm_alert'       => __( "Are You sure to delete?", 'classified-listing-store' ),
			'selection_alert'     => __( "Please select a row to delete", 'classified-listing-store' ),
			rtcl()->nonceId       => wp_create_nonce( rtcl()->nonceText ),
			'is_tax_enabled'      => (bool) Functions::is_enable_tax(),
			'is_billing_disabled' => (bool) Functions::is_billing_address_disabled(),
			'currency_symbol'     => Functions::get_currency_symbol( Functions::get_order_currency() ),
			'currency_position'   => Functions::get_option_item( 'rtcl_payment_settings', 'currency_position', 'left' ),
			'countries'           => rtcl()->countries->get_countries(),
			'states'              => rtcl()->countries->get_states(),
		] );
	}

	function register_script_frontend() {
		$version = ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? time() : RTCL_STORE_VERSION;
		wp_register_script( 'rtcl-store', RTCL_STORE_URL . '/assets/js/store.js', [
			'jquery',
			'rtcl-validator',
			'bootstrap-timepicker',
		], $version, true );

		wp_register_script( 'rtcl-store-public', RTCL_STORE_URL . '/assets/js/store-public.js', [
			'jquery',
			'rtcl-validator',
		], $version, true );

		wp_register_style( 'rtcl-store', RTCL_STORE_URL . '/assets/css/store.css', [ 'rtcl-public' ], $version );
		wp_register_style( 'rtcl-store-public', RTCL_STORE_URL . '/assets/css/store-public.css', [ 'rtcl-public' ], $version );

		$max_image_size = Functions::get_max_upload();
		global $post;
		wp_localize_script( 'rtcl-store', 'rtcl_store', apply_filters( 'rtcl_store_localize', [
			"store_time_options"    => apply_filters( 'rtcl_store_time_options', [
				"icons" => [
					"up"   => 'rtcl-icon-up-open',
					"down" => 'rtcl-icon-down-open',
				],
				"showMeridian" => ! StoreFunctions::is_24_hour_format(),
			] ),
			"store_manager_options" => [
				"email_placeholder" => esc_html__( "Email address", "classified-listing-store" ),
				"add_button_text"   => esc_html__( "Add", "classified-listing-store" ),
			],
			"ajaxurl"               => admin_url( "admin-ajax.php" ),
			'confirm_text'          => __( "Are You sure?", 'classified-listing-store' ),
			rtcl()->nonceId         => wp_create_nonce( rtcl()->nonceText ),
			"max_image_size"        => $max_image_size,
			'store_id'              => is_singular( rtclStore()->post_type ) ? $post->ID : 0,
			"image_allowed_type"    => (array) Functions::get_option_item( 'rtcl_misc_media_settings', 'image_allowed_type', [
				'png',
				'jpeg',
				'jpg',
			] ),
			"error_common"          => __( "Error while upload image", "classified-listing-store" ),
			"error_image_size"      => sprintf( __( "Image size is more then %s.", "classified-listing-store" ), Functions::formatBytes( $max_image_size ) ),
			"error_image_extension" => __( "File extension not supported.", "classified-listing-store" ),
			"server_error"          => __( "Server Error.", "classified-listing-store" ),
			'lng'                   => [
				'error' => __( 'Error while processing data', 'classified-listing-store' ),
			],
		] ) );
		wp_localize_script( 'rtcl-store-public', 'rtcl_store_public', apply_filters( 'rtcl_store_public_localize', [
			"ajaxurl"       => admin_url( "admin-ajax.php" ),
			'is_rtl'        => is_rtl(),
			rtcl()->nonceId => wp_create_nonce( rtcl()->nonceText ),
			'store_id'      => is_singular( rtclStore()->post_type ) ? $post->ID : 0,
		] ) );
	}

	function load_admin_script_for_store_post_type() {
		global $pagenow, $post_type;
		// validate page
		if ( ! in_array( $pagenow, [ 'post.php', 'post-new.php', 'edit.php' ] ) ) {
			return;
		}
		if ( rtclStore()->post_type != $post_type ) {
			return;
		}

		wp_enqueue_style( 'rtcl-admin' );
		wp_enqueue_script( 'rtcl-admin' );
		wp_enqueue_style( 'rtcl-store-admin' );
		wp_enqueue_script( 'rtcl-store-admin' );
	}

	function load_admin_script_for_settings() {
		if ( ! empty( $_GET['page'] ) && $_GET['page'] == 'rtcl-settings'
		     && ( isset( $_GET['tab'] )
		          && ( $_GET['tab'] === 'membership'
		               || $_GET['tab'] === 'tools' ) )
		) {
			wp_enqueue_style( 'rtcl-store-admin' );
		}
	}

	function load_admin_script_for_pricing_post_type() {
		global $pagenow, $post_type;
		// validate page
		if ( ! in_array( $pagenow, [ 'post.php', 'post-new.php', 'edit.php' ] ) ) {
			return;
		}
		if ( rtcl()->post_type_pricing != $post_type ) {
			return;
		}

		wp_enqueue_script( 'rtcl-admin-pricing' );
		wp_enqueue_style( 'rtcl-store-admin' );
	}

	function load_script() {
		global $wp;

		if ( Functions::is_account_page()
		     && ( isset( $wp->query_vars['store'] ) || isset( $wp->query_vars['page'] )
		          || isset( $wp->query_vars['listings'] ) )
		) {
			wp_enqueue_script( 'rtcl-store' );
			wp_enqueue_style( 'rtcl-store' );
			// Reuse the base plugin's international phone widget + social/telegram
			// validation (registered as `rtcl-edit-account`) so the store form's
			// Phone / WhatsApp / social fields behave exactly like Account Details.
			$this->localize_intl_phone_script();
		}

		if ( Functions::is_checkout_page()
		     && ( isset( $wp->query_vars['membership'] ) || isset( $wp->query_vars['submission'] )
		          || isset( $wp->query_vars['payment-receipt'] ) )
		) {
			wp_enqueue_style( 'rtcl-store-public' );
		}

		if ( StoreFunctions::is_store() || StoreFunctions::is_single_store() || StoreFunctions::is_store_taxonomy()
		     || isset( $wp->query_vars['submission'] )
		) {
			wp_enqueue_script( 'rtcl-store-public' );
			wp_enqueue_style( 'fontawesome' );
			wp_enqueue_style( 'rtcl-store-public' );
		}
	}

	function load_admin_script_for_manage_membership() {
		if ( ! empty( $_GET['page'] ) && $_GET['page'] == 'rtcl-membership' ) {
			wp_enqueue_style( 'rtcl-admin' );
			wp_enqueue_script( 'rtcl-admin' );
			wp_enqueue_style( 'rtcl-membership-app' );
			wp_enqueue_script( 'rtcl-membership-app' );
		}
	}

	/**
	 * Enqueue the base plugin's intl-phone widget script on the store form and
	 * localize the config it expects (`rtcl_edit_account`). The base only
	 * localizes this on its own Account Details / registration pages, so we
	 * rebuild the same payload here from the shared public APIs, honouring the
	 * default/allowed countries configured in the main Phone settings.
	 *
	 * @return void
	 */
	private function localize_intl_phone_script() {
		// `rtcl-edit-account` is registered by the base ScriptLoader at
		// `wp_enqueue_scripts` priority 1; this runs at priority 5, so it exists.
		wp_enqueue_script( 'rtcl-edit-account' );

		$allowed = (array) Functions::get_option_item( 'rtcl_misc_phone_settings', 'phone_allowed_countries' );
		$allowed = array_values( array_filter( array_map( 'strval', $allowed ) ) );

		$default = Functions::get_option_item( 'rtcl_misc_phone_settings', 'phone_default_country' );
		if ( ! $default ) {
			$default = rtcl()->countries->get_base_country();
		}
		if ( ! empty( $allowed ) && ! in_array( $default, $allowed, true ) ) {
			$default = reset( $allowed );
		}

		$phone_country_list = [];
		if ( method_exists( rtcl()->countries, 'get_phone_country_list' ) ) {
			// Base plugin's shared list: built-in countries plus admin-added custom codes
			// (flagged `custom`, which the base widget shows as a text badge, not a flag).
			foreach ( (array) rtcl()->countries->get_phone_country_list() as $entry ) {
				if ( empty( $entry['value'] ) ) {
					continue;
				}
				if ( ! empty( $allowed ) && ! in_array( (string) $entry['value'], $allowed, true ) ) {
					continue;
				}
				$phone_country_list[] = $entry;
			}
		} else {
			foreach ( rtcl()->countries->get_countries() as $code => $name ) {
				$dial_code = rtcl()->countries->get_country_calling_code( $code );
				if ( ! $dial_code ) {
					continue;
				}
				if ( ! empty( $allowed ) && ! in_array( $code, $allowed, true ) ) {
					continue;
				}
				$phone_country_list[] = [
					'value'     => $code,
					'label'     => $name . ' (' . $dial_code . ')',
					'dial_code' => $dial_code,
				];
			}
		}

		wp_localize_script(
			'rtcl-edit-account',
			'rtcl_edit_account',
			[
				'countryPhoneList'       => $phone_country_list,
				'default_country'        => $default,
				'social_profiles'        => Options::get_social_profiles_list(),
				'social_profile_domains' => Options::get_social_profile_domains(),
				'i18n'                   => [
					'search'             => esc_html__( 'Search', 'classified-listing-store' ),
					'need_country'       => esc_html__( 'Please select a country code.', 'classified-listing-store' ),
					'invalid_phone'      => esc_html__( 'Please enter a valid phone number for the selected country.', 'classified-listing-store' ),
					'invalid_telegram'   => esc_html__( 'Telegram ID must start with @ and be 5–32 characters (letters, numbers and underscore).', 'classified-listing-store' ),
					/* translators: %s: social platform name, e.g. Facebook */
					'invalid_social_url' => esc_html__( 'Please enter a valid %s URL', 'classified-listing-store' ),
				],
			]
		);
	}
}
