<?php
/**
 * @author        RadiusTheme
 * @package       classified-listing/templates/compare
 * @version       1.0.0
 *
 * @var array $compare_ids
 */

use Rtcl\Helpers\Functions;
use Rtcl\Helpers\Link;

if (empty($compare_ids) || !is_array($compare_ids)) return;
?>

<div id="rtcl-compare-panel">
    <div id="rtcl-compare-wrap">
        <div id="rtcl-compare-panel-btn">
            <span class="rtcl-compare-listing-count"><?php echo count($compare_ids) ?></span>
            <i class="rtcl-icon rtcl-icon-exchange"></i>
        </div>
        <h5 class="rtcl-compare-wrap-title"><?php esc_html_e("Compare", 'classified-listing-pro'); ?></h5>
        <div id="rtcl-compare-list">
            <?php
            foreach ($compare_ids as $compare_id) {
                $listing = rtcl()->factory->get_listing($compare_id);
                if ($listing) {
                    ?>
                    <?php
                    // Note: the drawer renders in wp_footer on every page, so the listing's
                    // can_show_*() helpers can't be used here — they read archive vs. single
                    // display options depending on the current page, which would make the same
                    // item show different meta from one page to the next. Only globally
                    // disabled data is hidden.
                    $price_disabled = Functions::is_price_disabled() || 'disabled' === $listing->get_pricing_type();
                    $price_html     = $price_disabled ? '' : $listing->get_price_html();

                    // Show the most specific category. get_last_child_category() can't be used:
                    // Listing::setTermsOrder() skips ordering when a listing has more than one
                    // category, so its last item may well be the parent term.
                    $category = false;
                    $depth    = -1;
                    foreach ((array) $listing->get_categories() as $term) {
                        $term_depth = count(get_ancestors($term->term_id, rtcl()->category));
                        if ($term_depth > $depth) {
                            $category = $term;
                            $depth    = $term_depth;
                        }
                    }
                    ?>
                    <div class="rtcl-compare-item">
                        <a class="rtcl-compare-item-image" href="<?php echo get_the_permalink($listing->get_id()) ?>">
                            <?php $listing->the_thumbnail('thumbnail') ?>
                        </a>
                        <div class="rtcl-compare-item-content">
                            <h4 class="rtcl-compare-item-title"><a
                                        href="<?php echo get_the_permalink($listing->get_id()) ?>"><?php $listing->the_title(); ?></a>
                            </h4>
                            <?php if ($category) { ?>
                                <ul class="rtcl-compare-item-meta">
                                    <li class="rtcl-compare-item-category">
                                        <i class="rtcl-icon rtcl-icon-tags"></i><?php echo esc_html($category->name); ?>
                                    </li>
                                </ul>
                            <?php } ?>
                            <?php if ($price_html) { ?>
                                <div class="rtcl-compare-item-price"><?php
                                    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                                    echo $price_html; ?></div>
                            <?php } ?>
                        </div>
                        <div class="rtcl-compare-remove-wrap">
                            <a class="rtcl-compare-remove"
                               data-listing_id="<?php echo absint($listing->get_id()); ?>"><i
                                        class="rtcl-icon rtcl-icon-trash-empty"></i></a>
                        </div>
                    </div>
                    <?php
                }
            }
            ?>
        </div>
        <div id="rtcl-compare-no-item"><?php esc_html_e("No Items Selected", 'classified-listing-pro'); ?></div>
        <div id="rtcl-compare-btn-wrap">
            <a class="rtcl-compare-btn"
               href="<?php echo esc_url(Link::get_page_permalink('compare_page')); ?>"><?php esc_html_e("Compare", 'classified-listing-pro'); ?></a>
            <a class="rtcl-compare-btn-clear"
               href="javascript():;"><?php esc_html_e("Clear", 'classified-listing-pro'); ?></a>
        </div>
    </div>
</div>
