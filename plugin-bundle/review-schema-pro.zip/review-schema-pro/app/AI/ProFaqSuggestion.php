<?php
/**
 * Pro FAQ Suggestion — editor panel extension.
 *
 * Enqueues JS files that hook into the free plugin's editor panels
 * (both block editor and classic editor) to suggest FAQ schema
 * generation when no FAQ block/meta exists and FAQPage is not
 * already selected.
 *
 * @package Rtrsp\AI
 * @since   1.2.0
 */

namespace Rtrsp\AI;

use Rtrs\AI\AIInit;

defined( 'ABSPATH' ) || exit;

class ProFaqSuggestion {

	/**
	 * Register WordPress hooks.
	 *
	 * @return void
	 */
	public function register_hooks() {
		add_action( 'enqueue_block_editor_assets', [ $this, 'enqueue_editor_assets' ], 20 );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_classic_editor_assets' ], 20 );
	}

	/**
	 * Get shared i18n strings for FAQ suggestion panels.
	 *
	 * @return array
	 */
	private function get_i18n_strings() {
		return [
			'faqSuggestionHint'     => __( 'Adding FAQ schema can significantly improve your Google Rich Results visibility.', 'review-schema-pro' ),
			'faqSuggestionQuestion' => __( 'Would you like to auto-generate FAQs from your content?', 'review-schema-pro' ),
			'faqCountLabel'         => __( 'Number of FAQs', 'review-schema-pro' ),
			'generateWithFaqs'      => __( 'Generate with FAQs', 'review-schema-pro' ),
			'skip'                  => __( 'Skip', 'review-schema-pro' ),
		];
	}

	/**
	 * Enqueue Pro FAQ suggestion JS after the free plugin's block editor panel.
	 *
	 * @return void
	 */
	public function enqueue_editor_assets() {
		if ( ! wp_script_is( 'rtrs-ai-editor-panel', 'enqueued' ) ) {
			return;
		}

		wp_enqueue_script(
			'rtrs-pro-faq-suggestion',
			rtrsp()->get_assets_uri( 'ai/js/pro-faq-suggestion.js' ),
			[ 'rtrs-ai-editor-panel', 'wp-hooks', 'wp-element', 'wp-components' ],
			RTRSP_VERSION,
			true
		);

		wp_localize_script(
			'rtrs-pro-faq-suggestion',
			'aiseProFaqData',
			[
				'i18n' => $this->get_i18n_strings(),
			]
		);
	}

	/**
	 * Enqueue Pro FAQ suggestion JS for classic editor.
	 *
	 * @return void
	 */
	public function enqueue_classic_editor_assets() {
		$screen = get_current_screen();

		if ( ! $screen || $screen->is_block_editor() || 'post' !== $screen->base ) {
			return;
		}

		if ( ! wp_script_is( 'rtrs-ai-classic-editor-panel', 'enqueued' ) ) {
			return;
		}

		wp_enqueue_script(
			'rtrs-pro-classic-faq-suggestion',
			rtrsp()->get_assets_uri( 'ai/js/pro-classic-faq-suggestion.js' ),
			[ 'rtrs-ai-classic-editor-panel', 'wp-hooks' ],
			RTRSP_VERSION,
			true
		);

		wp_localize_script(
			'rtrs-pro-classic-faq-suggestion',
			'aiseProFaqData',
			[
				'i18n' => $this->get_i18n_strings(),
			]
		);
	}
}
