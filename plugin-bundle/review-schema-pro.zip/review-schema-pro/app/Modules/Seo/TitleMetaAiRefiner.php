<?php
/**
 * Title & Meta AI refinement (Pro).
 *
 * Hooks the free `rtrs_seo_ai_refine` filter: layers a bounded qualitative AI
 * judgment on top of the deterministic Title & Meta baseline. The AI may only
 * adjust the score within a small bounded range and can never override a factual
 * failure (an empty title/meta stays a failure). No key / provider error ⇒ the
 * baseline is returned untouched.
 *
 * @package Rtrsp\Modules\Seo
 * @since   1.0.0
 */

namespace Rtrsp\Modules\Seo;

use Rtrs\AI\AIClient;
use Rtrs\AI\AIInit;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class TitleMetaAiRefiner
 */
class TitleMetaAiRefiner {

	/**
	 * Maximum number of points the AI may add or remove from the baseline.
	 * Sized so a genuine qualitative re-assessment can land more than 5 points
	 * from the deterministic score when the AI disagrees.
	 */
	const BOUND = 15;

	/**
	 * Filter callback for `rtrs_seo_ai_refine`.
	 *
	 * @param array $baseline The Title & Meta dimension from the free analyzer.
	 * @param int   $post_id  Post ID (unused; the baseline carries what we need).
	 * @param mixed $context  Shared AnalysisContext (unused).
	 * @return array Refined object (scored_by='ai') or the unchanged baseline.
	 */
	public static function refine( $baseline, $post_id = 0, $context = null ) {
		if ( ! is_array( $baseline ) || ! AIInit::hasApiKey() ) {
			return $baseline;
		}

		$measured = isset( $baseline['measured'] ) ? $baseline['measured'] : [];
		$title    = isset( $measured['title'] ) ? (string) $measured['title'] : '';
		$meta     = isset( $measured['meta'] ) ? (string) $measured['meta'] : '';

		// Nothing qualitative to judge when both strings are missing.
		if ( '' === $title && '' === $meta ) {
			return $baseline;
		}

		$client   = new AIClient();
		$response = $client->complete( self::system_prompt(), self::user_prompt( $title, $meta ) );

		if ( is_wp_error( $response ) || ! is_array( $response ) ) {
			return $baseline; // Fail soft — keep the deterministic result.
		}

		$adjustment = isset( $response['adjustment'] ) ? (int) $response['adjustment'] : 0;
		$adjustment = max( -self::BOUND, min( self::BOUND, $adjustment ) );

		$title_present = ! empty( $measured['title_length'] );
		$meta_present  = ! empty( $measured['meta_length'] );

		$score = (int) $baseline['score'] + $adjustment;
		$score = max( 0, min( 100, $score ) );

		// Guard: AI may never lift a presence failure into a passing band.
		if ( ( ! $title_present || ! $meta_present ) && $score >= 80 ) {
			$score = 79;
		}

		$baseline['score']     = $score;
		$baseline['status']    = self::band( $score );
		$baseline['scored_by'] = 'ai';

		// Append AI notes as issues (never replace the deterministic ones).
		foreach ( self::sanitize_notes( $response ) as $note ) {
			$baseline['issues'][] = $note;
		}

		return $baseline;
	}

	/**
	 * System prompt: a strict, bounded JSON judgment.
	 *
	 * @return string
	 */
	private static function system_prompt() {
		return implode(
			' ',
			[
				'You are an SEO copy reviewer. Judge ONLY the qualitative quality of a page',
				'title and meta description: clarity, how compelling they are, and keyword relevance.',
				'Do not judge length or presence — those are measured separately.',
				'Respond with STRICT JSON only, no prose, in this exact shape:',
				'{"adjustment": <integer from -15 to 15>, "notes": [{"message": <string>,',
				'"severity": "info"|"warning", "effort": "low"|"medium"|"high"}]}.',
				'"adjustment" is how many points (max ±15) the qualitative quality should shift the',
				'score. Keep notes short and actionable. Return at most 3 notes.',
			]
		);
	}

	/**
	 * User prompt: the resolved title and meta to assess.
	 *
	 * @param string $title Resolved SEO title.
	 * @param string $meta  Resolved meta description.
	 * @return string
	 */
	private static function user_prompt( $title, $meta ) {
		return wp_json_encode(
			[
				'title'            => $title,
				'meta_description' => '' !== $meta ? $meta : null,
			]
		);
	}

	/**
	 * Map a 0–100 score to the dimension band.
	 *
	 * @param int $score Score 0–100.
	 * @return string 'pass' | 'warn' | 'fail'.
	 */
	private static function band( $score ) {
		if ( $score >= 80 ) {
			return 'pass';
		}
		if ( $score >= 50 ) {
			return 'warn';
		}
		return 'fail';
	}

	/**
	 * Normalize AI "notes" into issue rows (message/severity/points/effort).
	 *
	 * @param array $response Decoded AI response.
	 * @return array[]
	 */
	private static function sanitize_notes( array $response ) {
		if ( empty( $response['notes'] ) || ! is_array( $response['notes'] ) ) {
			return [];
		}

		$allowed_sev    = [ 'info', 'warning' ];
		$allowed_effort = [ 'low', 'medium', 'high' ];
		$out            = [];

		foreach ( array_slice( $response['notes'], 0, 3 ) as $note ) {
			if ( empty( $note['message'] ) || ! is_string( $note['message'] ) ) {
				continue;
			}
			$severity = isset( $note['severity'] ) && in_array( $note['severity'], $allowed_sev, true ) ? $note['severity'] : 'info';
			$effort   = isset( $note['effort'] ) && in_array( $note['effort'], $allowed_effort, true ) ? $note['effort'] : 'low';

			$out[] = [
				'message'  => sanitize_text_field( $note['message'] ),
				'severity' => $severity,
				'points'   => 0,
				'effort'   => $effort,
			];
		}

		return $out;
	}
}
