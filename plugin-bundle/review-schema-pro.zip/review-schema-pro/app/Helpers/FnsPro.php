<?php

namespace Rtrsp\Helpers;

class FnsPro {

	/**
	 * @return mixed|null
	 */
	public static function check_license() {
		return apply_filters( 'rtrs_check_license', true );
	}
	/**
	 * Get product pricing with cache support.
	 *
	 * @param int $product_id The product ID.
	 *
	 * @return array|false Pricing data or false if not found.
	 */
	public static function get_woocommerce_pricing( $product_id ) {
		$cache_key = 'rtrs_pricing_' . $product_id;

		$pricing_data = get_transient( $cache_key );

		if ( false !== $pricing_data ) {
			return $pricing_data;
		}

		$meta_key     = '_rtrs_product_pricing_offer_schema';
		$pricing_data = get_post_meta( $product_id, $meta_key, true );

		if ( empty( $pricing_data ) ) {
			return false;
		}

		set_transient( $cache_key, $pricing_data, 0 );

		return $pricing_data;
	}

	/**
	 * Build MerchantReturnPolicy schema from ecommerce settings.
	 *
	 * @return array MerchantReturnPolicy schema or empty array.
	 */
	public static function get_merchant_return_policy() {
		$category = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'return_policy_category' );
		if ( empty( $category ) ) {
			$category = 'MerchantReturnFiniteReturnWindow';
		}

		$policy = [
			'@type'                => 'MerchantReturnPolicy',
			'@id'                  => home_url( '#StandardReturnPolicy' ),
			'returnPolicyCategory' => 'https://schema.org/' . $category,
		];

		$country = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'return_policy_country' );
		if ( empty( $country ) ) {
			$country = ( function_exists( 'WC' ) && WC()->countries ) ? WC()->countries->get_base_country() : 'US';
		}
		$policy['applicableCountry'] = esc_html( $country );

		if ( 'MerchantReturnFiniteReturnWindow' === $category ) {
			$days                         = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'return_policy_days' );
			$policy['merchantReturnDays'] = ( $days !== '' && $days !== false ) ? absint( $days ) : 30;
		}

		$method = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'return_policy_method' );
		if ( empty( $method ) ) {
			$method = 'ReturnByMail';
		}
		$policy['returnMethod'] = 'https://schema.org/' . $method;

		$fees = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'return_policy_fees' );
		if ( empty( $fees ) ) {
			$fees = 'FreeReturn';
		}
		$policy['returnFees'] = 'https://schema.org/' . $fees;

		$shipping_fees_amount   = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'return_shipping_fees_amount' );
		$shipping_fees_currency = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'return_shipping_fees_currency' );
		if ( empty( $shipping_fees_currency ) ) {
			$shipping_fees_currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD';
		}

		if ( 'FreeReturn' === $fees ) {
			$policy['returnShippingFeesAmount'] = [
				'@type'    => 'MonetaryAmount',
				'value'    => 0,
				'currency' => esc_html( $shipping_fees_currency ),
			];
		} else {
			$policy['returnShippingFeesAmount'] = [
				'@type'    => 'MonetaryAmount',
				'value'    => ( $shipping_fees_amount !== '' && $shipping_fees_amount !== false ) ? floatval( $shipping_fees_amount ) : 0,
				'currency' => esc_html( $shipping_fees_currency ),
			];
		}

		$link = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'return_policy_link' );
		if ( ! empty( $link ) ) {
			$policy['merchantReturnLink'] = esc_url( $link );
		}

		return $policy;
	}

	/**
	 * Build OfferShippingDetails schema from WooCommerce shipping zones.
	 *
	 * @param string $currency The currency code.
	 *
	 * @return array Array of OfferShippingDetails or empty array.
	 */
	public static function get_offer_shipping_details( $currency ) {
		if ( ! class_exists( 'WC_Shipping_Zones' ) ) {
			return self::get_fallback_shipping_details( $currency );
		}

		$all_zones = \WC_Shipping_Zones::get_zones();

		// Include default zone 0 ("Locations not covered by your other zones").
		$default_zone = \WC_Shipping_Zones::get_zone( 0 );
		if ( $default_zone ) {
			$all_zones[0] = [
				'id'               => 0,
				'zone_name'        => $default_zone->get_zone_name(),
				'zone_locations'   => $default_zone->get_zone_locations(),
				'shipping_methods' => $default_zone->get_shipping_methods( true ),
			];
		}

		if ( empty( $all_zones ) ) {
			return [];
		}

		$ecommerce_settings = get_option( 'rtrs_schema_ecommerce_settings', [] );

		$handling_min = $ecommerce_settings['handling_time_min'] ?? null;
		$handling_max = $ecommerce_settings['handling_time_max'] ?? null;
		$transit_min  = $ecommerce_settings['transit_time_min'] ?? null;
		$transit_max  = $ecommerce_settings['transit_time_max'] ?? null;

		$handling_min = ( $handling_min !== null && $handling_min !== '' ) ? absint( $handling_min ) : 0;
		$handling_max = ( $handling_max !== null && $handling_max !== '' ) ? absint( $handling_max ) : 1;
		$transit_min  = ( $transit_min !== null && $transit_min !== '' ) ? absint( $transit_min ) : 3;
		$transit_max  = ( $transit_max !== null && $transit_max !== '' ) ? absint( $transit_max ) : 7;

		$shipping_details = [];
		$shipping_index   = 0;

		foreach ( $all_zones as $zone_data ) {
			$zone      = new \WC_Shipping_Zone( $zone_data['id'] );
			$locations = $zone->get_zone_locations();
			$methods   = $zone->get_shipping_methods( true );

			if ( empty( $methods ) ) {
				continue;
			}

			$countries = self::get_zone_countries( $locations );

			foreach ( $methods as $method ) {
				if ( 'flat_rate' === $method->id ) {
					$cost = $method->get_option( 'cost' );
					if ( is_numeric( $cost ) ) {
						$rate_value = $cost;
					} else {
						continue;
					}
				} elseif ( 'free_shipping' === $method->id ) {
					$rate_value = '0';
				} else {
					continue;
				}

				if ( ! empty( $countries ) ) {
					foreach ( $countries as $country_code ) {
						$shipping_details[] = [
							'@type'               => 'OfferShippingDetails',
							'@id'                 => home_url( '#StandardShipping-' . $shipping_index ),
							'shippingRate'        => [
								'@type'    => 'MonetaryAmount',
								'value'    => $rate_value ?? 0,
								'currency' => $currency,
							],
							'shippingDestination' => [
								'@type'          => 'DefinedRegion',
								'addressCountry' => $country_code,
							],
							'deliveryTime'        => [
								'@type'        => 'ShippingDeliveryTime',
								'handlingTime' => [
									'@type'    => 'QuantitativeValue',
									'minValue' => $handling_min,
									'maxValue' => $handling_max,
									'unitCode' => 'DAY',
								],
								'transitTime'  => [
									'@type'    => 'QuantitativeValue',
									'minValue' => $transit_min,
									'maxValue' => $transit_max,
									'unitCode' => 'DAY',
								],
							],
						];
						++$shipping_index;
					}
				} else {
					// Zone with no specific countries (e.g. "Rest of the world", "Everywhere", default zone 0).
					$shipping_details[] = [
						'@type'               => 'OfferShippingDetails',
						'@id'                 => home_url( '#StandardShipping-' . $shipping_index ),
						'shippingRate'        => [
							'@type'    => 'MonetaryAmount',
							'value'    => $rate_value ?? 0,
							'currency' => $currency,
						],
						'shippingDestination' => [
							'@type' => 'DefinedRegion',
						],
						'deliveryTime'        => [
							'@type'        => 'ShippingDeliveryTime',
							'handlingTime' => [
								'@type'    => 'QuantitativeValue',
								'minValue' => $handling_min,
								'maxValue' => $handling_max,
								'unitCode' => 'DAY',
							],
							'transitTime'  => [
								'@type'    => 'QuantitativeValue',
								'minValue' => $transit_min,
								'maxValue' => $transit_max,
								'unitCode' => 'DAY',
							],
						],
					];
					++$shipping_index;
				}
			}
		}

		return $shipping_details;
	}

	/**
	 * Build fallback shipping details from ecommerce settings for non-WooCommerce products.
	 *
	 * Used by FluentCart, SureCart, EDD, Download Manager, and other ecommerce plugins
	 * that do not have WooCommerce shipping zones.
	 *
	 * @param string $currency The currency code.
	 *
	 * @return array Array of OfferShippingDetails or empty array.
	 */
	private static function get_fallback_shipping_details( $currency ) {
		$ecommerce_settings = get_option( 'rtrs_schema_ecommerce_settings', [] );

		$country = $ecommerce_settings['return_policy_country'] ?? '';

		// Try FluentCart store country.
		if ( empty( $country ) && class_exists( 'FluentCart\Api\StoreSettings' ) ) {
			$store_settings = ( new \FluentCart\Api\StoreSettings() )->get();
			$country        = $store_settings['store_country'] ?? '';
		}

		if ( empty( $country ) ) {
			return [];
		}

		$handling_min = $ecommerce_settings['handling_time_min'] ?? null;
		$handling_max = $ecommerce_settings['handling_time_max'] ?? null;
		$transit_min  = $ecommerce_settings['transit_time_min'] ?? null;
		$transit_max  = $ecommerce_settings['transit_time_max'] ?? null;

		$handling_min = ( $handling_min !== null && $handling_min !== '' ) ? absint( $handling_min ) : 0;
		$handling_max = ( $handling_max !== null && $handling_max !== '' ) ? absint( $handling_max ) : 1;
		$transit_min  = ( $transit_min !== null && $transit_min !== '' ) ? absint( $transit_min ) : 3;
		$transit_max  = ( $transit_max !== null && $transit_max !== '' ) ? absint( $transit_max ) : 7;

		// Try to get shipping rate from FluentCart.
		$shipping_rate = '0.00';
		if ( defined( 'FLUENTCART_PLUGIN_PATH' ) && class_exists( 'FluentCart\App\Helpers\AddressHelper' ) ) {
			$shipping_methods = \FluentCart\App\Helpers\AddressHelper::getShippingMethods( $country );
			if ( ! empty( $shipping_methods ) && ! is_wp_error( $shipping_methods ) ) {
				$shipping_rate = number_format( (float) $shipping_methods[0]->amount, 2, '.', '' );
			}
		}

		return [
			[
				'@type'               => 'OfferShippingDetails',
				'@id'                 => home_url( '#StandardShipping-0' ),
				'shippingRate'        => [
					'@type'    => 'MonetaryAmount',
					'value'    => $shipping_rate ?? 0,
					'currency' => $currency,
				],
				'shippingDestination' => [
					'@type'          => 'DefinedRegion',
					'addressCountry' => strtoupper( $country ),
				],
				'deliveryTime'        => [
					'@type'        => 'ShippingDeliveryTime',
					'handlingTime' => [
						'@type'    => 'QuantitativeValue',
						'minValue' => $handling_min,
						'maxValue' => $handling_max,
						'unitCode' => 'DAY',
					],
					'transitTime'  => [
						'@type'    => 'QuantitativeValue',
						'minValue' => $transit_min,
						'maxValue' => $transit_max,
						'unitCode' => 'DAY',
					],
				],
			],
		];
	}

	/**
	 * Extract country codes from zone locations.
	 *
	 * Handles country, state, and continent location types.
	 *
	 * @param array $locations Zone location objects.
	 *
	 * @return array Unique country codes.
	 */
	public static function get_zone_countries( $locations ) {
		$countries = [];

		foreach ( $locations as $location ) {
			switch ( $location->type ) {
				case 'country':
					$countries[] = $location->code;
					break;
				case 'state':
					$parts = explode( ':', $location->code );
					if ( ! empty( $parts[0] ) ) {
						$countries[] = $parts[0];
					}
					break;
				case 'continent':
					if ( function_exists( 'WC' ) && isset( WC()->countries ) ) {
						$continent_countries = WC()->countries->get_continent_countries( $location->code );
						if ( ! empty( $continent_countries ) ) {
							$countries = array_merge( $countries, $continent_countries );
						}
					}
					break;
			}
		}

		return array_unique( $countries );
	}

	/**
	 * Convert a Product schema into ProductGroup with hasVariant.
	 *
	 * Used as a filter callback for 'rtrs_ai_convert_product_group'.
	 *
	 * @param array  $schema     Product schema.
	 * @param array  $variations Variation data with 'varies_by' and 'items'.
	 * @param array  $primary    Primary payload data.
	 * @param string $entity_id  Entity @id for seller reference.
	 *
	 * @return array Modified schema (ProductGroup).
	 */
	public static function convert_to_product_group( $schema, $variations, $primary, $entity_id ) {
		$varies_by_items = $variations['varies_by'] ?? [];
		$variant_items   = $variations['items'] ?? [];

		if ( empty( $variant_items ) ) {
			return $schema;
		}

		// Change type and @id.
		$schema['@type'] = 'ProductGroup';
		if ( ! empty( $schema['@id'] ) ) {
			$schema['@id'] = str_replace( '#product', '#productgroup', $schema['@id'] );
		}

		// ProductGroup ID from SKU or post slug.
		if ( empty( $schema['productGroupID'] ) ) {
			$schema['productGroupID'] = ! empty( $schema['sku'] ) ? $schema['sku'] : sanitize_title( $primary['title'] ?? '' );
		}

		// Map attribute labels to schema.org URLs for variesBy.
		$attr_url_map = [
			'color'    => 'https://schema.org/color',
			'colour'   => 'https://schema.org/color',
			'size'     => 'https://schema.org/size',
			'material' => 'https://schema.org/material',
			'pattern'  => 'https://schema.org/pattern',
		];

		$varies_by_urls = [];
		foreach ( $varies_by_items as $label ) {
			$lower            = strtolower( $label );
			$varies_by_urls[] = $attr_url_map[ $lower ] ?? 'https://schema.org/additionalProperty';
		}
		$schema['variesBy'] = array_values( array_unique( $varies_by_urls ) );

		// Remove parent-level offers (each variant gets its own).
		unset( $schema['offers'] );

		// Remove parent-level variant-specific attributes.
		unset( $schema['color'], $schema['size'], $schema['material'], $schema['pattern'] );

		// Parent-level fallbacks for variants.
		$parent_image = $schema['image'] ?? null;
		$parent_desc  = $schema['description'] ?? '';
		$product_url  = $primary['permalink'] ?? '';
		$seller       = [ '@id' => $entity_id ];

		// Build return policy and shipping @id references for variant offers.
		$return_policy_ref = [];
		$shipping_refs     = [];

		$return_policy = self::get_merchant_return_policy();
		if ( ! empty( $return_policy['@id'] ) ) {
			$return_policy_ref = [ '@id' => $return_policy['@id'] ];
		}

		$variant_currency = $primary['currency'] ?? ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD' );
		$shipping_details = self::get_offer_shipping_details( $variant_currency );
		if ( ! empty( $shipping_details ) ) {
			foreach ( $shipping_details as $sd ) {
				if ( ! empty( $sd['@id'] ) ) {
					$shipping_refs[] = [ '@id' => $sd['@id'] ];
				}
			}
		}

		// Schema.org property mapping for variant attributes.
		$attr_prop_map = [
			'color'    => 'color',
			'colour'   => 'color',
			'size'     => 'size',
			'material' => 'material',
			'pattern'  => 'pattern',
		];

		// Build hasVariant array.
		$has_variant = [];
		$parent_name = $primary['title'] ?? '';

		foreach ( $variant_items as $item ) {
			$variant = [
				'@type' => 'Product',
			];

			if ( ! empty( $item['sku'] ) ) {
				$variant['sku'] = $item['sku'];
			}

			// Variant name format: "Product Name - Variant Name" (e.g., "T-Shirt - Large, Red").
			if ( ! empty( $item['name'] ) ) {
				// Combine parent name with item's own name.
				$variant['name'] = $parent_name ? $parent_name . ' - ' . $item['name'] : $item['name'];
			} elseif ( ! empty( $item['attributes'] ) && is_array( $item['attributes'] ) ) {
				// Build name from parent + attribute values (e.g., "T-Shirt - Large, Red").
				$attr_values    = array_values( $item['attributes'] );
				$variant_suffix = implode( ', ', $attr_values );
				$variant['name'] = $parent_name ? $parent_name . ' - ' . $variant_suffix : $variant_suffix;
			} elseif ( ! empty( $item['sku'] ) ) {
				// Fallback to parent + SKU if no name or attributes.
				$variant['name'] = $parent_name ? $parent_name . ' - ' . $item['sku'] : $item['sku'];
			} elseif ( $parent_name ) {
				// Last resort: just use parent name.
				$variant['name'] = $parent_name;
			}

			// Variant description: use variation's own, or build from parent + attributes.
			if ( ! empty( $item['description'] ) ) {
				$variant['description'] = $item['description'];
			} elseif ( $parent_desc ) {
				$attr_parts = [];
				if ( ! empty( $item['attributes'] ) && is_array( $item['attributes'] ) ) {
					foreach ( $item['attributes'] as $attr_label => $attr_value ) {
						$attr_parts[] = $attr_label . ': ' . $attr_value;
					}
				}
				$variant['description'] = $attr_parts
					? $parent_desc . ' - ' . implode( ', ', $attr_parts )
					: $parent_desc;
			}

			// Map variant attributes to schema.org properties.
			if ( ! empty( $item['attributes'] ) && is_array( $item['attributes'] ) ) {
				foreach ( $item['attributes'] as $attr_label => $attr_value ) {
					$lower = strtolower( $attr_label );
					if ( isset( $attr_prop_map[ $lower ] ) ) {
						$variant[ $attr_prop_map[ $lower ] ] = $attr_value;
					}
				}
			}

			// Variant image or parent fallback.
			if ( ! empty( $item['image'] ) ) {
				$variant['image'] = $item['image'];
			} elseif ( $parent_image ) {
				$variant['image'] = $parent_image;
			}

			// Build individual Offer for this variant.
			$price    = $item['price'] ?? $item['regular_price'] ?? '';
			$currency = $item['currency'] ?? 'USD';

			if ( '' !== $price ) {
				$offer = [
					'@type'         => 'Offer',
					'price'         => $price,
					'priceCurrency' => $currency,
					'url'           => $product_url,
					'seller'        => $seller,
				];

				if ( ! empty( $item['availability'] ) ) {
					$offer['availability'] = $item['availability'];
				}

				if ( ! empty( $return_policy_ref ) ) {
					$offer['hasMerchantReturnPolicy'] = $return_policy_ref;
				}

				if ( ! empty( $shipping_refs ) ) {
					$offer['shippingDetails'] = $shipping_refs;
				}

				$variant['offers'] = $offer;
			}

			$has_variant[] = $variant;
		}

		$schema['hasVariant'] = $has_variant;

		return $schema;
	}
}
