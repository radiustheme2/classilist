<?php
/**
 * Pro Course Extractor - Course data extraction and schema filling (Pro feature).
 *
 * Hooks into the free plugin's `rtrs_ai_extract_course_data`,
 * `rtrs_ai_fill_course_schema`, and `rtrs_ai_type_template` filters.
 *
 * @package Rtrsp\AI
 * @since   1.0.0
 */

namespace Rtrsp\AI;

use Rtrs\AI\ContentExtractor;

defined( 'ABSPATH' ) || exit;

class ProCourseExtractor {

	/**
	 * Extract course data (Pro feature).
	 *
	 * Supports Tutor LMS and LearnPress.
	 *
	 * @param null     $default Default null from free plugin.
	 * @param \WP_Post $post    Post object.
	 *
	 * @return array|null Course data or null.
	 */
	public static function extract_course_data( $default, $post ) {
		$extractor = new ContentExtractor();
		$extractor->set_post( $post );

		if ( 'courses' === $post->post_type && function_exists( 'tutor_utils' ) ) {
			return $extractor->extract_tutor_course_data();
		}

		if ( 'lp_course' === $post->post_type && function_exists( 'learn_press_get_course' ) ) {
			return $extractor->extract_learnpress_course_data();
		}

		return $default;
	}

	/**
	 * Get Course AI prompt template.
	 *
	 * @param string $template    Existing template (empty for pro-gated types).
	 * @param string $type        Schema type name.
	 * @param string $entity_type Entity type (Organization/Person).
	 *
	 * @return string Template string.
	 */
	public static function get_course_template( $template, $type, $entity_type ) {
		if ( 'Course' !== $type ) {
			return $template;
		}

		$entity_frag = ( 'Person' === $entity_type ) ? 'person' : 'organization';

		return <<<TPL
Required fields for Course:
- name, description
- provider: {"@id": "{site_url}/#{$entity_frag}"} (reference to global entity — do NOT inline Organization)
- educationalLevel (if determinable)
- offers (Offer with price, priceCurrency — if course has pricing data)
- aggregateRating (if reviews exist)
TPL;
	}

	/**
	 * Fill missing Course schema fields from extracted course data.
	 *
	 * @param array  $schema    The Course schema node.
	 * @param array  $primary   Primary content signals.
	 * @param array  $secondary Secondary content signals.
	 * @param string $permalink Post permalink.
	 * @param string $entity_id Entity @id reference.
	 *
	 * @return array Modified schema.
	 */
	public static function fill_course_schema( $schema, $primary, $secondary, $permalink, $entity_id = '' ) {
		$tutor = $secondary['tutor_course'] ?? [];

		if ( empty( $schema['name'] ) && ! empty( $primary['title'] ) ) {
			$schema['name'] = $primary['title'];
		}

		if ( empty( $schema['description'] ) && ! empty( $primary['excerpt'] ) ) {
			$schema['description'] = mb_substr( $primary['excerpt'], 0, 200 );
		}

		if ( empty( $schema['url'] ) && ! empty( $primary['permalink'] ) ) {
			$schema['url'] = $primary['permalink'];
		}

		if ( empty( $schema['image'] ) && ! empty( $primary['featured_image']['url'] ) ) {
			$fi              = $primary['featured_image'];
			$schema['image'] = array_filter( [
				'@type'  => 'ImageObject',
				'url'    => $fi['url'],
				'width'  => $fi['width'] ?? null,
				'height' => $fi['height'] ?? null,
			] );
		}

		if ( empty( $schema['provider'] ) && $entity_id ) {
			$schema['provider'] = [ '@id' => $entity_id ];
		}

		if ( empty( $tutor ) ) {
			return $schema;
		}

		// Instructor as author.
		if ( empty( $schema['author'] ) && ! empty( $tutor['instructor']['name'] ) ) {
			$author = [ '@type' => 'Person', 'name' => $tutor['instructor']['name'] ];
			if ( ! empty( $tutor['instructor']['url'] ) ) {
				$author['url'] = $tutor['instructor']['url'];
			}
			$schema['author'] = $author;
		}

		// Course level → educationalLevel.
		if ( empty( $schema['educationalLevel'] ) && ! empty( $tutor['level'] ) ) {
			$level_map = [
				'all_levels'   => 'Beginner',
				'beginner'     => 'Beginner',
				'intermediate' => 'Intermediate',
				'expert'       => 'Advanced',
			];
			$schema['educationalLevel'] = $level_map[ $tutor['level'] ] ?? ucfirst( $tutor['level'] );
		}

		// Duration → timeRequired (ISO 8601).
		if ( empty( $schema['timeRequired'] ) && ! empty( $tutor['duration'] ) ) {
			$dur = $tutor['duration'];
			if ( is_array( $dur ) ) {
				$h = (int) ( $dur['hours'] ?? 0 );
				$m = (int) ( $dur['minutes'] ?? 0 );
				$s = (int) ( $dur['seconds'] ?? 0 );
				if ( $h > 0 || $m > 0 || $s > 0 ) {
					$iso = 'PT';
					if ( $h > 0 ) {
						$iso .= $h . 'H';
					}
					if ( $m > 0 ) {
						$iso .= $m . 'M';
					}
					if ( $s > 0 ) {
						$iso .= $s . 'S';
					}
					$schema['timeRequired'] = $iso;
				}
			}
		}

		// Price → offers.
		if ( empty( $schema['offers'] ) ) {
			if ( 'free' === ( $tutor['price_type'] ?? '' ) ) {
				$schema['offers'] = [
					[
						'@type'         => 'Offer',
						'price'         => '0',
						'priceCurrency' => 'USD',
						'availability'  => 'https://schema.org/InStock',
						'url'           => $permalink,
						'category'      => 'Free',
					],
				];
			} elseif ( ! empty( $tutor['price'] ) ) {
				$offer = [
					'@type'         => 'Offer',
					'price'         => $tutor['price'],
					'priceCurrency' => $tutor['currency'] ?: 'USD',
					'availability'  => 'https://schema.org/InStock',
					'url'           => $permalink,
				];

				// LearnPress sale price support.
				if ( ! empty( $tutor['sale_price'] ) && (float) $tutor['sale_price'] > 0 ) {
					$offer['price'] = $tutor['sale_price'];
				}

				$schema['offers'] = [ $offer ];
			}
		}

		// Number of enrolled students.
		if ( empty( $schema['totalHistoricalEnrollment'] ) && ! empty( $tutor['enrolled'] ) ) {
			$schema['totalHistoricalEnrollment'] = $tutor['enrolled'];
		}

		return $schema;
	}
}
