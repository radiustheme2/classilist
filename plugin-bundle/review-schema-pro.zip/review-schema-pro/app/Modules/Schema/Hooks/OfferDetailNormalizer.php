<?php
/**
 * Offer Detail Normalizer (Pro).
 *
 * Guarantees that every Product / ProductGroup / SoftwareApplication / Course
 * offer in the rendered @graph carries `seller` and `priceSpecification`, so
 * quality scoring credits full "Offer detail" regardless of which builder
 * produced the offer (manual, auto per e-commerce plugin, or AI).
 *
 * Runs as a single post-processing pass on both render paths:
 * - `rtrs_schema_graph_data`        — manual + auto (traditional) render.
 * - `rtrs_ai_schema_before_render`  — AI schema render.
 *
 * Every addition is guarded by empty(), so builders that already set a field
 * are never overwritten and repeated passes are idempotent.
 *
 * @package Rtrsp\Modules\Schema\Hooks
 * @since   1.2.0
 */

namespace Rtrsp\Modules\Schema\Hooks;

use Rtrsp\Traits\SingletonTrait;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class OfferDetailNormalizer
 */
class OfferDetailNormalizer {

	use SingletonTrait;

	/**
	 * Node types whose offers should be normalized.
	 *
	 * @var string[]
	 */
	private $target_types = [ 'Product', 'ProductGroup', 'SoftwareApplication', 'Course' ];

	/**
	 * Register render-time hooks.
	 *
	 * Late priorities so this runs after the per-type builders and the
	 * shipping/return and merge injectors have finished.
	 */
	public function init() {
		add_filter( 'rtrs_schema_graph_data', [ $this, 'normalize' ], 100 );
		add_filter( 'rtrs_ai_schema_before_render', [ $this, 'normalize' ], 30 );
	}

	/**
	 * Ensure seller + priceSpecification on every target offer in the graph.
	 *
	 * @param array $graph Full schema graph.
	 * @return array Modified graph.
	 */
	public function normalize( $graph ) {
		if ( empty( $graph ) || ! is_array( $graph ) ) {
			return $graph;
		}

		$seller_ref = $this->get_seller_ref();

		foreach ( $graph as &$node ) {
			if ( ! is_array( $node ) || empty( $node['@type'] ) || empty( $node['offers'] ) ) {
				continue;
			}

			$types = array_map( 'strval', (array) $node['@type'] );
			if ( ! array_intersect( $types, $this->target_types ) ) {
				continue;
			}

			if ( is_array( $node['offers'] ) ) {
				$this->normalize_offers( $node['offers'], $seller_ref );
			}
		}
		unset( $node );

		return $graph;
	}

	/**
	 * Walk an offers structure (Offer, AggregateOffer + nested, or an array).
	 *
	 * @param array      $offers     Offers data (by reference).
	 * @param array|null $seller_ref Site entity @id reference for seller.
	 */
	private function normalize_offers( &$offers, $seller_ref ) {
		$offer_type = $offers['@type'] ?? '';

		if ( 'AggregateOffer' === $offer_type ) {
			$this->normalize_single_offer( $offers, $seller_ref );

			if ( ! empty( $offers['offers'] ) && is_array( $offers['offers'] ) ) {
				foreach ( $offers['offers'] as &$nested ) {
					if ( is_array( $nested ) ) {
						$this->normalize_single_offer( $nested, $seller_ref );
					}
				}
				unset( $nested );
			}

			return;
		}

		if ( 'Offer' === $offer_type ) {
			$this->normalize_single_offer( $offers, $seller_ref );

			return;
		}

		// Array of Offer / AggregateOffer objects.
		if ( isset( $offers[0] ) ) {
			foreach ( $offers as &$offer ) {
				if ( is_array( $offer ) ) {
					$this->normalize_offers( $offer, $seller_ref );
				}
			}
			unset( $offer );
		}
	}

	/**
	 * Add seller + priceSpecification to a single offer when missing.
	 *
	 * @param array      $offer      Offer schema (by reference).
	 * @param array|null $seller_ref Site entity @id reference for seller.
	 */
	private function normalize_single_offer( &$offer, $seller_ref ) {
		if ( ! empty( $seller_ref ) && empty( $offer['seller'] ) ) {
			$offer['seller'] = $seller_ref;
		}

		if ( ! empty( $offer['priceSpecification'] ) ) {
			return;
		}

		// AggregateOffer uses lowPrice; a single Offer uses price.
		$price = $offer['price'] ?? $offer['lowPrice'] ?? '';

		if ( '' === $price || ! is_numeric( $price ) ) {
			return;
		}

		$spec = [
			'@type' => 'UnitPriceSpecification',
			'price' => $price,
		];

		if ( ! empty( $offer['priceCurrency'] ) ) {
			$spec['priceCurrency'] = $offer['priceCurrency'];
		}

		$offer['priceSpecification'] = $spec;
	}

	/**
	 * Build the seller reference to the site entity node.
	 *
	 * Mirrors Schema::get_site_schema_id() so the @id matches the global
	 * Organization / LocalBusiness node already present in the graph.
	 *
	 * @return array { '@id': string }
	 */
	private function get_seller_ref() {
		$settings      = get_option( 'rtrs_schema_settings', [] );
		$site_category = ! empty( $settings['site_category'] ) ? $settings['site_category'] : 'localBusiness';

		return [ '@id' => home_url( '#' . strtolower( $site_category ) ) ];
	}
}
