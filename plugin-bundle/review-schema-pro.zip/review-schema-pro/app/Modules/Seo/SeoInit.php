<?php
/**
 * SEO / AEO / GEO Initialization Handler (Pro)
 *
 * Bootstraps the Pro additions to the SEO, AEO and GEO report channels:
 * Keyword Coverage, Page Performance, "Refine with AI", the AI suggest/apply
 * REST routes and the bounded "Verify with AI" re-score.
 *
 * Booted unconditionally from ModulesInit. These are content-analysis channels,
 * not schema output, so they must stay available when the Schema module is
 * disabled. They previously lived in SchemaInit, which meant turning Schema off
 * silently unregistered the SEO AI REST routes while the editor panel kept
 * offering the buttons that call them.
 *
 * @package Rtrsp\Modules\Seo
 */

namespace Rtrsp\Modules\Seo;

use Rtrs\Modules\Seo\Analysis\Grade;
use Rtrs\Modules\Seo\Analysis\SeoSuggestions;
use Rtrsp\Modules\Analysis\ChannelAiVerifier;
use Rtrsp\Traits\SingletonTrait;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SeoInit
 *
 * Registers the Pro SEO/AEO/GEO hooks. Singleton so repeated getInstance()
 * calls cannot double-register a filter.
 */
class SeoInit {

	/**
	 * Singleton trait.
	 */
	use SingletonTrait;

	/**
	 * SeoInit constructor.
	 *
	 * @return void
	 */
	private function __construct() {
		$this->init();
	}

	/**
	 * Register the Pro SEO/AEO/GEO hooks.
	 *
	 * @return void
	 */
	public function init() {
		// SEO report: real Keyword Coverage analysis (Pro feature; free ships it locked).
		add_filter( 'rtrs_seo_analysis', [ self::class, 'apply_keyword_coverage' ], 10, 3 );

		// SEO report: real Page Performance analysis (Pro feature; free ships it locked).
		add_filter( 'rtrs_seo_analysis', [ self::class, 'apply_page_performance' ], 11, 3 );

		// SEO report: AI "Refine with AI" (Pro feature; free ships it locked).
		add_filter( 'rtrs_seo_ai_refine', [ TitleMetaAiRefiner::class, 'refine' ], 10, 3 );

		// SEO report: AI "Apply with AI" suggest/save REST routes (Pro feature).
		SeoAiController::getInstance();

		// Channel reports: AI "Verify with AI" bounded re-score (Pro feature).
		add_filter( 'rtrs_seo_ai_verify', [ ChannelAiVerifier::class, 'verify' ], 10, 3 );
		add_filter( 'rtrs_aeo_ai_verify', [ ChannelAiVerifier::class, 'verify' ], 10, 3 );
		add_filter( 'rtrs_geo_ai_verify', [ ChannelAiVerifier::class, 'verify' ], 10, 3 );
	}

	/**
	 * Replace the free locked Keyword Coverage row with a real analysis (Pro).
	 *
	 * Computes keyword coverage from the shared AnalysisContext, unlocks the
	 * keyword_coverage criterion in the channel, recomputes the channel score and
	 * grade over the countable criteria, and merges keyword suggestions. When no
	 * focus keyword is set, the row shows a "set a focus keyword" prompt and is
	 * excluded from the aggregate.
	 *
	 * @param array                                  $channel The SEO channel object.
	 * @param int                                    $post_id Post ID.
	 * @param \Rtrs\Modules\Seo\Analysis\AnalysisContext $context Shared context.
	 * @return array
	 */
	public static function apply_keyword_coverage( $channel, $post_id, $context ) {
		if ( ! is_array( $channel ) || empty( $channel['criteria'] ) ) {
			return $channel;
		}

		$analysis = KeywordCoverageAnalyzer::analyze_context( $context );
		$pending  = empty( $analysis['has_keyword'] );

		$details     = [];
		$suggestions = [];
		foreach ( $analysis['issues'] as $issue ) {
			$message   = isset( $issue['message'] ) ? $issue['message'] : '';
			$details[] = $message;
			$points    = isset( $issue['points'] ) ? (int) $issue['points'] : 0;

			$suggestion = [
				'sev'    => isset( $issue['severity'] ) && 'critical' === $issue['severity'] ? 'high' : 'med',
				'title'  => $message,
				'body'   => '',
				'impact' => 0 !== $points ? sprintf( '+%d pts', abs( $points ) ) : '',
				'effort' => isset( $issue['effort'] ) ? ucfirst( $issue['effort'] ) : 'Low',
			];
			if ( isset( $issue['apply'] ) ) {
				$suggestion['apply'] = $issue['apply'];
			}
			$suggestions[] = $suggestion;
		}

		// Unlock + replace the keyword_coverage criterion entry.
		foreach ( $channel['criteria'] as $i => $criterion ) {
			if ( ( isset( $criterion['key'] ) ? $criterion['key'] : '' ) !== 'keyword_coverage' ) {
				continue;
			}
			$channel['criteria'][ $i ]['value']   = (int) $analysis['score'];
			$channel['criteria'][ $i ]['status']  = $analysis['score'] >= 65 ? 'ok' : 'warn';
			$channel['criteria'][ $i ]['issues']  = count( $details );
			$channel['criteria'][ $i ]['details'] = $details;
			$channel['criteria'][ $i ]['checks']  = isset( $analysis['checks'] ) ? $analysis['checks'] : [];
			$channel['criteria'][ $i ]['locked']  = false;
			$channel['criteria'][ $i ]['pending'] = $pending;
			break;
		}

		// Recompute the channel score over countable (unlocked, non-pending) criteria.
		$sum = 0;
		$wt  = 0;
		foreach ( $channel['criteria'] as $criterion ) {
			if ( ! empty( $criterion['locked'] ) || ! empty( $criterion['pending'] ) ) {
				continue;
			}
			$weight = isset( $criterion['weight'] ) ? (int) $criterion['weight'] : 0;
			$sum   += (int) $criterion['value'] * $weight;
			$wt    += $weight;
		}
		if ( $wt > 0 ) {
			$channel['score'] = (int) round( $sum / $wt );
			$channel['grade'] = Grade::from_score( $channel['score'] );
		}

		// Merge keyword suggestions (high-impact + AI-actionable first, cap 6).
		if ( ! empty( $suggestions ) ) {
			$merged                 = array_merge( isset( $channel['suggestions'] ) ? $channel['suggestions'] : [], $suggestions );
			$channel['suggestions'] = SeoSuggestions::prioritize( $merged, SeoSuggestions::CAP );
		}

		return $channel;
	}

	/**
	 * Replace the free locked Page Performance row with a real analysis (Pro).
	 *
	 * Computes content-level performance heuristics from the shared
	 * AnalysisContext, unlocks the page_performance criterion in the channel, and
	 * recomputes the channel score/grade over the countable criteria.
	 *
	 * @param array                                      $channel The SEO channel object.
	 * @param int                                        $post_id Post ID.
	 * @param \Rtrs\Modules\Seo\Analysis\AnalysisContext $context Shared context.
	 * @return array
	 */
	public static function apply_page_performance( $channel, $post_id, $context ) {
		if ( ! is_array( $channel ) || empty( $channel['criteria'] ) ) {
			return $channel;
		}

		$analysis = PagePerformanceAnalyzer::analyze_context( $context );

		$details     = [];
		$suggestions = [];
		foreach ( $analysis['issues'] as $issue ) {
			$message   = isset( $issue['message'] ) ? $issue['message'] : '';
			$details[] = $message;
			$points    = isset( $issue['points'] ) ? (int) $issue['points'] : 0;
			$items     = isset( $issue['items'] ) && is_array( $issue['items'] ) ? $issue['items'] : [];

			// Name the specific offenders (e.g. image files) so the fix is actionable.
			$body = '';
			if ( ! empty( $items ) ) {
				$shown = array_slice( $items, 0, 5 );
				$more  = count( $items ) - count( $shown );
				/* translators: %s: comma-separated list of image file names. */
				$body  = sprintf( __( 'Affected: %s', 'review-schema-pro' ), implode( ', ', $shown ) );
				if ( $more > 0 ) {
					/* translators: %d: number of additional images not listed. */
					$body .= ' ' . sprintf( __( '(+%d more)', 'review-schema-pro' ), $more );
				}
			}

			$suggestions[] = [
				'sev'    => isset( $issue['severity'] ) && 'critical' === $issue['severity'] ? 'high' : 'med',
				'title'  => $message,
				'body'   => $body,
				'impact' => 0 !== $points ? sprintf( '+%d pts', abs( $points ) ) : '',
				'effort' => isset( $issue['effort'] ) ? ucfirst( $issue['effort'] ) : 'Low',
			];
		}

		// Unlock + replace the page_performance criterion entry.
		foreach ( $channel['criteria'] as $i => $criterion ) {
			if ( ( isset( $criterion['key'] ) ? $criterion['key'] : '' ) !== 'page_performance' ) {
				continue;
			}
			$channel['criteria'][ $i ]['value']   = (int) $analysis['score'];
			$channel['criteria'][ $i ]['status']  = $analysis['score'] >= 65 ? 'ok' : 'warn';
			$channel['criteria'][ $i ]['issues']  = count( $details );
			$channel['criteria'][ $i ]['details'] = $details;
			$channel['criteria'][ $i ]['checks']  = isset( $analysis['checks'] ) ? $analysis['checks'] : [];
			$channel['criteria'][ $i ]['locked']  = false;
			break;
		}

		// Recompute the channel score over countable (unlocked, non-pending) criteria.
		$sum = 0;
		$wt  = 0;
		foreach ( $channel['criteria'] as $criterion ) {
			if ( ! empty( $criterion['locked'] ) || ! empty( $criterion['pending'] ) ) {
				continue;
			}
			$weight = isset( $criterion['weight'] ) ? (int) $criterion['weight'] : 0;
			$sum   += (int) $criterion['value'] * $weight;
			$wt    += $weight;
		}
		if ( $wt > 0 ) {
			$channel['score'] = (int) round( $sum / $wt );
			$channel['grade'] = Grade::from_score( $channel['score'] );
		}

		// Merge performance suggestions (high-impact + AI-actionable first, cap 6).
		if ( ! empty( $suggestions ) ) {
			$merged                 = array_merge( isset( $channel['suggestions'] ) ? $channel['suggestions'] : [], $suggestions );
			$channel['suggestions'] = SeoSuggestions::prioritize( $merged, SeoSuggestions::CAP );
		}

		return $channel;
	}
}
