<?php
/**
 * Subscription cancelled email to customer
 * This template can be overridden by copying it to yourtheme/classified-listing/emails/subscription-cancelled-email-to-customer.php
 *
 * @package ClassifiedListingPro/Templates/Emails
 * @version 1.0.0
 *
 * @var \Rtcl\Models\RtclEmail      $email
 * @var \RtclPro\Models\Subscription $subscription
 * @var \WP_User                     $user
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$_display_name = $user ? ( trim( $user->first_name . ' ' . $user->last_name ) ?: $user->user_login ) : '';

do_action( 'rtcl_email_header', $email ); ?>

	<p style="margin: 0 0 16px;"><?php printf( esc_html__( 'Hi %s,', 'classified-listing-pro' ), esc_html( $_display_name ) ); ?></p>
	<p style="margin: 0 0 16px;"><?php esc_html_e( 'Your subscription has been cancelled.', 'classified-listing-pro' ); ?></p>

	<?php if ( $subscription->getName() ) : ?>
		<p style="margin: 0 0 16px;">
			<strong><?php esc_html_e( 'Plan:', 'classified-listing-pro' ); ?></strong>
			<?php echo esc_html( $subscription->getName() ); ?>
		</p>
	<?php endif; ?>

	<p style="margin: 0 0 16px;"><?php esc_html_e( 'If you cancelled by mistake or have any questions, please contact us.', 'classified-listing-pro' ); ?></p>

<?php do_action( 'rtcl_email_footer', $email );
