<?php
/**
 * Cron Batch - Auto-generates AI schemas via WP-Cron.
 *
 * Processes posts one-by-one based on rtrs_ai_settings and
 * rtrs_schema_settings configuration. Tracks progress for
 * a dashboard admin notice.
 *
 * @package Rtrsp\AI
 * @since   1.0.0
 */

namespace Rtrsp\AI;

use Rtrs\AI\AIInit;
use Rtrs\AI\ContentExtractor;
use Rtrs\AI\RestApi;
use Rtrs\AI\SchemaExtractor;
use Rtrs\Helpers\Functions;
use Rtrs\Modules\Schema\Helpers\SchemaFns;

defined( 'ABSPATH' ) || exit;

class CronBatch {

	/**
	 * Cron hook name for the recurring batch event.
	 */
	const CRON_HOOK = 'rtrs_ai_batch_generate';

	/**
	 * Option key for batch progress tracking.
	 */
	const PROGRESS_OPTION = '_rtrs_ai_batch_progress';

	/**
	 * Option key to mark batch as completed (prevents re-running).
	 */
	const BATCH_DONE_OPTION = '_rtrs_ai_batch_done';

	/**
	 * Option key set when the queue could not be built because no
	 * post types are mapped + auto-generate enabled.
	 */
	const NEEDS_CONFIG_OPTION = '_rtrs_ai_batch_needs_config';

	/**
	 * Whether the notice has already been rendered in this request.
	 *
	 * @var bool
	 */
	private static $notice_rendered = false;

	/**
	 * Per-post-type queue totals from the latest build, keyed by post type slug
	 * (e.g. [ 'post' => 10, 'product' => 8 ]). Used so the progress message
	 * counts items per post type instead of across the whole batch.
	 *
	 * @var array<string,int>
	 */
	private $queue_type_totals = [];

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register_hooks() {
		add_action( self::CRON_HOOK, [ $this, 'process_next' ] );
		add_action( 'admin_notices', [ self::class, 'render_admin_notice' ] );
		add_action( 'all_admin_notices', [ self::class, 'render_admin_notice' ] );
		add_action( 'admin_init', [ $this, 'maybe_schedule' ] );

		// Handle reset link click on page load.
		add_action( 'admin_init', [ self::class, 'handle_reset_batch' ] );

		// Show success toast after reset redirect.
		add_action( 'admin_notices', [ self::class, 'render_reset_notice' ] );

		// AJAX handler for cancelling an in-progress batch from the settings UI.
		add_action( 'wp_ajax_rtrs_cancel_auto_gen', [ $this, 'handle_cancel_ajax' ] );

		// Auto-invalidate the batch whenever the Post Type Mapping settings
		// change so the count always reflects the latest configuration.
		add_action( 'update_option_rtrs_schema_post_types_settings', [ $this, 'on_post_type_settings_change' ], 10, 2 );
		add_action( 'add_option_rtrs_schema_post_types_settings', [ $this, 'on_post_type_settings_add' ], 10, 2 );
	}

	/**
	 * Invalidate the cached batch when post type mapping settings change.
	 *
	 * Deletes the progress / done / needs-config flags so the next admin_init
	 * rebuilds the queue from the freshly saved settings.
	 *
	 * @param mixed $old_value Previous option value.
	 * @param mixed $new_value New option value.
	 *
	 * @return void
	 */
	public function on_post_type_settings_change( $old_value, $new_value ) {
		if ( $old_value === $new_value ) {
			return;
		}
		$this->invalidate_batch();
	}

	/**
	 * Invalidate the cached batch when the option is created for the first time.
	 *
	 * @param string $option    Option name.
	 * @param mixed  $new_value New option value.
	 *
	 * @return void
	 */
	public function on_post_type_settings_add( $option, $new_value ) {
		unset( $option, $new_value );
		$this->invalidate_batch();
	}

	/**
	 * Clear all batch tracking options and unschedule the cron event so the
	 * next admin request can rebuild a fresh queue from current settings.
	 *
	 * @return void
	 */
	private function invalidate_batch() {
		delete_option( self::PROGRESS_OPTION );
		delete_option( self::BATCH_DONE_OPTION );
		delete_option( self::NEEDS_CONFIG_OPTION );
		wp_clear_scheduled_hook( self::CRON_HOOK );
	}

	/**
	 * AJAX: cancel the current auto-generation batch.
	 *
	 * Clears the queue, unschedules the cron event, and marks the batch as
	 * done so admin_init does not auto-restart it. The user can later click
	 * "Reset & Re-run Auto-Generation" to start a fresh batch.
	 *
	 * @return void Sends a JSON response and exits.
	 */
	public function handle_cancel_ajax() {
		$nonce = isset( $_SERVER['HTTP_X_WP_NONCE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_WP_NONCE'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, rtrs()->getNonceId() ) ) {
			wp_send_json_error( [ 'message' => esc_html__( 'Session expired. Please reload the page.', 'review-schema-pro' ) ] );
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => esc_html__( 'You do not have permission to perform this action.', 'review-schema-pro' ) ] );
		}

		wp_clear_scheduled_hook( self::CRON_HOOK );
		delete_option( self::PROGRESS_OPTION );
		delete_option( self::NEEDS_CONFIG_OPTION );
		update_option( self::BATCH_DONE_OPTION, time(), false );

		wp_send_json_success( [ 'status' => 'idle' ] );
	}

	/**
	 * Handle the reset batch link click.
	 *
	 * When the user clicks the reset link, the page reloads with
	 * ?rtrs_reset_batch=1&_wpnonce=xxx. This clears the completion
	 * flag and redirects back to the settings page.
	 *
	 * @return void
	 */
	public static function handle_reset_batch() {
		if ( empty( $_GET['rtrs_reset_batch'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		check_admin_referer( 'rtrs_reset_ai_batch' );

		delete_option( self::BATCH_DONE_OPTION );
		delete_option( self::PROGRESS_OPTION );
		delete_option( self::NEEDS_CONFIG_OPTION );
		wp_clear_scheduled_hook( self::CRON_HOOK );

		wp_safe_redirect( admin_url( 'admin.php?page=review-schema&tab=ai&rtrs_batch_reset=1#/ai' ) );
		exit;
	}

	/**
	 * Render a success toast after batch reset.
	 *
	 * @return void
	 */
	public static function render_reset_notice() {
		if ( empty( $_GET['rtrs_batch_reset'] ) ) {
			return;
		}
		?>
		<div class="notice notice-success is-dismissible rtrs-ai-reset-toast" style="border-left-color:#4f46e5;">
			<p>
				<strong><?php esc_html_e( 'SchemaEngine AI', 'review-schema-pro' ); ?></strong> —
				<?php esc_html_e( 'Auto-generation has been reset successfully. It will re-run shortly.', 'review-schema-pro' ); ?>
			</p>
		</div>
		<script>
			setTimeout( function() {
				var toast = document.querySelector( '.rtrs-ai-reset-toast' );
				if ( toast ) {
					toast.style.transition = 'opacity 0.5s';
					toast.style.opacity = '0';
					setTimeout( function() { toast.remove(); }, 500 );
				}
			}, 5000 );
		</script>
		<?php
	}

	/**
	 * Check settings and schedule or unschedule the cron event.
	 *
	 * @return void
	 */
	public function maybe_schedule() {
		$auto_generate = AIInit::getSetting( 'auto_generate' );
		$has_api_key   = AIInit::hasApiKey();
		$scheduled     = wp_next_scheduled( self::CRON_HOOK );

		if ( 'yes' === $auto_generate && $has_api_key ) {
			// Already completed once — don't re-run until user resets.
			if ( get_option( self::BATCH_DONE_OPTION ) ) {
				return;
			}

			if ( ! $scheduled ) {
				$this->start_batch();
			}
		} else {
			if ( $scheduled ) {
				wp_clear_scheduled_hook( self::CRON_HOOK );
			}
			delete_option( self::PROGRESS_OPTION );
		}
	}

	/**
	 * Initialize the batch: build the queue of post IDs and schedule cron.
	 *
	 * @return void
	 */
	private function start_batch() {
		$progress = get_option( self::PROGRESS_OPTION );

		// Already running — don't restart.
		if ( ! empty( $progress ) && ! empty( $progress['queue'] ) ) {
			if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
				wp_schedule_single_event( time() + 30, self::CRON_HOOK );
			}
			return;
		}

		$post_ids = $this->build_queue();

		if ( empty( $post_ids ) ) {
			delete_option( self::PROGRESS_OPTION );
			// Flag for the admin notice so the user knows to configure mapping.
			update_option( self::NEEDS_CONFIG_OPTION, time(), false );
			update_option( self::BATCH_DONE_OPTION, time(), false );
			return;
		}

		// Clear stale needs-config flag once we have a valid queue.
		delete_option( self::NEEDS_CONFIG_OPTION );

		$first_type = get_post_type( $post_ids[0] );

		$progress = [
			'queue'           => $post_ids,
			'total'           => count( $post_ids ),
			'completed'       => 0,
			'failed'          => 0,
			'started'         => time(),
			// Per-type totals and a running per-type processed map so the
			// progress message counts within the current post type only.
			'type_totals'     => $this->queue_type_totals,
			'type_done'       => [],
			'current_type'    => $first_type,
			// Initial label reflects the first post in the queue; it is updated
			// per item as the batch processes each post.
			'post_type_label' => self::resolve_post_type_label( $first_type ),
		];

		update_option( self::PROGRESS_OPTION, $progress, false );
		wp_schedule_single_event( time() + 10, self::CRON_HOOK );
	}

	/**
	 * Resolve the plural, human-readable label for a post type slug.
	 *
	 * @param string $post_type Post type slug (e.g. 'post', 'page', 'product').
	 *
	 * @return string Plural label (e.g. 'Posts', 'Pages', 'Products') or the slug.
	 */
	private static function resolve_post_type_label( $post_type ) {
		$object = $post_type ? get_post_type_object( $post_type ) : null;

		if ( $object && ! empty( $object->labels->name ) ) {
			return $object->labels->name;
		}

		return (string) $post_type;
	}

	/**
	 * Build the queue of post IDs that need schema generation.
	 *
	 * Only includes post types that have a schema_type selected
	 * AND auto_generate enabled in rtrs_schema_settings.
	 *
	 * Excludes posts that already have AI-generated schema data.
	 *
	 * @return array Post IDs to process.
	 */
	private function build_queue() {
		$eligible_types = [];
		$post_types     = Functions::getPostTypes( false, false );
		$settings       = SchemaFns::getPostTypeSettings();

		// Reset per-type totals for this build.
		$this->queue_type_totals = [];

		// Only honor explicit user settings — bypass any helper-level fallbacks
		// (e.g. the ecommerce auto-product mapping) so that post types the user
		// did not opt into are never queued.
		foreach ( array_keys( $post_types ) as $type_slug ) {
			$schema_type   = $settings[ $type_slug . '_schema_type' ] ?? '';
			$auto_generate = $settings[ $type_slug . '_auto_generate' ] ?? '';

			if ( empty( $schema_type ) || 'yes' !== $auto_generate ) {
				continue;
			}

			$eligible_types[] = $type_slug;
		}

		if ( empty( $eligible_types ) ) {
			return [];
		}

		// Build the queue grouped per post type so each type's items run
		// together, and record per-type totals for the progress display.
		$queue = [];

		foreach ( $eligible_types as $type_slug ) {
			$args = [
				'post_type'      => $type_slug,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_query'     => [
					'relation' => 'OR',
					[
						'key'     => AIInit::META_KEY,
						'compare' => 'NOT EXISTS',
					],
					[
						'key'     => AIInit::META_KEY,
						'value'   => '',
						'compare' => '=',
					],
				],
			];

			$query = new \WP_Query( $args );
			$ids   = $query->posts;

			if ( empty( $ids ) ) {
				continue;
			}

			$this->queue_type_totals[ $type_slug ] = count( $ids );
			$queue                                 = array_merge( $queue, $ids );
		}

		return $queue;
	}

	/**
	 * Process the next post in the queue.
	 *
	 * Runs via WP-Cron. Generates schema for one post,
	 * updates progress, and schedules the next run.
	 *
	 * @return void
	 */
	public function process_next() {
		$progress = get_option( self::PROGRESS_OPTION );

		if ( empty( $progress ) || empty( $progress['queue'] ) ) {
			// Batch complete — mark done and clean up.
			update_option( self::BATCH_DONE_OPTION, time(), false );
			delete_option( self::PROGRESS_OPTION );
			wp_clear_scheduled_hook( self::CRON_HOOK );
			return;
		}

		$post_id = array_shift( $progress['queue'] );

		// Verify the post still exists and is published.
		$post = get_post( $post_id );
		if ( ! $post || 'publish' !== $post->post_status ) {
			$progress['completed']++;
			update_option( self::PROGRESS_OPTION, $progress, false );
			$this->schedule_next( $progress );
			return;
		}

		// Reflect the post type currently being processed and count it within
		// that type's running total for the progress message.
		$post_type                           = $post->post_type;
		$progress['current_type']            = $post_type;
		$progress['post_type_label']         = self::resolve_post_type_label( $post_type );
		$progress['type_done'][ $post_type ] = ( $progress['type_done'][ $post_type ] ?? 0 ) + 1;

		// Skip if schema already exists (may have been manually generated).
		$existing = get_post_meta( $post_id, AIInit::META_KEY, true );
		if ( ! empty( $existing ) ) {
			$progress['completed']++;
			update_option( self::PROGRESS_OPTION, $progress, false );
			$this->schedule_next( $progress );
			return;
		}

		// Determine the schema type for this post type from explicit settings
		// only — skip the ecommerce fallback so disabled types are never processed.
		$settings         = SchemaFns::getPostTypeSettings();
		$setting_type_key = $settings[ $post_type . '_schema_type' ] ?? '';
		$auto_generate    = $settings[ $post_type . '_auto_generate' ] ?? '';

		if ( empty( $setting_type_key ) || 'yes' !== $auto_generate ) {
			$progress['completed']++;
			update_option( self::PROGRESS_OPTION, $progress, false );
			$this->schedule_next( $progress );
			return;
		}

		// Map setting key to Schema.org type.
		$schema_type = AIInit::SNIPPET_TO_SCHEMA_TYPE[ $setting_type_key ] ?? $setting_type_key;

		// Skip pro-gated types when Pro is not active.
		$pro_gated_types = apply_filters( 'rtrs_ai_pro_gated_types', AIInit::getProSchemaTypes() );

		if ( in_array( $schema_type, $pro_gated_types, true ) && ! function_exists( 'rtrsp' ) ) {
			$progress['completed']++;
			update_option( self::PROGRESS_OPTION, $progress, false );
			$this->schedule_next( $progress );

			return;
		}

		// Generate schema.
		$result = $this->generate_for_post( $post_id, $schema_type );

		if ( is_wp_error( $result ) ) {
			$progress['failed']++;
		} else {
			$progress['completed']++;
		}

		update_option( self::PROGRESS_OPTION, $progress, false );
		$this->schedule_next( $progress );
	}

	/**
	 * Schedule the next cron run if there are more posts.
	 *
	 * @param array $progress Current progress data.
	 *
	 * @return void
	 */
	private function schedule_next( $progress ) {
		if ( ! empty( $progress['queue'] ) ) {
			wp_schedule_single_event( time() + 30, self::CRON_HOOK );
		} else {
			// All done — mark as completed and clean up.
			update_option( self::BATCH_DONE_OPTION, time(), false );
			delete_option( self::PROGRESS_OPTION );
			wp_clear_scheduled_hook( self::CRON_HOOK );
		}
	}

	/**
	 * Generate AI schema for a single post.
	 *
	 * Follows the same pipeline as RestApi::handle_generate():
	 * ContentExtractor → SchemaClassifier → SchemaExtractor → save.
	 *
	 * @param int    $post_id     The post ID.
	 * @param string $schema_type The forced Schema.org type from settings.
	 *
	 * @return true|\WP_Error True on success, WP_Error on failure.
	 */
	private function generate_for_post( $post_id, $schema_type ) {
		$extractor = new ContentExtractor();

		// Use forced type from settings (skip classification).
		$classification = [
			'primary_type'    => $schema_type,
			'secondary_types' => [],
			'confidence'      => 100,
			'reasoning'       => __( 'Auto-generated from schema settings.', 'review-schema-pro' ),
		];

		$full_payload = $extractor->extract( $post_id );

		if ( is_wp_error( $full_payload ) ) {
			return $full_payload;
		}

		// If the post has an FAQ block or existing FAQ meta, skip AI FAQPage generation.
		$has_existing_faq = ! empty( $full_payload['structural']['has_faq_block'] )
			|| ! empty( $full_payload['structural']['has_faq_meta'] );

		if ( $has_existing_faq ) {
			if ( 'FAQPage' === $classification['primary_type'] ) {
				$classification['primary_type'] = 'Article';
			}

			$classification['secondary_types'] = array_values(
				array_filter(
					$classification['secondary_types'],
					function ( $type ) {
						return 'FAQPage' !== $type;
					}
				)
			);
		}

		$schema_extractor = new SchemaExtractor();
		$schemas          = $schema_extractor->extract(
			$full_payload,
			$classification['primary_type'],
			$classification['secondary_types']
		);

		if ( is_wp_error( $schemas ) ) {
			return $schemas;
		}

		if ( empty( $schemas ) ) {
			return new \WP_Error( 'empty_schema', __( 'AI returned empty schema.', 'review-schema-pro' ) );
		}

		// When existing FAQ meta data exists, build FAQPage schema from it
		// instead of AI-generating it — reuses the manually curated FAQ data.
		if ( $has_existing_faq && ! empty( $full_payload['structural']['has_faq_meta'] ) ) {
			$faq_schema = RestApi::build_faqpage_from_meta( $post_id );
			if ( $faq_schema ) {
				$schemas[] = $faq_schema;
			}
		}

		// Filter out global node types before saving.
		$always_global = [ 'WebPage', 'WebSite', 'BreadcrumbList', 'Organization', 'Person' ];
		$entity_id     = AIInit::getEntityData()['entity_id'];

		$content_schemas = array_values(
			array_filter(
				$schemas,
				function ( $s ) use ( $always_global, $entity_id ) {
					if ( in_array( $s['@type'] ?? '', $always_global, true ) ) {
						return false;
					}
					if ( ! empty( $s['@id'] ) && preg_match( '/#(organization|person)$/i', $s['@id'] ) ) {
						return false;
					}
					return true;
				}
			)
		);

		if ( empty( $content_schemas ) ) {
			return new \WP_Error( 'no_content_schema', __( 'No content schemas generated.', 'review-schema-pro' ) );
		}

		// Extract FAQPage mainEntity and strip from saved schemas.
		$faq_main_entity = null;
		$content_schemas = array_values(
			array_filter(
				$content_schemas,
				function ( $s ) use ( &$faq_main_entity ) {
					if ( 'FAQPage' === ( $s['@type'] ?? '' ) && ! empty( $s['mainEntity'] ) ) {
						$faq_main_entity = $s['mainEntity'];
						return false;
					}
					return true;
				}
			)
		);

		// Save to post meta.
		// wp_slash() counteracts the wp_unslash() inside update_post_meta().
		update_post_meta(
			$post_id,
			AIInit::META_KEY,
			wp_slash( wp_json_encode( $content_schemas, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) )
		);

		// Sync AI-generated FAQ data to dedicated meta.
		if ( $faq_main_entity ) {
			$faq_data = [];
			$entities = isset( $faq_main_entity['@type'] ) ? [ $faq_main_entity ] : $faq_main_entity;
			foreach ( $entities as $entity ) {
				if ( ( $entity['@type'] ?? '' ) === 'Question'
					&& ! empty( $entity['name'] )
					&& ! empty( $entity['acceptedAnswer']['text'] )
				) {
					$faq_data[] = [
						'question' => sanitize_text_field( $entity['name'] ),
						'answer'   => sanitize_textarea_field( $entity['acceptedAnswer']['text'] ),
					];
				}
			}
			if ( ! empty( $faq_data ) ) {
				update_post_meta( $post_id, '_rtrs_faqpage_data', $faq_data );
			}
		}

		update_post_meta( $post_id, AIInit::TYPE_META_KEY, sanitize_text_field( $schema_type ) );
		update_post_meta( $post_id, AIInit::CONFIDENCE_META_KEY, 100 );
		wp_cache_delete( "rtrs_ai_schemas_{$post_id}", 'rtrs_ai' );

		return true;
	}

	/**
	 * Render admin notice showing batch generation progress.
	 *
	 * Only displays when a batch is actively running.
	 * Static method so it works reliably regardless of object lifecycle.
	 *
	 * @return void
	 */
	public static function render_admin_notice() {
		if ( self::$notice_rendered ) {
			return;
		}

		$progress = get_option( self::PROGRESS_OPTION );

		// No active batch — show the "needs configuration" notice if applicable.
		if ( empty( $progress ) || empty( $progress['total'] ) ) {
			if ( get_option( self::NEEDS_CONFIG_OPTION ) ) {
				self::$notice_rendered = true;
				$settings_url          = admin_url( 'admin.php?page=review-schema&tab=schema#/schema/post-types' );
				?>
				<div class="notice notice-warning is-dismissible" style="border-left-color:#e37400;">
					<p>
						<strong><?php esc_html_e( 'SchemaEngine AI - Auto-Generation', 'review-schema-pro' ); ?></strong>
					</p>
					<p>
						<?php esc_html_e( 'No post types are configured for auto-generation. Total count is 0.', 'review-schema-pro' ); ?>
					</p>
					<p>
						<?php esc_html_e( 'Please map post types properly (select a Schema Type and enable Auto-Generate), then re-run.', 'review-schema-pro' ); ?>
						&nbsp;
						<a href="<?php echo esc_url( $settings_url ); ?>">
							<?php esc_html_e( 'Open Post Type Mapping', 'review-schema-pro' ); ?>
						</a>
					</p>
				</div>
				<?php
			}
			return;
		}

		self::$notice_rendered = true;

		$total     = (int) $progress['total'];
		$completed = (int) ( $progress['completed'] ?? 0 );
		$failed    = (int) ( $progress['failed'] ?? 0 );
		$remaining = count( $progress['queue'] ?? [] );

		// Count within the post type currently being processed, falling back to
		// the overall batch totals for legacy batches without per-type data.
		$current_type    = $progress['current_type'] ?? '';
		$type_total      = ( $current_type && isset( $progress['type_totals'][ $current_type ] ) ) ? (int) $progress['type_totals'][ $current_type ] : $total;
		$processed       = ( $current_type && isset( $progress['type_done'][ $current_type ] ) ) ? (int) $progress['type_done'][ $current_type ] : ( $completed + $failed );
		$percent         = $type_total > 0 ? round( ( $processed / $type_total ) * 100 ) : 0;
		$post_type_label = ! empty( $progress['post_type_label'] ) ? $progress['post_type_label'] : esc_html__( 'Items', 'review-schema-pro' );

		// Summary of post types already fully processed (e.g. "10 Posts"), kept
		// visible after the batch moves on to the next type.
		$completed_types = [];
		$type_totals     = isset( $progress['type_totals'] ) && is_array( $progress['type_totals'] ) ? $progress['type_totals'] : [];
		$type_done_map   = isset( $progress['type_done'] ) && is_array( $progress['type_done'] ) ? $progress['type_done'] : [];

		foreach ( $type_totals as $type_slug => $type_count ) {
			$type_count = (int) $type_count;
			$done_count = (int) ( $type_done_map[ $type_slug ] ?? 0 );

			if ( $type_count > 0 && $done_count >= $type_count ) {
				/* translators: 1: processed count, 2: post type label */
				$completed_types[] = sprintf( '%d %s', $done_count, self::resolve_post_type_label( $type_slug ) );
			}
		}

		?>
		<div class="notice notice-info rtrs-ai-batch-notice" style="border-left-color: #4f46e5;">
			<p>
				<strong><?php esc_html_e( 'SchemaEngine AI - Auto-Generation', 'review-schema-pro' ); ?></strong>
			</p>
			<p>
				<?php
				printf(
					/* translators: 1: processed count, 2: total count for the current post type, 3: post type label, 4: percentage */
					esc_html__( 'Generating Schemas: %1$d of %2$d %3$s Processed (%4$d%%)', 'review-schema-pro' ),
					$processed,
					$type_total,
					esc_html( $post_type_label ),
					$percent
				);

				if ( $failed > 0 ) {
					printf(
						/* translators: %d: failed count */
						' — ' . esc_html__( '%d failed', 'review-schema-pro' ),
						$failed
					);
				}
				?>
			</p>
			<?php if ( ! empty( $completed_types ) ) : ?>
				<p style="color:#15803d;margin:0 0 8px;">
					<?php
					$completed_labels = array_map(
						function ( $entry ) {
							/* translators: %s: "<count> <post type>" e.g. "10 Posts" */
							return sprintf( esc_html__( '%s done', 'review-schema-pro' ), $entry );
						},
						$completed_types
					);
					echo esc_html( implode( ' · ', $completed_labels ) );
					?>
				</p>
			<?php endif; ?>
			<div style="background:#e5e5e5;border-radius:3px;height:20px;width:100%;max-width:400px;margin:5px 0 10px;">
				<div style="background:#4f46e5;border-radius:3px;height:20px;width:<?php echo esc_attr( $percent ); ?>%;transition:width 0.3s;"></div>
			</div>
		</div>
		<?php
	}
}
