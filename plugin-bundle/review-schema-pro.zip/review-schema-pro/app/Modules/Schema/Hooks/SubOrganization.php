<?php
/**
 * Sub-organization schema (Pro).
 *
 * Owns the "Schema → Sub Organization" settings section and adds the
 * `subOrganization` list to the site Organization / LocalBusiness entity.
 *
 * Settings live in the existing `rtrs_schema_sub_organization_settings`
 * option, so values saved by earlier versions keep working. The property is
 * assigned (never appended) on the free plugin's `rtseo_site_schema` filter,
 * which feeds both the AI and the traditional render paths, so the site
 * entity always carries a single subOrganization list.
 *
 * @package Rtrsp\Modules\Schema\Hooks
 */

namespace Rtrsp\Modules\Schema\Hooks;

use Rtrsp\Traits\SingletonTrait;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SubOrganization
 */
class SubOrganization {

	use SingletonTrait;

	/**
	 * Option holding the sub-organization list.
	 */
	const OPTION = 'rtrs_schema_sub_organization_settings';

	/**
	 * Settings sub-section key (Schema tab).
	 */
	const SECTION = 'sub_organization';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function init() {
		add_filter( 'rtseo_site_schema', [ $this, 'add_sub_organization' ], 10, 2 );
		add_filter( 'rtrs_schema_sub_sections', [ $this, 'register_section' ] );
		add_filter( 'rtrs_settings_all_option_fields', [ $this, 'register_fields' ] );
		add_filter( 'rtrs_settings_api_sanitized_fields_rtrs_schema_sub_organization_settings', [ $this, 'sanitize_settings' ] );
	}

	/**
	 * Add `subOrganization` to the site Organization / LocalBusiness entity.
	 *
	 * @param array|mixed $site_schema Site entity node.
	 * @param array|mixed $meta_data   Site Info settings (unused).
	 * @return array|mixed
	 */
	public function add_sub_organization( $site_schema, $meta_data = [] ) {
		if ( ! is_array( $site_schema ) || empty( $site_schema['@id'] ) || ! is_string( $site_schema['@id'] ) ) {
			return $site_schema;
		}

		// Sub-organizations apply to an organization entity, never to a Person site.
		if ( in_array( 'Person', (array) ( $site_schema['@type'] ?? [] ), true ) ) {
			return $site_schema;
		}

		$sub_organization = self::build( $site_schema['@id'] );
		if ( $sub_organization ) {
			$site_schema['subOrganization'] = $sub_organization;
		}

		return $site_schema;
	}

	/**
	 * Build the sub-organization nodes from the saved settings.
	 *
	 * Same node shape and @id scheme the free plugin used before this feature
	 * moved to Pro, so output is unchanged for existing sites.
	 *
	 * @param string $parent_id Site entity @id.
	 * @return array
	 */
	public static function build( $parent_id ) {
		$settings = get_option( self::OPTION );
		if ( empty( $settings[ self::SECTION ] ) || ! is_array( $settings[ self::SECTION ] ) ) {
			return [];
		}

		$nodes = [];
		foreach ( $settings[ self::SECTION ] as $index => $sub_org ) {
			if ( ! is_array( $sub_org ) || ( empty( $sub_org['name'] ) && empty( $sub_org['url'] ) ) ) {
				continue;
			}
			$nodes[] = [
				'@type' => 'Organization',
				'@id'   => $parent_id . '-suborg-' . absint( $index ),
				'name'  => self::clean( $sub_org['name'] ?? '' ),
				'url'   => self::clean( $sub_org['url'] ?? '' ),
			];
		}

		return $nodes;
	}

	/**
	 * Plain-text value for JSON-LD: tags stripped, empty → null (null keys are
	 * removed later by the free plugin's NullValueStripper).
	 *
	 * @param mixed $value Raw setting value.
	 * @return string|null
	 */
	private static function clean( $value ) {
		if ( ! is_scalar( $value ) || ( '' === (string) $value ) ) {
			return null;
		}

		return wp_strip_all_tags( stripslashes( (string) $value ) );
	}

	/**
	 * Register the "Sub Organization" section in Settings → Schema.
	 *
	 * Idempotent: the free plugin applies this filter more than once per load.
	 *
	 * @param array $sections Schema sub-sections.
	 * @return array
	 */
	public function register_section( $sections ) {
		if ( ! is_array( $sections ) || isset( $sections[ self::SECTION ] ) ) {
			return $sections;
		}

		$section = [
			self::SECTION => [
				'label'         => esc_html__( 'Sub Organization', 'review-schema-pro' ),
				'is_pro'        => false,
				'section_group' => 'IDENTITY',
				'iconHtml'      => '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="2.5" width="11" height="11" rx="1"/><path d="M5 5h2M5 8h2M5 11h2M9 5h2M9 8h2M9 11h2"/></svg>',
			],
		];

		// Keep the original position: right after "Social Profiles".
		$position = array_search( 'social_profiles', array_keys( $sections ), true );
		if ( false === $position ) {
			return $sections + $section;
		}

		return array_slice( $sections, 0, $position + 1, true ) + $section + array_slice( $sections, $position + 1, null, true );
	}

	/**
	 * Provide the section's field definitions.
	 *
	 * @param array $fields All settings fields keyed by "tab" / "tab/section".
	 * @return array
	 */
	public function register_fields( $fields ) {
		$key = 'schema/' . self::SECTION;
		if ( ! is_array( $fields ) || ! empty( $fields[ $key ] ) ) {
			return $fields;
		}

		$options = [
			'sub_organization_section' => [
				'title'       => esc_html__( 'Sub Organization', 'review-schema-pro' ),
				'description' => esc_html__( 'Provide your sub organization information to a Google Knowledge panel', 'review-schema-pro' ),
				'type'        => 'title',
			],
			self::SECTION              => [
				'type'   => 'group',
				'title'  => esc_html__( 'Sub Organization', 'review-schema-pro' ),
				'fields' => [
					'name' => [
						'type'  => 'text',
						'class' => 'regular-text',
						'title' => esc_html__( 'Name', 'review-schema-pro' ),
					],
					'url'  => [
						'type'  => 'text',
						'class' => 'regular-text',
						'title' => esc_html__( 'URL', 'review-schema-pro' ),
					],
				],
			],
		];

		/**
		 * Filter the Sub Organization settings fields.
		 *
		 * @param array $options Field definitions.
		 */
		$fields[ $key ] = apply_filters( 'rtrs_schema_sub_organization_settings_options', $options );

		return $fields;
	}

	/**
	 * Sanitize the sub-organization settings on save.
	 *
	 * @param mixed $settings Submitted settings.
	 * @return array
	 */
	public function sanitize_settings( $settings ) {
		$rows = [];
		if ( is_array( $settings ) && ! empty( $settings[ self::SECTION ] ) && is_array( $settings[ self::SECTION ] ) ) {
			foreach ( $settings[ self::SECTION ] as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}
				$name   = isset( $row['name'] ) && is_scalar( $row['name'] ) ? (string) $row['name'] : '';
				$url    = isset( $row['url'] ) && is_scalar( $row['url'] ) ? (string) $row['url'] : '';
				$rows[] = [
					'name' => sanitize_text_field( wp_unslash( $name ) ),
					'url'  => esc_url_raw( wp_unslash( $url ) ),
				];
			}
		}

		return [ self::SECTION => $rows ];
	}
}
