<?php
/**
 * User verify email
 *
 * @package ClassifiedListing/Templates/Emails
 * @version 1.2.27
 *
 * @var RtclEmail $email
 * @var WP_User   $user
 * @var string    $verify_link
 */

use Rtcl\Helpers\Functions;
use Rtcl\Models\RtclEmail;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @hooked RtclEmails::email_header() Output the email header
 */
$_display_name = trim( $user->first_name . ' ' . $user->last_name ) ?: $user->user_login;

do_action( 'rtcl_email_header', $email ); ?>

	<p style="margin: 0 0 16px;"><?php /* translators: %s: user display name */ printf( esc_html__( 'Hi %s,', 'classified-listing-pro' ), esc_html( $_display_name ) ); ?></p>
	<p style="margin: 0 0 16px;"><?php printf( __( 'Thank you for registering on our website. Please %s.', 'classified-listing-pro' ), sprintf( '<a href="%s" target="_blank">%s</a>', esc_url( $verify_link ), esc_html__( 'click here to confirm your email address', 'classified-listing-pro' ) ) ); ?></p>
	<p style="margin: 0 0 16px;"><?php esc_html_e( 'If you did not create this account, you can safely ignore this email.', 'classified-listing-pro' ); ?></p>
	<p style="margin: 0 0 16px;"><?php esc_html_e( 'Thank you.', 'classified-listing-pro' ); ?></p>

<?php
/**
 * @hooked RtclEmails::email_footer() Output the email footer
 */
do_action( 'rtcl_email_footer', $email );
