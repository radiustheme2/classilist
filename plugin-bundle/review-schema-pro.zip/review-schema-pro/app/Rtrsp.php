<?php

namespace Rtrsp;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Rtrsp\Controllers\Admin\AdminController;
use Rtrsp\Modules\ModulesInit;
use Rtrsp\Traits\SingletonTrait;

/**
 * Class Rtrsp
 */
final class Rtrsp {

	use SingletonTrait;

	/**
	 * SchemaEngine AI Constructor.
	 */
	public function __construct() {
		$this->init_hooks();
	}

	private function init_hooks() {
		add_action( 'plugins_loaded', [ $this, 'on_plugins_loaded' ], -1 );
		add_action( 'init', [ $this, 'init' ], 15 );
		add_filter( 'body_class', [ $this, 'add_body_class' ] );
	}

	/**
	 * Append the pro plugin version as a frontend body class.
	 *
	 * @param array $classes Existing body classes.
	 * @return array
	 */
	public function add_body_class( $classes ) {
		$classes[] = 'rtrs-pro-v-' . esc_attr( RTRSP_VERSION );

		return $classes;
	}

	public function init() {
		do_action( 'rtrsp_before_init' );
		$this->load_plugin_textdomain();
		ModulesInit::getInstance();
		// Load your all dependency hooks.
		AdminController::getInstance();
		do_action( 'rtrsp_init' );
	}

	public function on_plugins_loaded() {
		do_action( 'rtrsp_loaded' );
	}

	/**
	 * Load Localisation files
	 */
	public function load_plugin_textdomain() {
		// $locale = determine_locale();
		// $locale = apply_filters('rtrsp_plugin_locale', $locale, 'review-schema-pro');
		// unload_textdomain('review-schema-pro');
		// load_textdomain('review-schema-pro', WP_LANG_DIR . '/review-schema-pro/review-schema-pro-' . $locale . '.mo');
		load_plugin_textdomain( 'review-schema-pro', false, plugin_basename( dirname( RTRSP_PLUGIN_FILE ) ) . '/languages' );
	}

	/**
	 * Get the plugin path.
	 *
	 * @return string
	 */
	public function plugin_path() {
		return untrailingslashit( plugin_dir_path( RTRSP_PLUGIN_FILE ) );
	}

	/**
	 * Get the template path.
	 *
	 * @return string
	 */
	public function get_template_path() {
		return apply_filters( 'rtrsp_template_path', 'review-schema-pro/' );
	}

	/**
	 * @param $file
	 *
	 * @return string
	 */
	public function get_assets_uri( $file ) {
		$file = ltrim( $file, '/' );

		return trailingslashit( RTRSP_URL . '/assets' ) . $file;
	}
}
