<?php
/**
 * Store contact mail to store owner
 *
 * @package ClassifiedListingStore/Templates/Emails
 * @version 1.2.0
 *
 * @var array     $data
 * @var Store     $store
 * @var RtclEmail $email
 */


use Rtcl\Helpers\Link;
use Rtcl\Models\RtclEmail;
use RtclStore\Models\Store;


if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Check if lead manager gates contact info for this store owner.
$show_contact = true;
if ( class_exists( \RtclLeadManager\Helpers\Functions::class ) ) {
	$show_contact = \RtclLeadManager\Helpers\Functions::owner_has_lead_access( $store->owner_id() );
}

/**
 * @hooked RtclEmails::email_header() Output the email header
 */
do_action( 'rtcl_email_header', $email ); ?>
    <p style="margin: 0 0 16px;"><?php printf( esc_html__( 'Hi %s', 'classified-listing-store' ), esc_html( $store->owner_name() ) ); ?>,</p>
    <p style="margin: 0 0 16px;"><?php printf( esc_html__( 'You have received a reply from your store at %s.', 'classified-listing-store' ), sprintf( '<strong>%s</strong>', esc_html( $store->get_the_title() ) ) ); ?></p>
<?php if ( $show_contact ) : ?>
<?php printf( '<strong>%s</strong> %s', esc_html__( 'Name: ', 'classified-listing-store' ), esc_html( $data['name'] ) ); ?><br>
<?php printf( '<strong>%s</strong> %s', esc_html__( 'Email: ', 'classified-listing-store' ), esc_html( $data['email'] ) ); ?><br>
<?php if ( ! empty( $data['phone'] ) ) : ?>
<?php printf( '<strong>%s</strong> %s', esc_html__( 'Phone: ', 'classified-listing-store' ), esc_html( $data['phone'] ) ); ?><br>
<?php endif; ?>
<?php printf( '<strong>%s</strong><br>%s', esc_html__( 'Message: ', 'classified-listing-store' ), nl2br( esc_html( $data['message'] ) ) ); ?>
    <br>
    <br>
<?php else : ?>
    <p style="margin: 0 0 16px;"><?php esc_html_e( 'A new lead has been added to your account. Please check it from your dashboard.', 'classified-listing-store' ); ?></p>
    <p style="margin: 0 0 16px;">
        <a href="<?php echo esc_url( Link::get_account_endpoint_url( 'leads' ) ); ?>" style="display:inline-block;padding:10px 20px;background-color:#3232FF;color:#ffffff;text-decoration:none;border-radius:4px;font-size:14px;">
            <?php esc_html_e( 'View Leads Dashboard', 'classified-listing-store' ); ?>
        </a>
    </p>
<?php endif; ?>
<?php
/**
 * @hooked RtclEmails::email_footer() Output the email footer
 */
do_action( 'rtcl_email_footer', $email );
