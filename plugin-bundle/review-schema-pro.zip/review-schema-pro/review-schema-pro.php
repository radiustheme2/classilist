<?php
/**
 * @wordpress-plugin
 * Plugin Name:       SchemaEngine AI Pro
 * Plugin URI:        https://www.radiustheme.com/downloads/wordpress-review-structure-data-schema-plugin/?utm_source=WordPress&utm_medium=reviewschema&utm_campaign=pro_click
 * Description:       This is a pro version of SchemaEngine AI Plugin
 * Version:           2.1.2
 * Author:            RadiusTheme
 * Author URI:        https://radiustheme.com
 * Text Domain:       review-schema-pro
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define PLUGIN_FILE.
if ( ! defined( 'RTRSP_PLUGIN_FILE' ) ) {
	define( 'RTRSP_PLUGIN_FILE', __FILE__ );
}

// Define VERSION.
if ( ! defined( 'RTRSP_VERSION' ) ) {
	define( 'RTRSP_VERSION', '2.1.2' );
}

define( 'RTRSP_PATH', plugin_dir_path( __FILE__ ) );

// Define URL.
if ( ! defined( 'RTRSP_URL' ) ) {
	define( 'RTRSP_URL', plugins_url( '', __FILE__ ) );
}

// Define SLUG.
if ( ! defined( 'RTRSP_SLUG' ) ) {
	define( 'RTRSP_SLUG', basename( dirname( __FILE__ ) ) );
}

// Define TEMPLATE_DEBUG_MODE.
if ( ! defined( 'RTRSP_TEMPLATE_DEBUG_MODE' ) ) {
	define( 'RTRSP_TEMPLATE_DEBUG_MODE', false );
}

/**
 * Base plugin slug.
 */
define( 'RTRSP_BASE_PLUGIN', 'review-schema/review-schema.php' );

require_once RTRSP_PATH . 'vendor/autoload.php';

/**
 * Check if the base SchemaEngine AI plugin is active.
 *
 * @return bool
 */
function rtrsp_is_base_plugin_active() {
	$active_plugins = apply_filters( 'active_plugins', get_option( 'active_plugins', [] ) );

	if ( in_array( RTRSP_BASE_PLUGIN, $active_plugins, true ) ) {
		return true;
	}

	// Multisite: check network-activated plugins.
	if ( is_multisite() ) {
		$network_plugins = get_site_option( 'active_sitewide_plugins', [] );
		if ( isset( $network_plugins[ RTRSP_BASE_PLUGIN ] ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Check if the base plugin file exists (installed but maybe not active).
 *
 * @return bool
 */
function rtrsp_is_base_plugin_installed() {
	$plugin_file = WP_PLUGIN_DIR . '/' . RTRSP_BASE_PLUGIN;
	return file_exists( $plugin_file );
}

/**
 * On activation: auto-activate base plugin if installed, or block activation if not installed.
 */
register_activation_hook( RTRSP_PLUGIN_FILE, function () {
	if ( rtrsp_is_base_plugin_active() ) {
		// Base plugin already active — nothing to do.
		add_option( 'rtrsp_activation_redirect', true );
		return;
	}

	if ( rtrsp_is_base_plugin_installed() ) {
		// Base plugin is installed but not active — activate it.
		$result = activate_plugin( RTRSP_BASE_PLUGIN );

		if ( is_wp_error( $result ) ) {
			deactivate_plugins( plugin_basename( RTRSP_PLUGIN_FILE ) );
			wp_die(
				sprintf(
					/* translators: %s: error message */
					esc_html__( 'Failed to activate SchemaEngine AI: %s', 'review-schema-pro' ),
					esc_html( $result->get_error_message() )
				),
				esc_html__( 'Plugin Activation Error', 'review-schema-pro' ),
				[ 'back_link' => true ]
			);
		}

		add_option( 'rtrsp_activation_redirect', true );
		return;
	}

	// Base plugin is not installed at all — block activation.
	deactivate_plugins( plugin_basename( RTRSP_PLUGIN_FILE ) );
	wp_die(
		sprintf(
			'<strong>%s</strong> %s',
			esc_html__( 'SchemaEngine AI', 'review-schema-pro' ),
			esc_html__( 'plugin must be installed and activated before activating SchemaEngine AI Pro.', 'review-schema-pro' )
		),
		esc_html__( 'Plugin Activation Error', 'review-schema-pro' ),
		[ 'back_link' => true ]
	);
} );

/**
 * Runtime dependency guard.
 *
 * The pro plugin bootstraps from the `rtrs_ai_loaded` action the free plugin
 * fires, so it never initialises — and never fatals — when the free plugin is
 * absent. We therefore only warn the admin, and we gate that warning on whether
 * the free plugin's CODE is actually loaded (a stable class/function) rather
 * than on the active_plugins option / plugin folder path. The path-based check
 * misfired when the free plugin lived under a non-standard folder name, was
 * symlinked, or loaded as an mu-plugin — showing a false "not working" notice
 * and deactivating pro even though everything was working.
 */
add_action( 'admin_notices', function () {
	// Free plugin code is present — nothing to warn about.
	if ( function_exists( 'rtrs' ) || class_exists( '\Rtrs\Helpers\Functions' ) ) {
		return;
	}

	printf(
		'<div class="notice notice-error"><p><a target="_blank" href="%1$s"><strong>SchemaEngine AI Pro</strong></a> is not working because the <strong>%2$s</strong> plugin is not active. Install and activate it to enable pro features.</p></div>',
		esc_url( 'https://www.radiustheme.com/downloads/review-schema' ),
		esc_html__( 'SchemaEngine AI', 'review-schema-pro' )
	);
} );

use Rtrsp\Rtrsp;

/**
 * SchemaEngine AI Pro.
 *
 * @return bool|SingletonTrait|Rtrsp
 */
function rtrsp() {
	return Rtrsp::getInstance();
}

add_action( 'rtrs_ai_loaded', function () {
	rtrsp(); // Run Rtrsp Plugin.
} );

// Redirect to settings page after activation.
class RtrspActivation {
	public function __construct() {
		add_action( 'admin_init', [ $this, 'plugin_redirect' ] );
	}

	public function plugin_redirect() {
		if ( get_option( 'rtrsp_activation_redirect', false ) ) {
			delete_option( 'rtrsp_activation_redirect' );
			wp_redirect( admin_url( 'admin.php?page=review-schema#/tools' ) );
		}
	}
}
new RtrspActivation();

