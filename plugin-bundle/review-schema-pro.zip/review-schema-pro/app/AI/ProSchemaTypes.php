<?php
/**
 * Pro Schema Types - Templates and validation for pro-gated schema types.
 *
 * Provides AI prompt templates and validation for: Book, JobPosting, Recipe,
 * LocalBusiness, Restaurant, Product, ProductGroup, Course.
 *
 * @package Rtrsp\AI
 * @since   1.0.0
 */

namespace Rtrsp\AI;

use Rtrs\AI\SchemaValidator;

defined( 'ABSPATH' ) || exit;

class ProSchemaTypes {

	/**
	 * Provide AI prompt templates for pro-gated schema types.
	 *
	 * Hooked to `rtrs_ai_type_template` filter.
	 *
	 * @param string $template    Existing template.
	 * @param string $type        Schema type name.
	 * @param string $entity_type Entity type (Organization/Person).
	 *
	 * @return string Template string.
	 */
	public static function get_type_template( $template, $type, $entity_type ) {
		if ( '' !== $template ) {
			return $template;
		}

		switch ( $type ) {
			case 'Recipe':
				return self::get_recipe_template();

			case 'LocalBusiness':
			case 'Restaurant':
				return self::get_local_business_template();

			case 'Book':
				return self::get_book_template();

			case 'JobPosting':
				return self::get_job_posting_template();
		}

		return $template;
	}

	/**
	 * Validate pro-gated schema types.
	 *
	 * Hooked to `rtrs_ai_validate_schema_type` action.
	 *
	 * @param string          $type      Schema @type.
	 * @param array           $schema    Schema data.
	 * @param string          $prefix    Error prefix.
	 * @param SchemaValidator $validator Validator instance.
	 */
	public static function validate_schema_type( $type, $schema, $prefix, $validator ) {
		switch ( $type ) {
			case 'Product':
				self::validate_product( $schema, $prefix, $validator );
				break;

			case 'ProductGroup':
				self::validate_productgroup( $schema, $prefix, $validator );
				break;

			case 'Recipe':
				self::validate_recipe( $schema, $prefix, $validator );
				break;

			case 'Course':
				self::validate_course( $schema, $prefix, $validator );
				break;

			case 'LocalBusiness':
			case 'Restaurant':
				self::validate_localbusiness( $schema, $prefix, $validator );
				break;

			case 'TouristAttraction':
				self::validate_touristattraction( $schema, $prefix, $validator );
				break;
		}
	}

	// -------------------------------------------------------------------------
	// Templates
	// -------------------------------------------------------------------------

	private static function get_recipe_template() {
		return <<<TPL
Required fields for Recipe:
- name, description, image
- recipeIngredient (array of strings)
- recipeInstructions (array of HowToStep)
- prepTime, cookTime, totalTime (ISO 8601 duration)
- recipeYield, recipeCategory, recipeCuisine
- author, datePublished
TPL;
	}

	private static function get_local_business_template() {
		return <<<TPL
Required fields for LocalBusiness:
- name, description, image
- address (PostalAddress)
- telephone, email (if available)
- openingHours (if available)
- geo (latitude, longitude if available)
- priceRange (if determinable)
TPL;
	}

	private static function get_book_template() {
		return <<<TPL
Required fields for Book:
- name, description, image
- author (Person)
- isbn (if available)
- numberOfPages (if available)
- publisher, datePublished
TPL;
	}

	private static function get_job_posting_template() {
		return <<<TPL
Required fields for JobPosting:
- title, description
- datePosted, validThrough
- hiringOrganization (Organization with name)
- jobLocation (Place with address)
- employmentType (if available)
- baseSalary (if available)
TPL;
	}

	// -------------------------------------------------------------------------
	// Validators
	// -------------------------------------------------------------------------

	/**
	 * Validate Product per Google Rich Results requirements.
	 */
	private static function validate_product( $schema, $prefix, SchemaValidator $v ) {
		if ( empty( $schema['name'] ) ) {
			$v->add_error( "{$prefix}: Product missing required 'name'" );
		}

		if ( empty( $schema['image'] ) ) {
			$v->add_error( "{$prefix}: Product missing required 'image'" );
		}

		if ( empty( $schema['offers'] ) && empty( $schema['review'] ) && empty( $schema['aggregateRating'] ) ) {
			$v->add_error( "{$prefix}: Product must have 'offers', 'review', or 'aggregateRating' for rich results" );
		}

		if ( ! empty( $schema['offers'] ) ) {
			$v->validate_product_offers( $schema['offers'], $prefix );
		}

		if ( ! empty( $schema['aggregateRating'] ) ) {
			$v->validate_aggregate_rating( $schema['aggregateRating'], $prefix );
		}

		if ( ! empty( $schema['review'] ) && is_array( $schema['review'] ) ) {
			$reviews = isset( $schema['review']['@type'] ) ? [ $schema['review'] ] : $schema['review'];

			// Use a numeric counter (not the array key) so a reference object
			// like [ '@id' => '...#review' ] — which has string keys — does not
			// trigger a "string + int" TypeError. Skip non-array entries.
			$index = 0;
			foreach ( $reviews as $review ) {
				if ( ! is_array( $review ) ) {
					continue;
				}
				$v->validate_review_item( $review, $prefix, ++$index );
			}
		}

		if ( ! empty( $schema['brand'] ) && is_array( $schema['brand'] ) && empty( $schema['brand']['name'] ) ) {
			$v->add_warning( "{$prefix}: 'brand' should have a 'name' field" );
		}

		if ( empty( $schema['description'] ) ) {
			$v->add_warning( "{$prefix}: Product missing recommended 'description'" );
		}

		if ( empty( $schema['sku'] ) && empty( $schema['gtin'] ) && empty( $schema['gtin8'] )
			&& empty( $schema['gtin13'] ) && empty( $schema['gtin14'] ) && empty( $schema['mpn'] ) ) {
			$v->add_warning( "{$prefix}: Product missing identifier — 'sku', 'gtin', or 'mpn' is recommended" );
		}

		if ( empty( $schema['brand'] ) ) {
			$v->add_warning( "{$prefix}: Product missing recommended 'brand'" );
		}
	}

	/**
	 * Validate ProductGroup schema (variable product with hasVariant).
	 */
	private static function validate_productgroup( $schema, $prefix, SchemaValidator $v ) {
		if ( empty( $schema['name'] ) ) {
			$v->add_error( "{$prefix}: ProductGroup missing required 'name'" );
		}

		if ( empty( $schema['hasVariant'] ) || ! is_array( $schema['hasVariant'] ) ) {
			$v->add_error( "{$prefix}: ProductGroup missing required 'hasVariant' array" );
		} else {
			foreach ( $schema['hasVariant'] as $i => $variant ) {
				$vi = $i + 1;

				if ( empty( $variant['@type'] ) || 'Product' !== $variant['@type'] ) {
					$v->add_error( "{$prefix}: hasVariant[{$vi}] must have @type 'Product'" );
				}

				if ( empty( $variant['name'] ) ) {
					$v->add_warning( "{$prefix}: hasVariant[{$vi}] missing 'name'" );
				}

				if ( empty( $variant['offers'] ) ) {
					$v->add_warning( "{$prefix}: hasVariant[{$vi}] missing 'offers'" );
				}
			}
		}

		if ( empty( $schema['productGroupID'] ) ) {
			$v->add_warning( "{$prefix}: ProductGroup missing recommended 'productGroupID'" );
		}

		if ( empty( $schema['variesBy'] ) ) {
			$v->add_warning( "{$prefix}: ProductGroup missing recommended 'variesBy'" );
		}

		if ( empty( $schema['image'] ) ) {
			$v->add_warning( "{$prefix}: ProductGroup missing recommended 'image'" );
		}

		if ( empty( $schema['description'] ) ) {
			$v->add_warning( "{$prefix}: ProductGroup missing recommended 'description'" );
		}

		if ( empty( $schema['brand'] ) ) {
			$v->add_warning( "{$prefix}: ProductGroup missing recommended 'brand'" );
		}
	}

	/**
	 * Validate Recipe per Google Rich Results requirements.
	 */
	private static function validate_recipe( $schema, $prefix, SchemaValidator $v ) {
		foreach ( [ 'name', 'recipeIngredient', 'recipeInstructions' ] as $field ) {
			if ( empty( $schema[ $field ] ) ) {
				$v->add_error( "{$prefix}: Recipe missing required field '{$field}'" );
			}
		}

		foreach ( [ 'image', 'author', 'datePublished', 'totalTime', 'recipeYield' ] as $field ) {
			if ( empty( $schema[ $field ] ) ) {
				$v->add_warning( "{$prefix}: Recipe missing recommended field '{$field}'" );
			}
		}
	}

	/**
	 * Validate Course per Google Rich Results requirements.
	 */
	private static function validate_course( $schema, $prefix, SchemaValidator $v ) {
		foreach ( [ 'name', 'description', 'provider' ] as $field ) {
			if ( empty( $schema[ $field ] ) ) {
				$v->add_error( "{$prefix}: Course missing required field '{$field}'" );
			}
		}

		if ( ! empty( $schema['provider'] ) && is_array( $schema['provider'] ) ) {
			if ( empty( $schema['provider']['name'] ) && empty( $schema['provider']['@id'] ) ) {
				$v->add_warning( "{$prefix}: 'provider' should have a 'name' or '@id'" );
			}
		}
	}

	/**
	 * Validate LocalBusiness per Google Rich Results requirements.
	 */
	private static function validate_localbusiness( $schema, $prefix, SchemaValidator $v ) {
		foreach ( [ 'name', 'address' ] as $field ) {
			if ( empty( $schema[ $field ] ) ) {
				$v->add_error( "{$prefix}: LocalBusiness missing required field '{$field}'" );
			}
		}

		if ( ! empty( $schema['address'] ) && is_array( $schema['address'] ) ) {
			foreach ( [ 'streetAddress', 'addressLocality', 'addressCountry' ] as $addr_field ) {
				if ( empty( $schema['address'][ $addr_field ] ) ) {
					$v->add_warning( "{$prefix}: 'address.{$addr_field}' is recommended" );
				}
			}
		}
	}

	/**
	 * Validate TouristAttraction required fields.
	 */
	private static function validate_touristattraction( $schema, $prefix, SchemaValidator $v ) {
		foreach ( [ 'name', 'image', 'description', 'address' ] as $field ) {
			if ( empty( $schema[ $field ] ) ) {
				$v->add_error( "{$prefix}: TouristAttraction missing required field '{$field}'" );
			}
		}

		if ( empty( $schema['geo']['latitude'] ) ) {
			$v->add_error( "{$prefix}: TouristAttraction missing required field 'latitude'" );
		}

		if ( empty( $schema['geo']['longitude'] ) ) {
			$v->add_error( "{$prefix}: TouristAttraction missing required field 'longitude'" );
		}
	}
}
