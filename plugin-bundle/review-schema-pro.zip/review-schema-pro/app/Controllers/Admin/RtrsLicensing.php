<?php
namespace Rtrsp\Controllers\Admin;

use Rtrs\Helpers\Functions;
use Rtrsp\Helpers\FnsPro;
use Rtrsp\Models\RtrsLicense;

class RtrsLicensing {

	// Licensing variable
	private static $store_url  = 'https://www.radiustheme.com';
	private static $product_id = 152929;
	private static $author     = 'RadiusTheme';

	static function init() {
		add_action( 'admin_init', [ __CLASS__, 'license' ] );
		add_action( 'rtrs_admin_settings_saved', [ __CLASS__, 'update_licencing_status' ] );
		add_action( 'wp_ajax_rtrs_manage_licensing', [ __CLASS__, 'manage_licensing' ] );
		add_filter( 'rtrs_tools_settings_options', [ __CLASS__, 'add_tools_licensing_options' ], 15 );
	}

	public static function license() {
		if ( FnsPro::check_license() ) {
			$settings    = Functions::get_option( 'rtrs_tools_settings' );
			$license_key = ! empty( $settings['license_key'] ) ? trim( $settings['license_key'] ) : null;
			$status      = ! empty( $settings['license_status'] ) && $settings['license_status'] === 'valid';
			new RtrsLicense(
				static::$store_url,
				RTRSP_PLUGIN_FILE,
				[
					'version' => RTRSP_VERSION,
					'license' => $license_key,
					'item_id' => self::$product_id,
					'author'  => self::$author,
					'url'     => home_url(),
					'beta'    => false,
					'status'  => $status,
				]
			);
		}
	}

	public static function update_licencing_status( $action ) {
		if ( 'tools_settings' == $action ) {
			$settings    = Functions::get_option( 'rtrs_tools_settings' );
			$license_key = ! empty( $settings['license_key'] ) ? trim( $settings['license_key'] ) : null;
			$status      = ! empty( $settings['license_status'] ) && $settings['license_status'] === 'valid';
			if ( $license_key && ! $status ) {
				$api_params = [
					'edd_action' => 'activate_license',
					'license'    => $license_key,
					'item_id'    => self::$product_id,
					'url'        => home_url(),
				];
				$response   = wp_remote_post(
					self::$store_url,
					[
						'timeout'   => 15,
						'sslverify' => true,
						'body'      => $api_params,
					]
				);
				if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
					$err     = is_wp_error( $response ) ? $response->get_error_message() : '';
					$message = ! empty( $err ) ? $err : esc_html__( 'An error occurred, please try again.', 'review-schema-pro' );
				} else {
					$license_data = json_decode( wp_remote_retrieve_body( $response ) );
					if ( ! is_object( $license_data ) ) {
						$message = esc_html__( 'Invalid response from licensing server.', 'review-schema-pro' );
					} elseif ( isset( $license_data->success ) && false === $license_data->success ) {
						$error_code = isset( $license_data->error ) ? $license_data->error : '';
						switch ( $error_code ) {
							case 'expired':
								$expires = isset( $license_data->expires ) ? $license_data->expires : '';
								$message = sprintf(
									esc_html__( 'Your license key expired on %s.', 'review-schema-pro' ),
									date_i18n(
										get_option( 'date_format' ),
										strtotime( $expires, current_time( 'timestamp' ) )
									)
								);
								break;
							case 'revoked':
								$message = esc_html__( 'Your license key has been disabled.', 'review-schema-pro' );
								break;
							case 'missing':
								$message = esc_html__( 'Invalid license.', 'review-schema-pro' );
								break;
							case 'invalid':
							case 'site_inactive':
								$message = esc_html__( 'Your license is not active for this URL.', 'review-schema-pro' );
								break;
							case 'item_name_mismatch':
								$message = esc_html__( 'This appears to be an invalid license key for SchemaEngine AI Pro.', 'review-schema-pro' );
								break;
							case 'no_activations_left':
								$message = esc_html__( 'Your license key has reached its activation limit.', 'review-schema-pro' );
								break;
							default:
								$message = esc_html__( 'An error occurred, please try again.', 'review-schema-pro' );
								break;
						}
					}
					// Check if anything passed on a message constituting a failure
					if ( empty( $message ) && is_object( $license_data ) && isset( $license_data->license ) && $license_data->license === 'valid' ) {
						$settings['license_status'] = $license_data->license;
						update_option( 'rtrs_tools_settings', $settings );
					}
				}
			} elseif ( ! $license_key && ! $status ) {
				unset( $settings['license_status'] );
				update_option( 'rtrs_tools_settings', $settings );
			}
		}
	}

	public static function manage_licensing() {
		$type  = $value = $data = $message = null;
		$error = true;

		if ( ! wp_verify_nonce( Functions::get_nonce(), rtrs()->getNonceId() ) ) {
			$response = [
				'error' => true,
				'msg'   => $message,
				'type'  => $type,
				'value' => $value,
				'data'  => $data,
			];
			wp_send_json( $response );
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json(
				[
					'error' => true,
					'msg'   => esc_html__( 'You do not have permission to manage licenses.', 'review-schema-pro' ),
					'type'  => null,
					'value' => null,
					'data'  => null,
				]
			);
		}

		$settings    = Functions::get_option( 'rtrs_tools_settings' );
		$license_key = ! empty( $settings['license_key'] ) ? trim( $settings['license_key'] ) : null;

		// Accept license key from POST only (in case user hasn't saved settings yet).
		// $_REQUEST also accepted GET, which put the credential in the URL and so
		// into access logs, Referer headers and proxy logs.
		// A value starting with the mask run is the redacted placeholder the
		// settings page renders (8 asterisks + the key's last 4 characters).
		// It is never a real key and must not overwrite the stored one — fall
		// back to the saved key instead.
		if ( ! empty( $_POST['license_key'] ) ) {
			$posted_key = trim( sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) );
			if ( 0 === strpos( $posted_key, '********' ) ) {
				$posted_key = '';
			}
			if ( $posted_key && $posted_key !== $license_key ) {
				$license_key            = $posted_key;
				$settings['license_key'] = $license_key;
				update_option( 'rtrs_tools_settings', $settings );
			}
		}

		$request_type = isset( $_REQUEST['type'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['type'] ) ) : '';

		if ( 'license_activate' === $request_type ) {
			$api_params = [
				'edd_action' => 'activate_license',
				'license'    => $license_key,
				'item_id'    => self::$product_id,
				'url'        => home_url(),
			];
			$response   = wp_remote_post(
				self::$store_url,
				[
					'timeout'   => 15,
					'sslverify' => true,
					'body'      => $api_params,
				]
			);
			if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
				$err     = is_wp_error( $response ) ? $response->get_error_message() : '';
				$message = ! empty( $err ) ? $err : esc_html__( 'An error occurred, please try again.', 'review-schema-pro' );
			} else {
				$license_data = json_decode( wp_remote_retrieve_body( $response ) );
				if ( ! is_object( $license_data ) ) {
					$message = esc_html__( 'Invalid response from licensing server.', 'review-schema-pro' );
				} elseif ( isset( $license_data->success ) && false === $license_data->success ) {
					$error_code = isset( $license_data->error ) ? $license_data->error : '';
					switch ( $error_code ) {
						case 'expired':
							$expires = isset( $license_data->expires ) ? $license_data->expires : '';
							$message = sprintf(
								esc_html__( 'Your license key expired on %s.', 'review-schema-pro' ),
								date_i18n(
									get_option( 'date_format' ),
									strtotime( $expires, current_time( 'timestamp' ) )
								)
							);
							break;
						case 'revoked':
							$message = esc_html__( 'Your license key has been disabled.', 'review-schema-pro' );
							break;
						case 'missing':
							$message = esc_html__( 'Invalid license.', 'review-schema-pro' );
							break;
						case 'invalid':
						case 'site_inactive':
							$message = esc_html__( 'Your license is not active for this URL.', 'review-schema-pro' );
							break;
						case 'item_name_mismatch':
							$message = esc_html__( 'This appears to be an invalid license key for SchemaEngine AI Pro.', 'review-schema-pro' );
							break;
						case 'no_activations_left':
							$message = esc_html__( 'Your license key has reached its activation limit.', 'review-schema-pro' );
							break;
						default:
							$message = esc_html__( 'An error occurred, please try again.', 'review-schema-pro' );
							break;
					}
				}
				// Check if anything passed on a message constituting a failure
				if ( empty( $message ) && is_object( $license_data ) ) {
					$settings['license_status'] = isset( $license_data->license ) ? $license_data->license : '';
					$settings['expires']        = isset( $license_data->expires ) ? $license_data->expires : '';
					update_option( 'rtrs_tools_settings', $settings );
					$error   = false;
					$type    = 'license_deactivate';
					$message = esc_html__( 'License successfully activated', 'review-schema-pro' );
					$value   = esc_html__( 'Deactivate License', 'review-schema-pro' );
				}
			}
		}
		if ( 'license_deactivate' === $request_type ) {
			$api_params = [
				'edd_action' => 'deactivate_license',
				'license'    => $license_key,
				'item_id'    => self::$product_id,
				'url'        => home_url(),
			];
			$response   = wp_remote_post(
				self::$store_url,
				[
					'timeout'   => 15,
					'sslverify' => true,
					'body'      => $api_params,
				]
			);

			// Make sure there are no errors
			if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
				$err     = is_wp_error( $response ) ? $response->get_error_message() : '';
				$message = ! empty( $err ) ? $err : esc_html__( 'An error occurred, please try again.', 'review-schema-pro' );
			} else {
				unset( $settings['license_status'] );
				update_option( 'rtrs_tools_settings', $settings );
				$error   = false;
				$type    = 'license_activate';
				$message = esc_html__( 'License successfully deactivated', 'review-schema-pro' );
				$value   = esc_html__( 'Activate License', 'review-schema-pro' );
			}
		}
		$response = [
			'error' => $error,
			'msg'   => $message,
			'type'  => $type,
			'value' => $value,
			'data'  => $data,
		];
		wp_send_json( $response );
	}

	public static function add_tools_licensing_options( $options ) {
		$position = array_search( 'license_key', array_keys( $options ) );
		if ( $position > -1 ) {
			$settings = Functions::get_option( 'rtrs_tools_settings' );
			$status   = ! empty( $settings['license_status'] ) && $settings['license_status'] === 'valid';
			$expires  = ! empty( $settings['expires'] ) ? $settings['expires'] : '';
			if ( $status ) {
				$description = esc_html__( 'Your license is active. You are receiving updates and support.', 'review-schema-pro' );
				if ( $expires && 'lifetime' !== $expires ) {
					$expires_date = date_i18n( get_option( 'date_format' ), strtotime( $expires ) );
					$description .= ' ' . sprintf(
						__( 'Expires on <strong style="color:#8B1538">%s</strong>.', 'review-schema-pro' ),
						$expires_date
					);
				} elseif ( 'lifetime' === $expires ) {
					$description .= ' <strong style="color:#16a34a">' . esc_html__( 'Lifetime license.', 'review-schema-pro' ) . '</strong>';
				}
			} else {
				$description = esc_html__( 'Enter your license key and save settings to activate Pro features and updates.', 'review-schema-pro' );
			}
			$option      = [
				'license_key' => [
					'title'         => esc_html__( 'License key', 'review-schema-pro' ),
					'type'          => 'text',
					'class'         => 'regular-text',
					'wrapper_class' => 'rtrs-license-wrapper',
					'description'   => $description,
				],
			];
			Functions::array_insert( $options, $position, $option );
		}

		return $options;
	}
}
