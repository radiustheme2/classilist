<?php

namespace Rtrsp\Helpers;

/**
 * Schema Evaluator - Multi-criteria quality assessment for generated JSON-LD schemas.
 *
 * Evaluates schemas across 6 criteria to provide a detailed quality breakdown
 * beyond pass/fail validation. Each criterion scores 0–100 and contributes to
 * an overall weighted score.
 *
 * Criteria:
 *  1. Completeness    – Required + recommended field coverage per schema type.
 *  2. Rich Results    – Meets Google's minimum requirements for rich snippets.
 *  3. Cross-References – @id integrity and inter-node linking quality.
 *  4. Content Depth   – Richness of descriptions, images, and nested data.
 *  5. Identifiers     – Product identifiers (SKU/GTIN/brand), author info, etc.
 *  6. Graph Structure – Structural types coverage (WebPage, Breadcrumb, WebSite, Entity).
 *
 * @package Rtrs\AI
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

class SchemaEvaluator {

	/**
	 * All @id values found in the current @graph.
	 *
	 * @var array
	 */
	private $graph_ids = [];

	/**
	 * All @type values found in the current @graph.
	 *
	 * @var array
	 */
	private $graph_types = [];

	/**
	 * The @graph items array being evaluated.
	 *
	 * @var array
	 */
	private $schemas = [];

	/**
	 * Criteria weights for overall score calculation.
	 * Must sum to 1.0.
	 *
	 * @var array
	 */
	private $weights = [
		'completeness'    => 0.25,
		'rich_results'    => 0.25,
		'cross_references' => 0.15,
		'content_depth'   => 0.15,
		'identifiers'     => 0.10,
		'graph_structure'  => 0.10,
	];

	/**
	 * Evaluate a @graph items array or a full @graph wrapper object.
	 *
	 * @since 1.0.0
	 *
	 * @param array $schemas @graph items array or {"@context":..., "@graph":[...]} wrapper.
	 *
	 * @return array Evaluation result with criteria scores and overall score.
	 */
	public function evaluate( $schemas ) {
		/** Unwrap @graph wrapper if present. */
		if ( is_array( $schemas ) && isset( $schemas['@graph'] ) ) {
			$schemas = $schemas['@graph'];
		}

		if ( ! is_array( $schemas ) || empty( $schemas ) ) {
			return $this->empty_result();
		}

		$this->schemas = $schemas;

		/** Collect @id and @type values. */
		$this->graph_ids   = [];
		$this->graph_types = [];

		foreach ( $schemas as $schema ) {
			if ( ! empty( $schema['@id'] ) ) {
				$this->graph_ids[] = $schema['@id'];
			}

			if ( ! empty( $schema['@type'] ) ) {
				$this->graph_types[] = is_array( $schema['@type'] ) ? $schema['@type'][0] : $schema['@type'];
			}
		}

		/** Evaluate each criterion. */
		$criteria = [
			'completeness'     => $this->evaluate_completeness(),
			'rich_results'     => $this->evaluate_rich_results(),
			'cross_references' => $this->evaluate_cross_references(),
			'content_depth'    => $this->evaluate_content_depth(),
			'identifiers'      => $this->evaluate_identifiers(),
			'graph_structure'  => $this->evaluate_graph_structure(),
		];

		/**
		 * Scaffolding-only guard: a page that emits only site-wide structural
		 * nodes (WebPage/WebSite/BreadcrumbList), a publisher entity, and/or an
		 * FAQ — but NO page-specific primary entity (Article, Product, Recipe,
		 * Event, …) — is valid markup yet not genuinely rich. Cap the
		 * content-dependent criteria so the health score reflects that the page
		 * itself carries no primary structured data instead of showing a perfect
		 * A+. Validation (pass/fail) is intentionally left untouched.
		 */
		if ( ! $this->has_primary_content_node() ) {
			$cap = 40;

			// The root cause is stated ONCE, in Graph Structure (see Check 5). For
			// the other capped criteria add a short, criterion-specific reason only
			// when the bar would otherwise be unexplained — never repeat the same
			// sentence across criteria.
			$fallback_notes = [
				'rich_results'  => __( 'No page-specific content type eligible for rich results.', 'review-schema-pro' ),
				'content_depth' => __( 'No page-specific content entity to measure depth on.', 'review-schema-pro' ),
			];

			foreach ( [ 'rich_results', 'content_depth', 'graph_structure' ] as $capped_key ) {
				if ( $criteria[ $capped_key ]['score'] > $cap ) {
					$criteria[ $capped_key ]['score'] = $cap;
				}

				if ( isset( $fallback_notes[ $capped_key ] ) && empty( $criteria[ $capped_key ]['details'] ) ) {
					$criteria[ $capped_key ]['details'][] = $fallback_notes[ $capped_key ];
				}
			}
		}

		/** Calculate weighted overall score. */
		$overall = 0;

		foreach ( $criteria as $key => $criterion ) {
			$overall += $criterion['score'] * $this->weights[ $key ];
		}

		$overall = (int) round( $overall );

		return [
			'overall'  => $overall,
			'grade'    => $this->score_to_grade( $overall ),
			'criteria' => $criteria,
		];
	}

	// -------------------------------------------------------------------------
	// Criterion 1: Completeness
	// -------------------------------------------------------------------------

	/**
	 * Evaluate field completeness across all schema types.
	 *
	 * Checks both required and recommended fields per type.
	 * Required fields count double towards the score.
	 *
	 * @since 1.0.0
	 *
	 * @return array Criterion result: score, label, details.
	 */
	private function evaluate_completeness() {
		$total_fields  = 0;
		$filled_fields = 0;
		$details       = [];
		$suggestions   = [];

		foreach ( $this->schemas as $schema ) {
			$type = $schema['@type'] ?? '';

			if ( empty( $type ) ) {
				continue;
			}

			$primary_type = is_array( $type ) ? $type[0] : $type;

			$fields = $this->get_type_fields( $primary_type );

			/** Fallback: entity subtypes (Restaurant, Dentist, etc.) use Organization fields. */
			if ( empty( $fields ) && $this->is_entity_node( $schema ) ) {
				$fields = $this->get_type_fields( 'Organization' );
			}

			if ( empty( $fields ) ) {
				continue;
			}

			$type_total          = 0;
			$type_filled         = 0;
			$missing             = [];
			$missing_recommended = [];

			foreach ( $fields['required'] as $field ) {
				$type_total += 1;

				if ( $this->has_field( $schema, $field ) ) {
					$type_filled += 1;
				} else {
					$missing[] = $field;
				}
			}

			// Recommended fields do NOT affect the score — a missing one (e.g.
			// aggregateRating on Product) is a non-scoring enhancement suggestion,
			// not an issue. Only required-field gaps reduce completeness.
			foreach ( $fields['recommended'] as $field ) {
				// An array of alternatives counts as satisfied if any one is present
				// (e.g. VideoObject accepts either contentUrl or embedUrl).
				if ( is_array( $field ) ) {
					$has_any = false;

					foreach ( $field as $alt ) {
						if ( $this->has_field( $schema, $alt ) ) {
							$has_any = true;
							break;
						}
					}

					if ( ! $has_any ) {
						$missing_recommended[] = implode( ' or ', $field );
					}

					continue;
				}

				if ( ! $this->has_field( $schema, $field ) ) {
					$missing_recommended[] = $field;
				}
			}

			$total_fields  += $type_total;
			$filled_fields += $type_filled;

			if ( ! empty( $missing ) ) {
				$details[] = sprintf(
					'[%s] Missing required: %s',
					$primary_type,
					implode( ', ', $missing )
				);
			}

			foreach ( $missing_recommended as $field ) {
				$suggestions[] = sprintf(
					'[%s] Add recommended field: %s',
					$primary_type,
					$field
				);
			}
		}

		$score = $total_fields > 0
			? (int) round( ( $filled_fields / $total_fields ) * 100 )
			: 100;

		return [
			'score'       => $score,
			'label'       => __( 'Completeness', 'review-schema-pro' ),
			'details'     => $details,
			'suggestions' => $suggestions,
		];
	}

	/**
	 * Get required and recommended fields per schema type.
	 *
	 * @since 1.0.0
	 *
	 * @param string $type Schema.org @type.
	 *
	 * @return array { required: [], recommended: [] } or empty array.
	 */
	private function get_type_fields( $type ) {
		$map = [
			'Article'       => [
				'required'    => [ 'headline', 'datePublished', 'author', '@id' ],
				'recommended' => [ 'image', 'dateModified', 'description', 'mainEntityOfPage', 'publisher', 'wordCount' ],
			],
			'BlogPosting'   => [
				'required'    => [ 'headline', 'datePublished', 'author', '@id' ],
				'recommended' => [ 'image', 'dateModified', 'description', 'mainEntityOfPage', 'publisher', 'wordCount' ],
			],
			'Product'       => [
				'required'    => [ 'name', 'image', '@id' ],
				'recommended' => [ 'description', 'offers', 'aggregateRating', 'brand', 'sku', 'url' ],
			],
			'ProductGroup'  => [
				'required'    => [ 'name', 'hasVariant', '@id' ],
				'recommended' => [ 'description', 'image', 'brand', 'productGroupID', 'variesBy', 'url' ],
			],
			'FAQPage'       => [
				'required'    => [ 'mainEntity', '@id' ],
				// Google's FAQ rich result only needs mainEntity (Q&A pairs);
				// name/description are not recommended for FAQPage.
				'recommended' => [],
			],
			'HowTo'         => [
				'required'    => [ 'name', 'step', '@id' ],
				'recommended' => [ 'description', 'totalTime', 'image' ],
			],
			'Recipe'        => [
				'required'    => [ 'name', 'recipeIngredient', 'recipeInstructions', '@id' ],
				'recommended' => [ 'image', 'author', 'datePublished', 'totalTime', 'prepTime', 'cookTime', 'recipeYield', 'recipeCategory', 'recipeCuisine', 'description' ],
			],
			'Event'         => [
				'required'    => [ 'name', 'startDate', 'location', '@id' ],
				'recommended' => [ 'endDate', 'description', 'eventStatus', 'eventAttendanceMode', 'organizer', 'offers', 'image' ],
			],
			'LocalBusiness' => [
				'required'    => [ 'name', 'address', '@id' ],
				'recommended' => [ 'telephone', 'url', 'openingHoursSpecification', 'image', 'geo', 'priceRange' ],
			],
			'TouristAttraction' => [
				'required'    => [ 'name', 'image', 'description', 'address', 'geo.latitude', 'geo.longitude' ],
				'recommended' => [ 'touristType', 'url', 'sameAs', 'openingHoursSpecification' ],
			],
			'VideoObject'   => [
				'required'    => [ 'name', 'description', 'thumbnailUrl', 'uploadDate', '@id' ],
				'recommended' => [ [ 'contentUrl', 'embedUrl' ], 'duration' ],
			],
			'WebPage'       => [
				'required'    => [ 'name', 'url', '@id' ],
				'recommended' => [ 'description', 'isPartOf', 'breadcrumb', 'datePublished', 'dateModified', 'inLanguage' ],
			],
			'WebSite'       => [
				'required'    => [ 'name', 'url', '@id' ],
				'recommended' => [ 'publisher', 'inLanguage' ],
			],
			'BreadcrumbList' => [
				'required'    => [ 'itemListElement', '@id' ],
				'recommended' => [],
			],
			'Organization'  => [
				'required'    => [ 'name', '@id' ],
				'recommended' => [ 'url', 'logo', 'sameAs' ],
			],
			'Person'        => [
				'required'    => [ 'name', '@id' ],
				'recommended' => [ 'url', 'image', 'jobTitle', 'sameAs' ],
			],
			'Course'        => [
				'required'    => [ 'name', 'description', 'provider', '@id' ],
				'recommended' => [ 'educationalLevel' ],
			],
		];

		return $map[ $type ] ?? [];
	}

	// -------------------------------------------------------------------------
	// Criterion 2: Rich Results Eligibility
	// -------------------------------------------------------------------------

	/**
	 * Evaluate whether schemas meet Google Rich Results minimum requirements.
	 *
	 * Each eligible type is checked for its minimum field set. The score
	 * reflects how many eligible types fully pass their checks.
	 *
	 * @since 1.0.0
	 *
	 * @return array Criterion result.
	 */
	private function evaluate_rich_results() {
		$eligible_types = [
			'Article', 'BlogPosting', 'Product', 'FAQPage', 'HowTo',
			'Recipe', 'Event', 'LocalBusiness', 'VideoObject', 'Course',
		];

		$checked = 0;
		$passed  = 0;
		$details = [];

		foreach ( $this->schemas as $schema ) {
			$type = $schema['@type'] ?? '';
			$type = is_array( $type ) ? $type[0] : $type;

			if ( ! in_array( $type, $eligible_types, true ) ) {
				continue;
			}

			$checked++;
			$check = $this->check_rich_results_for_type( $schema, $type );

			if ( $check['pass'] ) {
				$passed++;
			} else {
				$details[] = sprintf(
					'[%s] Not eligible: %s',
					$type,
					implode( ', ', $check['missing'] )
				);
			}
		}

		if ( 0 === $checked ) {
			return [
				'score'   => 100,
				'label'   => __( 'Rich Results',  'review-schema-pro' ),
				'details' => [ __( 'No rich-result-eligible types found.',  'review-schema-pro' ) ],
			];
		}

		$score = (int) round( ( $passed / $checked ) * 100 );

		return [
			'score'   => $score,
			'label'   => __( 'Rich Results',  'review-schema-pro' ),
			'details' => $details,
		];
	}

	/**
	 * Check Google Rich Results minimum requirements for a specific type.
	 *
	 * @since 1.0.0
	 *
	 * @param array  $schema Schema data.
	 * @param string $type   Schema @type.
	 *
	 * @return array { pass: bool, missing: [] }
	 */
	private function check_rich_results_for_type( $schema, $type ) {
		$requirements = [
			'Article'       => [ 'headline', 'author', 'datePublished', 'image' ],
			'BlogPosting'   => [ 'headline', 'author', 'datePublished', 'image' ],
			'Product'       => [ 'name', 'image' ],
			'FAQPage'       => [ 'mainEntity' ],
			'HowTo'         => [ 'name', 'step' ],
			'Recipe'        => [ 'name', 'recipeIngredient', 'recipeInstructions' ],
			'Event'         => [ 'name', 'startDate', 'location' ],
			'LocalBusiness' => [ 'name', 'address' ],
			'VideoObject'   => [ 'name', 'description', 'thumbnailUrl', 'uploadDate' ],
			'Course'        => [ 'name', 'description', 'provider' ],
		];

		$required = $requirements[ $type ] ?? [];
		$missing  = [];

		foreach ( $required as $field ) {
			if ( ! $this->has_field( $schema, $field ) ) {
				$missing[] = $field;
			}
		}

		/** Product needs at least one of: offers, review, aggregateRating. */
		if ( 'Product' === $type ) {
			if ( empty( $schema['offers'] ) && empty( $schema['review'] ) && empty( $schema['aggregateRating'] ) ) {
				$missing[] = 'offers/review/aggregateRating';
			}
		}

		return [
			'pass'    => empty( $missing ),
			'missing' => $missing,
		];
	}

	// -------------------------------------------------------------------------
	// Criterion 3: Cross-Reference Integrity
	// -------------------------------------------------------------------------

	/**
	 * Evaluate @id cross-reference quality across the @graph.
	 *
	 * Checks that:
	 * - Every node has a well-formed @id.
	 * - Every @id reference resolves to an existing node.
	 * - Key relationships are properly linked (WebPage ↔ BreadcrumbList, etc.).
	 *
	 * @since 1.0.0
	 *
	 * @return array Criterion result.
	 */
	private function evaluate_cross_references() {
		$total_checks = 0;
		$passed       = 0;
		$details      = [];

		/** Check 1: Every node has an @id. */
		foreach ( $this->schemas as $schema ) {
			$total_checks++;

			if ( ! empty( $schema['@id'] ) ) {
				$passed++;
			} else {
				$type = $schema['@type'] ?? 'unknown';
				$type = is_array( $type ) ? $type[0] : $type;
				$details[] = sprintf( '[%s] Missing @id', $type );
			}
		}

		/** Check 2: Key cross-reference links. */
		$ref_checks = [
			[ 'source' => 'WebPage', 'field' => 'breadcrumb', 'target_type' => 'BreadcrumbList' ],
			[ 'source' => 'WebPage', 'field' => 'isPartOf', 'target_type' => 'WebSite' ],
			[ 'source' => 'Article', 'field' => 'mainEntityOfPage', 'target_type' => 'WebPage' ],
			[ 'source' => 'BlogPosting', 'field' => 'mainEntityOfPage', 'target_type' => 'WebPage' ],
			[ 'source' => 'Article', 'field' => 'publisher', 'target_type' => null ],
			[ 'source' => 'BlogPosting', 'field' => 'publisher', 'target_type' => null ],
			[ 'source' => 'WebSite', 'field' => 'publisher', 'target_type' => null ],
		];

		foreach ( $ref_checks as $check ) {
			$source_schema = $this->find_by_type( $check['source'] );

			if ( ! $source_schema ) {
				continue;
			}

			$total_checks++;

			$ref = $source_schema[ $check['field'] ] ?? null;

			if ( ! empty( $ref ) && is_array( $ref ) && ! empty( $ref['@id'] ) ) {
				if ( in_array( $ref['@id'], $this->graph_ids, true ) ) {
					$passed++;
				} else {
					$details[] = sprintf(
						'[%s] "%s" references unresolved @id: %s',
						$check['source'],
						$check['field'],
						$ref['@id']
					);
				}
			} elseif ( ! empty( $ref ) ) {
				/** Has the field but not as @id reference — partial credit. */
				$passed++;
			} else {
				$details[] = sprintf(
					'[%s] Missing "%s" cross-reference',
					$check['source'],
					$check['field']
				);
			}
		}

		$score = $total_checks > 0
			? (int) round( ( $passed / $total_checks ) * 100 )
			: 100;

		return [
			'score'   => $score,
			'label'   => __( 'Cross-References',  'review-schema-pro' ),
			'details' => $details,
		];
	}

	// -------------------------------------------------------------------------
	// Criterion 4: Content Depth
	// -------------------------------------------------------------------------

	/**
	 * Evaluate the richness and depth of schema content.
	 *
	 * Checks description lengths, image presence with dimensions, breadcrumb
	 * depth, nested object richness, and other quality signals.
	 *
	 * @since 1.0.0
	 *
	 * @return array Criterion result.
	 */
	private function evaluate_content_depth() {
		$total_checks = 0;
		$points       = 0;
		$details      = [];

		foreach ( $this->schemas as $schema ) {
			$type = $schema['@type'] ?? '';
			$type = is_array( $type ) ? $type[0] : $type;

			/** Description length check (50+ chars is good). */
			if ( in_array( $type, [ 'Article', 'BlogPosting', 'Product', 'WebPage', 'Event', 'Recipe', 'Course', 'VideoObject' ], true ) ) {
				$total_checks++;
				$desc = $schema['description'] ?? '';
				if ( mb_strlen( $desc ) >= 50 ) {
					$points++;
				} elseif ( mb_strlen( $desc ) >= 20 ) {
					$points += 0.5;
					$details[] = sprintf( '[%s] Description could be longer (currently %d chars)', $type, mb_strlen( $desc ) );
				} else {
					$details[] = sprintf( '[%s] Description is too short or missing', $type );
				}
			}

			/** Image with dimensions check. */
			if ( in_array( $type, [ 'Article', 'BlogPosting', 'Product', 'Recipe', 'Event' ], true ) ) {
				$total_checks++;

				$image = $schema['image'] ?? null;

				if ( ! empty( $image ) ) {
					$img = is_array( $image ) && isset( $image[0] ) ? $image[0] : $image;

					if ( is_array( $img ) && ! empty( $img['width'] ) && ! empty( $img['height'] ) ) {
						$points++;
					} else {
						$points += 0.5;
						$details[] = sprintf( '[%s] Image missing width/height dimensions', $type );
					}
				} else {
					$details[] = sprintf( '[%s] No image provided', $type );
				}
			}

			/** BreadcrumbList depth check (2+ items is acceptable). */
			if ( 'BreadcrumbList' === $type ) {
				$total_checks++;

				$items = $schema['itemListElement'] ?? [];
				$count = is_array( $items ) ? count( $items ) : 0;

				if ( $count >= 2 ) {
					$points++;
				} else {
					$details[] = __( '[BreadcrumbList] Too few items',  'review-schema-pro' );
				}
			}

			/** Product: Offer depth. */
			if ( 'Product' === $type && ! empty( $schema['offers'] ) ) {
				$total_checks++;

				$offers = isset( $schema['offers'][0] ) ? $schema['offers'] : [ $schema['offers'] ];
				$offer  = $offers[0];

				$offer_points = 0;
				$offer_max    = 4;

				$has_price     = isset( $offer['price'] ) && '' !== $offer['price'] && is_numeric( $offer['price'] );
				$has_low_price = isset( $offer['lowPrice'] ) && '' !== $offer['lowPrice'] && is_numeric( $offer['lowPrice'] );
				if ( $has_price || $has_low_price ) {
					// Count a price of 0 (free item); empty() would miss it.
					$offer_points++;
				}

				if ( ! empty( $offer['availability'] ) ) {
					$offer_points++;
				}

				if ( ! empty( $offer['priceSpecification'] ) ) {
					$offer_points++;
				}

				if ( ! empty( $offer['seller'] ) ) {
					$offer_points++;
				}

				$points += $offer_points / $offer_max;

				if ( $offer_points < $offer_max ) {
					$details[] = sprintf( '[Product] Offer detail: %d/%d fields', $offer_points, $offer_max );
				}
			}

			/** Article/BlogPosting: Author depth. */
			if ( in_array( $type, [ 'Article', 'BlogPosting' ], true ) ) {
				$total_checks++;

				$author = $schema['author'] ?? null;

				if ( is_array( $author ) && ! empty( $author['name'] ) ) {
					if ( ! empty( $author['url'] ) ) {
						$points++;
					} else {
						$points += 0.5;
						$details[] = sprintf( '[%s] Author missing URL', $type );
					}
				} else {
					$details[] = sprintf( '[%s] Author details incomplete', $type );
				}
			}
		}

		$score = $total_checks > 0
			? (int) round( ( $points / $total_checks ) * 100 )
			: 100;

		return [
			'score'   => $score,
			'label'   => __( 'Content Depth',  'review-schema-pro' ),
			'details' => $details,
		];
	}

	// -------------------------------------------------------------------------
	// Criterion 5: Identifiers
	// -------------------------------------------------------------------------

	/**
	 * Evaluate identifier coverage (SKU, GTIN, brand, author, etc.).
	 *
	 * Different schema types have different identifier expectations.
	 * Products need commercial identifiers; Articles need author attribution.
	 *
	 * @since 1.0.0
	 *
	 * @return array Criterion result.
	 */
	private function evaluate_identifiers() {
		$total_checks = 0;
		$points       = 0;
		$details      = [];

		foreach ( $this->schemas as $schema ) {
			$type = $schema['@type'] ?? '';
			$type = is_array( $type ) ? $type[0] : $type;

			/** Product identifiers. */
			if ( 'Product' === $type ) {
				/** SKU / GTIN / MPN. */
				$total_checks++;

				if ( ! empty( $schema['sku'] ) || ! empty( $schema['gtin'] ) || ! empty( $schema['gtin8'] )
					|| ! empty( $schema['gtin13'] ) || ! empty( $schema['gtin14'] ) || ! empty( $schema['mpn'] ) ) {
					$points++;
				} else {
					$details[] = __( '[Product] No product identifier (SKU, GTIN, or MPN)',  'review-schema-pro' );
				}

				/** Brand. */
				$total_checks++;

				if ( ! empty( $schema['brand'] ) ) {
					$points++;
				} else {
					$details[] = __( '[Product] Missing brand',  'review-schema-pro' );
				}

				/** Price currency. */
				$total_checks++;

				$has_currency = false;

				if ( ! empty( $schema['offers'] ) ) {
					$offers = isset( $schema['offers'][0] ) ? $schema['offers'] : [ $schema['offers'] ];

					foreach ( $offers as $offer ) {
						if ( ! empty( $offer['priceCurrency'] ) ) {
							$has_currency = true;
							break;
						}
					}
				}

				if ( $has_currency ) {
					$points++;
				} else {
					$details[] = __( '[Product] Offers missing priceCurrency',  'review-schema-pro' );
				}
			}

			/** Article/BlogPosting author identification. */
			if ( in_array( $type, [ 'Article', 'BlogPosting' ], true ) ) {
				$total_checks++;

				$author = $schema['author'] ?? null;

				if ( is_array( $author ) && ! empty( $author['name'] ) ) {
					$points++;
				} else {
					$details[] = sprintf( '[%s] Author name missing', $type );
				}

				/** Publisher. */
				$total_checks++;

				if ( ! empty( $schema['publisher'] ) ) {
					$points++;
				} else {
					$details[] = sprintf( '[%s] Publisher missing', $type );
				}
			}

			/** Organization/Person identifiers (including subtypes like Restaurant, Dentist, etc.). */
			if ( in_array( $type, [ 'Organization', 'Person', 'LocalBusiness' ], true ) || $this->is_entity_node( $schema ) ) {
				/** URL. */
				$total_checks++;

				if ( ! empty( $schema['url'] ) ) {
					$points++;
				} else {
					$details[] = sprintf( '[%s] Missing URL', $type );
				}

				/** Logo or image. */
				$total_checks++;

				if ( ! empty( $schema['logo'] ) || ! empty( $schema['image'] ) ) {
					$points++;
				} else {
					$details[] = sprintf( '[%s] Missing logo/image', $type );
				}

				/** sameAs (social profiles). */
				$total_checks++;

				if ( ! empty( $schema['sameAs'] ) ) {
					$points++;
				} else {
					$details[] = sprintf( '[%s] No sameAs social profiles', $type );
				}
			}

			/** Event organizer. */
			if ( 'Event' === $type ) {
				$total_checks++;

				if ( ! empty( $schema['organizer'] ) ) {
					$points++;
				} else {
					$details[] = __( '[Event] Missing organizer',  'review-schema-pro' );
				}
			}
		}

		if ( 0 === $total_checks ) {
			return [
				'score'   => 100,
				'label'   => __( 'Identifiers',  'review-schema-pro' ),
				'details' => [],
			];
		}

		$score = (int) round( ( $points / $total_checks ) * 100 );

		return [
			'score'   => $score,
			'label'   => __( 'Identifiers',  'review-schema-pro' ),
			'details' => $details,
		];
	}

	// -------------------------------------------------------------------------
	// Criterion 6: Graph Structure
	// -------------------------------------------------------------------------

	/**
	 * Evaluate the structural completeness of the @graph.
	 *
	 * A well-formed @graph should include:
	 * - WebPage (always)
	 * - BreadcrumbList (always)
	 * - WebSite (always)
	 * - Publisher entity: Organization, Person, or LocalBusiness (always)
	 * - At least one content-type node (Article, Product, etc.)
	 *
	 * @since 1.0.0
	 *
	 * @return array Criterion result.
	 */
	private function evaluate_graph_structure() {
		$total_checks = 5;
		$passed       = 0;
		$details      = [];

		/** Check 1: WebPage or subtype (ItemPage, FAQPage, etc.) present. */
		$webpage_types = [ 'WebPage', 'ItemPage', 'CollectionPage', 'AboutPage', 'CheckoutPage', 'ContactPage', 'FAQPage', 'MedicalWebPage', 'ProfilePage', 'QAPage', 'RealEstateListing', 'SearchResultsPage' ];
		if ( ! empty( array_intersect( $webpage_types, $this->graph_types ) ) ) {
			$passed++;
		} else {
			$details[] = __( 'Missing WebPage node', 'review-schema-pro' );
		}

		/** Check 2: BreadcrumbList present. */
		if ( in_array( 'BreadcrumbList', $this->graph_types, true ) ) {
			$passed++;
		} else {
			$details[] = __( 'Missing BreadcrumbList node',  'review-schema-pro' );
		}

		/** Check 3: WebSite present. */
		if ( in_array( 'WebSite', $this->graph_types, true ) ) {
			$passed++;
		} else {
			$details[] = __( 'Missing WebSite node',  'review-schema-pro' );
		}

		/** Check 4: Publisher entity present (Organization, Person, or any subtype like Restaurant). */
		$has_entity = false;

		foreach ( $this->schemas as $schema ) {
			if ( $this->is_entity_node( $schema ) ) {
				$has_entity = true;
				break;
			}
		}

		if ( $has_entity ) {
			$passed++;
		} else {
			$details[] = __( 'Missing publisher entity (Organization/Person)',  'review-schema-pro' );
		}

		/** Check 5: At least one page-specific primary content node (not a
		 *  WebPage subtype such as FAQPage, not WebSite/BreadcrumbList, and not
		 *  an Organization/Person entity). */
		if ( $this->has_primary_content_node() ) {
			$passed++;
		} else {
			$details[] = __( 'No page-specific primary entity (Article, Product, Recipe, Event, etc.) — the page emits only site scaffolding/FAQ. Add a content type to become rich-result ready.', 'review-schema-pro' );
		}

		$score = (int) round( ( $passed / $total_checks ) * 100 );

		return [
			'score'   => $score,
			'label'   => __( 'Graph Structure',  'review-schema-pro' ),
			'details' => $details,
		];
	}

	// -------------------------------------------------------------------------
	// Helpers
	// -------------------------------------------------------------------------

	/**
	 * Check whether a schema node is an entity/publisher node (Organization, Person, or any subtype).
	 *
	 * Uses the @id pattern (#organization / #person) rather than @type, because the @type
	 * can be any Organization subtype (Restaurant, Dentist, Corporation, etc.) set via settings.
	 *
	 * @since 1.0.0
	 *
	 * @param array $schema Schema item.
	 *
	 * @return bool
	 */
	private function is_entity_node( $schema ) {
		$id = $schema['@id'] ?? '';

		return (bool) preg_match( '/#(organization|person)$/i', $id );
	}

	/**
	 * Whether the @graph contains a page-specific PRIMARY content entity.
	 *
	 * Site-wide scaffolding (WebPage and its subtypes incl. FAQPage/QAPage,
	 * WebSite, BreadcrumbList) and publisher entities (Organization/Person and
	 * subtypes) are NOT primary content — they exist on every page. A genuine
	 * page-specific entity (Article, Product, Recipe, Event, HowTo, Course,
	 * VideoObject, JobPosting, etc.) is required for a page to be considered
	 * rich; without one the readiness score is capped (see evaluate()).
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	private function has_primary_content_node() {
		$non_primary = [
			'WebPage', 'ItemPage', 'CollectionPage', 'AboutPage', 'CheckoutPage',
			'ContactPage', 'FAQPage', 'MedicalWebPage', 'ProfilePage', 'QAPage',
			'RealEstateListing', 'SearchResultsPage', 'WebSite', 'BreadcrumbList',
		];

		foreach ( $this->schemas as $schema ) {
			$type = $schema['@type'] ?? '';
			$type = is_array( $type ) ? $type[0] : $type;

			if ( '' === $type || in_array( $type, $non_primary, true ) ) {
				continue;
			}

			if ( $this->is_entity_node( $schema ) ) {
				continue;
			}

			return true;
		}

		return false;
	}

	/**
	 * Check whether a schema has a non-empty field value.
	 *
	 * Handles nested fields with dot notation (e.g., "author.name").
	 *
	 * @since 1.0.0
	 *
	 * @param array  $schema Schema data.
	 * @param string $field  Field name.
	 *
	 * @return bool
	 */
	private function has_field( $schema, $field ) {
		if ( false !== strpos( $field, '.' ) ) {
			$parts   = explode( '.', $field );
			$current = $schema;

			foreach ( $parts as $part ) {
				if ( ! is_array( $current ) || ! isset( $current[ $part ] ) ) {
					return false;
				}

				$current = $current[ $part ];
			}

			return ! empty( $current ) || 0 === $current || '0' === $current;
		}

		return isset( $schema[ $field ] ) && ( ! empty( $schema[ $field ] ) || 0 === $schema[ $field ] || '0' === $schema[ $field ] );
	}

	/**
	 * Find the first schema node matching a given @type.
	 *
	 * @since 1.0.0
	 *
	 * @param string $type Schema @type to find.
	 *
	 * @return array|null Schema item or null.
	 */
	private function find_by_type( $type ) {
		foreach ( $this->schemas as $schema ) {
			$schema_type = $schema['@type'] ?? '';

			if ( is_array( $schema_type ) ) {
				if ( in_array( $type, $schema_type, true ) ) {
					return $schema;
				}
			} elseif ( $schema_type === $type ) {
				return $schema;
			}
		}

		return null;
	}

	/**
	 * Convert a numeric score to a letter grade.
	 *
	 * @since 1.0.0
	 *
	 * @param int $score Score 0–100.
	 *
	 * @return string Grade (A+, A, B+, B, C, D, F).
	 */
	private function score_to_grade( $score ) {
		if ( $score >= 95 ) {
			return 'A+';
		}

		if ( $score >= 85 ) {
			return 'A';
		}

		if ( $score >= 75 ) {
			return 'B+';
		}

		if ( $score >= 65 ) {
			return 'B';
		}

		if ( $score >= 50 ) {
			return 'C';
		}

		if ( $score >= 35 ) {
			return 'D';
		}

		return 'F';
	}

	/**
	 * Return an empty evaluation result for invalid input.
	 *
	 * @since 1.0.0
	 *
	 * @return array Empty result structure.
	 */
	private function empty_result() {
		$empty_criterion = [
			'score'   => 0,
			'label'   => '',
			'details' => [],
		];

		return [
			'overall'  => 0,
			'grade'    => 'F',
			'criteria' => [
				'completeness'     => array_merge( $empty_criterion, [ 'label' => __( 'Completeness',  'review-schema-pro' ) ] ),
				'rich_results'     => array_merge( $empty_criterion, [ 'label' => __( 'Rich Results',  'review-schema-pro' ) ] ),
				'cross_references' => array_merge( $empty_criterion, [ 'label' => __( 'Cross-References',  'review-schema-pro' ) ] ),
				'content_depth'    => array_merge( $empty_criterion, [ 'label' => __( 'Content Depth',  'review-schema-pro' ) ] ),
				'identifiers'      => array_merge( $empty_criterion, [ 'label' => __( 'Identifiers',  'review-schema-pro' ) ] ),
				'graph_structure'  => array_merge( $empty_criterion, [ 'label' => __( 'Graph Structure',  'review-schema-pro' ) ] ),
			],
		];
	}
}
