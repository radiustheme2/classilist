<?php
/**
 * Review Initialization Handler
 *
 * Bootstraps review-related functionality, including shortcode registration.
 *
 * @package Rtrs\Review
 */

namespace Rtrsp\Modules\Schema;

use Rtrsp\AI\CronBatch;
use Rtrsp\AI\ProClassifier;
use Rtrsp\AI\ProCourseExtractor;
use Rtrsp\AI\ProFaqSuggestion;
use Rtrsp\AI\ProFluentCartExtractor;
use Rtrsp\AI\ProProductExtractor;
use Rtrsp\AI\ProSchemaTypes;
use Rtrsp\AI\ProSureCartExtractor;
use Rtrsp\AI\SchemaEditController;
use Rtrsp\Helpers\FnsPro;
use Rtrsp\Helpers\SchemaEvaluator;
use Rtrsp\Modules\Schema\Admin\SchemaAjax;
use Rtrsp\Modules\Schema\FrontEnd\FrontendHook;
use Rtrsp\Modules\Schema\Hooks\ShippingDetailsInjector;
use Rtrsp\Modules\Schema\Hooks\OfferDetailNormalizer;
use Rtrsp\Modules\Schema\Hooks\SubOrganization;
use Rtrsp\Modules\Schema\Meta\MetaOptions;
use Rtrsp\Traits\SingletonTrait;


/**
 * Class ReviewInit
 *
 * Handles initialization tasks for the Review module.
 * Uses the Singleton pattern to ensure a single instance.
 */
class SchemaInit {

	use SingletonTrait;

	/**
	 * ReviewInit constructor.
	 *
	 * Registers required actions and initializes review shortcodes.
	 * Constructor is private to enforce singleton usage.
	 *
	 * @return void
	 */
	private function __construct() {
		MetaOptions::getInstance();
		FrontendHook::getInstance();
		SchemaAjax::getInstance();
		ShippingDetailsInjector::getInstance();
		OfferDetailNormalizer::getInstance();
		SubOrganization::getInstance();

		// AI schema: auto-detect classification (Pro feature).
		add_filter( 'rtrs_ai_auto_classify', [ ProClassifier::class, 'auto_classify' ], 10, 2 );

		// AI schema: WooCommerce product data extraction (Pro feature).
		add_filter( 'rtrs_ai_extract_wc_product_data', [ ProProductExtractor::class, 'extract_wc_product_data' ], 10, 2 );

		// AI schema: EDD product data extraction (Pro feature).
		add_filter( 'rtrs_ai_extract_edd_product_data', [ ProProductExtractor::class, 'extract_edd_product_data' ], 10, 2 );

		// AI schema: convert Product to ProductGroup for variable products.
		add_filter( 'rtrs_ai_convert_product_group', [ FnsPro::class, 'convert_to_product_group' ], 10, 4 );

		// AI schema: Product schema filling (Pro feature).
		add_filter( 'rtrs_ai_fill_product_schema', [ ProProductExtractor::class, 'fill_product' ], 10, 5 );

		// AI schema: Product AI prompt template (Pro feature).
		add_filter( 'rtrs_ai_type_template', [ ProProductExtractor::class, 'get_product_template' ], 10, 3 );

		// AI schema: Course data extraction (Pro feature).
		add_filter( 'rtrs_ai_extract_course_data', [ ProCourseExtractor::class, 'extract_course_data' ], 10, 2 );

		// AI schema: Course schema filling (Pro feature).
		add_filter( 'rtrs_ai_fill_course_schema', [ ProCourseExtractor::class, 'fill_course_schema' ], 10, 5 );

		// AI schema: Course AI prompt template (Pro feature).
		add_filter( 'rtrs_ai_type_template', [ ProCourseExtractor::class, 'get_course_template' ], 10, 3 );

		// AI schema: Pro type templates (Book, JobPosting, Recipe, LocalBusiness/Restaurant).
		add_filter( 'rtrs_ai_type_template', [ ProSchemaTypes::class, 'get_type_template' ], 10, 3 );

		// AI schema: Pro type validation (Product, ProductGroup, Recipe, Course, LocalBusiness).
		add_action( 'rtrs_ai_validate_schema_type', [ ProSchemaTypes::class, 'validate_schema_type' ], 10, 4 );

		// AI schema: real quality score evaluation (Pro feature).
		add_filter( 'rtrs_ai_schema_evaluation', [ self::class, 'evaluate_schema' ], 10, 2 );

		// Manual schema: real quality score evaluation (Pro feature).
		add_filter( 'rtrs_manual_schema_evaluation', [ self::class, 'evaluate_schema' ], 10, 2 );

		// SEO / AEO / GEO Pro hooks (Keyword Coverage, Page Performance, Refine
		// with AI, the AI suggest/apply REST routes and Verify with AI) are
		// registered by Rtrsp\Modules\Seo\SeoInit, booted unconditionally from
		// ModulesInit — they are analysis channels, not schema output, and must
		// remain available when the Schema module is disabled.

		// AI schema: FAQ suggestion in block editor (Pro feature).
		( new ProFaqSuggestion() )->register_hooks();

		// AI schema: Cron batch auto-generation (Pro feature).
		( new CronBatch() )->register_hooks();

		// AI schema: save manually edited schema (Pro feature, own REST route).
		( new SchemaEditController() )->register_hooks();

		// AI schema: FluentCart product data extraction (Pro feature).
		add_filter( 'rtrs_ai_extract_fluentcart_product_data', [ ProFluentCartExtractor::class, 'extract_fluentcart_product_data' ], 10, 2 );

		// AI schema: FluentCart product schema filling (Pro feature).
		// Priority 11 to run after ProProductExtractor::fill_product (priority 10).
		add_filter( 'rtrs_ai_fill_product_schema', [ ProFluentCartExtractor::class, 'fill_product' ], 11, 5 );

		// AI schema: SureCart product data extraction (Pro feature).
		add_filter( 'rtrs_ai_extract_surecart_product_data', [ ProSureCartExtractor::class, 'extract_surecart_product_data' ], 10, 2 );

		// AI schema: SureCart product schema filling (Pro feature).
		// Priority 12 to run after FluentCart fill_product (priority 11).
		add_filter( 'rtrs_ai_fill_product_schema', [ ProSureCartExtractor::class, 'fill_product' ], 12, 5 );

		// AI schema: Merge Product + SoftwareApplication into combined @type array.
		add_filter( 'rtrs_ai_generated_schemas', [ ProProductExtractor::class, 'merge_product_software_application' ], 10, 2 );

		// AI schema: Normalize SoftwareApplication offers (convert multiple Offers to AggregateOffer).
		// Priority 11 to run after merge_product_software_application (priority 10).
		add_filter( 'rtrs_ai_generated_schemas', [ ProProductExtractor::class, 'normalize_software_application_offers' ], 11, 2 );
	}

	/**
	 * Run the full multi-criteria schema evaluation (Pro).
	 *
	 * @param array $default   Default (dummy) evaluation from free plugin.
	 * @param array $full_graph The full @graph array.
	 *
	 * @return array Real evaluation result.
	 */
	public static function evaluate_schema( $default, $full_graph ) {
		$evaluator = new SchemaEvaluator();

		return $evaluator->evaluate( $full_graph );
	}


}
