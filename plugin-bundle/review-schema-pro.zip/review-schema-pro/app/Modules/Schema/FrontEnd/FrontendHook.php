<?php
/**
 * Main FrontendHook  Class.
 *
 * The main class that initiates and runs the plugin.
 *
 * @package  review-schema-pro
 *
 * @since    1.0.0
 */

namespace Rtrsp\Modules\Schema\FrontEnd;

use FluentCart\App\Helpers\Helper;
use Rtrs\Modules\Schema\Helpers\SchemaFns;
use Rtrs\Modules\Schema\Models\Schema;
use Rtrsp\Helpers\FnsPro;
use Rtrs\Helpers\Functions;
use Rtrsp\Traits\SingletonTrait;
use Rtrs\Modules\Review\Helpers\ReviewFns;


/**
 * FrontendHook class
 */
class FrontendHook {
	/**
	 * Singletone.
	 */
	use SingletonTrait;

	/**
	 * Shared schema entries (return policy, shipping) to output at graph level.
	 *
	 * @var array
	 */
	private $shared_schema_entries = [];

	/**
	 * Initialize hooks
	 *
	 * @return void
	 */
	private function __construct() {
		add_filter( 'rtrs_schema_graph_data', [ $this, 'archive_page_schema_output' ], 14 );
		add_filter( 'rtrs_schema_graph_data', [ $this, 'maybe_merge_product_software_schema' ], 99 );
		add_filter( 'rtseo_snippet_add_more_schema_output', [ &$this, 'schema_output' ], 10, 4 );
		add_filter( 'rtrs_custom_rich_snippet', [ $this, 'custom_rich_snippet' ], 15, 2 );
		add_filter( 'rtseo_snippet_add_more_auto_schema_output', [ $this, 'auto_schema_rich_snippet' ], 15, 5 );
	}
	/**
	 * Generate schema output for archive pages.
	 *
	 * Handles WooCommerce, Classified Listing, and standard WordPress archives.
	 *
	 * @param  array $schemaOutput  Existing schema output array.
	 *
	 * @return array Modified schema output array.
	 * @since 1.0.0
	 */
	public function archive_page_schema_output( $schemaOutput ) {
		$schema = new Schema();
		// Detect archive type.
		$archive_type = $this->detect_archive_type();

		if ( ! $archive_type ) {
			return $schemaOutput;
		}

		// Check if schema generation is enabled for this archive type.
		$settings_schema = get_option( 'rtrs_schema_archive_settings' );

		if ( ! $this->is_archive_schema_enabled( $archive_type, $settings_schema ) ) {
			return $schemaOutput;
		}

		// Determine the archive URL and name.
		$archive_info = $this->get_archive_info( $archive_type );

		if ( empty( $archive_info['url'] ) ) {
			return $schemaOutput;
		}

		$archive_url = esc_url( $archive_info['url'] );

		// Build CollectionPage schema.
		$archive_data = [
			'@type'      => 'CollectionPage',
			'@id'        => trailingslashit( $archive_url ) . '#webpage',
			'url'        => $archive_url,
			'name'       => $archive_info['name'],
			'breadcrumb' => [ '@id' => trailingslashit( $archive_url ) . '#breadcrumb' ],
			'isPartOf'   => [ '@id' => trailingslashit( home_url( '#website' ) ) ],
			'publisher'  => [ '@id' => $schema->get_site_schema_id() ],
		];

		if ( ! empty( $archive_info['description'] ) ) {
			$archive_data['description'] = $archive_info['description'];
		}

		// Determine item @type based on archive type.
		$item_type = in_array( $archive_type, [ 'product', 'classified' ], true ) ? 'Product' : 'Article';

		// Build query and collect items.
		$items         = [];
		$archive_query = $this->get_archive_query( $archive_type );
		$custom_query  = $archive_query !== $GLOBALS['wp_query'];

		if ( $archive_query->have_posts() ) {
			$position = 1;

			while ( $archive_query->have_posts() ) {
				$archive_query->the_post();

				$item = [
					'@type' => $item_type,
					'url'   => get_permalink(),
					'name'  => get_the_title(),
				];

				$thumbnail = get_the_post_thumbnail_url( get_the_ID(), 'full' );
				if ( $thumbnail ) {
					$item['image'] = esc_url( $thumbnail );
				}

				$items[] = [
					'@type'    => 'ListItem',
					'position' => $position++,
					'item'     => $item,
				];
			}

			if ( $custom_query ) {
				wp_reset_postdata();
			}
		}

		// Assemble mainEntity ItemList.
		$archive_data['mainEntity'] = [
			'@type'           => 'ItemList',
			'numberOfItems'   => count( $items ),
			'itemListElement' => $items,
		];

		$schemaOutput[] = apply_filters( 'rtseo_archive_page', $archive_data );

		return $schemaOutput;
	}

	/**
	 * Detect the current archive type.
	 *
	 * @return string|null Archive type or null if not an archive page.
	 */
	private function detect_archive_type() {
		// WooCommerce shop or product taxonomy.
		if ( Functions::is_plugin_active( 'woocommerce/woocommerce.php' ) && is_shop() ) {
			return 'product';
		}

		if ( is_tax( 'product_cat' ) || is_tax( 'product_tag' ) || is_tax( 'download_category' ) || is_tax( 'download_tag' ) ) {
			return 'product';
		}

		// Classified Listing.
		if ( Functions::is_plugin_active( 'classified-listing/classified-listing.php' ) && \Rtcl\Helpers\Functions::is_listings() ) {
			return 'classified';
		}

		if ( is_tax( 'rtcl_category' ) || is_tax( 'rtcl_location' ) ) {
			return 'classified';
		}

		// Blog home.
		if ( is_home() ) {
			return 'blog';
		}

		// Standard taxonomy archives.
		if ( is_category() || is_tag() || is_tax() ) {
			return 'taxonomy';
		}

		return null;
	}

	/**
	 * Check if schema is enabled for the given archive type.
	 *
	 * @param  string      $archive_type  Archive type.
	 * @param  array|false $settings_schema  Schema settings.
	 *
	 * @return bool
	 */
	private function is_archive_schema_enabled( $archive_type, $settings_schema ) {
		if ( ! is_array( $settings_schema ) ) {
			return false;
		}

		switch ( $archive_type ) {
			case 'product':
				return isset( $settings_schema['product_archive'] ) && 'yes' === $settings_schema['product_archive'];
			case 'classified':
				return isset( $settings_schema['cl_archive'] ) && 'yes' === $settings_schema['cl_archive'];
			case 'blog':
			case 'taxonomy':
				return isset( $settings_schema['archive'] ) && 'yes' === $settings_schema['archive'];
			default:
				return false;
		}
	}

	/**
	 * Get archive URL, name, and description.
	 *
	 * @param  string $archive_type  Archive type.
	 *
	 * @return array{url: string, name: string, description: string}
	 */
	private function get_archive_info( $archive_type ) {
		$category = get_queried_object();

		// Taxonomy term archive (category, tag, product_cat, rtcl_category, etc.).
		if ( is_object( $category ) && isset( $category->term_id ) ) {
			$term_link = get_term_link( absint( $category->term_id ) );

			return [
				'url'         => is_wp_error( $term_link ) ? '' : $term_link,
				'name'        => single_cat_title( '', false ) . esc_html__( ' Category', 'review-schema-pro' ),
				'description' => wp_strip_all_tags( $category->description ?? '' ),
			];
		}

		// Blog home page.
		if ( 'blog' === $archive_type ) {
			return [
				'url'         => home_url( '/' ),
				'name'        => get_bloginfo( 'name' ),
				'description' => get_bloginfo( 'description', 'display' ),
			];
		}

		// Classified Listing main page.
		if ( 'classified' === $archive_type ) {
			$listings_page_id = \Rtcl\Helpers\Functions::get_page_id( 'listings' );

			return [
				'url'         => get_permalink( $listings_page_id ),
				'name'        => get_the_title( $listings_page_id ),
				'description' => '',
			];
		}

		// WooCommerce shop page.
		if ( 'product' === $archive_type && function_exists( 'wc_get_page_id' ) ) {
			$shop_id = wc_get_page_id( 'shop' );

			return [
				'url'         => get_permalink( $shop_id ),
				'name'        => get_the_title( $shop_id ),
				'description' => '',
			];
		}

		return [
			'url'         => '',
			'name'        => '',
			'description' => '',
		];
	}

	/**
	 * Get the WP_Query for the current archive.
	 *
	 * @param  string $archive_type  Archive type.
	 *
	 * @return \WP_Query
	 */
	private function get_archive_query( $archive_type ) {
		$per_page = get_option( 'posts_per_page' );
		$paged    = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;
		$taxonomy = get_query_var( 'taxonomy' );

		// WooCommerce product taxonomy.
		if ( 'product' === $archive_type && ( 'product_cat' === $taxonomy || 'product_tag' === $taxonomy ) ) {
			return new \WP_Query(
				[
					'post_type'      => 'product',
					'posts_per_page' => $per_page,
					'paged'          => $paged,
					'tax_query'      => [
						[
							'taxonomy' => $taxonomy,
							'field'    => 'slug',
							'terms'    => get_query_var( 'term' ),
						],
					],
				],
			);
		}

		// Classified Listing main page.
		if ( 'classified' === $archive_type && ! is_tax() ) {
			return new \WP_Query(
				[
					'post_type'      => 'rtcl_listing',
					'posts_per_page' => $per_page,
					'paged'          => $paged,
				],
			);
		}

		// Standard archives — use the main query.
		global $wp_query;

		return $wp_query;
	}

	/**
	 * Modify the rich snippet output for a given post.
	 *
	 * This function retrieves custom snippet code from post meta and incorporates it into
	 * the rich snippet if available. The retrieved code is sanitized before being output.
	 *
	 * @param  string $rich_snippet  The current rich snippet content.
	 * @param  int    $post_id  The post ID for which the snippet is being generated.
	 *
	 * @return string The modified rich snippet content.
	 */
	public function custom_rich_snippet( $rich_snippet, $post_id ) {
		$snippet_code_meta_value = get_post_meta( $post_id, '_rtrs_generated_snippet_code', true );
		if ( ! empty( $snippet_code_meta_value ) ) {
			ob_start();
			$arr = [
				'br'     => [],
				'p'      => [],
				'strong' => [],
			];
			?>
			<script type="application/ld+json"> <?php echo wp_kses( $snippet_code_meta_value, $arr ); ?></script>
			<?php
			$rich_snippet = ob_get_clean();
		}

		return $rich_snippet;
	}

	/**
	 * schema output.
	 *
	 * @return array
	 */
	public function auto_schema_rich_snippet( $schema_graph_list, $schemaCat, $metaData, $post, $schemaObj ) {
		if ( ! $schemaCat ) {
			return $schema_graph_list;
		}

		$helper  = new Functions();
		$post_id = $post->ID;
		switch ( $schemaCat ) {
			case 'job_posting':
				$job = $this->get_job_posting_auto_schema( $post, $schemaObj, $helper );

				// Final validation (Google requires title + description).
				if ( ! empty( $job['title'] ) && ! empty( $job['description'] ) ) {
					$schema_graph_list[] = apply_filters(
						'rtseo_auto_schema_snippet_job_posting',
						$job,
						$metaData,
					);
				}
				break;

			case 'recipe':
				$recipe              = $this->get_recipe_auto_schema( $post, $schemaObj, $helper );
				$schema_graph_list[] = apply_filters( 'rtseo_auto_schema_snippet_recipe', $recipe, $metaData );
				break;

			case 'Restaurant':
				$restaurant          = $this->get_restaurant_auto_schema( $post, $schemaObj, $helper );
				$schema_graph_list[] = apply_filters( 'rtseo_auto_schema_snippet_restaurant', $restaurant, $metaData );
				break;

			case 'software_app':
				$software            = $this->get_software_app_auto_schema( $post, $schemaObj, $helper );
				$schema_graph_list[] = apply_filters( 'rtseo_auto_schema_snippet_software_application', $software, $metaData );
				break;

			case 'course':
				if ( $post->post_type == 'lp_course' || in_array( 'learnpress/learnpress.php', apply_filters( 'active_plugins', get_option( 'active_plugins', [] ) ), true ) ) {
					$course_data = $this->get_learn_press_course_auto_schema( $post, $schemaObj, $helper );
				} elseif ( $post->post_type == 'courses' || in_array( 'tutor/tutor.php', apply_filters( 'active_plugins', get_option( 'active_plugins', [] ) ), true ) ) {
					$course_data = $this->get_tutor_lms_course_auto_schema( $post, $schemaObj, $helper );
				} elseif ( $post->post_type == 'academy_courses' || in_array( 'academy/academy.php', apply_filters( 'active_plugins', get_option( 'active_plugins', [] ) ), true ) ) {
					$course_data = $this->get_academy_lms_course_auto_schema( $post, $schemaObj, $helper );
				} elseif ( $post->post_type == 'course' || in_array( 'lifterlms/lifterlms.php', apply_filters( 'active_plugins', get_option( 'active_plugins', [] ) ), true ) ) {
					$course_data = $this->get_lifter_lms_course_auto_schema( $post, $schemaObj, $helper );
				} else {
					$course_data = [
						'course'   => [],
						'metaData' => [],
					];
				}

				$schema_graph_list[] = apply_filters( 'rtseo_auto_schema_snippet_course', $course_data['course'], $course_data['metaData'] );
				break;

			case 'product':
				$markup = [];
				if ( 'download' == $post->post_type && function_exists( 'EDD' ) ) {
					$markup = $this->get_edd_product_auto_schema( $post, $schemaObj );
				} elseif ( 'rtcl_listing' == $post->post_type && defined( 'RTCL_VERSION' ) ) {
					$markup = $this->get_rtcl_listing_product_auto_schema( $post, $schemaObj );
				} elseif ( 'fluent-products' == $post->post_type && defined( 'FLUENTCART_PLUGIN_PATH' ) ) {
					$markup = $this->get_fluentcart_product_auto_schema( $post, $schemaObj );
				} elseif ( 'sc_product' == $post->post_type && defined( 'SURECART_PLUGIN_FILE' ) ) {
					$markup = $this->get_surecart_product_auto_schema( $post, $schemaObj );
				} elseif ( 'wpdmpro' == $post->post_type && defined( 'WPDM_VERSION' ) ) {
					$markup = $this->get_download_manager_product_auto_schema( $post, $schemaObj );
				} else {
					$markup = $this->get_woocommerce_product_auto_schema( $schemaObj, $helper );
				}
				if ( ! empty( $markup ) ) {
					$schema_graph_list[] = apply_filters( 'rtseo_snippet_product', $markup, $metaData );
				}

				// Add shared return policy & shipping entries at graph level.
				foreach ( $this->shared_schema_entries as $shared ) {
					$schema_graph_list[] = $shared;
				}
				$this->shared_schema_entries = [];

				break;
			default:
				break;
		}

		return $schema_graph_list;
	}

	/**
	 * Generate and filter schema output.
	 *
	 * Builds the schema markup output based on the schema category
	 * and provided metadata. The generated output can be modified
	 * using the `rtseo_snippet_others_schema_output` filter.
	 *
	 * @param  array  $schemaOutput  Existing schema output.
	 * @param  string $schemaCat  Schema category data.
	 * @param  array  $metaData  Schema metadata.
	 *
	 * @return string Modified schema output.
	 */
	public function schema_output( $schemaOutput, $schemaCat, $metaData, $schemaObject ) {
		$helper         = new Functions();
		$post_id        = get_the_ID();
		$site_schema_id = $schemaObject->get_site_schema_id();

		$schema_key_id = $metaData['schema_id'] ?? 0;
		switch ( $schemaCat ) {
			case 'special_announcement':
				$schemaOutput[] = $this->get_special_announcement_schema( $metaData, $site_schema_id, $schemaObject, $helper, $schema_key_id );
				break;
			case 'image_license':
				$schemaOutput[] = $this->get_image_license_schema( $metaData, $schemaObject, $helper, $schema_key_id );
				break;
			case 'software_app':
				$schemaOutput = array_merge( $schemaOutput, $this->get_software_app_schema( $metaData, $schemaObject, $helper, $schema_key_id ) );
				break;
			case 'recipe':
				$schemaOutput[] = $this->get_recipe_schema( $metaData, $schemaObject, $helper, $schema_key_id );
				$recipe_review  = $this->get_recipe_review_schema( $metaData, $schemaObject, $helper, $schema_key_id );
				if ( ! empty( $recipe_review ) ) {
					$schemaOutput[] = $recipe_review;
				}
				break;
			case 'job_posting':
				$schemaOutput[] = $this->get_job_posting_schema( $metaData, $site_schema_id, $schemaObject, $helper, $schema_key_id );
				break;
			case 'course':
				$schemaOutput[] = $this->get_course_schema( $metaData, $schemaObject, $helper, $schema_key_id );
				$course_review  = $this->get_course_review_schema( $metaData, $schemaObject, $helper, $schema_key_id );
				if ( ! empty( $course_review ) ) {
					$schemaOutput[] = $course_review;
				}
				break;
			case 'real_state_listing':
				$schemaOutput[]   = $this->get_real_state_listing_schema( $metaData, $schemaObject, $helper, $schema_key_id );
				$real_state_video = $this->get_real_state_video_schema( $metaData, $schemaObject, $helper, $schema_key_id );
				if ( ! empty( $real_state_video ) ) {
					$schemaOutput[] = $real_state_video;
				}
				$real_state_audio = $this->get_real_state_audio_schema( $metaData, $schemaObject, $helper, $schema_key_id );
				if ( ! empty( $real_state_audio ) ) {
					$schemaOutput[] = $real_state_audio;
				}
				break;
			case 'book':
				$schemaOutput[] = $this->get_book_schema( $metaData, $schemaObject, $helper, $schema_key_id );
				$book_review    = $this->get_book_review_schema( $metaData, $schemaObject, $helper, $schema_key_id );
				if ( ! empty( $book_review ) ) {
					$schemaOutput[] = $book_review;
				}
				break;
			case 'product':
				$schemaOutput[] = $this->get_product_schema( $metaData, $schemaObject, $helper, $schema_key_id );
				$product_review = $this->get_product_review_schema( $metaData, $schemaObject, $helper, $schema_key_id );
				if ( ! empty( $product_review ) ) {
					$schemaOutput[] = $product_review;
				}
				break;
			case 'Restaurant':
				$schemaOutput[] = $this->get_restaurant_schema( $metaData, $schemaObject, $helper, $schema_key_id );
				break;
			case 'Dataset':
				$schemaOutput[] = $this->get_dataset_schema( $metaData, $schemaObject, $helper, $schema_key_id );
				break;
			case 'DiscussionForumPosting':
				$schemaOutput[] = $this->get_discussion_forum_posting_schema( $metaData, $schemaObject, $helper, $schema_key_id, $post_id, $site_schema_id );
				break;
			case 'PodcastEpisode':
				$schemaOutput[] = $this->get_podcast_episode_schema( $metaData, $schemaObject, $helper, $schema_key_id, $site_schema_id );
				break;
			case 'tv_series':
				$schemaOutput[] = $this->get_tv_series_schema( $metaData, $schemaObject, $helper, $schema_key_id, $site_schema_id );
				break;
			case 'collection_page':
				$schemaOutput[] = $this->get_collection_page_schema( $metaData, $schemaObject, $helper, $schema_key_id );
				break;
			case 'vacation_rental':
				$schemaOutput[] = $this->get_vacation_rental_schema( $metaData, $schemaObject, $helper, $schema_key_id, $site_schema_id );
				break;
			case 'vehicle_listing':
				$schemaOutput[] = $this->get_vehicle_listing_schema( $metaData, $schemaObject, $helper, $schema_key_id, $site_schema_id );
				break;
			case 'TaxiService':
				$schemaOutput[] = $this->get_taxi_service_schema( $metaData, $schemaObject, $helper, $schema_key_id, $site_schema_id );
				break;
			case 'touristattraction':
				$schemaOutput[] = $this->get_touristattraction_schema( $metaData, $schemaObject, $helper, $schema_key_id, $site_schema_id );
				break;
			default:
		}
		return $schemaOutput;
	}

	/**
	 * Merge Product and SoftwareApplication into one entry if both exist.
	 * Runs after the full switch so both types are guaranteed to be present.
	 *
	 * @param  array $schemaOutput Full schema output array.
	 *
	 * @return array Schema output with merged entry if applicable.
	 */
	public function maybe_merge_product_software_schema( array $schemaOutput ): array {
		$product_index  = SchemaFns::find_schema_index_by_type( $schemaOutput, 'Product' );
		$software_index = SchemaFns::find_schema_index_by_type( $schemaOutput, 'SoftwareApplication' );
		if ( false === $product_index || false === $software_index ) {
			return $schemaOutput;
		}

		$software = $schemaOutput[ $software_index ];
		$product  = $schemaOutput[ $product_index ];

		// Collect review @id references from both schemas.
		$product_review_id  = $product['review']['@id'] ?? '';
		$software_review_id = $software['review']['@id'] ?? '';

		// Remove aggregateRating from SoftwareApplication — Product's takes precedence.
		unset( $software['review'], $software['aggregateRating'] );
		unset( $product['review'] );

		$merged          = array_merge( $software, $product );
		$merged['@type'] = [ 'Product', 'SoftwareApplication' ];
		$merged['@id']   = $product['@id'] ?? $software['@id'] ?? '';

		// Remove both originals.
		$keep_indexes = array_diff( array_keys( $schemaOutput ), [ $product_index, $software_index ] );
		$result       = array_values( array_intersect_key( $schemaOutput, array_flip( $keep_indexes ) ) );

		// Deduplicate review graph items by author + reviewBody.
		$remove_review_id = $this->deduplicate_review_graph_items( $result, $product_review_id, $software_review_id );

		// Remove the duplicate review graph item if found.
		if ( $remove_review_id ) {
			$result = array_values(
				array_filter(
					$result,
					function ( $item ) use ( $remove_review_id ) {
						return ! isset( $item['@id'] ) || $item['@id'] !== $remove_review_id;
					}
				)
			);
		}

		// Build merged review reference(s).
		$review_refs = [];
		if ( $product_review_id && $product_review_id !== $remove_review_id ) {
			$review_refs[] = [ '@id' => $product_review_id ];
		}
		if ( $software_review_id && $software_review_id !== $remove_review_id ) {
			$review_refs[] = [ '@id' => $software_review_id ];
		}

		if ( count( $review_refs ) === 1 ) {
			$merged['review'] = $review_refs[0];
		} elseif ( count( $review_refs ) > 1 ) {
			$merged['review'] = $review_refs;
		}
		$result[] = $merged;

		return $result;
	}

	/**
	 * Deduplicate review graph items by comparing author and reviewBody.
	 *
	 * Resolves @id references to actual Review graph items in the schema output
	 * and checks if they have the same author and reviewBody content.
	 *
	 * @param array  $schema_items      The schema output items.
	 * @param string $product_review_id  Product review @id.
	 * @param string $software_review_id SoftwareApplication review @id.
	 *
	 * @return string The @id of the duplicate review to remove, or empty string.
	 */
	private function deduplicate_review_graph_items( $schema_items, $product_review_id, $software_review_id ) {
		if ( empty( $product_review_id ) || empty( $software_review_id ) ) {
			return '';
		}

		$product_review  = null;
		$software_review = null;

		foreach ( $schema_items as $item ) {
			if ( ! isset( $item['@id'] ) ) {
				continue;
			}
			if ( $item['@id'] === $product_review_id ) {
				$product_review = $item;
			} elseif ( $item['@id'] === $software_review_id ) {
				$software_review = $item;
			}
		}

		if ( ! $product_review || ! $software_review ) {
			return '';
		}

		// Compare author name.
		$product_author  = $product_review['author']['name'] ?? '';
		$software_author = $software_review['author']['name'] ?? '';
		$same_author     = strtolower( trim( $product_author ) ) === strtolower( trim( $software_author ) );

		// Compare reviewBody.
		$product_body  = $product_review['reviewBody'] ?? '';
		$software_body = $software_review['reviewBody'] ?? '';
		$same_body     = strtolower( trim( $product_body ) ) === strtolower( trim( $software_body ) );

		// If same author and same body, remove the SoftwareApplication review.
		if ( $same_author && $same_body ) {
			return $software_review_id;
		}

		return '';
	}

	/**
	 * Get JobPosting auto schema markup.
	 *
	 * @param \WP_Post  $post      The post object.
	 * @param object    $schemaObj The schema object.
	 * @param Functions $helper    The helper object.
	 *
	 * @return array JobPosting schema markup.
	 */
	private function get_job_posting_auto_schema( $post, $schemaObj, $helper ) {
		$post_id        = $post->ID;
		$site_schema_id = $schemaObj->get_site_schema_id();
		$job            = [
			'@type' => 'JobPosting',
			'@id'   => $schemaObj->get_id_with_hash( 'job_posting0' ),
			'title' => $helper->sanitizeOutPut( $post->post_title ),
			'url'   => get_permalink( $post_id ),
		];

		// Description (required by Google).
		if ( ! empty( $post->post_content ) ) {
			$job['description'] = $helper->sanitizeOutPut(
				wpautop( wp_strip_all_tags( $post->post_content ) ),
				'textarea',
			);
		}

		// Date posted.
		$job['datePosted'] = get_the_date( DATE_W3C, $post_id );

		// Property validThrough fallback (30 days from publish).
		$published = get_the_modified_date( 'U', $post_id );
		if ( $published ) {
			$job['validThrough'] = gmdate(
				DATE_W3C,
				strtotime( '+30 days', $published ),
			);
		}

		// Employment type (safe default).
		$job['employmentType'] = 'FULL_TIME';

		// Hiring organization (site business).
		if ( ! empty( $site_schema_id ) ) {
			$job['hiringOrganization'] = [
				'@type' => 'Organization',
				'@id'   => $site_schema_id,
			];
		}

		// Job location (from site address).
		$job['jobLocation'] = [
			'@type' => 'Place',
			'@id'   => $site_schema_id,
		];

		// Featured image (company logo pattern).
		$image_id = get_post_thumbnail_id( $post->ID );
		if ( ! empty( $image_id ) ) {
			$img          = $helper->imageInfo( absint( $image_id ) );
			$job['image'] = [
				'@type'  => 'ImageObject',
				'url'    => $helper->sanitizeOutPut( $img['url'], 'url' ),
				'height' => $img['height'],
				'width'  => $img['width'],
			];
		}

		// Base salary from post type settings.
		$post_type          = $post->post_type;
		$post_type_settings = SchemaFns::getPostTypeSettings();
		$salary             = $post_type_settings[ $post_type . '_job_salary' ] ?? '';
		if ( ! empty( $salary ) ) {
			$currency = $post_type_settings[ $post_type . '_job_salary_currency' ] ?? 'USD';
			$unit     = $post_type_settings[ $post_type . '_job_salary_unit' ] ?? 'YEAR';

			$job['baseSalary'] = [
				'@type'    => 'MonetaryAmount',
				'currency' => sanitize_text_field( $currency ),
				'value'    => [
					'@type'    => 'QuantitativeValue',
					'value'    => (float) $salary,
					'unitText' => sanitize_text_field( $unit ),
				],
			];
		}

		// WebPage relation.
		$job['mainEntityOfPage'] = [
			'@type' => 'WebPage',
			'@id'   => $schemaObj->get_id_with_hash( 'webpage' ),
		];

		return $job;
	}

	/**
	 * Get Recipe auto schema markup.
	 *
	 * @param \WP_Post  $post      The post object.
	 * @param object    $schemaObj The schema object.
	 * @param Functions $helper    The helper object.
	 *
	 * @return array Recipe schema markup.
	 */
	private function get_recipe_auto_schema( $post, $schemaObj, $helper ) {
		$post_id        = $post->ID;
		$site_schema_id = $schemaObj->get_site_schema_id();
		$content        = wp_strip_all_tags( $post->post_content );
		$content        = trim( preg_replace( '/\s+/', ' ', $content ) );

		$recipe = [
			'@type' => 'Recipe',
			'@id'   => $schemaObj->get_id_with_hash( 'recipe0' ),
			'name'  => $helper->sanitizeOutPut( $post->post_title ),
			'url'   => get_permalink( $post_id ),
		];

		// Description (REQUIRED).
		$recipe['description'] = ! empty( $post->post_excerpt )
				? $helper->sanitizeOutPut( $post->post_excerpt, 'textarea' )
				: wp_trim_words( $content, 40, '' );

		// Featured image (REQUIRED).
		$image_id = get_post_thumbnail_id( $post->ID );
		if ( ! empty( $image_id ) ) {
			$img             = $helper->imageInfo( absint( $image_id ) );
			$recipe['image'] = [
				'@type'  => 'ImageObject',
				'url'    => $helper->sanitizeOutPut( $img['url'], 'url' ),
				'height' => $img['height'],
				'width'  => $img['width'],
			];
		}

		// Author.
		$author = get_the_author_meta( 'display_name', $post->post_author );
		if ( ! empty( $author ) ) {
			$author_url       = trailingslashit( get_author_posts_url( $post->post_author ) );
			$recipe['author'] = [
				'@type' => 'Person',
				'@id'   => $author_url . '#person',
				'name'  => $helper->sanitizeOutPut( $author ),
				'url'   => $author_url,
			];
		}

		// Dates.
		$recipe['datePublished'] = get_the_date( DATE_W3C, $post_id );
		$recipe['dateModified']  = get_the_modified_date( DATE_W3C, $post_id );

		// Publisher.
		$recipe['publisher'] = [
			'@id' => $site_schema_id,
		];

		// WebPage relation.
		$recipe['mainEntityOfPage'] = [
			'@type' => 'WebPage',
			'@id'   => $schemaObj->get_id_with_hash( 'webpage' ),
		];

		return $recipe;
	}

	/**
	 * Get Restaurant auto schema markup.
	 *
	 * @param \WP_Post  $post      The post object.
	 * @param object    $schemaObj The schema object.
	 * @param Functions $helper    The helper object.
	 *
	 * @return array Restaurant schema markup.
	 */
	private function get_restaurant_auto_schema( $post, $schemaObj, $helper ) {
		$post_id            = $post->ID;
		$post_type          = $post->post_type;
		$schema_settings    = get_option( 'rtrs_schema_settings' );
		$post_type_settings = SchemaFns::getPostTypeSettings();
		$site_schema_id     = $schemaObj->get_site_schema_id();
		$restaurant         = [
			'@type' => 'Restaurant',
			'@id'   => $schemaObj->get_id_with_hash( 'Restaurant0' ),
			'name'  => $helper->sanitizeOutPut( $post->post_title ),
			'url'   => get_permalink( $post_id ),
		];

		// Description.
		if ( ! empty( $post->post_excerpt ) ) {
			$restaurant['description'] = $helper->sanitizeOutPut( $post->post_excerpt, 'textarea' );
		} else {
			$restaurant['description'] = wp_trim_words( wp_strip_all_tags( $post->post_content ), 30, '' );
		}
		if ( ! empty( $schema_settings['priceRange'] ) ) {
			$restaurant['priceRange'] = $helper->sanitizeOutPut( $schema_settings['priceRange'] );
		}
		if ( ! empty( $schema_settings['telephone'] ) ) {
			$restaurant['telephone'] = $helper->sanitizeOutPut( $schema_settings['telephone'] );
		}
		// Featured image.
		$image_id = get_post_thumbnail_id( $post->ID );
		if ( ! empty( $image_id ) ) {
			$img                 = $helper->imageInfo( absint( $image_id ) );
			$restaurant['image'] = [
				'@type'  => 'ImageObject',
				'url'    => $helper->sanitizeOutPut( $img['url'], 'url' ),
				'height' => $img['height'],
				'width'  => $img['width'],
			];
		}

		// Cuisine.

		$servesCuisine = get_post_meta( $post->ID, 'restaurant_cuisine', true );
		if ( $servesCuisine ) {
			$servesCuisine = sanitize_text_field( $servesCuisine );
		} else {
			$servesCuisine = $post_type_settings[ $post_type . '_servesCuisine' ] ?? '';
		}
		$restaurant['servesCuisine'] = sanitize_text_field( $servesCuisine );
		// Publisher.
		$restaurant['address'] = [
			'@id' => $site_schema_id . '-address-0',
		];
		$restaurant['geo']     = [
			'@id' => $site_schema_id . '-geocircle',
		];

		// WebPage relation.
		$restaurant['mainEntityOfPage'] = [
			'@type' => 'WebPage',
			'@id'   => $schemaObj->get_id_with_hash( 'webpage' ),
		];

		return $restaurant;
	}

	/**
	 * Get SoftwareApplication auto schema markup.
	 *
	 * @param \WP_Post  $post      The post object.
	 * @param object    $schemaObj  The schema object.
	 * @param Functions $helper     The helper object.
	 *
	 * @return array SoftwareApplication schema data.
	 */
	private function get_software_app_auto_schema( $post, $schemaObj, $helper ) {
		$post_id        = $post->ID;
		$site_schema_id = $schemaObj->get_site_schema_id();

		$software = [
			'@type'               => 'SoftwareApplication',
			'@id'                 => $schemaObj->get_id_with_hash( 'software_app0' ),
			'name'                => $helper->sanitizeOutPut( $post->post_title ),
			'url'                 => get_permalink( $post_id ),
			'applicationCategory' => 'BusinessApplication',
			'operatingSystem'     => 'Web',
		];

		// Description.
		if ( ! empty( $post->post_excerpt ) ) {
			$software['description'] = $helper->sanitizeOutPut( $post->post_excerpt, 'textarea' );
		} elseif ( ! empty( $post->post_content ) ) {
			$software['description'] = $helper->sanitizeOutPut(
				Functions::filter_content( $post->post_content, 200 ),
				'textarea',
			);
		}

		// Featured image.
		$image_id = get_post_thumbnail_id( $post_id );
		if ( ! empty( $image_id ) ) {
			$img               = $helper->imageInfo( absint( $image_id ) );
			$software['image'] = [
				'@type'  => 'ImageObject',
				'url'    => $helper->sanitizeOutPut( $img['url'], 'url' ),
				'height' => $img['height'],
				'width'  => $img['width'],
			];
		}

		// Publisher / organization.
		if ( ! empty( $site_schema_id ) ) {
			$software['publisher'] = [
				'@id' => $site_schema_id,
			];
		}

		// WebPage relation.
		$software['mainEntityOfPage'] = [
			'@type' => 'WebPage',
			'@id'   => $schemaObj->get_id_with_hash( 'webpage' ),
		];

		/**
		 * Detect software pricing (Free / Pro) and generate Offer schema.
		 */
		$is_paid  = false;
		$price    = null;
		$currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD';
		$avail    = 'https://schema.org/InStock';

		// 1. Dynamic PricingCollector.
		if ( class_exists( '\Rtrs\Supports\Pricing\PricingCollector' ) ) {
			$collector    = \Rtrs\Supports\Pricing\PricingCollector::getInstance();
			$pricing_data = $collector->resolve( $post_id );

			if ( $pricing_data && $pricing_data->has_price() ) {
				$is_paid  = (float) $pricing_data->get_price() > 0;
				$price    = $pricing_data->get_price();
				$currency = $pricing_data->get_price_currency();
				$avail    = $pricing_data->get_availability();
			}
		}

		// 2. WooCommerce linked product fallback.
		if ( ! $is_paid && function_exists( 'wc_get_product' ) ) {
			$product_id = get_post_meta( $post_id, '_related_product', true );
			if ( $product_id ) {
				$product = wc_get_product( $product_id );
				if ( $product && $product->get_price() !== '' ) {
					$is_paid  = true;
					$price    = $product->get_price();
					$currency = get_woocommerce_currency();
				}
			}
		}

		// 3. Content-based heuristic fallback.
		if ( ! $is_paid ) {
			$content = strtolower( wp_strip_all_tags( $post->post_title . ' ' . $post->post_content ) );
			if ( preg_match( '/\b(pro|premium|paid|license|upgrade|pricing)\b/', $content ) ) {
				$is_paid = true;
			}
		}

		// 4. Offer schema.
		$software['offers'] = [
			'@type'         => 'Offer',
			'price'         => $is_paid ? ( $price ?? '0' ) : '0',
			'priceCurrency' => $currency,
			'availability'  => $avail,
		];

		// 5. Aggregate rating.
		if ( Functions::isEnableReviewByPostType( get_post_type( $post_id ) ) ) {
			$total_rating = ReviewFns::getTotalRatings( $post_id );
			if ( $total_rating ) {
				$software['aggregateRating'] = [
					'@type'       => 'AggregateRating',
					'ratingValue' => (float) ReviewFns::getAvgRatings( $post_id, true ),
					'reviewCount' => $total_rating,
				];
			}
		} else {
			$native_ratings = ReviewFns::getNativeCommentRatings( $post_id );
			if ( $native_ratings ) {
				$software['aggregateRating'] = [
					'@type'       => 'AggregateRating',
					'ratingValue' => esc_attr( $native_ratings['average'] ),
					'reviewCount' => $native_ratings['total'],
				];
			}
		}

		return $software;
	}

	/**
	 * Get Course auto schema markup.
	 *
	 * @param \WP_Post  $post      The post object.
	 * @param object    $schemaObj The schema object.
	 * @param Functions $helper    The helper object.
	 *
	 * @return array Course schema data with 'course' and 'metaData' keys.
	 */
	private function get_learn_press_course_auto_schema( $post, $schemaObj, $helper ) {

		if ( ! in_array( 'learnpress/learnpress.php', apply_filters( 'active_plugins', get_option( 'active_plugins', [] ) ), true ) ) {
			return [
				'course'   => [],
				'metaData' => [],
			];
		}

		$site_schema_id = $schemaObj->get_site_schema_id();
		$post_meta      = get_post_meta( $post->ID );

		// Get price via LearnPress course object API.
		$price = '';
		if ( function_exists( 'learn_press_get_course' ) ) {
			$lp_course = learn_press_get_course( $post->ID );
			if ( $lp_course ) {
				$price = $lp_course->get_price();
			}
		}

		// Fallback to meta keys if API returned nothing.
		if ( empty( $price ) ) {
			$regular_price = $post_meta['_lp_regular_price'][0] ?? ( $post_meta['_lp_price'][0] ?? '' );
			$sale_price    = $post_meta['_lp_sale_price'][0] ?? '';
			$price         = $sale_price ? $sale_price : $regular_price;
		}

		$currency  = function_exists( 'learn_press_get_currency' ) ? learn_press_get_currency() : 'USD';
		$permalink = get_the_permalink( $post->ID );

		$metaData = [
			'price'         => $price ?: '',
			'priceCurrency' => $currency,
			'availability'  => $price ? 'https://schema.org/InStock' : '',
			'url'           => $permalink,
			'courseMode'    => 'Online',
		];

		$course_id = $schemaObj->get_id_with_hash( 'course0' );
		$course    = [
			'@type'    => 'Course',
			'@id'      => $course_id,
			'provider' => [
				'@id' => $site_schema_id,
			],
		];

		if ( ! empty( $post->post_title ) ) {
			$course['name'] = wp_specialchars_decode( sanitize_text_field( $post->post_title ), ENT_QUOTES );
		}

		$description = ! empty( $post->post_excerpt ) ? $post->post_excerpt : wp_strip_all_tags( $post->post_content );
		if ( ! empty( $description ) ) {
			$course['description'] = wp_specialchars_decode( sanitize_text_field( $description ), ENT_QUOTES );
		}

		$image_id = get_post_thumbnail_id( $post->ID );
		if ( ! empty( $image_id ) ) {
			$img             = $helper->imageInfo( absint( $image_id ) );
			$course['image'] = [
				'@type'  => 'ImageObject',
				'url'    => $helper->sanitizeOutPut( $img['url'], 'url' ),
				'height' => $img['height'],
				'width'  => $img['width'],
			];
		}

		if ( ! empty( $permalink ) ) {
			$course['url'] = $helper->sanitizeOutPut( $permalink, 'url' );
		}

		// Offers at Course level.
		if ( ! empty( $price ) && ! empty( $currency ) ) {
			$course['offers'] = [
				[
					'@type'         => 'Offer',
					'category'      => 'Paid',
					'price'         => number_format( (float) $price, 2, '.', '' ),
					'priceCurrency' => sanitize_text_field( $currency ),
					'availability'  => 'https://schema.org/InStock',
				],
			];
		} else {
			$course['offers'] = [
				[
					'@type'         => 'Offer',
					'category'      => 'Free',
					'price'         => '0.00',
					'priceCurrency' => sanitize_text_field( $currency ),
					'availability'  => 'https://schema.org/InStock',
				],
			];
		}

		// Educational level from LearnPress difficulty level.
		$course_level = $post_meta['_lp_level'][0] ?? '';
		if ( ! empty( $course_level ) && $course_level !== 'all' ) {
			$level_map = [
				'beginner'     => 'Beginner',
				'intermediate' => 'Intermediate',
				'expert'       => 'Advanced',
			];
			if ( isset( $level_map[ $course_level ] ) ) {
				$course['educationalLevel'] = $level_map[ $course_level ];
			}
		}

		// CourseInstance.
		$is_offline      = get_post_meta( $post->ID, '_lp_offline_course', true ) === 'yes';
		$course_instance = [
			'@type'      => 'CourseInstance',
			'courseMode' => $is_offline ? 'Onsite' : 'Online',
		];

		// Course workload from LearnPress duration meta (e.g., "10 week").
		$duration = $post_meta['_lp_duration'][0] ?? '';
		if ( ! empty( $duration ) ) {
			$workload = $this->convert_lp_duration_to_iso8601( $duration );
			if ( ! empty( $workload ) ) {
				$course_instance['courseWorkload'] = $workload;
			}
		}

		// Instructor from course author.
		$author_id = $post->post_author;
		if ( $author_id ) {
			$author_name = get_the_author_meta( 'display_name', $author_id );
			if ( $author_name ) {
				$course_instance['instructor'] = [
					'@type' => 'Person',
					'name'  => esc_html( $author_name ),
				];
			}
		}

		$course['hasCourseInstance'] = $course_instance;

		// Syllabus from LearnPress sections.
		if ( function_exists( 'learn_press_get_course' ) ) {
			$lp_course = learn_press_get_course( $post->ID );
			if ( $lp_course ) {
				$sections = $lp_course->get_sections( 'object' );
				if ( ! empty( $sections ) ) {
					$syllabus = [];
					foreach ( $sections as $section ) {
						$section_title = $section->get_title();
						if ( ! empty( $section_title ) ) {
							$syllabus_item = [
								'@type' => 'Syllabus',
								'name'  => wp_specialchars_decode( sanitize_text_field( $section_title ), ENT_QUOTES ),
							];
							$section_desc  = $section->get_description();
							if ( ! empty( $section_desc ) ) {
								$syllabus_item['description'] = wp_specialchars_decode( sanitize_text_field( wp_strip_all_tags( $section_desc ) ), ENT_QUOTES );
							}
							$syllabus[] = $syllabus_item;
						}
					}
					if ( ! empty( $syllabus ) ) {
						$course['syllabusSections'] = $syllabus;
					}
				}
			}
		}

		return [
			'course'   => $course,
			'metaData' => $metaData,
		];
	}

	/**
	 * Convert LearnPress duration string to ISO 8601 duration.
	 *
	 * LearnPress stores duration as e.g. "10 week", "5 day", "2 hour", "30 minute".
	 * Converts all units to PT (hours/minutes) format for best Google snippet display.
	 *
	 * @param string $duration LearnPress duration string.
	 *
	 * @return string ISO 8601 duration in PT format (e.g., "PT1680H", "PT120H", "PT2H", "PT30M").
	 */
	private function convert_lp_duration_to_iso8601( $duration ) {
		$duration = trim( $duration );
		if ( empty( $duration ) ) {
			return '';
		}

		$parts = preg_split( '/\s+/', $duration, 2 );
		$value = absint( $parts[0] );
		$unit  = isset( $parts[1] ) ? strtolower( rtrim( $parts[1], 's' ) ) : '';

		switch ( $unit ) {
			case 'week':
				return 'PT' . ( $value * 168 ) . 'H';
			case 'day':
				return 'PT' . ( $value * 24 ) . 'H';
			case 'hour':
				return 'PT' . $value . 'H';
			case 'minute':
				return 'PT' . $value . 'M';
			default:
				return 'PT' . $value . 'H';
		}
	}

	/**
	 * Get Tutor LMS Course auto schema markup.
	 *
	 * @param \WP_Post  $post      The post object.
	 * @param object    $schemaObj The schema object.
	 * @param Functions $helper    The helper object.
	 *
	 * @return array Course schema data with 'course' and 'metaData' keys.
	 */
	private function get_tutor_lms_course_auto_schema( $post, $schemaObj, $helper ) {

		if ( ! in_array( 'tutor/tutor.php', apply_filters( 'active_plugins', get_option( 'active_plugins', [] ) ), true ) ) {
			return [
				'course'   => [],
				'metaData' => [],
			];
		}

		$site_schema_id = $schemaObj->get_site_schema_id();
		$post_meta      = get_post_meta( $post->ID );

		// Get price via Tutor LMS utility API (supports native Tutor, WooCommerce, and EDD).
		$price       = '';
		$currency    = 'USD';
		$monetize_by = '';

		if ( function_exists( 'tutor_utils' ) ) {
			$monetize_by = tutor_utils()->get_option( 'monetize_by' );

			$raw_price = tutor_utils()->get_raw_course_price( $post->ID );
			if ( $raw_price ) {
				$price = ! empty( $raw_price->sale_price ) ? $raw_price->sale_price : ( $raw_price->regular_price ?? '' );
			}

			// Fallback: WooCommerce product price directly.
			if ( empty( $price ) && $monetize_by === 'wc' && function_exists( 'wc_get_product' ) ) {
				$product_id = get_post_meta( $post->ID, '_tutor_course_product_id', true );
				if ( $product_id ) {
					$product = wc_get_product( $product_id );
					if ( $product ) {
						$price = $product->get_sale_price() ?: $product->get_regular_price();
					}
				}
			}

			// Currency based on monetization engine.
			if ( $monetize_by === 'wc' && function_exists( 'get_woocommerce_currency' ) ) {
				$currency = get_woocommerce_currency();
			} elseif ( $monetize_by === 'edd' && function_exists( 'edd_get_currency' ) ) {
				$currency = edd_get_currency();
			} else {
				$currency = tutor_utils()->get_option( 'currency_code', 'USD' );
			}
		}

		// Fallback to meta keys if API returned nothing (native Tutor only).
		if ( empty( $price ) && ( empty( $monetize_by ) || $monetize_by === 'tutor' ) ) {
			$regular_price = $post_meta['tutor_course_price'][0] ?? '';
			$sale_price    = $post_meta['tutor_course_sale_price'][0] ?? '';
			$price         = $sale_price ? $sale_price : $regular_price;
		}

		// Only clear price for native Tutor monetization when price type is free.
		if ( ( empty( $monetize_by ) || $monetize_by === 'tutor' ) ) {
			$price_type = $post_meta['_tutor_course_price_type'][0] ?? 'free';
			if ( $price_type === 'free' ) {
				$price = '';
			}
		}

		$permalink = get_the_permalink( $post->ID );

		$metaData = [
			'price'         => $price ?: '',
			'priceCurrency' => $currency,
			'availability'  => $price ? 'https://schema.org/InStock' : '',
			'url'           => $permalink,
			'courseMode'    => 'Online',
		];

		$course_id = $schemaObj->get_id_with_hash( 'course0' );
		$course    = [
			'@type'    => 'Course',
			'@id'      => $course_id,
			'provider' => [
				'@id' => $site_schema_id,
			],
		];

		if ( ! empty( $post->post_title ) ) {
			$course['name'] = wp_specialchars_decode( sanitize_text_field( $post->post_title ), ENT_QUOTES );
		}

		$description = ! empty( $post->post_excerpt ) ? $post->post_excerpt : wp_strip_all_tags( $post->post_content );
		if ( ! empty( $description ) ) {
			$course['description'] = wp_specialchars_decode( sanitize_text_field( $description ), ENT_QUOTES );
		}

		$image_id = get_post_thumbnail_id( $post->ID );
		if ( ! empty( $image_id ) ) {
			$img             = $helper->imageInfo( absint( $image_id ) );
			$course['image'] = [
				'@type'  => 'ImageObject',
				'url'    => $helper->sanitizeOutPut( $img['url'], 'url' ),
				'height' => $img['height'],
				'width'  => $img['width'],
			];
		}

		if ( ! empty( $permalink ) ) {
			$course['url'] = $helper->sanitizeOutPut( $permalink, 'url' );
		}

		// Offers at Course level.
		if ( ! empty( $price ) && ! empty( $currency ) ) {
			$course['offers'] = [
				[
					'@type'         => 'Offer',
					'category'      => 'Paid',
					'price'         => number_format( (float) $price, 2, '.', '' ),
					'priceCurrency' => sanitize_text_field( $currency ),
					'availability'  => 'https://schema.org/InStock',
				],
			];
		} else {
			$course['offers'] = [
				[
					'@type'         => 'Offer',
					'category'      => 'Free',
					'price'         => '0.00',
					'priceCurrency' => sanitize_text_field( $currency ),
					'availability'  => 'https://schema.org/InStock',
				],
			];
		}

		// Educational level from Tutor LMS difficulty level.
		$course_level = get_post_meta( $post->ID, '_tutor_course_level', true );
		if ( ! empty( $course_level ) && $course_level !== 'all_levels' ) {
			$level_map = [
				'beginner'     => 'Beginner',
				'intermediate' => 'Intermediate',
				'expert'       => 'Advanced',
			];
			if ( isset( $level_map[ $course_level ] ) ) {
				$course['educationalLevel'] = $level_map[ $course_level ];
			}
		}

		// CourseInstance — Tutor LMS has no online/offline mode, default to Online.
		$course_instance = [
			'@type'      => 'CourseInstance',
			'courseMode' => 'Online',
		];

		// Course workload from Tutor LMS duration meta (serialized array: hours, minutes, seconds).
		$duration = $post_meta['_course_duration'][0] ?? '';
		if ( ! empty( $duration ) ) {
			$workload = $this->convert_tutor_duration_to_iso8601( $duration );
			if ( ! empty( $workload ) ) {
				$course_instance['courseWorkload'] = $workload;
			}
		}

		// Instructors from Tutor LMS.
		if ( function_exists( 'tutor_utils' ) ) {
			$instructors = tutor_utils()->get_instructors_by_course( $post->ID );
			if ( ! empty( $instructors ) && is_array( $instructors ) ) {
				$instructor                    = $instructors[0];
				$course_instance['instructor'] = [
					'@type' => 'Person',
					'name'  => esc_html( $instructor->display_name ),
				];
			}
		}

		// Fallback to post author if no instructor found.
		if ( empty( $course_instance['instructor'] ) ) {
			$author_id = $post->post_author;
			if ( $author_id ) {
				$author_name = get_the_author_meta( 'display_name', $author_id );
				if ( $author_name ) {
					$course_instance['instructor'] = [
						'@type' => 'Person',
						'name'  => esc_html( $author_name ),
					];
				}
			}
		}

		$course['hasCourseInstance'] = $course_instance;

		// Syllabus from Tutor LMS topics.
		if ( function_exists( 'tutor_utils' ) ) {
			$topics_query = tutor_utils()->get_topics( $post->ID );
			if ( ! empty( $topics_query->posts ) ) {
				$syllabus = [];
				foreach ( $topics_query->posts as $topic ) {
					$syllabus_item = [
						'@type' => 'Syllabus',
						'name'  => wp_specialchars_decode( sanitize_text_field( $topic->post_title ), ENT_QUOTES ),
					];
					if ( ! empty( $topic->post_content ) ) {
						$syllabus_item['description'] = wp_specialchars_decode( sanitize_text_field( wp_strip_all_tags( $topic->post_content ) ), ENT_QUOTES );
					}
					$syllabus[] = $syllabus_item;
				}
				if ( ! empty( $syllabus ) ) {
					$course['syllabusSections'] = $syllabus;
				}
			}
		}

		return [
			'course'   => $course,
			'metaData' => $metaData,
		];
	}

	/**
	 * Convert Tutor LMS duration to ISO 8601 duration.
	 *
	 * Tutor LMS stores duration as a serialized array: ['hours' => int, 'minutes' => int, 'seconds' => int].
	 *
	 * @param string $duration Tutor LMS duration (serialized or raw).
	 *
	 * @return string ISO 8601 duration (e.g., "PT2H30M").
	 */
	private function convert_tutor_duration_to_iso8601( $duration ) {
		$data = maybe_unserialize( $duration );

		if ( ! is_array( $data ) ) {
			return '';
		}

		$hours   = absint( $data['hours'] ?? 0 );
		$minutes = absint( $data['minutes'] ?? 0 );
		$seconds = absint( $data['seconds'] ?? 0 );

		if ( ! $hours && ! $minutes && ! $seconds ) {
			return '';
		}

		$iso = 'PT';
		if ( $hours ) {
			$iso .= $hours . 'H';
		}
		if ( $minutes ) {
			$iso .= $minutes . 'M';
		}
		if ( $seconds ) {
			$iso .= $seconds . 'S';
		}

		return $iso;
	}

	/**
	 * Get Academy LMS Course auto schema markup.
	 *
	 * @param \WP_Post  $post      The post object.
	 * @param object    $schemaObj The schema object.
	 * @param Functions $helper    The helper object.
	 *
	 * @return array Course schema data with 'course' and 'metaData' keys.
	 */
	private function get_academy_lms_course_auto_schema( $post, $schemaObj, $helper ) {

		if ( ! in_array( 'academy/academy.php', apply_filters( 'active_plugins', get_option( 'active_plugins', [] ) ), true ) ) {
			return [
				'course'   => [],
				'metaData' => [],
			];
		}

		$site_schema_id = $schemaObj->get_site_schema_id();
		$post_meta      = get_post_meta( $post->ID );

		// Get course type (free/paid/public).
		$course_type = $post_meta['academy_course_type'][0] ?? 'free';

		// Get price based on monetization engine (WooCommerce, StoreEngine, or EDD).
		$prices   = [];
		$currency = 'USD';

		if ( $course_type === 'paid' ) {
			$monetize_engine = class_exists( '\Academy\Helper' ) ? \Academy\Helper::monetization_engine() : '';

			if ( $monetize_engine === 'woocommerce' && function_exists( 'wc_get_product' ) ) {
				$product_id = $post_meta['academy_course_product_id'][0] ?? '';
				if ( ! empty( $product_id ) ) {
					$product = wc_get_product( $product_id );
					if ( $product ) {
						$prices[] = $product->get_sale_price() ?: $product->get_regular_price();
						$currency = get_woocommerce_currency();
					}
				}
			} elseif ( $monetize_engine === 'storeengine' && class_exists( '\StoreEngine\Utils\Helper' ) ) {
				$integrations = \StoreEngine\Utils\Helper::get_integration_repository_by_id( 'storeengine/academylms', $post->ID );
				if ( ! empty( $integrations ) ) {
					$currency = \StoreEngine\Utils\Formatting::get_currency();
					foreach ( $integrations as $integration ) {
						$p = $integration->price->get_price();
						if ( ! empty( $p ) ) {
							$prices[] = $p;
						}
					}
				}
			} elseif ( $monetize_engine === 'edd' && function_exists( 'edd_get_download_price' ) ) {
				$download_id = $post_meta['academy_course_download_id'][0] ?? '';
				if ( ! empty( $download_id ) ) {
					$prices[] = edd_get_download_price( $download_id );
					$currency = function_exists( 'edd_get_currency' ) ? edd_get_currency() : 'USD';
				}
			}
		}

		$permalink = get_the_permalink( $post->ID );

		$metaData = [
			'price'         => ! empty( $prices ) ? $prices[0] : '',
			'priceCurrency' => $currency,
			'availability'  => ! empty( $prices ) ? 'https://schema.org/InStock' : '',
			'url'           => $permalink,
			'courseMode'    => 'Online',
		];

		$course_id = $schemaObj->get_id_with_hash( 'course0' );
		$course    = [
			'@type'    => 'Course',
			'@id'      => $course_id,
			'provider' => [
				'@id' => $site_schema_id,
			],
		];

		if ( ! empty( $post->post_title ) ) {
			$course['name'] = wp_specialchars_decode( sanitize_text_field( $post->post_title ), ENT_QUOTES );
		}

		$description = ! empty( $post->post_excerpt ) ? $post->post_excerpt : wp_strip_all_tags( $post->post_content );
		if ( ! empty( $description ) ) {
			$course['description'] = wp_specialchars_decode( sanitize_text_field( $description ), ENT_QUOTES );
		}

		$image_id = get_post_thumbnail_id( $post->ID );
		if ( ! empty( $image_id ) ) {
			$img             = $helper->imageInfo( absint( $image_id ) );
			$course['image'] = [
				'@type'  => 'ImageObject',
				'url'    => $helper->sanitizeOutPut( $img['url'], 'url' ),
				'height' => $img['height'],
				'width'  => $img['width'],
			];
		}

		if ( ! empty( $permalink ) ) {
			$course['url'] = $helper->sanitizeOutPut( $permalink, 'url' );
		}

		// Offers at Course level (supports multiple prices from StoreEngine).
		if ( ! empty( $prices ) && ! empty( $currency ) ) {
			$course['offers'] = [];
			foreach ( $prices as $offer_price ) {
				$course['offers'][] = [
					'@type'         => 'Offer',
					'category'      => 'Paid',
					'price'         => number_format( (float) $offer_price, 2, '.', '' ),
					'priceCurrency' => sanitize_text_field( $currency ),
					'availability'  => 'https://schema.org/InStock',
				];
			}
		} else {
			$course['offers'] = [
				[
					'@type'         => 'Offer',
					'category'      => 'Free',
					'price'         => '0.00',
					'priceCurrency' => sanitize_text_field( $currency ),
					'availability'  => 'https://schema.org/InStock',
				],
			];
		}

		// Educational level from Academy LMS difficulty level.
		$course_level = $post_meta['academy_course_difficulty_level'][0] ?? '';
		if ( ! empty( $course_level ) && $course_level !== 'all_levels' ) {
			$level_map = [
				'beginner'     => 'Beginner',
				'intermediate' => 'Intermediate',
				'experts'      => 'Advanced',
			];
			if ( isset( $level_map[ $course_level ] ) ) {
				$course['educationalLevel'] = $level_map[ $course_level ];
			}
		}

		// CourseInstance — Academy LMS is online only.
		$course_instance = [
			'@type'      => 'CourseInstance',
			'courseMode' => 'Online',
		];

		// Course workload from Academy LMS duration meta (array: [hours, minutes, seconds]).
		$duration = $post_meta['academy_course_duration'][0] ?? '';
		if ( ! empty( $duration ) ) {
			$workload = $this->convert_academy_duration_to_iso8601( $duration );
			if ( ! empty( $workload ) ) {
				$course_instance['courseWorkload'] = $workload;
			}
		}

		// Instructors from Academy LMS.
		if ( class_exists( '\Academy\Helper' ) ) {
			$instructors = \Academy\Helper::get_instructors_by_course_id( $post->ID );
			if ( ! empty( $instructors ) && is_array( $instructors ) ) {
				$instructor                    = $instructors[0];
				$course_instance['instructor'] = [
					'@type' => 'Person',
					'name'  => wp_specialchars_decode( sanitize_text_field( $instructor->display_name ), ENT_QUOTES ),
				];
			}
		}

		// Fallback to post author if no instructor found.
		if ( empty( $course_instance['instructor'] ) ) {
			$author_id = $post->post_author;
			if ( $author_id ) {
				$author_name = get_the_author_meta( 'display_name', $author_id );
				if ( $author_name ) {
					$course_instance['instructor'] = [
						'@type' => 'Person',
						'name'  => wp_specialchars_decode( sanitize_text_field( $author_name ), ENT_QUOTES ),
					];
				}
			}
		}

		$course['hasCourseInstance'] = $course_instance;

		// Syllabus from Academy LMS curriculum meta (nested array of sections/topics).
		$curriculum = $post_meta['academy_course_curriculum'][0] ?? '';
		if ( ! empty( $curriculum ) ) {
			$sections = maybe_unserialize( $curriculum );
			if ( is_array( $sections ) ) {
				$syllabus = [];
				foreach ( $sections as $section ) {
					$section_title = $section['title'] ?? '';
					if ( ! empty( $section_title ) ) {
						$syllabus_item = [
							'@type' => 'Syllabus',
							'name'  => wp_specialchars_decode( sanitize_text_field( $section_title ), ENT_QUOTES ),
						];
						$section_desc  = $section['content'] ?? '';
						if ( ! empty( $section_desc ) ) {
							$syllabus_item['description'] = wp_specialchars_decode( sanitize_text_field( wp_strip_all_tags( $section_desc ) ), ENT_QUOTES );
						}
						$syllabus[] = $syllabus_item;
					}
				}
				if ( ! empty( $syllabus ) ) {
					$course['syllabusSections'] = $syllabus;
				}
			}
		}

		return [
			'course'   => $course,
			'metaData' => $metaData,
		];
	}

	/**
	 * Convert Academy LMS duration to ISO 8601 duration.
	 *
	 * Academy LMS stores duration as a serialized array: [hours, minutes, seconds].
	 *
	 * @param string $duration Academy LMS duration (serialized or raw).
	 *
	 * @return string ISO 8601 duration (e.g., "PT2H30M").
	 */
	private function convert_academy_duration_to_iso8601( $duration ) {
		$data = maybe_unserialize( $duration );

		if ( ! is_array( $data ) ) {
			return '';
		}

		$hours   = absint( $data[0] ?? 0 );
		$minutes = absint( $data[1] ?? 0 );
		$seconds = absint( $data[2] ?? 0 );

		if ( ! $hours && ! $minutes && ! $seconds ) {
			return '';
		}

		$iso = 'PT';
		if ( $hours ) {
			$iso .= $hours . 'H';
		}
		if ( $minutes ) {
			$iso .= $minutes . 'M';
		}
		if ( $seconds ) {
			$iso .= $seconds . 'S';
		}

		return $iso;
	}

	/**
	 * Get LifterLMS Course auto schema markup.
	 *
	 * @param \WP_Post  $post      The post object.
	 * @param object    $schemaObj The schema object.
	 * @param Functions $helper    The helper object.
	 *
	 * @return array Course schema data with 'course' and 'metaData' keys.
	 */
	private function get_lifter_lms_course_auto_schema( $post, $schemaObj, $helper ) {

		if ( ! in_array( 'lifterlms/lifterlms.php', apply_filters( 'active_plugins', get_option( 'active_plugins', [] ) ), true ) ) {
			return [
				'course'   => [],
				'metaData' => [],
			];
		}

		// Get LifterLMS course object.
		$llms_course = function_exists( 'llms_get_post' ) ? llms_get_post( $post->ID ) : null;

		if ( ! $llms_course || ! is_a( $llms_course, 'LLMS_Course' ) ) {
			return [
				'course'   => [],
				'metaData' => [],
			];
		}

		$site_schema_id = $schemaObj->get_site_schema_id();

		// Get prices from all access plans via LLMS_Product.
		$prices   = [];
		$currency = function_exists( 'get_lifterlms_currency' ) ? get_lifterlms_currency() : 'USD';

		$product = $llms_course->get_product();
		if ( $product && method_exists( $product, 'get_access_plans' ) ) {
			$access_plans = $product->get_access_plans();
			if ( ! empty( $access_plans ) ) {
				foreach ( $access_plans as $plan ) {
					$plan_price = $plan->get( 'price' );
					$plan_title = $plan->get( 'title' );

					if ( ! empty( $plan_price ) && is_numeric( $plan_price ) ) {
						$prices[] = [
							'price' => number_format( (float) $plan_price, 2, '.', '' ),
							'title' => $plan_title,
						];
					} elseif ( method_exists( $plan, 'is_free' ) && $plan->is_free() ) {
						$prices[] = [
							'price' => '0.00',
							'title' => $plan_title,
						];
					}
				}
			}
		}

		$permalink  = get_the_permalink( $post->ID );
		$first_paid = '';
		foreach ( $prices as $p ) {
			if ( (float) $p['price'] > 0 ) {
				$first_paid = $p['price'];
				break;
			}
		}

		$metaData = [
			'price'         => $first_paid ?: '',
			'priceCurrency' => $currency,
			'availability'  => $first_paid ? 'https://schema.org/InStock' : '',
			'url'           => $permalink,
			'courseMode'    => 'Online',
		];

		$course_id = $schemaObj->get_id_with_hash( 'course0' );
		$course    = [
			'@type'    => 'Course',
			'@id'      => $course_id,
			'provider' => [
				'@id' => $site_schema_id,
			],
		];

		if ( ! empty( $post->post_title ) ) {
			$course['name'] = wp_specialchars_decode( sanitize_text_field( $post->post_title ), ENT_QUOTES );
		}

		$description = ! empty( $post->post_excerpt )
			? strip_shortcodes( $post->post_excerpt )
			: strip_shortcodes( wp_strip_all_tags( $post->post_content ) );
		$description = trim( preg_replace( '/\s+/', ' ', $description ) );
		if ( ! empty( $description ) ) {
			$course['description'] = wp_specialchars_decode( sanitize_text_field( $description ), ENT_QUOTES );
		}

		$image_id = get_post_thumbnail_id( $post->ID );
		if ( ! empty( $image_id ) ) {
			$img             = $helper->imageInfo( absint( $image_id ) );
			$course['image'] = [
				'@type'  => 'ImageObject',
				'url'    => $helper->sanitizeOutPut( $img['url'], 'url' ),
				'height' => $img['height'],
				'width'  => $img['width'],
			];
		}

		if ( ! empty( $permalink ) ) {
			$course['url'] = $helper->sanitizeOutPut( $permalink, 'url' );
		}

		// Offers from all access plans.
		if ( ! empty( $prices ) ) {
			$course['offers'] = [];
			foreach ( $prices as $plan_data ) {
				$actual_price = (float) $plan_data['price'];
				$offer        = [
					'@type'         => 'Offer',
					'category'      => $actual_price > 0 ? 'Paid' : 'Free',
					'price'         => number_format( $actual_price, 2, '.', '' ),
					'priceCurrency' => sanitize_text_field( $currency ),
					'availability'  => 'https://schema.org/InStock',
				];
				if ( ! empty( $plan_data['title'] ) ) {
					$offer['name'] = sanitize_text_field( $plan_data['title'] );
				}
				$course['offers'][] = $offer;
			}
		} else {
			$course['offers'] = [
				[
					'@type'         => 'Offer',
					'category'      => 'Free',
					'price'         => '0.00',
					'priceCurrency' => sanitize_text_field( $currency ),
					'availability'  => 'https://schema.org/InStock',
				],
			];
		}

		// Educational level from LifterLMS difficulty.
		$difficulty = method_exists( $llms_course, 'get_difficulty' ) ? $llms_course->get_difficulty() : '';
		if ( ! empty( $difficulty ) ) {
			$level_map        = [
				'beginner'     => 'Beginner',
				'intermediate' => 'Intermediate',
				'advanced'     => 'Advanced',
			];
			$difficulty_lower = strtolower( $difficulty );
			if ( isset( $level_map[ $difficulty_lower ] ) ) {
				$course['educationalLevel'] = $level_map[ $difficulty_lower ];
			}
		}

		// CourseInstance.
		$course_instance = [
			'@type'      => 'CourseInstance',
			'courseMode' => 'Online',
		];

		// Course workload from LifterLMS length meta.
		$length = $llms_course->get( 'length' );
		if ( ! empty( $length ) ) {
			$workload = $this->convert_lifter_duration_to_iso8601( $length );
			if ( ! empty( $workload ) ) {
				$course_instance['courseWorkload'] = $workload;
			}
		}

		// Instructor from LifterLMS.
		$instructors = method_exists( $llms_course, 'get_instructors' ) ? $llms_course->get_instructors() : [];
		if ( ! empty( $instructors ) && is_array( $instructors ) ) {
			$instructor_name = $instructors[0]['display_name'] ?? '';
			if ( empty( $instructor_name ) && ! empty( $instructors[0]['id'] ) ) {
				$instructor_name = get_the_author_meta( 'display_name', $instructors[0]['id'] );
			}
			if ( $instructor_name ) {
				$course_instance['instructor'] = [
					'@type' => 'Person',
					'name'  => esc_html( $instructor_name ),
				];
			}
		}

		// Fallback to post author if no instructor found.
		if ( empty( $course_instance['instructor'] ) ) {
			$author_id = $post->post_author;
			if ( $author_id ) {
				$author_name = get_the_author_meta( 'display_name', $author_id );
				if ( $author_name ) {
					$course_instance['instructor'] = [
						'@type' => 'Person',
						'name'  => esc_html( $author_name ),
					];
				}
			}
		}

		$course['hasCourseInstance'] = $course_instance;

		// Syllabus from LifterLMS sections.
		$sections = method_exists( $llms_course, 'get_sections' ) ? $llms_course->get_sections() : [];
		if ( ! empty( $sections ) ) {
			$syllabus = [];
			foreach ( $sections as $section ) {
				$section_title = '';
				if ( is_object( $section ) && method_exists( $section, 'get' ) ) {
					$section_title = $section->get( 'title' );
				} elseif ( is_object( $section ) && isset( $section->post_title ) ) {
					$section_title = $section->post_title;
				}
				if ( ! empty( $section_title ) ) {
					$syllabus_item = [
						'@type' => 'Syllabus',
						'name'  => wp_specialchars_decode( sanitize_text_field( $section_title ), ENT_QUOTES ),
					];
					$section_desc  = '';
					if ( is_object( $section ) && method_exists( $section, 'get' ) ) {
						$section_desc = $section->get( 'content' );
					} elseif ( is_object( $section ) && isset( $section->post_content ) ) {
						$section_desc = $section->post_content;
					}
					if ( ! empty( $section_desc ) ) {
						$syllabus_item['description'] = wp_specialchars_decode( sanitize_text_field( wp_strip_all_tags( $section_desc ) ), ENT_QUOTES );
					}
					$syllabus[] = $syllabus_item;
				}
			}
			if ( ! empty( $syllabus ) ) {
				$course['syllabusSections'] = $syllabus;
			}
		}

		return [
			'course'   => $course,
			'metaData' => $metaData,
		];
	}

	/**
	 * Convert LifterLMS duration string to ISO 8601 duration.
	 *
	 * LifterLMS stores length as a free-text string like "2 hours", "3 weeks", "45 minutes".
	 *
	 * @param string $duration LifterLMS length string.
	 *
	 * @return string ISO 8601 duration (e.g., "PT2H", "PT504H", "PT45M").
	 */
	private function convert_lifter_duration_to_iso8601( $duration ) {
		$duration = trim( $duration );
		if ( empty( $duration ) ) {
			return '';
		}

		$parts = preg_split( '/\s+/', $duration, 2 );
		$value = absint( $parts[0] );
		$unit  = isset( $parts[1] ) ? strtolower( rtrim( $parts[1], 's' ) ) : '';

		if ( ! $value ) {
			return '';
		}

		switch ( $unit ) {
			case 'week':
				return 'PT' . ( $value * 168 ) . 'H';
			case 'day':
				return 'PT' . ( $value * 24 ) . 'H';
			case 'hour':
				return 'PT' . $value . 'H';
			case 'minute':
				return 'PT' . $value . 'M';
			default:
				return 'PT' . $value . 'H';
		}
	}

	/**
	 * Get EDD product schema markup.
	 *
	 * @param  \WP_Post $post  The post object.
	 * @param  object   $schemaObj  The schema object.
	 *
	 * @return array Product schema markup.
	 */
	private function get_edd_product_auto_schema( $post, $schemaObj ) {
		$permalink = get_the_permalink( $post->ID );
		$markup    = [
			'@type'       => 'Product',
			'@id'         => $permalink . '#product0',
			'name'        => wp_kses_post( $post->post_title ),
			'url'         => $permalink,
			'description' => wp_strip_all_tags( do_shortcode( $post->post_excerpt ? $post->post_excerpt : $post->post_content ) ),
		];

		$image = get_the_post_thumbnail_url( $post->ID );
		if ( $image ) {
			$markup['image'] = $image;
		}

		$markup['sku'] = $post->ID;
		$brand_name    = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'brand_name' );
		if ( $brand_name ) {
			$markup['brand'] = [
				'@type' => 'Brand',
				'name'  => esc_html( $brand_name ),
			];
		}

		$identifier_type = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'identifier_type' );
		$identifier      = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'identifier' );
		if ( $identifier_type && $identifier ) {
			$markup[ $identifier_type ] = esc_html( $identifier );
		}

		$currency          = function_exists( 'edd_get_currency' ) ? edd_get_currency() : 'USD';
		$price_valid_until = gmdate( 'Y-12-31', time() + 2 * YEAR_IN_SECONDS );
		$site_schema_id    = $schemaObj->get_site_schema_id();

		// Shipping details from ecommerce settings.
		$DownloadableOfferShippingDetails = home_url( '#DownloadableOfferShippingDetails' );
		$edd_ecommerce_settings           = get_option( 'rtrs_schema_ecommerce_settings', [] );

		$edd_ship_country = $edd_ecommerce_settings['return_policy_country'] ?? '';
		if ( empty( $edd_ship_country ) ) {
			$edd_ship_country = 'US';
		}

		$edd_handling_min = $edd_ecommerce_settings['handling_time_min'] ?? '';
		$edd_handling_max = $edd_ecommerce_settings['handling_time_max'] ?? '';
		$edd_transit_min  = $edd_ecommerce_settings['transit_time_min'] ?? '';
		$edd_transit_max  = $edd_ecommerce_settings['transit_time_max'] ?? '';

		$shippingDetails               = [
			'@type'               => 'OfferShippingDetails',
			'@id'                 => $DownloadableOfferShippingDetails,
			'shippingRate'        => [
				'@type'    => 'MonetaryAmount',
				'value'    => '0.00',
				'currency' => $currency,
			],
			'shippingDestination' => [
				'@type'          => 'DefinedRegion',
				'addressCountry' => $edd_ship_country,
			],
			'deliveryTime'        => [
				'@type'        => 'ShippingDeliveryTime',
				'handlingTime' => [
					'@type'    => 'QuantitativeValue',
					'minValue' => ( '' !== $edd_handling_min ) ? absint( $edd_handling_min ) : 0,
					'maxValue' => ( '' !== $edd_handling_max ) ? absint( $edd_handling_max ) : 0,
					'unitCode' => 'DAY',
				],
				'transitTime'  => [
					'@type'    => 'QuantitativeValue',
					'minValue' => ( '' !== $edd_transit_min ) ? absint( $edd_transit_min ) : 0,
					'maxValue' => ( '' !== $edd_transit_max ) ? absint( $edd_transit_max ) : 0,
					'unitCode' => 'DAY',
				],
			],
		];
		$this->shared_schema_entries[] = $shippingDetails;
		// Return policy from settings.
		$return_policy_id = '';
		$return_policy    = FnsPro::get_merchant_return_policy();
		if ( ! empty( $return_policy ) ) {
			$return_policy_id              = $return_policy['@id'];
			$this->shared_schema_entries[] = $return_policy;
		}

		if ( edd_has_variable_prices( $post->ID ) ) {
			$variable_prices = edd_get_variable_prices( $post->ID );

			if ( ! empty( $variable_prices ) ) {
				$prices    = array_map( 'floatval', wp_list_pluck( $variable_prices, 'amount' ) );
				$lowPrice  = min( $prices );
				$highPrice = max( $prices );

				$markup['offers'] = [
					'@type'                   => 'AggregateOffer',
					'lowPrice'                => number_format( $lowPrice, 2, '.', '' ),
					'highPrice'               => number_format( $highPrice, 2, '.', '' ),
					'priceCurrency'           => $currency,
					'offerCount'              => count( $variable_prices ),
					'availability'            => 'https://schema.org/InStock',
					'seller'                  => [
						'@id' => $site_schema_id,
					],
					'shippingDetails'         => [ '@id' => $DownloadableOfferShippingDetails ],
					'hasMerchantReturnPolicy' => [ '@id' => $return_policy_id ],
					'offers'                  => [],
				];

				foreach ( $variable_prices as $variable_price ) {
					$markup['offers']['offers'][] = [
						'@type'           => 'Offer',
						'description'     => esc_html( $variable_price['name'] ?? '' ),
						'price'           => number_format( (float) $variable_price['amount'], 2, '.', '' ),
						'priceCurrency'   => $currency,
						'priceValidUntil' => $price_valid_until,
						'availability'    => 'https://schema.org/InStock',
						'url'             => $permalink,
					];
				}
			}
		} else {
			$price            = edd_get_download_price( $post->ID, false );
			$markup['offers'] = [
				'@type'                   => 'Offer',
				'url'                     => $permalink,
				'price'                   => number_format( (float) $price, 2, '.', '' ),
				'priceValidUntil'         => $price_valid_until,
				'priceCurrency'           => $currency,
				'itemCondition'           => 'https://schema.org/NewCondition',
				'availability'            => 'https://schema.org/InStock',
				'seller'                  => [
					'@id' => $site_schema_id,
				],
				'shippingDetails'         => [ '@id' => $DownloadableOfferShippingDetails ],
				'hasMerchantReturnPolicy' => [ '@id' => $return_policy_id ],
			];
		}
		if ( Functions::isEnableReviewByPostType( 'download' ) ) {
			// Plugin review enabled — use plugin's own review ratings.
			$total_rating = ReviewFns::getTotalRatings( $post->ID );
			if ( $total_rating ) {
				$markup['aggregateRating'] = [
					'@type'       => 'AggregateRating',
					'ratingValue' => (float) ReviewFns::getAvgRatings( $post->ID, true ),
					'reviewCount' => $total_rating,
				];
			}
		} else {
			// Fallback to native EDD/WordPress comment ratings.
			$native_ratings = ReviewFns::getNativeCommentRatings( $post->ID );
			if ( $native_ratings ) {
				$markup['aggregateRating'] = [
					'@type'       => 'AggregateRating',
					'ratingValue' => (float) $native_ratings['average'],
					'reviewCount' => $native_ratings['total'],
				];
			}
		}

		$markup = $this->add_product_reviews( $markup, $post->ID, 'download', $schemaObj );

		return $markup;
	}

	/**
	 * Get RTCL Listing product schema markup.
	 *
	 * @param  \WP_Post $post  The post object.
	 * @param  object   $schemaObj  The schema object.
	 *
	 * @return array Product schema markup.
	 */
	private function get_rtcl_listing_product_auto_schema( $post, $schemaObj ) {
		$permalink = get_the_permalink( $post->ID );
		$markup    = [
			'@type'       => 'Product',
			'@id'         => $permalink . '#comments',
			'name'        => wp_kses_post( $post->post_title ),
			'url'         => $permalink,
			'description' => wp_strip_all_tags( do_shortcode( $post->post_excerpt ?: $post->post_content ) ),
		];

		global $listing;

		if ( $listing ) {
			$image = $listing->get_images();
			if ( $image ) {
				$markup['image'] = $image[0]->url;
			}
		}

		$markup['sku'] = $post->ID;
		$brand_name    = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'brand_name' );
		if ( $brand_name ) {
			$markup['brand'] = [
				'@type' => 'Brand',
				'name'  => esc_html( $brand_name ),
			];
		}

		$identifier_type = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'identifier_type' );
		$identifier      = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'identifier' );
		if ( $identifier_type && $identifier ) {
			$markup[ $identifier_type ] = esc_html( $identifier );
		}

		if ( ! $listing ) {
			$listing = rtcl()->factory->get_listing( $post->ID );
		}

		if ( ! $listing ) {
			return $markup;
		}

		$price             = $listing->get_price();
		$price_valid_until = gmdate( 'Y-12-31', time() + 2 * YEAR_IN_SECONDS );
		$site_schema_id    = $schemaObj->get_site_schema_id();
		$currency          = class_exists( '\Rtcl\Helpers\Functions' ) ? \Rtcl\Helpers\Functions::get_currency() : 'USD';

		// Shipping details (default from plugin settings).
		$shippingDetails = $this->get_default_shipping_details( $currency );

		// Return policy.
		$returnPolicy = FnsPro::get_merchant_return_policy();

		// Add shared entries at graph level.
		if ( ! empty( $shippingDetails ) ) {
			foreach ( $shippingDetails as $sd ) {
				$this->shared_schema_entries[] = $sd;
			}
		}

		if ( ! empty( $returnPolicy ) ) {
			$return_policy_id              = $returnPolicy['@id'];
			$this->shared_schema_entries[] = $returnPolicy;
		} else {
			$return_policy_id = '';
		}

		// Build shipping references.
		$shipping_refs = [];
		if ( ! empty( $shippingDetails ) ) {
			foreach ( $shippingDetails as $sd ) {
				$shipping_refs[] = [ '@id' => $sd['@id'] ];
			}
		}

		$markup['offers'] = [
			'@type'           => 'Offer',
			'url'             => $permalink,
			'price'           => number_format( (float) $price, 2, '.', '' ),
			'priceValidUntil' => $price_valid_until,
			'priceCurrency'   => $currency,
			'itemCondition'   => 'https://schema.org/NewCondition',
			'availability'    => 'https://schema.org/InStock',
			'seller'          => [
				'@id' => $site_schema_id,
			],
		];

		if ( ! empty( $shipping_refs ) ) {
			$markup['offers']['shippingDetails'] = $shipping_refs;
		}
		if ( ! empty( $return_policy_id ) ) {
			$markup['offers']['hasMerchantReturnPolicy'] = [ '@id' => $return_policy_id ];
		}

		$total_rating = ReviewFns::getTotalRatings( $post->ID );
		if ( $total_rating ) {
			$markup['aggregateRating'] = [
				'@type'       => 'AggregateRating',
				'ratingValue' => (float) ReviewFns::getAvgRatings( $post->ID, true ),
				'reviewCount' => $total_rating,
			];
		}

		$markup = $this->add_product_reviews( $markup, $post->ID, 'rtcl_listing', $schemaObj );

		return $markup;
	}

	/**
	 * Get FluentCart product schema markup.
	 *
	 * @param \WP_Post $post      The post object.
	 * @param object   $schemaObj The schema object.
	 *
	 * @return array Product schema markup.
	 */
	private function get_fluentcart_product_auto_schema( $post, $schemaObj ) {
		$product = \FluentCart\App\Models\Product::with( [ 'detail', 'variants' ] )->find( $post->ID );

		if ( ! $product || ! $product->detail ) {
			return [];
		}

		$site_schema_id = $schemaObj->get_site_schema_id();
		$permalink      = get_permalink( $post->ID );
		$markup         = [
			'@type'       => 'Product',
			'@id'         => $permalink . '#product0',
			'name'        => wp_kses_post( $post->post_title ),
			'url'         => $permalink,
			'description' => wp_strip_all_tags( do_shortcode( $post->post_excerpt ? $post->post_excerpt : $post->post_content ) ),
		];

		// Image.
		$image = get_the_post_thumbnail_url( $post->ID, 'full' );
		if ( $image ) {
			$markup['image'] = $image;
		}

		// SKU.
		$markup['sku'] = $post->ID;

		$brand = $this->get_product_brand( $post->ID );
		if ( ! empty( $brand ) ) {
			$markup['brand'] = $brand;
		}

		// Identifier.
		$identifier_type = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'identifier_type' );
		$identifier      = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'identifier' );
		if ( $identifier_type && $identifier ) {
			$markup[ $identifier_type ] = esc_html( $identifier );
		}

		// Currency & store settings.
		$currency = \FluentCart\Api\CurrencySettings::get( 'currency' );
		if ( ! $currency ) {
			$currency = 'USD';
		}

		$store_settings = ( new \FluentCart\Api\StoreSettings() )->get();
		$store_country  = $store_settings['store_country'] ?? '';

		// Offers.
		$detail            = $product->detail;
		$variants          = $product->variants;
		$price_valid_until = gmdate( 'Y-12-31', time() + 2 * YEAR_IN_SECONDS );
		$availability      = $product->isStock() ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock';

		$active_variants = $variants->filter(
			function ( $v ) {
				return 'active' === $v->item_status;
			}
		);

		// Shipping details.
		$shippingDetails  = [];
		$shipping_amount  = '0.00';
		$shipping_methods = $store_country ? \FluentCart\App\Helpers\AddressHelper::getShippingMethods( $store_country ) : null;
		if ( ! empty( $shipping_methods ) && ! is_wp_error( $shipping_methods ) ) {
			$shipping_amount = Helper::toDecimal( $shipping_methods[0]->amount, false ); // number_format( (float) $shipping_methods[0]->amount, 2, '.', '' );
		}

		if ( $store_country ) {
			$ecommerce_settings = get_option( 'rtrs_schema_ecommerce_settings', [] );

			$handling_min = $ecommerce_settings['handling_time_min'] ?? '';
			$handling_max = $ecommerce_settings['handling_time_max'] ?? '';
			$transit_min  = $ecommerce_settings['transit_time_min'] ?? '';
			$transit_max  = $ecommerce_settings['transit_time_max'] ?? '';

			$shippingDetails = [
				'@type'               => 'OfferShippingDetails',
				'shippingRate'        => [
					'@type'    => 'MonetaryAmount',
					'value'    => $shipping_amount ?? 0,
					'currency' => $currency,
				],
				'shippingDestination' => [
					'@type'          => 'DefinedRegion',
					'addressCountry' => $store_country,
				],
				'deliveryTime'        => [
					'@type'        => 'ShippingDeliveryTime',
					'handlingTime' => [
						'@type'    => 'QuantitativeValue',
						'minValue' => ( '' !== $handling_min ) ? absint( $handling_min ) : 0,
						'maxValue' => ( '' !== $handling_max ) ? absint( $handling_max ) : 1,
						'unitCode' => 'DAY',
					],
					'transitTime'  => [
						'@type'    => 'QuantitativeValue',
						'minValue' => ( '' !== $transit_min ) ? absint( $transit_min ) : 3,
						'maxValue' => ( '' !== $transit_max ) ? absint( $transit_max ) : 7,
						'unitCode' => 'DAY',
					],
				],
			];
		}

		// Return policy from ecommerce settings.
		$returnPolicy = [];
		if ( $store_country ) {
			$fct_return_category = $ecommerce_settings['return_policy_category'] ?? 'MerchantReturnFiniteReturnWindow';
			$fct_return_method   = $ecommerce_settings['return_policy_method'] ?? 'ReturnByMail';
			$fct_return_fees     = $ecommerce_settings['return_policy_fees'] ?? 'FreeReturn';
			$fct_return_days     = $ecommerce_settings['return_policy_days'] ?? 7;
			$fct_return_link     = $ecommerce_settings['return_policy_link'] ?? '';

			$returnPolicy = [
				'@type'                => 'MerchantReturnPolicy',
				'applicableCountry'    => $store_country,
				'returnPolicyCategory' => 'https://schema.org/' . $fct_return_category,
			];

			if ( 'MerchantReturnFiniteReturnWindow' === $fct_return_category ) {
				$returnPolicy['merchantReturnDays'] = absint( $fct_return_days );
			}

			$returnPolicy['returnMethod'] = 'https://schema.org/' . $fct_return_method;
			$returnPolicy['returnFees']   = 'https://schema.org/' . $fct_return_fees;

			$fct_return_shipping_currency = $ecommerce_settings['return_shipping_fees_currency'] ?? $currency;
			if ( 'FreeReturn' === $fct_return_fees ) {
				$returnPolicy['returnShippingFeesAmount'] = [
					'@type'    => 'MonetaryAmount',
					'value'    => 0,
					'currency' => esc_html( $fct_return_shipping_currency ),
				];
			} else {
				$fct_return_shipping_amount               = $ecommerce_settings['return_shipping_fees_amount'] ?? 0;
				$returnPolicy['returnShippingFeesAmount'] = [
					'@type'    => 'MonetaryAmount',
					'value'    => floatval( $fct_return_shipping_amount ),
					'currency' => esc_html( $fct_return_shipping_currency ),
				];
			}

			if ( ! empty( $fct_return_link ) ) {
				$returnPolicy['merchantReturnLink'] = esc_url( $fct_return_link );
			}
		}

		if ( $active_variants->count() > 1 ) {
			$markup['offers'] = [
				'@type'         => 'AggregateOffer',
				'lowPrice'      => Helper::toDecimal( $detail->min_price, false ), // number_format( (float) $detail->min_price, 2, '.', '' ),
				'highPrice'     => Helper::toDecimal( $detail->max_price, false ), // number_format( (float) $detail->max_price, 2, '.', '' ),
				'priceCurrency' => $currency,
				'offerCount'    => $active_variants->count(),
				'availability'  => $availability,
				'seller'        => [
					'@id' => $site_schema_id,
				],
			];

			if ( ! empty( $shippingDetails ) ) {
				$markup['offers']['shippingDetails'] = $shippingDetails;
			}
			if ( ! empty( $returnPolicy ) ) {
				$markup['offers']['hasMerchantReturnPolicy'] = $returnPolicy;
			}

			// Individual variant offers.
			$markup['offers']['offers'] = [];
			foreach ( $active_variants as $variant ) {
				$offer = [
					'@type'         => 'Offer',
					'price'         => Helper::toDecimal( $variant->item_price, false ), // number_format( (float) $variant->item_price, 2, '.', '' ),
					'priceCurrency' => $currency,
					'availability'  => 'in-stock' === $variant->stock_status ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
					'url'           => $permalink,
					'seller'        => [
						'@id' => $site_schema_id,
					],
				];

				if ( ! empty( $variant->variation_title ) ) {
					$offer['name'] = esc_html( $variant->variation_title );
				}

				$markup['offers']['offers'][] = $offer;
			}
		} elseif ( $active_variants->count() === 1 ) {
			$variant          = $active_variants->first();
			$markup['offers'] = [
				'@type'           => 'Offer',
				'url'             => $permalink,
				'price'           => Helper::toDecimal( $variant->item_price, false ),
				'priceValidUntil' => $price_valid_until,
				'priceCurrency'   => $currency,
				'itemCondition'   => 'https://schema.org/NewCondition',
				'availability'    => $availability,
				'seller'          => [
					'@id' => $site_schema_id,
				],
			];

			if ( ! empty( $shippingDetails ) ) {
				$markup['offers']['shippingDetails'] = $shippingDetails;
			}
			if ( ! empty( $returnPolicy ) ) {
				$markup['offers']['hasMerchantReturnPolicy'] = $returnPolicy;
			}
		}

		// Category.
		$categories = get_the_terms( $post->ID, 'product-categories' );
		if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) {
			$markup['category'] = esc_html( $categories[0]->name );
		}

		// Aggregate rating.
		$total_rating = ReviewFns::getTotalRatings( $post->ID );
		if ( $total_rating ) {
			$markup['aggregateRating'] = [
				'@type'       => 'AggregateRating',
				'ratingValue' => (float) ReviewFns::getAvgRatings( $post->ID, true ),
				'reviewCount' => $total_rating,
			];
		}

		$markup = $this->add_product_reviews( $markup, $post->ID, 'fluent-products', $schemaObj );

		return $markup;
	}

	/**
	 * Get Download Manager product schema markup.
	 *
	 * @param \WP_Post $post      The post object.
	 * @param object   $schemaObj The schema object.
	 *
	 * @return array Product schema markup.
	 */
	private function get_download_manager_product_auto_schema( $post, $schemaObj ) {
		$site_schema_id = $schemaObj->get_site_schema_id();
		$permalink      = get_permalink( $post->ID );
		$markup         = [
			'@type'       => 'Product',
			'@id'         => $permalink . '#product0',
			'name'        => wp_kses_post( $post->post_title ),
			'url'         => $permalink,
			'description' => wp_strip_all_tags( do_shortcode( $post->post_excerpt ? $post->post_excerpt : $post->post_content ) ),
		];

		// Image.
		$image = get_the_post_thumbnail_url( $post->ID, 'full' );
		if ( $image ) {
			$markup['image'] = $image;
		}

		// SKU (Download Manager has no SKU field, use post ID).
		$markup['sku'] = (string) $post->ID;

		// Brand.
		$brand_name = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'brand_name' );
		if ( $brand_name ) {
			$markup['brand'] = [
				'@type' => 'Brand',
				'name'  => esc_html( $brand_name ),
			];
		}

		// Identifier.
		$identifier_type = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'identifier_type' );
		$identifier      = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'identifier' );
		if ( $identifier_type && $identifier ) {
			$markup[ $identifier_type ] = esc_html( $identifier );
		}

		// Availability from quota.
		$quota        = get_post_meta( $post->ID, '__wpdm_quota', true );
		$availability = 'https://schema.org/InStock';
		if ( ! empty( $quota ) && (int) $quota > 0 ) {
			$download_count = get_post_meta( $post->ID, '__wpdm_download_count', true );
			if ( (int) $download_count >= (int) $quota ) {
				$availability = 'https://schema.org/OutOfStock';
			}
		}

		$price_valid_until = gmdate( 'Y-12-31', time() + 2 * YEAR_IN_SECONDS );

		// Shipping & return policy from ecommerce settings.
		$ecommerce_settings = get_option( 'rtrs_schema_ecommerce_settings', [] );

		$ship_country = $ecommerce_settings['return_policy_country'] ?? '';
		if ( empty( $ship_country ) ) {
			$ship_country = 'US';
		}

		$handling_min = $ecommerce_settings['handling_time_min'] ?? '';
		$handling_max = $ecommerce_settings['handling_time_max'] ?? '';
		$transit_min  = $ecommerce_settings['transit_time_min'] ?? '';
		$transit_max  = $ecommerce_settings['transit_time_max'] ?? '';

		$shippingDetails = [
			'@type'               => 'OfferShippingDetails',
			'shippingRate'        => [
				'@type'    => 'MonetaryAmount',
				'value'    => '0.00',
				'currency' => 'USD',
			],
			'shippingDestination' => [
				'@type'          => 'DefinedRegion',
				'addressCountry' => $ship_country,
			],
			'deliveryTime'        => [
				'@type'        => 'ShippingDeliveryTime',
				'handlingTime' => [
					'@type'    => 'QuantitativeValue',
					'minValue' => ( '' !== $handling_min ) ? absint( $handling_min ) : 0,
					'maxValue' => ( '' !== $handling_max ) ? absint( $handling_max ) : 0,
					'unitCode' => 'DAY',
				],
				'transitTime'  => [
					'@type'    => 'QuantitativeValue',
					'minValue' => ( '' !== $transit_min ) ? absint( $transit_min ) : 0,
					'maxValue' => ( '' !== $transit_max ) ? absint( $transit_max ) : 0,
					'unitCode' => 'DAY',
				],
			],
		];

		// Return policy from ecommerce settings.
		$return_category = $ecommerce_settings['return_policy_category'] ?? 'MerchantReturnNotPermitted';
		$return_method   = $ecommerce_settings['return_policy_method'] ?? 'ReturnByMail';
		$return_fees     = $ecommerce_settings['return_policy_fees'] ?? 'FreeReturn';
		$return_days     = $ecommerce_settings['return_policy_days'] ?? 30;
		$return_link     = $ecommerce_settings['return_policy_link'] ?? '';

		$returnPolicy = [
			'@type'                => 'MerchantReturnPolicy',
			'applicableCountry'    => $ship_country,
			'returnPolicyCategory' => 'https://schema.org/' . $return_category,
		];

		if ( 'MerchantReturnFiniteReturnWindow' === $return_category ) {
			$returnPolicy['merchantReturnDays'] = absint( $return_days );
		}

		$returnPolicy['returnMethod'] = 'https://schema.org/' . $return_method;
		$returnPolicy['returnFees']   = 'https://schema.org/' . $return_fees;

		$return_shipping_currency = $ecommerce_settings['return_shipping_fees_currency'] ?? 'USD';
		if ( 'FreeReturn' === $return_fees ) {
			$returnPolicy['returnShippingFeesAmount'] = [
				'@type'    => 'MonetaryAmount',
				'value'    => 0,
				'currency' => esc_html( $return_shipping_currency ),
			];
		} else {
			$return_shipping_amount                   = $ecommerce_settings['return_shipping_fees_amount'] ?? 0;
			$returnPolicy['returnShippingFeesAmount'] = [
				'@type'    => 'MonetaryAmount',
				'value'    => floatval( $return_shipping_amount ),
				'currency' => esc_html( $return_shipping_currency ),
			];
		}

		if ( ! empty( $return_link ) ) {
			$returnPolicy['merchantReturnLink'] = esc_url( $return_link );
		}

		// Pricing via Premium Packages add-on.
		if ( defined( 'WPDMPP_VERSION' ) ) {
			$currency = function_exists( 'wpdmpp_currency_code' ) ? wpdmpp_currency_code() : 'USD';

			// Update shipping currency to match product currency.
			$shippingDetails['shippingRate']['currency'] = $currency;

			$enable_license = get_post_meta( $post->ID, '__wpdm_enable_license', true );
			$licenses_meta  = get_post_meta( $post->ID, '__wpdm_license', true );

			if ( $enable_license && ! empty( $licenses_meta ) && is_array( $licenses_meta ) && count( $licenses_meta ) > 1 ) {
				// Multiple licenses — AggregateOffer.
				$prices = [];
				foreach ( $licenses_meta as $license_key => $license_data ) {
					if ( isset( $license_data['price'] ) && is_numeric( $license_data['price'] ) ) {
						$prices[] = (float) $license_data['price'];
					}
				}

				if ( empty( $prices ) ) {
					$base_price = function_exists( 'wpdmpp_effective_price' ) ? wpdmpp_effective_price( $post->ID ) : 0;
					$prices     = [ (float) $base_price ];
				}

				$markup['offers'] = [
					'@type'                   => 'AggregateOffer',
					'lowPrice'                => number_format( (float) min( $prices ), 2, '.', '' ),
					'highPrice'               => number_format( (float) max( $prices ), 2, '.', '' ),
					'priceCurrency'           => $currency,
					'offerCount'              => count( $prices ),
					'availability'            => $availability,
					'seller'                  => [
						'@id' => $site_schema_id,
					],
					'shippingDetails'         => $shippingDetails,
					'hasMerchantReturnPolicy' => $returnPolicy,
				];

				// Individual license offers.
				$markup['offers']['offers'] = [];
				foreach ( $licenses_meta as $license_key => $license_data ) {
					if ( isset( $license_data['price'] ) && is_numeric( $license_data['price'] ) ) {
						$offer = [
							'@type'         => 'Offer',
							'price'         => number_format( (float) $license_data['price'], 2, '.', '' ),
							'priceCurrency' => $currency,
							'availability'  => $availability,
							'url'           => $permalink,
							'seller'        => [
								'@id' => $site_schema_id,
							],
						];

						if ( ! empty( $license_data['name'] ) ) {
							$offer['name'] = esc_html( $license_data['name'] );
						}

						$markup['offers']['offers'][] = $offer;
					}
				}
			} else {
				// Single offer.
				$price = function_exists( 'wpdmpp_effective_price' ) ? wpdmpp_effective_price( $post->ID ) : 0;

				$markup['offers'] = [
					'@type'                   => 'Offer',
					'url'                     => $permalink,
					'price'                   => number_format( (float) $price, 2, '.', '' ),
					'priceValidUntil'         => $price_valid_until,
					'priceCurrency'           => $currency,
					'itemCondition'           => 'https://schema.org/NewCondition',
					'availability'            => $availability,
					'seller'                  => [
						'@id' => $site_schema_id,
					],
					'shippingDetails'         => $shippingDetails,
					'hasMerchantReturnPolicy' => $returnPolicy,
				];
			}
		} else {
			// No premium packages — free download.
			$markup['offers'] = [
				'@type'                   => 'Offer',
				'url'                     => $permalink,
				'price'                   => '0.00',
				'priceValidUntil'         => $price_valid_until,
				'priceCurrency'           => 'USD',
				'itemCondition'           => 'https://schema.org/NewCondition',
				'availability'            => $availability,
				'seller'                  => [
					'@id' => $site_schema_id,
				],
				'shippingDetails'         => $shippingDetails,
				'hasMerchantReturnPolicy' => $returnPolicy,
			];
		}

		// Category.
		$categories = get_the_terms( $post->ID, 'wpdmcategory' );
		if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) {
			$markup['category'] = esc_html( $categories[0]->name );
		}

		// Aggregate rating.
		$total_rating = ReviewFns::getTotalRatings( $post->ID );
		if ( $total_rating ) {
			$markup['aggregateRating'] = [
				'@type'       => 'AggregateRating',
				'ratingValue' => (float) ReviewFns::getAvgRatings( $post->ID, true ),
				'reviewCount' => $total_rating,
			];
		}

		return $this->add_product_reviews( $markup, $post->ID, 'wpdmpro', $schemaObj );
	}

	/**
	 * Get SureCart product schema markup.
	 *
	 * @param \WP_Post $post      The post object.
	 * @param object   $schemaObj The schema object.
	 *
	 * @return array Product schema markup.
	 */
	private function get_surecart_product_auto_schema( $post, $schemaObj ) {
		$product = sc_get_product( $post->ID );

		if ( ! $product ) {
			return [];
		}

		$site_schema_id = $schemaObj->get_site_schema_id();
		$permalink      = get_permalink( $post->ID );
		$markup         = [
			'@type'       => 'Product',
			'@id'         => $permalink . '#product0',
			'name'        => wp_kses_post( $post->post_title ),
			'url'         => $permalink,
			'description' => wp_strip_all_tags( do_shortcode( $post->post_excerpt ? $post->post_excerpt : $post->post_content ) ),
		];

		// Image.
		$image = $product->image_url ?? '';
		if ( empty( $image ) ) {
			$image = get_the_post_thumbnail_url( $post->ID, 'full' );
		}
		if ( $image ) {
			$markup['image'] = $image;
		}

		// SKU.
		$sku           = get_post_meta( $post->ID, 'sku', true );
		$markup['sku'] = ! empty( $sku ) ? (string) $sku : (string) $post->ID;

		// Brand.
		$brand_name = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'brand_name' );
		if ( $brand_name ) {
			$markup['brand'] = [
				'@type' => 'Brand',
				'name'  => esc_html( $brand_name ),
			];
		}

		// Identifier.
		$identifier_type = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'identifier_type' );
		$identifier      = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'identifier' );
		if ( $identifier_type && $identifier ) {
			$markup[ $identifier_type ] = esc_html( $identifier );
		}

		// Currency.
		$account  = \SureCart::account();
		$currency = $account->currency ?? 'usd';

		// Offers.
		$active_prices     = (array) $product->active_prices;
		$availability      = ! empty( $product->in_stock ) ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock';
		$price_valid_until = gmdate( 'Y-12-31', time() + 2 * YEAR_IN_SECONDS );

		// Shipping details (SureCart-specific).
		$shippingDetails = $this->get_surecart_shipping_details( strtoupper( $currency ) );

		// Return policy.
		$returnPolicy = FnsPro::get_merchant_return_policy();

		// Add shared shipping & return policy entries at graph level.
		if ( ! empty( $shippingDetails ) ) {
			foreach ( $shippingDetails as $sd ) {
				$this->shared_schema_entries[] = $sd;
			}
		}
		if ( ! empty( $returnPolicy ) ) {
			$return_policy_id              = $returnPolicy['@id'];
			$this->shared_schema_entries[] = $returnPolicy;
		} else {
			$return_policy_id = '';
		}

		// Build shipping/return references for offers.
		$shipping_refs = [];
		if ( ! empty( $shippingDetails ) ) {
			foreach ( $shippingDetails as $sd ) {
				$shipping_refs[] = [ '@id' => $sd['@id'] ];
			}
		}

		if ( count( $active_prices ) > 1 ) {
			$min_price      = get_post_meta( $post->ID, 'min_price_amount', true );
			$max_price      = get_post_meta( $post->ID, 'max_price_amount', true );
			$price_currency = ! empty( $active_prices[0]->currency ) ? $active_prices[0]->currency : $currency;

			$markup['offers'] = [
				'@type'         => 'AggregateOffer',
				'lowPrice'      => number_format( (float) $min_price, 2, '.', '' ),
				'highPrice'     => number_format( (float) $max_price, 2, '.', '' ),
				'priceCurrency' => strtoupper( $price_currency ),
				'offerCount'    => count( $active_prices ),
				'availability'  => $availability,
				'seller'        => [
					'@id' => $site_schema_id,
				],
			];

			if ( ! empty( $shipping_refs ) ) {
				$markup['offers']['shippingDetails'] = $shipping_refs;
			}
			if ( ! empty( $return_policy_id ) ) {
				$markup['offers']['hasMerchantReturnPolicy'] = [ '@id' => $return_policy_id ];
			}

			// Individual price offers.
			$markup['offers']['offers'] = [];
			foreach ( $active_prices as $price ) {
				$offer = [
					'@type'         => 'Offer',
					'price'         => number_format( (float) \SureCart\Support\Currency::maybeConvertAmount( $price->amount, $price->currency ), 2, '.', '' ),
					'priceCurrency' => strtoupper( $price->currency ),
					'availability'  => $availability,
					'url'           => $permalink,
				];

				if ( ! empty( $price->name ) ) {
					$offer['name'] = esc_html( $price->name );
				}

				$markup['offers']['offers'][] = $offer;
			}
		} elseif ( count( $active_prices ) === 1 ) {
			$price          = $active_prices[0];
			$price_currency = ! empty( $price->currency ) ? $price->currency : $currency;

			$markup['offers'] = [
				'@type'           => 'Offer',
				'url'             => $permalink,
				'price'           => number_format( (float) \SureCart\Support\Currency::maybeConvertAmount( $price->amount, $price->currency ), 2, '.', '' ),
				'priceValidUntil' => $price_valid_until,
				'priceCurrency'   => strtoupper( $price_currency ),
				'itemCondition'   => 'https://schema.org/NewCondition',
				'availability'    => $availability,
				'seller'          => [
					'@id' => $site_schema_id,
				],
			];

			if ( ! empty( $shipping_refs ) ) {
				$markup['offers']['shippingDetails'] = $shipping_refs;
			}
			if ( ! empty( $return_policy_id ) ) {
				$markup['offers']['hasMerchantReturnPolicy'] = [ '@id' => $return_policy_id ];
			}
		}

		// Category.
		$categories = get_the_terms( $post->ID, 'sc_collection' );
		if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) {
			$markup['category'] = esc_html( $categories[0]->name );
		}

		// Aggregate rating.
		$total_rating = ReviewFns::getTotalRatings( $post->ID );
		if ( $total_rating ) {
			$markup['aggregateRating'] = [
				'@type'       => 'AggregateRating',
				'ratingValue' => (float) ReviewFns::getAvgRatings( $post->ID, true ),
				'reviewCount' => $total_rating,
			];
		} elseif ( ! empty( $product->total_reviews ) && ! empty( $product->average_stars ) ) {
			// Fallback to SureCart's built-in review data.
			$markup['aggregateRating'] = [
				'@type'       => 'AggregateRating',
				'ratingValue' => (float) $product->average_stars,
				'reviewCount' => $product->total_reviews,
			];
		}

		return $this->add_product_reviews( $markup, $post->ID, 'sc_product', $schemaObj );
	}

	/**
	 * Get WooCommerce product schema markup.
	 *
	 * @param object $schemaObj The schema object.
	 *
	 * @return array Product schema markup.
	 */
	private function get_woocommerce_product_auto_schema( $schemaObj, $helper ) {
		$markup = [];

		if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ), true ) ) {
			return $markup;
		}

		global $product;
		if ( ! is_a( $product, 'WC_Product' ) ) {
			$product = wc_get_product( $schemaObj->post_id );
		}
		if ( ! is_a( $product, 'WC_Product' ) ) {
			return $markup;
		}

		$site_schema_id = $schemaObj->get_site_schema_id();
		$currency       = get_woocommerce_currency();
		$permalink      = get_permalink( $product->get_id() );
		$markup         = [
			'@type'       => 'Product',
			'@id'         => $permalink . '#product0',
			'name'        => wp_kses_post( $product->get_name() ),
			'url'         => $permalink,
			'description' => wp_strip_all_tags( do_shortcode( $product->get_short_description() ? $product->get_short_description() : $product->get_description() ) ),
		];

		$image = wp_get_attachment_url( $product->get_image_id() );
		if ( $image ) {
			$markup['image'] = $image;
		}

		$brand = $this->get_product_brand( $product->get_id(), $product );
		if ( ! empty( $brand ) ) {
			$markup['brand'] = $brand;
		}

		$return_policy_id = '';
		$shipping_refs    = [];
		$return_policy    = FnsPro::get_merchant_return_policy();
		if ( ! empty( $return_policy ) ) {
			$return_policy_id              = $return_policy['@id'];
			$this->shared_schema_entries[] = $return_policy;
		}
		$shipping_details = FnsPro::get_offer_shipping_details( $currency );
		if ( ! empty( $shipping_details ) ) {
			foreach ( $shipping_details as $sd ) {
				$shipping_refs[]               = [ '@id' => $sd['@id'] ];
				$this->shared_schema_entries[] = $sd;
			}
		}

		if ( $product->is_type( 'variable' ) ) {
			// Variable product → ProductGroup schema.
			$markup['@type']          = 'ProductGroup';
			$markup['productGroupID'] = $product->get_sku() ? $product->get_sku() : (string) $product->get_id();
			$markup['variesBy']       = $this->get_variation_varies_by( $product );
			$markup['hasVariant']     = $this->get_variation_products( $product, $currency, $site_schema_id, $helper, $return_policy_id, $shipping_refs );
		} else {
			// Simple product → Product schema.
			$markup['sku'] = $product->get_sku() ? $product->get_sku() : $product->get_id();

			$identifier_type = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'identifier_type' );
			$identifier      = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'identifier' );
			if ( $identifier_type && $identifier ) {
				$markup[ $identifier_type ] = esc_html( $identifier );
			}

			if ( '' !== $product->get_price() ) {
				$markup_offer     = $this->get_woocommerce_offer( $product, $currency, $site_schema_id, $return_policy_id, $shipping_refs );
				$markup['offers'] = apply_filters( 'woocommerce_structured_data_product_offer', $markup_offer, $product );
			}
		}

		if ( $product->get_rating_count() && wc_review_ratings_enabled() ) {
			$markup['aggregateRating'] = [
				'@type'       => 'AggregateRating',
				'ratingValue' => (float) $product->get_average_rating(),
				'reviewCount' => $product->get_review_count(),
			];

			$markup = $this->add_product_reviews( $markup, $product->get_id(), 'product', $schemaObj );
		}

		return $markup;
	}

	/**
	 * Get WooCommerce offer schema.
	 *
	 * @param  \WC_Product $product  The WooCommerce product.
	 * @param  string      $currency  The currency code.
	 * @param  string      $site_schema_id  The site schema ID.
	 * @param \WC_Product $product           The WooCommerce product.
	 * @param string      $currency          The currency code.
	 * @param string      $site_schema_id    The site schema ID.
	 * @param string      $return_policy_id  Optional @id reference for shared MerchantReturnPolicy.
	 * @param array       $shipping_refs     Optional array of @id references for shared OfferShippingDetails.
	 *
	 * @return array Offer schema markup.
	 */
	private function get_woocommerce_offer( $product, $currency, $site_schema_id, $return_policy_id = '', $shipping_refs = [] ) {
		$permalink         = get_permalink( $product->get_id() );
		$price_valid_until = gmdate( 'Y-12-31', time() + 2 * YEAR_IN_SECONDS );
		if ( $product->is_type( 'variable' ) ) {
			$markup_offer = [
				'@type'         => 'AggregateOffer',
				'lowPrice'      => wc_format_decimal( $product->get_variation_price( 'min', false ), wc_get_price_decimals() ),
				'highPrice'     => wc_format_decimal( $product->get_variation_price( 'max', false ), wc_get_price_decimals() ),
				'priceCurrency' => $currency,
				'offerCount'    => count( $product->get_children() ),
				'offers'        => [],
			];

			$product_data = FnsPro::get_woocommerce_pricing( $product->get_id() );
			if ( $product_data && is_array( $product_data ) ) {
				foreach ( $product_data as $value ) {
					$markup_offer['offers'][] = [
						'@type'         => 'Offer',
						'price'         => wc_format_decimal( $value['price'], wc_get_price_decimals() ),
						'priceCurrency' => $currency,
						'availability'  => $value['availability'],
						'url'           => get_permalink( $value['variation_id'] ?? $product->get_id() ),
						'seller'        => [
							'@id' => $site_schema_id,
						],
					];
				}
			}
		} else {
			if ( $product->is_on_sale() && $product->get_date_on_sale_to() ) {
				$price_valid_until = gmdate( 'Y-m-d', $product->get_date_on_sale_to()->getTimestamp() );
			}

			$markup_offer = [
				'@type'              => 'Offer',
				'price'              => wc_format_decimal( $product->get_price(), wc_get_price_decimals() ),
				'priceCurrency'      => $currency,
				'availability'       => 'https://schema.org/' . ( $product->is_in_stock() ? 'InStock' : 'OutOfStock' ),
				'priceValidUntil'    => $price_valid_until,
				'url'                => $permalink,
				'seller'             => [
					'@id' => $site_schema_id,
				],
				'priceSpecification' => [
					'@type'                 => 'UnitPriceSpecification',
					'price'                 => wc_format_decimal( $product->get_price(), wc_get_price_decimals() ),
					'priceCurrency'         => $currency,
					'valueAddedTaxIncluded' => wc_prices_include_tax() ? 'true' : 'false',
				],
			];
		}

		if ( ! empty( $return_policy_id ) ) {
			$markup_offer['hasMerchantReturnPolicy'] = [ '@id' => $return_policy_id ];
		} else {
			$return_policy = FnsPro::get_merchant_return_policy();
			if ( ! empty( $return_policy ) ) {
				$markup_offer['hasMerchantReturnPolicy'] = $return_policy;
			}
		}

		if ( ! empty( $shipping_refs ) ) {
			$markup_offer['shippingDetails'] = $shipping_refs;
		} else {
			$shipping_details = FnsPro::get_offer_shipping_details( $currency );
			if ( ! empty( $shipping_details ) ) {
				$markup_offer['shippingDetails'] = $shipping_details;
			}
		}

		return $markup_offer;
	}

	/**
	 * Get product brand schema array.
	 *
	 * Checks product-level brand sources first (taxonomies, attributes),
	 * then falls back to global settings.
	 *
	 * @param int              $post_id The product post ID.
	 * @param \WC_Product|null $product Optional WC_Product for attribute lookup.
	 *
	 * @return array Brand schema array or empty array.
	 */
	private function get_product_brand( $post_id, $product = null ) {
		$brand_name = '';

		// 1. Check brand taxonomies.
		$brand_taxonomies = [ 'product_brand', 'pwb-brand', 'yith_product_brand', 'product-brands' ];
		foreach ( $brand_taxonomies as $tax ) {
			if ( taxonomy_exists( $tax ) ) {
				$brands = get_the_terms( $post_id, $tax );
				if ( ! empty( $brands ) && ! is_wp_error( $brands ) ) {
					$brand_name = $brands[0]->name;
					break;
				}
			}
		}

		// 2. Check WooCommerce product attribute 'brand'.
		if ( empty( $brand_name ) && $product && method_exists( $product, 'get_attribute' ) ) {
			$attr_brand = $product->get_attribute( 'brand' );
			if ( ! empty( $attr_brand ) ) {
				$brand_name = $attr_brand;
			}
		}

		// 3. Fallback: global brand from settings.
		if ( empty( $brand_name ) ) {
			$brand_name = rtrs()->get_options( 'rtrs_schema_ecommerce_settings', 'brand_name' );
		}

		if ( ! empty( $brand_name ) ) {
			return [
				'@type' => 'Brand',
				'name'  => esc_html( $brand_name ),
			];
		}

		return [];
	}

	/**
	 * Get Schema.org variesBy URLs from variation attributes.
	 *
	 * @param \WC_Product_Variable $product The variable product.
	 *
	 * @return array Array of Schema.org property URLs.
	 */
	private function get_variation_varies_by( $product ) {
		$known_map = [
			'color'       => 'https://schema.org/color',
			'pa_color'    => 'https://schema.org/color',
			'size'        => 'https://schema.org/size',
			'pa_size'     => 'https://schema.org/size',
			'material'    => 'https://schema.org/material',
			'pa_material' => 'https://schema.org/material',
			'pattern'     => 'https://schema.org/pattern',
			'pa_pattern'  => 'https://schema.org/pattern',
		];

		$varies_by  = [];
		$attributes = $product->get_variation_attributes();

		foreach ( array_keys( $attributes ) as $attribute_name ) {
			$clean_name = str_replace( 'attribute_', '', strtolower( $attribute_name ) );

			if ( isset( $known_map[ $clean_name ] ) ) {
				$varies_by[] = $known_map[ $clean_name ];
			} else {
				// Strip pa_ prefix for custom attributes.
				$schema_name = preg_replace( '/^pa_/', '', $clean_name );
				$varies_by[] = 'https://schema.org/' . $schema_name;
			}
		}

		return array_unique( $varies_by );
	}

	/**
	 * Build hasVariant array for a variable product.
	 *
	 * @param \WC_Product_Variable $product           The variable product.
	 * @param string               $currency          The currency code.
	 * @param string               $site_schema_id    The site schema ID.
	 * @param string               $return_policy_id  Optional @id reference for shared MerchantReturnPolicy.
	 * @param array                $shipping_refs     Optional array of @id references for shared OfferShippingDetails.
	 *
	 * @return array Array of Product schema objects for each variation.
	 */
	private function get_variation_products( $product, $currency, $site_schema_id, $helper, $return_policy_id = '', $shipping_refs = [] ) {
		$variants          = [];
		$variations        = $product->get_available_variations( 'objects' );
		$price_valid_until = gmdate( 'Y-12-31', time() + 2 * YEAR_IN_SECONDS );
		foreach ( $variations as $variation ) {
			$variant = [
				'@type'       => 'Product',
				'sku'         => $variation->get_sku() ? $variation->get_sku() : (string) $variation->get_id(),
				'name'        => $variation->get_name(),
				'description' => wp_strip_all_tags( do_shortcode( $product->get_short_description() ? $product->get_short_description() : $product->get_description() ) ),
			];

			// Add variation attribute properties (e.g. "color": "Blue").
			$attributes = $variation->get_attributes();
			foreach ( $attributes as $attr_key => $attr_value ) {
				$clean_key = preg_replace( '/^pa_/', '', strtolower( $attr_key ) );
				// Get the display name (term name for taxonomy attributes).
				$label = $variation->get_attribute( $attr_key );
				if ( ! empty( $label ) ) {
					$variant[ $clean_key ] = $label;
				} else {
					$labels = [];
					$terms  = wc_get_product_terms( $product->get_id(), $attr_key, [ 'fields' => 'all' ] );
					foreach ( $terms as $term ) {
						$labels[] = $term->name;
					}
					$variant[ $clean_key ] = $labels;
				}
			}

			$img = $helper->imageInfo( absint( $variation->get_image_id() ) );
			if ( $img ) {
				$variant['image'] = [
					'@type'       => 'ImageObject',
					'url'         => $helper->sanitizeOutPut( $img['url'], 'url' ),
					'description' => $helper->sanitizeOutPut( $img['title'] ),
					'height'      => $img['height'],
					'width'       => $img['width'],
				];
			}

			$variant_offer = [
				'@type'           => 'Offer',
				'price'           => wc_format_decimal( $variation->get_price(), wc_get_price_decimals() ),
				'priceCurrency'   => $currency,
				'availability'    => 'https://schema.org/' . ( $variation->is_in_stock() ? 'InStock' : 'OutOfStock' ),
				'url'             => $variation->get_permalink(),
				'priceValidUntil' => $price_valid_until,
				'seller'          => [
					'@id' => $site_schema_id,
				],
			];

			if ( ! empty( $return_policy_id ) ) {
				$variant_offer['hasMerchantReturnPolicy'] = [ '@id' => $return_policy_id ];
			}

			if ( ! empty( $shipping_refs ) ) {
				$variant_offer['shippingDetails'] = $shipping_refs;
			}

			$variant['offers'] = $variant_offer;

			$variants[] = $variant;
		}

		return $variants;
	}

	/**
	 * Add product reviews to schema markup.
	 *
	 * @param  array  $markup  The existing schema markup.
	 * @param  int    $post_id  The post ID.
	 * @param  string $post_type  The post type.
	 * @param  object $schemaObj  The schema object.
	 *
	 * @return array Modified schema markup with reviews.
	 */
	private function add_product_reviews( $markup, $post_id, $post_type, $schemaObj ) {
		$comments = get_comments(
			[
				'number'      => 5,
				'post_id'     => $post_id,
				'status'      => 'approve',
				'post_status' => 'publish',
				'post_type'   => $post_type,
				'parent'      => 0,
				'meta_query'  => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					[
						'key'     => 'rating',
						'type'    => 'NUMERIC',
						'compare' => '>',
						'value'   => 0,
					],
				],
			],
		);

		if ( $comments ) {
			$markup['review'] = [];
			foreach ( $comments as $comment ) {
				$rating = get_comment_meta( $comment->comment_ID, 'rating', true );
				if ( ! $rating ) {
					continue;
				}
				$markup['review'][] = [
					'@type'         => 'Review',
					'reviewRating'  => [
						'@type'       => 'Rating',
						'bestRating'  => '5',
						'ratingValue' => (float) $rating,
						'worstRating' => '1',
					],
					'author'        => [
						'@type' => 'Person',
						'name'  => get_comment_author( $comment ),
						'@id'   => $schemaObj->get_id_with_hash( 'person-' . sanitize_title( get_comment_author( $comment ) ) ),
					],
					'reviewBody'    => get_comment_text( $comment ),
					'datePublished' => get_comment_date( 'c', $comment ),
				];
			}
		}

		return $markup;
	}

	/**
	 * Get SpecialAnnouncement schema markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  string    $site_schema_id  The site schema ID.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 *
	 * @return array SpecialAnnouncement schema markup.
	 */
	private function get_special_announcement_schema( $metaData, $site_schema_id, $schemaObject, $helper, $schema_key_id ) {
		$schema_id    = $schemaObject->get_id_with_hash( 'special_announcement' . $schema_key_id );
		$announcement = [
			'@type' => 'SpecialAnnouncement',
			'@id'   => $schema_id,
			'url'   => $schemaObject->get_id_with_hash(),
		];
		if ( ! empty( $metaData['category'] ) ) {
			$announcement['category'] = $helper->sanitizeOutPut( $metaData['category'] ?? 'generalUpdate' );
		}
		if ( ! empty( $metaData['name'] ) ) {
			$announcement['name'] = $helper->sanitizeOutPut( $metaData['name'] );
		}
		$announcement['datePosted'] = get_the_date( DATE_W3C, get_the_ID() );
		if ( ! empty( $metaData['expires'] ) ) {
			$announcement['expires'] = $helper->sanitizeOutPut( $metaData['expires'] );
		}
		if ( ! empty( $metaData['text'] ) ) {
			$announcement['text'] = $helper->sanitizeOutPut( $metaData['text'], 'textarea' );
		}
		$announcement['provider']             = [
			'@id' => $site_schema_id,
		];
		$announcement['announcementLocation'] = [
			'@id' => $site_schema_id,
		];

		return apply_filters( 'rtseo_snippet_special_announcement', $announcement, $metaData );
	}

	/**
	 * Get ImageLicense schema markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 *
	 * @return array ImageLicense schema markup.
	 */
	private function get_image_license_schema( $metaData, $schemaObject, $helper, $schema_key_id ) {
		$schema_id     = $schemaObject->get_id_with_hash( 'image_license' . $schema_key_id );
		$image_license = [
			'@type' => 'ImageObject',
			'@id'   => $schema_id,
		];
		if ( ! empty( $metaData['name'] ) ) {
			$image_license['name'] = $helper->sanitizeOutPut( $metaData['name'] );
		}
		if ( ! empty( $metaData['description'] ) ) {
			$image_license['description'] = $helper->sanitizeOutPut( $metaData['description'] );
		}
		if ( ! empty( $metaData['contentUrl'] ) ) {
			$image_license['contentUrl'] = $helper->sanitizeOutPut( $metaData['contentUrl'], 'url' );
		}
		if ( ! empty( $metaData['license'] ) ) {
			$image_license['license'] = $helper->sanitizeOutPut( $metaData['license'], 'url' );
		}
		if ( ! empty( $metaData['acquireLicensePage'] ) ) {
			$image_license['acquireLicensePage'] = $helper->sanitizeOutPut( $metaData['acquireLicensePage'], 'url' );
		}

		return apply_filters( 'rtseo_snippet_image_license', $image_license, $metaData );
	}

	private function get_software_app_schema( $metaData, $schemaObject, $helper, $schema_key_id ) {
		$schemas   = [];
		$schema_id = $schemaObject->get_id_with_hash( 'software_app' . $schema_key_id );
		$app       = [
			'@type' => 'SoftwareApplication',
			'@id'   => $schema_id,
			'url'   => $schemaObject->get_id_with_hash(),
		];
		if ( ! empty( $metaData['name'] ) ) {
			$app['name'] = $helper->sanitizeOutPut( $metaData['name'] );
		}
		if ( ! empty( $metaData['description'] ) ) {
			$app['description'] = $helper->sanitizeOutPut(
				$metaData['description'],
				'textarea',
			);
		}
		$image_id = get_post_thumbnail_id( get_the_ID() );
		if ( $image_id ) {
			$img = $helper->imageInfo( $image_id );
			if ( $img ) {
				$app['image'] = [
					'@type'       => 'ImageObject',
					'url'         => $helper->sanitizeOutPut( $img['url'], 'url' ),
					'description' => $helper->sanitizeOutPut( $img['title'] ),
					'height'      => $img['height'],
					'width'       => $img['width'],
				];
			}
		}
		if ( ! empty( $metaData['applicationCategory'] ) ) {
			$app['applicationCategory'] = $helper->sanitizeOutPut( $metaData['applicationCategory'] );
		}
		if ( ! empty( $metaData['operatingSystem'] ) ) {
			$app['operatingSystem'] = $helper->sanitizeOutPut( $metaData['operatingSystem'] );
		}
		if ( ! empty( $metaData['softwareVersion'] ) ) {
			$app['softwareVersion'] = $helper->sanitizeOutPut( $metaData['softwareVersion'] );
		}
		if ( ! empty( $metaData['downloadUrl'] ) ) {
			$app['downloadUrl'] = $helper->sanitizeOutPut( $metaData['downloadUrl'], 'url' );
		}
		$variation_offers = $this->build_variation_offers( $metaData, get_permalink( get_the_ID() ), $helper, $schemaObject );

		if ( ! empty( $variation_offers ) ) {
			$app['offers'] = $variation_offers;
		} elseif ( isset( $metaData['price'] ) && '' !== $metaData['price'] && is_numeric( $metaData['price'] ) ) {
			// Use isset()/is_numeric() so a free app priced at 0 is still output;
			// empty() would incorrectly drop a legitimate "0" price.
			$app['offers'] = [
				'@type'        => 'Offer',
				'availability' => 'https://schema.org/InStock',
				'price'        => $helper->sanitizeOutPut( $metaData['price'], 'number' ),
			];
			if ( ! empty( $metaData['priceCurrency'] ) ) {
				$app['offers']['priceCurrency'] = $helper->sanitizeOutPut( $metaData['priceCurrency'] );
			}
		}
		if ( ! empty( $metaData['aggregate_ratingValue'] ) ) {
			$app['aggregateRating'] = [
				'@type'       => 'AggregateRating',
				'ratingValue' => esc_attr( $metaData['aggregate_ratingValue'] ),
			];
			if ( ! empty( $metaData['aggregate_bestRating'] ) ) {
				$app['aggregateRating']['bestRating'] = $helper->sanitizeOutPut( $metaData['aggregate_bestRating'], 'number' );
			}
			if ( ! empty( $metaData['aggregate_worstRating'] ) ) {
				$app['aggregateRating']['worstRating'] = $helper->sanitizeOutPut( $metaData['aggregate_worstRating'], 'number' );
			}
			if ( ! empty( $metaData['aggregate_ratingCount'] ) ) {
				$app['aggregateRating']['reviewCount'] = $helper->sanitizeOutPut( $metaData['aggregate_ratingCount'], 'number' );
			}
		}
		if ( isset( $metaData['review_active'] ) && 'show' === $metaData['review_active'] && ! empty( $metaData['review_body'] ) && ! empty( $metaData['review_author'] ) ) {
			$app_review = [
				'@type' => 'Review',
			];
			if ( ! empty( $app['url'] ) ) {
				$type_for_id       = is_array( $app['@type'] ) ? $app['@type'][0] : $app['@type'];
				$app_review['@id'] = $app['url'] . '#review-' . strtolower( $type_for_id ) . $schema_key_id;
				$app['review']     = [
					'@id' => $app_review['@id'],
				];
			}
			if ( ! empty( $metaData['review_datePublished'] ) ) {
				$app_review['datePublished'] = $helper->sanitizeOutPut( $metaData['review_datePublished'] );
			}
			$app_review['reviewBody'] = $helper->sanitizeOutPut( $metaData['review_body'], 'textarea' );
			if ( isset( $metaData['review_sameAs'] ) && ! empty( $metaData['review_sameAs'] ) ) {
				$sameAs = Functions::get_same_as( $helper->sanitizeOutPut( $metaData['review_sameAs'], 'textarea' ) );
				if ( ! empty( $sameAs ) ) {
					$app['sameAs'] = $sameAs;
				}
			}
			if ( ! empty( $metaData['review_author'] ) ) {
				$app_review['author'] = [
					'@type' => 'Person',
					'name'  => $helper->sanitizeOutPut( $metaData['review_author'] ),
					'@id'   => $schemaObject->get_id_with_hash( 'person-' . sanitize_title( $metaData['review_author'] ) ),
				];
				if ( isset( $metaData['review_author_sameAs'] ) && ! empty( $metaData['review_author_sameAs'] ) ) {
					$sameAs = Functions::get_same_as( $helper->sanitizeOutPut( $metaData['review_author_sameAs'], 'textarea' ) );
					if ( ! empty( $sameAs ) ) {
						$app_review['author']['sameAs'] = $sameAs;
					}
				}
			}
			if ( isset( $metaData['review_ratingValue'] ) ) {
				$app_review['reviewRating'] = [
					'@type'       => 'Rating',
					'ratingValue' => $helper->sanitizeOutPut( $metaData['review_ratingValue'], 'number' ),
				];
				if ( isset( $metaData['aggregate_bestRating'] ) ) { // Aggregate best rating will be same.
					$app_review['reviewRating']['bestRating'] = $helper->sanitizeOutPut( $metaData['aggregate_bestRating'], 'number' );
				}
				if ( isset( $metaData['review_worstRating'] ) ) { // Aggregate worst rating will be same.
					$app_review['reviewRating']['worstRating'] = $helper->sanitizeOutPut( $metaData['review_worstRating'], 'number' );
				}
			}
			$schemas[] = apply_filters( 'rtseo_snippet_software_application_review', $app_review, $metaData );
		}
		$schemas[] = apply_filters( 'rtseo_snippet_software_application', $app, $metaData );

		return $schemas;
	}

	/**
	 * Get Recipe schema markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 *
	 * @return array Recipe schema markup.
	 */
	private function get_recipe_schema( $metaData, $schemaObject, $helper, $schema_key_id ) {
		$recipe_id                  = $schemaObject->get_id_with_hash( 'recipe' . $schema_key_id );
		$recipe                     = [
			'@type' => 'Recipe',
			'@id'   => $recipe_id,
		];
		$recipe['mainEntityOfPage'] = get_permalink( get_the_ID() );

		if ( ! empty( $metaData['name'] ) ) {
			$recipe['name'] = $helper->sanitizeOutPut( $metaData['name'] );
		}
		if ( ! empty( $metaData['author'] ) ) {
			$recipe['author'] = [
				'@type' => 'Person',
				'name'  => $helper->sanitizeOutPut( $metaData['author'] ),
				'@id'   => $schemaObject->get_id_with_hash( 'person-' . sanitize_title( $metaData['author'] ) ),
			];
		}
		$recipe['datePublished'] = get_the_date( DATE_W3C, get_the_ID() );

		if ( ! empty( $metaData['keywords'] ) ) {
			$recipe['keywords'] = $helper->sanitizeOutPut( $metaData['keywords'] );
		}
		if ( ! empty( $metaData['recipeCategory'] ) ) {
			$recipe['recipeCategory'] = $helper->sanitizeOutPut( $metaData['recipeCategory'] );
		}
		if ( ! empty( $metaData['recipeCuisine'] ) ) {
			$recipe['recipeCuisine'] = $helper->sanitizeOutPut( $metaData['recipeCuisine'] );
		}
		if ( ! empty( $metaData['prepTime'] ) ) {
			$recipe['prepTime'] = $helper->sanitizeOutPut( $metaData['prepTime'] );
		}
		if ( ! empty( $metaData['cookTime'] ) ) {
			$recipe['cookTime'] = $helper->sanitizeOutPut( $metaData['cookTime'] );
		}
		if ( ! empty( $metaData['description'] ) ) {
			$recipe['description'] = $helper->sanitizeOutPut(
				$metaData['description'],
				'textarea',
			);
		}
		$image_id = get_post_thumbnail_id( get_the_ID() );
		if ( $image_id ) {
			$img             = $helper->imageInfo( $image_id );
			$recipe['image'] = $helper->sanitizeOutPut( $img['url'], 'url' );
		}

		if ( isset( $metaData['ingredient'] ) && is_array( $metaData['ingredient'] ) ) {
			$recipeIngredient = [];
			foreach ( $metaData['ingredient'] as $recipeIngredient_single ) {
				if ( ! empty( $recipeIngredient_single['name'] ) ) {
					array_push( $recipeIngredient, $helper->sanitizeOutPut( $recipeIngredient_single['name'] ) );
				}
			}
			$recipe['recipeIngredient'] = $recipeIngredient;
		}

		if ( isset( $metaData['instructions'] ) && is_array( $metaData['instructions'] ) ) {
			$recipeinstructions = [];
			foreach ( $metaData['instructions'] as $instructions_single ) {
				$instructions_single_schema = [
					'@type' => 'HowToStep',
				];

				if ( ! empty( $instructions_single['name'] ) ) {
					$instructions_single_schema['name'] = $helper->sanitizeOutPut( $instructions_single['name'] );
				}

				if ( ! empty( $instructions_single['text'] ) ) {
					$instructions_single_schema['text'] = $helper->sanitizeOutPut( $instructions_single['text'], 'textarea' );
				}

				if ( ! empty( $instructions_single['url'] ) ) {
					$instructions_single_schema['url'] = $helper->sanitizeOutPut( $instructions_single['url'], 'url' );
				}

				if ( ! empty( $instructions_single['image'] ) ) {
					$img                                 = $helper->imageInfo( absint( $instructions_single['image'] ) );
					$instructions_single_schema['image'] = $helper->sanitizeOutPut( $img['url'], 'url' );
				}

				array_push( $recipeinstructions, $instructions_single_schema );
			}
			$recipe['recipeInstructions'] = $recipeinstructions;
		}

		if ( isset( $metaData['video'] ) && is_array( $metaData['video'] ) ) {
			$recipevideo = [];
			foreach ( $metaData['video'] as $video_single ) {
				if ( $video_single['name'] && $video_single['contentUrl'] ) {
					$video_single_schema = [
						'@type'       => 'VideoObject',
						'name'        => $video_single['name'] ? $helper->sanitizeOutPut( $video_single['name'] ) : null,
						'description' => $video_single['description'] ? $helper->sanitizeOutPut( $video_single['description'] ) : null,
						'contentUrl'  => $video_single['contentUrl'] ? $helper->sanitizeOutPut( $video_single['contentUrl'] ) : null,
						'embedUrl'    => $video_single['embedUrl'] ? $helper->sanitizeOutPut( $video_single['embedUrl'] ) : null,
						'uploadDate'  => $video_single['uploadDate'] ? $helper->sanitizeOutPut( $video_single['uploadDate'] ) : null,
						'duration'    => $video_single['duration'] ? $helper->sanitizeOutPut( $video_single['duration'] ) : null,
					];
					if ( ! empty( $video_single['thumbnailUrl'] ) ) {
						$img                                 = $helper->imageInfo( absint( $video_single['thumbnailUrl'] ) );
						$video_single_schema['thumbnailUrl'] = $helper->sanitizeOutPut( $img['url'], 'url' );
					}

					$recipevideo = $video_single_schema;
				}
			}
			if ( $recipevideo ) {
				$recipe['video'] = $recipevideo;
			}
		}
		if ( ! empty( $metaData['ratingValue'] ) || ! empty( $metaData['reviewCount'] ) ) {
			$recipe['aggregateRating'] = [
				'@type'       => 'AggregateRating',
				'ratingValue' => (float) ( $metaData['ratingValue'] ?? 5 ),
				'reviewCount' => absint( $metaData['reviewCount'] ?? 1 ),
				'bestRating'  => absint( $metaData['bestRating'] ?? 5 ),
				'worstRating' => absint( $metaData['worstRating'] ?? 1 ),
			];
		}
		if ( ! empty( $metaData['calories'] ) || ! empty( $metaData['fatContent'] ) ) {
			$recipe['nutrition'] = [
				'@type'      => 'NutritionInformation',
				'calories'   => $helper->sanitizeOutPut( $metaData['calories'] ),
				'fatContent' => $helper->sanitizeOutPut( $metaData['fatContent'] ),
			];
		}
		if ( ! empty( $metaData['recipeYield'] ) ) {
			$recipe['recipeYield'] = $helper->sanitizeOutPut( $metaData['recipeYield'] );
		}
		if ( ! empty( $metaData['suitableForDiet'] ) ) {
			$recipe['suitableForDiet'] = $helper->sanitizeOutPut( $metaData['suitableForDiet'] );
		}

		// Add review reference if review is active.
		if ( isset( $metaData['review_active'] ) && 'show' === $metaData['review_active'] ) {
			$recipe['review'] = [
				'@id' => $schemaObject->get_id_with_hash( '#review-recipe' . $schema_key_id ),
			];
		}

		return apply_filters( 'rtseo_snippet_recipe', $recipe, $metaData );
	}

	/**
	 * Get Recipe SchemaEngine AI markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 *
	 * @return array|null Recipe SchemaEngine AI markup or null if not active.
	 */
	private function get_recipe_review_schema( $metaData, $schemaObject, $helper, $schema_key_id ) {
		if ( ! isset( $metaData['review_active'] ) || 'show' !== $metaData['review_active'] ) {
			return null;
		}

		$recipe_id     = $schemaObject->get_id_with_hash( 'recipe' . $schema_key_id );
		$recipe_review = [
			'@type' => 'Review',
			'@id'   => $schemaObject->get_id_with_hash( '#review-recipe' . $schema_key_id ),
		];

		if ( isset( $metaData['review_datePublished'] ) && ! empty( $metaData['review_datePublished'] ) ) {
			$recipe_review['datePublished'] = $helper->sanitizeOutPut( $metaData['review_datePublished'] );
		} elseif ( isset( $metaData['datePublished'] ) ) {
			$recipe_review['datePublished'] = $helper->sanitizeOutPut( $metaData['datePublished'] );
		}
		if ( isset( $metaData['review_body'] ) && ! empty( $metaData['review_body'] ) ) {
			$recipe_review['reviewBody'] = $helper->sanitizeOutPut( $metaData['review_body'], 'textarea' );
		}

		if ( ! empty( $metaData['review_author'] ) ) {
			$recipe_review['author'] = [
				'@type' => 'Person',
				'name'  => $helper->sanitizeOutPut( $metaData['review_author'] ),
				'@id'   => $schemaObject->get_id_with_hash( 'person-' . sanitize_title( $metaData['review_author'] ) ),
			];

			if ( isset( $metaData['review_author_sameAs'] ) && ! empty( $metaData['review_author_sameAs'] ) ) {
				$sameAs = Functions::get_same_as( $helper->sanitizeOutPut( $metaData['review_author_sameAs'], 'textarea' ) );
				if ( ! empty( $sameAs ) ) {
					$recipe_review['author']['sameAs'] = $sameAs;
				}
			}
		}
		if ( isset( $metaData['review_ratingValue'] ) ) {
			$recipe_review['reviewRating'] = [
				'@type'       => 'Rating',
				'ratingValue' => $helper->sanitizeOutPut( $metaData['review_ratingValue'], 'number' ),
			];
			if ( isset( $metaData['review_bestRating'] ) ) {
				$recipe_review['reviewRating']['bestRating'] = $helper->sanitizeOutPut( $metaData['review_bestRating'], 'number' );
			}
			if ( isset( $metaData['review_worstRating'] ) ) {
				$recipe_review['reviewRating']['worstRating'] = $helper->sanitizeOutPut( $metaData['review_worstRating'], 'number' );
			}
		}

		return apply_filters( 'rtseo_snippet_recipe_review', $recipe_review, $metaData );
	}

	/**
	 * Get JobPosting schema markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  string    $site_schema_id  The site schema ID.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 *
	 * @return array JobPosting schema markup.
	 */
	private function get_job_posting_schema( $metaData, $site_schema_id, $schemaObject, $helper, $schema_key_id ) {
		$schema_id  = $schemaObject->get_id_with_hash( 'job_posting' . $schema_key_id );
		$jobPosting = [
			'@type'       => 'JobPosting',
			'@id'         => $schema_id,
			'directApply' => true,
		];
		if ( ! empty( $metaData['title'] ) ) {
			$jobPosting['title'] = $helper->sanitizeOutPut( $metaData['title'] );
		}
		if ( ! empty( $metaData['workHours'] ) ) {
			$jobPosting['workHours'] = $helper->sanitizeOutPut( $metaData['workHours'] );
		}
		if ( ! empty( $metaData['salaryAmount'] ) || ! empty( $metaData['currency'] ) || ! empty( $metaData['salaryAt'] ) ) {
			$jobPosting['baseSalary'] = [
				'@type'    => 'MonetaryAmount',
				'currency' => $helper->sanitizeOutPut( $metaData['currency'] ),
				'value'    => [
					'@type'    => 'QuantitativeValue',
					'value'    => absint( $metaData['salaryAmount'] ),
					'unitText' => $helper->sanitizeOutPut( $metaData['salaryAt'] ),
				],
			];
		}
		if ( ! empty( $metaData['jobBenefits'] ) ) {
			$jobPosting['jobBenefits'] = $helper->sanitizeOutPut( $metaData['jobBenefits'] );
		}
		if ( ! empty( $metaData['datePosted'] ) ) {
			$jobPosting['datePosted'] = $helper->sanitizeOutPut( $metaData['datePosted'] );
		}
		if ( ! empty( $metaData['validThrough'] ) ) {
			$jobPosting['validThrough'] = $helper->sanitizeOutPut( $metaData['validThrough'] );
		}
		if ( ! empty( $metaData['description'] ) ) {
			$jobPosting['description'] = $helper->sanitizeOutPut(
				$metaData['description'],
				'textarea',
			);
		}
		if ( ! empty( $metaData['educationRequirements'] ) ) {
			$jobPosting['educationRequirements'] = [
				'@type'              => 'EducationalOccupationalCredential',
				'credentialCategory' => $helper->sanitizeOutPut( $metaData['educationRequirements'] ),
			];
		}
		if ( ! empty( $metaData['employmentType'] ) ) {
			$jobPosting['employmentType'] = $helper->sanitizeOutPut( $metaData['employmentType'] );
		}
		if ( ! empty( $metaData['experienceRequirements'] ) ) {
			$jobPosting['experienceRequirements'] = [
				'@type'              => 'OccupationalExperienceRequirements',
				'monthsOfExperience' => $helper->sanitizeOutPut( $metaData['experienceRequirements'] ),
			];
		}
		if ( ! empty( $metaData['incentiveCompensation'] ) ) {
			$jobPosting['incentiveCompensation'] = $helper->sanitizeOutPut( $metaData['incentiveCompensation'] );
		}
		if ( ! empty( $metaData['industry'] ) ) {
			$jobPosting['industry'] = $helper->sanitizeOutPut( $metaData['industry'] );
		}
		if ( ! empty( $metaData['addressLocality'] ) || ! empty( $metaData['addressRegion'] ) ) {
			$jobPosting['jobLocation'] = [
				'@type'   => 'Place',
				'address' => [
					'@type'           => 'PostalAddress',
					'addressCountry'  => $helper->sanitizeOutPut( $metaData['addressCountry'] ?? '' ),
					'addressLocality' => $helper->sanitizeOutPut( $metaData['addressLocality'] ),
					'addressRegion'   => $helper->sanitizeOutPut( $metaData['addressRegion'] ),
					'postalCode'      => $helper->sanitizeOutPut( $metaData['postalCode'] ),
					'streetAddress'   => $helper->sanitizeOutPut( $metaData['streetAddress'] ),
				],
			];
		}
		if ( ! empty( $metaData['occupationalCategory'] ) ) {
			$jobPosting['occupationalCategory'] = $helper->sanitizeOutPut( $metaData['occupationalCategory'] );
		}
		if ( ! empty( $metaData['qualifications'] ) ) {
			$jobPosting['qualifications'] = $helper->sanitizeOutPut(
				$metaData['qualifications'],
				'textarea',
			);
		}
		if ( ! empty( $metaData['responsibilities'] ) ) {
			$jobPosting['responsibilities'] = $helper->sanitizeOutPut(
				$metaData['responsibilities'],
				'textarea',
			);
		}
		if ( ! empty( $metaData['salaryCurrency'] ) ) {
			$jobPosting['salaryCurrency'] = $helper->sanitizeOutPut( $metaData['salaryCurrency'] );
		}
		if ( ! empty( $metaData['skills'] ) ) {
			$jobPosting['skills'] = $helper->sanitizeOutPut( $metaData['skills'], 'textarea' );
		}
		$jobPosting['hiringOrganization'] = [
			'@id' => $site_schema_id,
		];
		$jobPosting['mainEntityOfPage']   = [
			'@type' => 'WebPage',
			'@id'   => $schemaObject->get_id_with_hash( 'webpage' ),
		];

		return apply_filters( 'rtseo_snippet_job_posting', $jobPosting, $metaData );
	}

	/**
	 * Get Course schema markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 *
	 * @return array Course schema markup.
	 */
	private function get_course_schema( $metaData, $schemaObject, $helper, $schema_key_id ) {
		$permalink                   = get_permalink( get_the_ID() );
		$course_id                   = $schemaObject->get_id_with_hash( 'course' . $schema_key_id );
		$course                      = [
			'@type' => 'Course',
			'@id'   => $course_id,
		];
		$course['url']               = $permalink;
		$course['hasCourseInstance'] = [
			'@type' => 'CourseInstance',
		];
		if ( ! empty( $metaData['name'] ) ) {
			$course['name']                      = $helper->sanitizeOutPut( $metaData['name'] );
			$course['hasCourseInstance']['name'] = $helper->sanitizeOutPut( $metaData['name'] );
		}
		if ( ! empty( $metaData['description'] ) ) {
			$course['description']                      = $helper->sanitizeOutPut( $metaData['description'] );
			$course['hasCourseInstance']['description'] = $helper->sanitizeOutPut( $metaData['description'] );
		}
		if ( ! empty( $metaData['provider'] ) ) {
			$course['provider'] = [
				'@type' => 'Organization',
				'name'  => $helper->sanitizeOutPut( $metaData['provider'] ),
			];
		}

		if ( ! empty( $metaData['courseMode'] ) ) {
			$course['hasCourseInstance']['courseMode'] = explode(
				"\r\n",
				$helper->sanitizeOutPut( $metaData['courseMode'], 'textarea' ),
			);
		}

		$courseSchedule = [];

		if ( ! empty( $metaData['duration'] ) ) {
			$courseSchedule['duration'] = $helper->sanitizeOutPut( $metaData['duration'] );
		}
		if ( ! empty( $metaData['repeatFrequency'] ) ) {
			$courseSchedule['repeatFrequency'] = $helper->sanitizeOutPut( $metaData['repeatFrequency'] );
		}
		if ( ! empty( $metaData['repeatCount'] ) ) {
			$courseSchedule['repeatCount'] = $helper->sanitizeOutPut( $metaData['repeatCount'] );
		}

		if ( ! empty( $courseSchedule ) ) {
			$course['hasCourseInstance']['courseSchedule'] = array_merge(
				[
					'@type' => 'Schedule',
				],
				$courseSchedule,
			);
		}

		if ( ! empty( $metaData['endDate'] ) ) {
			$course['hasCourseInstance']['endDate'] = $helper->sanitizeOutPut( $metaData['endDate'] );
		}
		if ( ! empty( $metaData['startDate'] ) ) {
			$course['hasCourseInstance']['startDate'] = $helper->sanitizeOutPut( $metaData['startDate'] );
		}
		if ( ! empty( $metaData['locationName'] ) && ! empty( $metaData['locationAddress'] ) ) {
			$provider_address = [ 'streetAddress' => $metaData['locationAddress'] ];
			if ( ! empty( $metaData['addressLocality'] ) ) {
				$provider_address['addressLocality'] = $metaData['addressLocality'];
			}
			if ( ! empty( $metaData['addressRegion'] ) ) {
				$provider_address['addressRegion'] = $metaData['addressRegion'];
			}
			if ( ! empty( $metaData['postalCode'] ) ) {
				$provider_address['postalCode'] = $metaData['postalCode'];
			}
			if ( ! empty( $metaData['addressCountry'] ) ) {
				$provider_address['addressCountry'] = $metaData['addressCountry'];
			}
			$geo = [];
			if ( ! empty( $metaData['latitude'] ) ) {
				$geo['latitude'] = $metaData['latitude'];
			}
			if ( ! empty( $metaData['longitude'] ) ) {
				$geo['longitude'] = $metaData['longitude'];
			}
			$course['hasCourseInstance']['location'] = [
				'@type'   => 'Place',
				'name'    => $helper->sanitizeOutPut( $metaData['locationName'] ),
				'address' => $provider_address,
			];
			if ( ! empty( $geo ) ) {
				$course['hasCourseInstance']['location']['geo'] = [
					'@type' => 'GeoCoordinates',
				] + $geo;
			}
		}
		$image_id = get_post_thumbnail_id( get_the_ID() );
		if ( $image_id ) {
			$img                                  = $helper->imageInfo( $image_id );
			$course['hasCourseInstance']['image'] = [
				'@type'   => 'ImageObject',
				'url'     => $helper->sanitizeOutPut( $img['url'], 'url' ),
				'caption' => $helper->sanitizeOutPut( $img['caption'] ),
				'height'  => $img['height'],
				'width'   => $img['width'],
			];
		}
		if ( isset( $metaData['price'] ) && '' !== $metaData['price'] && is_numeric( $metaData['price'] ) && ! empty( $metaData['priceCurrency'] ) ) {
			// isset()/is_numeric() so a free course priced at 0 is still output.
			$course['offers'] = [
				'@type'         => 'Offer',
				'price'         => $helper->sanitizeOutPut( $metaData['price'] ),
				'priceCurrency' => $helper->sanitizeOutPut( $metaData['priceCurrency'] ),
			];
			if ( ! empty( $metaData['category'] ) ) {
				$course['offers']['category'] = $helper->sanitizeOutPut( $metaData['category'] );
			}
			if ( ! empty( $metaData['availability'] ) ) {
				$course['offers']['availability'] = $helper->sanitizeOutPut( $metaData['availability'] );
			}
			$course['offers']['url'] = get_permalink( get_the_ID() );
			if ( ! empty( $metaData['validFrom'] ) ) {
				$course['offers']['validFrom'] = $helper->sanitizeOutPut( $metaData['validFrom'] );
			}
		}
		if ( ! empty( $metaData['performerType'] ) && ! empty( $metaData['performerName'] ) ) {
			$course['hasCourseInstance']['performer'] = [
				'@type' => $helper->sanitizeOutPut( $metaData['performerType'] ),
				'name'  => $helper->sanitizeOutPut( $metaData['performerName'] ),
			];
		}
		if ( ! empty( $metaData['aggregate_ratingValue'] ) ) {
			$course['aggregateRating'] = [
				'@type'       => 'AggregateRating',
				'ratingValue' => esc_attr( $metaData['aggregate_ratingValue'] ),
				'bestRating'  => absint( $metaData['review_bestRating'] ?? 1 ),
				'worstRating' => absint( $metaData['review_worstRating'] ?? 1 ),
				'ratingCount' => absint( $metaData['aggregate_ratingCount'] ?? 1 ),
			];
		}

		// Add review reference if review is active.
		if ( 'show' === ( $metaData['review_active'] ?? '' ) && $permalink ) {
			$course['review'] = [
				'@id' => $permalink . '#review-course' . $schema_key_id,
			];
		}

		return apply_filters( 'rtseo_snippet_course', $course, $metaData );
	}

	/**
	 * Get Course SchemaEngine AI markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 *
	 * @return array|null Course SchemaEngine AI markup or null if not active.
	 */
	private function get_course_review_schema( $metaData, $schemaObject, $helper, $schema_key_id ) {
		if ( 'show' !== ( $metaData['review_active'] ?? '' ) ) {
			return null;
		}

		$permalink     = get_permalink( get_the_ID() );
		$course_id     = $schemaObject->get_id_with_hash( 'course' . $schema_key_id );
		$course_review = [
			'@type' => 'Review',
		];

		if ( $permalink ) {
			$course_review['@id'] = $permalink . '#review-course' . $schema_key_id;
		}

		if ( isset( $metaData['review_datePublished'] ) && ! empty( $metaData['review_datePublished'] ) ) {
			$course_review['datePublished'] = $helper->sanitizeOutPut( $metaData['review_datePublished'] );
		}
		if ( isset( $metaData['review_body'] ) && ! empty( $metaData['review_body'] ) ) {
			$course_review['reviewBody'] = $helper->sanitizeOutPut( $metaData['review_body'], 'textarea' );
		}
		if ( ! empty( $metaData['review_author'] ) ) {
			$course_review['author'] = [
				'@type' => 'Person',
				'name'  => $helper->sanitizeOutPut( $metaData['review_author'] ),
				'@id'   => $schemaObject->get_id_with_hash( 'person-' . sanitize_title( $metaData['review_author'] ) ),
			];

			if ( isset( $metaData['review_author_sameAs'] ) && ! empty( $metaData['review_author_sameAs'] ) ) {
				$sameAs = Functions::get_same_as( $helper->sanitizeOutPut( $metaData['review_author_sameAs'], 'textarea' ) );
				if ( ! empty( $sameAs ) ) {
					$course_review['author']['sameAs'] = $sameAs;
				}
			}
		}
		if ( isset( $metaData['review_ratingValue'] ) ) {
			$course_review['reviewRating'] = [
				'@type'       => 'Rating',
				'ratingValue' => $helper->sanitizeOutPut( $metaData['review_ratingValue'], 'number' ),
			];

			if ( isset( $metaData['aggregate_bestRating'] ) ) {
				$course_review['reviewRating']['bestRating'] = $helper->sanitizeOutPut( $metaData['aggregate_bestRating'], 'number' );
			}
			if ( isset( $metaData['aggregate_worstRating'] ) ) {
				$course_review['reviewRating']['worstRating'] = $helper->sanitizeOutPut( $metaData['aggregate_worstRating'], 'number' );
			}
		}

		return apply_filters( 'rtseo_snippet_course_review', $course_review, $metaData );
	}

	/**
	 * Get RealEstateListing schema markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 *
	 * @return array RealEstateListing schema markup.
	 */
	private function get_real_state_listing_schema( $metaData, $schemaObject, $helper, $schema_key_id ) {
		$permalink                      = get_permalink( get_the_ID() );
		$real_state_id                  = $permalink . '#realestatelisting';
		$real_state                     = [
			'@type' => 'RealEstateListing',
			'@id'   => $real_state_id,
		];
		$real_state['mainEntityOfPage'] = [
			'@type' => 'WebPage',
			'@id'   => $permalink,
		];
		if ( ! empty( $metaData['headline'] ) ) {
			$real_state['headline'] = $helper->sanitizeOutPut( $metaData['headline'] );
		}
		if ( ! empty( $metaData['description'] ) ) {
			$real_state['description'] = $helper->sanitizeOutPut(
				$metaData['description'],
				'textarea',
			);
		}

		if ( ! empty( $metaData['author'] ) ) {
			$real_state['author'] = [
				'@type' => 'Person',
				'name'  => $helper->sanitizeOutPut( $metaData['author'] ),
				'@id'   => $schemaObject->get_id_with_hash( 'person-' . sanitize_title( $metaData['author'] ) ),
			];

			if ( ! empty( $metaData['author_url'] ) ) {
				$real_state['author']['url'] = $helper->sanitizeOutPut( $metaData['author_url'], 'url' );
			}
			if ( ! empty( $metaData['author_url'] ) ) {
				$real_state['author']['url'] = $helper->sanitizeOutPut( $metaData['author_url'], 'url' );
			}
		}

		$real_state['publisher'] = [
			'@id' => $schemaObject->get_site_schema_id(),
		];
		$image_id                = get_post_thumbnail_id( get_the_ID() );
		if ( $image_id ) {
			$img                 = $helper->imageInfo( $image_id );
			$real_state['image'] = [
				'@type'  => 'ImageObject',
				'url'    => $helper->sanitizeOutPut( $img['url'], 'url' ),
				'height' => $img['height'],
				'width'  => $img['width'],
			];
		}
		if ( ! empty( $metaData['datePosted'] ) ) {
			$real_state['datePosted'] = $helper->sanitizeOutPut( $metaData['datePosted'] );
		}
		if ( ! empty( $metaData['award'] ) ) {
			$real_state['award'] = $helper->sanitizeOutPut( $metaData['award'] );
		}
		if ( isset( $metaData['price'] ) && '' !== $metaData['price'] && is_numeric( $metaData['price'] ) ) {
			// isset()/is_numeric() so a property priced at 0 is still output.
			$real_state['offers'] = [
				'@type' => 'Offer',
				'price' => $helper->sanitizeOutPut( $metaData['price'] ),
			];
			if ( ! empty( $metaData['priceCurrency'] ) ) {
				$real_state['offers']['priceCurrency'] = $helper->sanitizeOutPut( $metaData['priceCurrency'] );
			}
			$real_state['offers']['mainEntityOfPage'] = get_permalink( get_the_ID() );
			if ( ! empty( $metaData['availability'] ) ) {
				$real_state['offers']['availability'] = $helper->sanitizeOutPut( $metaData['availability'] );
			}
		}
		$mainEntity = [];
		if ( ! empty( $metaData['numberOfBedrooms'] ) ) {
			$mainEntity['numberOfBedrooms'] = absint( $metaData['numberOfBedrooms'] );
		}
		if ( ! empty( $metaData['numberOfRooms'] ) ) {
			$mainEntity['numberOfRooms'] = absint( $metaData['numberOfRooms'] );
		}
		if ( ! empty( $metaData['numberOfBathroomsTotal'] ) ) {
			$mainEntity['numberOfBathroomsTotal'] = absint( $metaData['numberOfBathroomsTotal'] );
		}

		// Floor Size.
		$floorSize = [];
		if ( ! empty( $metaData['floorSizeValue'] ) ) {
			$floorSize['value'] = $metaData['floorSizeValue'];
		}
		if ( ! empty( $metaData['unitCode'] ) ) {
			$floorSize['unitCode'] = $metaData['unitCode'];
		}
		if ( ! empty( $floorSize ) ) {
			$mainEntity['floorSize'] = [
				'@type' => 'QuantitativeValue',
			] + $floorSize;
		}
		// Address.
		$address = [];
		if ( ! empty( $metaData['addresses'] ) && is_array( $metaData['addresses'] ) ) {
			foreach ( $metaData['addresses'] as $part ) {
				if ( ! empty( $part['streetAddress'] ) ) {
					$address['streetAddress'] = $part['streetAddress'];
				}
				if ( ! empty( $part['addressLocality'] ) ) {
					$address['addressLocality'] = $part['addressLocality'];
				}
				if ( ! empty( $part['addressRegion'] ) ) {
					$address['addressRegion'] = $part['addressRegion'];
				}
				if ( ! empty( $part['postalCode'] ) ) {
					$address['postalCode'] = $part['postalCode'];
				}
				if ( ! empty( $part['addressCountry'] ) ) {
					$address['addressCountry'] = $part['addressCountry'];
				}
			}
		}
		if ( ! empty( $address ) ) {
			$mainEntity['address'] = [ '@type' => 'PostalAddress' ] + $address;
		}
		// Floor Size.
		if ( ! empty( $mainEntity ) ) {
			$mainEntity               = [ '@type' => 'SingleFamilyResidence' ] + $mainEntity;
			$real_state['mainEntity'] = $mainEntity;
		}

		return apply_filters( 'rtseo_snippet_real_state', $real_state, $metaData );
	}

	/**
	 * Get RealEstateListing Video schema markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 *
	 * @return array|null Video schema markup or null if not available.
	 */
	private function get_real_state_video_schema( $metaData, $schemaObject, $helper, $schema_key_id ) {
		$permalink     = get_permalink( get_the_ID() );
		$real_state_id = $permalink ? $permalink . '#realestatelisting' : $schemaObject->get_id_with_hash( 'real_state_listing' . $schema_key_id );

		$real_state_video = [];
		if ( isset( $metaData['video'] ) && is_array( $metaData['video'] ) ) {
			foreach ( $metaData['video'] as $video_single ) {
				if ( $video_single['name'] && $video_single['embedUrl'] ) {
					$video_single_schema = [
						'@type'       => 'VideoObject',
						'isPartOf'    => [
							'@id' => $real_state_id,
						],
						'name'        => $video_single['name'] ? $helper->sanitizeOutPut( $video_single['name'] ) : null,
						'description' => $video_single['description'] ? $helper->sanitizeOutPut( $video_single['description'] ) : null,
						'contentUrl'  => $video_single['contentUrl'] ? $helper->sanitizeOutPut( $video_single['contentUrl'] ) : null,
						'embedUrl'    => $video_single['embedUrl'] ? $helper->sanitizeOutPut( $video_single['embedUrl'] ) : null,
						'uploadDate'  => $video_single['uploadDate'] ? $helper->sanitizeOutPut( $video_single['uploadDate'] ) : null,
						'duration'    => $video_single['duration'] ? $helper->sanitizeOutPut( $video_single['duration'] ) : null,
					];
					if ( ! empty( $video_single['thumbnailUrl'] ) ) {
						$img                                 = $helper->imageInfo( absint( $video_single['thumbnailUrl'] ) );
						$video_single_schema['thumbnailUrl'] = $helper->sanitizeOutPut( $img['url'], 'url' );
					}
					$real_state_video = $video_single_schema;
				}
			}
		}

		if ( empty( $real_state_video ) ) {
			return null;
		}

		return apply_filters( 'rtseo_snippet_real_state_video', $real_state_video, $metaData );
	}

	/**
	 * Get RealEstateListing Audio schema markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 *
	 * @return array|null Audio schema markup or null if not available.
	 */
	private function get_real_state_audio_schema( $metaData, $schemaObject, $helper, $schema_key_id ) {
		$permalink     = get_permalink( get_the_ID() );
		$real_state_id = $permalink ? $permalink . '#realestatelisting' : $schemaObject->get_id_with_hash( 'real_state_listing' . $schema_key_id );

		$real_state_audio = [];
		if ( isset( $metaData['audio'] ) && is_array( $metaData['audio'] ) ) {
			foreach ( $metaData['audio'] as $audio_single ) {
				if ( $audio_single['name'] && $audio_single['contentUrl'] ) {
					$audio_single_schema = [
						'@type'          => 'AudioObject',
						'isPartOf'       => [
							'@id' => $real_state_id,
						],
						'name'           => $audio_single['name'] ? $helper->sanitizeOutPut( $audio_single['name'] ) : null,
						'description'    => $audio_single['description'] ? $helper->sanitizeOutPut( $audio_single['description'] ) : null,
						'duration'       => $audio_single['duration'] ? $helper->sanitizeOutPut( $audio_single['duration'] ) : null,
						'contentUrl'     => $audio_single['contentUrl'] ? $helper->sanitizeOutPut( $audio_single['contentUrl'] ) : null,
						'encodingFormat' => $audio_single['encodingFormat'] ? $helper->sanitizeOutPut( $audio_single['encodingFormat'] ) : null,
					];
					$real_state_audio    = $audio_single_schema;
				}
			}
		}

		if ( empty( $real_state_audio ) ) {
			return null;
		}

		return apply_filters( 'rtseo_snippet_real_state_audio', $real_state_audio, $metaData );
	}

	/**
	 * Get Book schema markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 *
	 * @return array Book schema markup.
	 */
	private function get_book_schema( $metaData, $schemaObject, $helper, $schema_key_id ) {
		$permalink = get_permalink( get_the_ID() );
		$schema_id = $permalink ? $permalink . '#book' : $schemaObject->get_id_with_hash( 'book' . $schema_key_id );
		$book      = [
			'@type' => 'Book',
			'@id'   => $schema_id,
		];
		if ( $permalink ) {
			$book['url'] = $permalink;
		}
		if ( ! empty( $metaData['name'] ) ) {
			$book['name'] = $helper->sanitizeOutPut( $metaData['name'] );
		}
		if ( ! empty( $metaData['author'] ) ) {
			$book['author'] = [
				'@type' => 'Person',
				'name'  => $helper->sanitizeOutPut( $metaData['author'] ),
				'@id'   => $schemaObject->get_id_with_hash( 'person-' . sanitize_title( $metaData['author'] ) ),
			];
			if ( isset( $metaData['author_sameAs'] ) && ! empty( $metaData['author_sameAs'] ) ) {
				$sameAs = Functions::get_same_as( $helper->sanitizeOutPut( $metaData['author_sameAs'], 'textarea' ) );
				if ( ! empty( $sameAs ) ) {
					$book['author']['sameAs'] = $sameAs;
				}
			}
		}
		if ( ! empty( $metaData['bookFormat'] ) ) {
			$book['bookFormat'] = $helper->sanitizeOutPut( $metaData['bookFormat'] );
		}
		if ( ! empty( $metaData['isbn'] ) ) {
			$book['isbn'] = $helper->sanitizeOutPut( $metaData['isbn'] );
		}
		if ( ! empty( $metaData['workExample'] ) ) {
			$book['workExample'] = [
				'@type' => 'CreativeWork',
				'name'  => $helper->sanitizeOutPut( $metaData['workExample'] ),
			];
		}

		if ( ! empty( $metaData['sameAs'] ) ) {
			$sameAs = Functions::get_same_as( $helper->sanitizeOutPut( $metaData['sameAs'], 'textarea' ) );
			if ( ! empty( $sameAs ) ) {
				$book['sameAs'] = $sameAs;
			}
		}
		$book['publisher'] = [
			'@id' => $schemaObject->get_site_schema_id(),
		];
		if ( ! empty( $metaData['numberOfPages'] ) ) {
			$book['numberOfPages'] = absint( $metaData['numberOfPages'] );
		}
		if ( ! empty( $metaData['copyrightHolder'] ) ) {
			$book['copyrightHolder'] = [
				'@type' => 'Organization',
				'name'  => $helper->sanitizeOutPut( $metaData['copyrightHolder'] ),
			];
		}
		if ( ! empty( $metaData['copyrightYear'] ) ) {
			$book['copyrightYear'] = absint( $metaData['copyrightYear'] );
		}
		if ( ! empty( $metaData['description'] ) ) {
			$book['description'] = $helper->sanitizeOutPut( $metaData['description'] );
		}
		if ( ! empty( $metaData['genre'] ) ) {
			$book['genre'] = $helper->sanitizeOutPut( $metaData['genre'] );
		}
		if ( ! empty( $metaData['inLanguage'] ) ) {
			$book['inLanguage'] = $helper->sanitizeOutPut( $metaData['inLanguage'] );
		}
		if ( ! empty( $metaData['review_ratingValue'] ) ) {
			$book['aggregateRating'] = [
				'@type'       => 'AggregateRating',
				'ratingValue' => (float) ( $metaData['review_ratingValue'] ?? 5 ),
				'reviewCount' => absint( $metaData['reviewCount'] ?? 1 ),
				'bestRating'  => absint( $metaData['review_bestRating'] ?? 1 ),
				'worstRating' => absint( $metaData['review_worstRating'] ?? 1 ),
			];
		}
		// Add review reference if review is active.
		if ( isset( $metaData['review_active'] ) && $permalink ) {
			$book['review'] = [
				'@id' => $permalink . '#review-book' . $schema_key_id,
			];
		}

		return apply_filters( 'rtseo_snippet_book', $book, $metaData );
	}

	/**
	 * Get Book SchemaEngine AI markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 *
	 * @return array|null Book SchemaEngine AI markup or null if not active.
	 */
	private function get_book_review_schema( $metaData, $schemaObject, $helper, $schema_key_id ) {
		if ( ! isset( $metaData['review_active'] ) ) {
			return null;
		}
		$permalink   = get_permalink( get_the_ID() );
		$book_review = [
			'@type' => 'Review',
		];

		if ( $permalink ) {
			$book_review['@id'] = $permalink . '#review-book' . $schema_key_id;
		}

		if ( isset( $metaData['review_datePublished'] ) && ! empty( $metaData['review_datePublished'] ) ) {
			$book_review['datePublished'] = $helper->sanitizeOutPut( $metaData['review_datePublished'] );
		}
		if ( isset( $metaData['review_body'] ) && ! empty( $metaData['review_body'] ) ) {
			$book_review['reviewBody'] = $helper->sanitizeOutPut( $metaData['review_body'], 'textarea' );
		}

		$book_review['publisher'] = [
			'@id' => $schemaObject->get_site_schema_id(),
		];
		if ( ! empty( $metaData['review_author'] ) ) {
			$book_review['author'] = [
				'@type' => 'Person',
				'name'  => $helper->sanitizeOutPut( $metaData['review_author'] ),
				'@id'   => $schemaObject->get_id_with_hash( 'person-' . sanitize_title( $metaData['review_author'] ) ),
			];
			if ( isset( $metaData['review_author_sameAs'] ) && ! empty( $metaData['review_author_sameAs'] ) ) {
				$sameAs = Functions::get_same_as( $helper->sanitizeOutPut( $metaData['review_author_sameAs'], 'textarea' ) );
				if ( ! empty( $sameAs ) ) {
					$book_review['author']['sameAs'] = $sameAs;
				}
			}
		}
		if ( isset( $metaData['author_ratingValue'] ) ) {
			$book_review['reviewRating'] = [
				'@type'       => 'Rating',
				'ratingValue' => $helper->sanitizeOutPut( $metaData['author_ratingValue'], 'number' ),
			];
			if ( isset( $metaData['review_bestRating'] ) ) {
				$book_review['reviewRating']['bestRating'] = $helper->sanitizeOutPut( $metaData['review_bestRating'], 'number' );
			}
			if ( isset( $metaData['review_worstRating'] ) ) {
				$book_review['reviewRating']['worstRating'] = $helper->sanitizeOutPut( $metaData['review_worstRating'], 'number' );
			}
		}

		return apply_filters( 'rtseo_snippet_book_review', $book_review, $metaData );
	}

	/**
	 * Get Product schema markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 *
	 * @return array Product schema markup.
	 */
	private function get_product_schema( $metaData, $schemaObject, $helper, $schema_key_id ) {
		$permalink  = get_permalink( get_the_ID() );
		$product_id = $schemaObject->get_id_with_hash( 'product' . $schema_key_id );
		$product    = [
			'@type' => 'Product',
			'@id'   => $product_id,
		];
		if ( $permalink ) {
			$product['url'] = $permalink;
		}
		if ( ! empty( $metaData['name'] ) ) {
			$product['name'] = $helper->sanitizeOutPut( $metaData['name'] );
		}
		$image_id = get_post_thumbnail_id( get_the_ID() );
		if ( $image_id ) {
			$img              = $helper->imageInfo( $image_id );
			$product['image'] = [
				'@type'  => 'ImageObject',
				'url'    => $helper->sanitizeOutPut( $img['url'], 'url' ),
				'height' => $img['height'],
				'width'  => $img['width'],
			];
		}
		if ( ! empty( $metaData['description'] ) ) {
			$product['description'] = $helper->sanitizeOutPut( $metaData['description'] );
		}
		/* product identifier */
		if ( ! empty( $metaData['sku'] ) ) {
			$product['sku'] = $helper->sanitizeOutPut( $metaData['sku'] ) ?: get_the_ID();
		}
		if ( ! empty( $metaData['brand'] ) ) {
			$product['brand'] = [
				'@type' => 'Brand',
				'name'  => $helper->sanitizeOutPut( $metaData['brand'] ),
			];
		}
		if ( ! empty( $metaData['identifier_type'] ) && ! empty( $metaData['identifier'] ) ) {
			$product[ $metaData['identifier_type'] ] = $helper->sanitizeOutPut( $metaData['identifier'] );
		}

		if ( ! empty( $metaData['reviewRatingValue'] ) ) {
			$product['aggregateRating'] = [
				'@type'       => 'AggregateRating',
				'ratingValue' => esc_attr( $metaData['reviewRatingValue'] ),
				'reviewCount' => absint( $metaData['reviewCount'] ?? 1 ),
				'bestRating'  => absint( $metaData['reviewBestRating'] ?? 1 ),
				'worstRating' => absint( $metaData['reviewWorstRating'] ?? 1 ),
			];
		}
		// Add review reference if review data exists.
		if ( 'hide' !== ( $metaData['review_active'] ?? '' ) && ! empty( $metaData['ratingValue'] ) && $permalink ) {
			$product['review'] = [
				'@id' => $permalink . '#review-product' . $schema_key_id,
			];
		}

		$variation_offers = $this->build_variation_offers( $metaData, $permalink, $helper, $schemaObject );

		if ( ! empty( $variation_offers ) ) {
			$product['offers'] = $variation_offers;
		} elseif ( isset( $metaData['price'] ) && '' !== $metaData['price'] && is_numeric( $metaData['price'] ) ) {
			// isset()/is_numeric() so a free product priced at 0 is still output.
			$product['offers'] = [
				'@type'           => 'Offer',
				'price'           => $helper->sanitizeOutPut( $metaData['price'] ),
				'priceValidUntil' => $helper->sanitizeOutPut( $metaData['priceValidUntil'] ),
				'priceCurrency'   => ! empty( $metaData['priceCurrency'] ) ? $helper->sanitizeOutPut( $metaData['priceCurrency'] ) : null,
				'itemCondition'   => ! empty( $metaData['itemCondition'] ) ? $helper->sanitizeOutPut( $metaData['itemCondition'] ) : null,
				'availability'    => ! empty( $metaData['availability'] ) ? $helper->sanitizeOutPut( $metaData['availability'] ) : null,
				'url'             => $permalink ?: null,
			];

			// --- Seller (merchant) — reference the site Organization entity. ---
			$site_schema_id = $schemaObject->get_site_schema_id();
			if ( ! empty( $site_schema_id ) ) {
				$product['offers']['seller'] = [ '@id' => $site_schema_id ];
			}

			// --- Structured price specification (richer Offer detail). ---
			$price_specification = [
				'@type' => 'UnitPriceSpecification',
				'price' => $helper->sanitizeOutPut( $metaData['price'], 'number' ),
			];
			if ( ! empty( $metaData['priceCurrency'] ) ) {
				$price_specification['priceCurrency'] = $helper->sanitizeOutPut( $metaData['priceCurrency'] );
			}
			$product['offers']['priceSpecification'] = $price_specification;

			// --- Shipping Details ---
			$shippingDetails = $this->build_product_shipping_details( $metaData, $product['offers']['priceCurrency'] ?? '', $helper );
			if ( ! empty( $shippingDetails ) ) {
				$product['offers']['shippingDetails'] = $shippingDetails;
			}

			// --- Merchant Return Policy ---
			$MerchantReturnPolicy = $this->build_product_return_policy( $metaData, $helper );
			if ( ! empty( $MerchantReturnPolicy ) ) {
				$product['offers']['hasMerchantReturnPolicy'] = $MerchantReturnPolicy;
			}
		}

		return apply_filters( 'rtseo_snippet_product', $product, $metaData );
	}

	/**
	 * Build variation offers for EDD/WooCommerce variable products.
	 *
	 * Returns an array of Offer objects when the current post has variable
	 * pricing. Returns empty array for non-variable or unsupported post types.
	 *
	 * @param array     $metaData     Schema metadata.
	 * @param string    $permalink    Post permalink.
	 * @param Functions $helper       Helper instance.
	 * @param object    $schemaObject Schema model instance (for site entity @id).
	 *
	 * @return array Array of Offer schema nodes, or empty array.
	 */
	private function build_variation_offers( $metaData, $permalink, $helper, $schemaObject = null ) {
		$post_id   = get_the_ID();
		$post_type = get_post_type( $post_id );

		$currency        = ! empty( $metaData['priceCurrency'] ) ? $helper->sanitizeOutPut( $metaData['priceCurrency'] ) : '';
		$priceValidUntil = ! empty( $metaData['priceValidUntil'] ) ? $helper->sanitizeOutPut( $metaData['priceValidUntil'] ) : gmdate( 'Y-12-31', time() + YEAR_IN_SECONDS );
		$availability    = ! empty( $metaData['availability'] ) ? $helper->sanitizeOutPut( $metaData['availability'] ) : 'https://schema.org/InStock';

		// EDD variable pricing.
		if ( 'download' === $post_type && function_exists( 'edd_has_variable_prices' ) && edd_has_variable_prices( $post_id ) ) {
			$variable_prices = edd_get_variable_prices( $post_id );

			if ( empty( $variable_prices ) ) {
				return [];
			}

			if ( empty( $currency ) ) {
				$currency = function_exists( 'edd_get_currency' ) ? edd_get_currency() : 'USD';
			}

			$prices   = array_map( 'floatval', wp_list_pluck( $variable_prices, 'amount' ) );
			$children = [];

			foreach ( $variable_prices as $vp ) {
				$children[] = [
					'@type'           => 'Offer',
					'description'     => esc_html( $vp['name'] ?? '' ),
					'price'           => number_format( (float) $vp['amount'], 2, '.', '' ),
					'priceCurrency'   => $currency,
					'priceValidUntil' => $priceValidUntil,
					'availability'    => $availability,
					'url'             => $permalink ?: null,
				];
			}

			$shippingDetails = $this->build_product_shipping_details( $metaData, $currency, $helper );
			$returnPolicy    = $this->build_product_return_policy( $metaData, $helper );

			$aggregate = [
				'@type'         => 'AggregateOffer',
				'lowPrice'      => number_format( min( $prices ), 2, '.', '' ),
				'highPrice'     => number_format( max( $prices ), 2, '.', '' ),
				'priceCurrency' => $currency,
				'offerCount'    => count( $variable_prices ),
				'availability'  => $availability,
			];

			$this->add_offer_seller_and_price_spec( $aggregate, $currency, $schemaObject );

			if ( ! empty( $shippingDetails ) ) {
				$aggregate['shippingDetails'] = $shippingDetails;
			}
			if ( ! empty( $returnPolicy ) ) {
				$aggregate['hasMerchantReturnPolicy'] = $returnPolicy;
			}

			$aggregate['offers'] = $children;

			return $aggregate;
		}

		// WooCommerce variable pricing.
		if ( 'product' === $post_type && function_exists( 'wc_get_product' ) ) {
			$wc_product = wc_get_product( $post_id );

			if ( ! $wc_product || ! $wc_product->is_type( 'variable' ) ) {
				return [];
			}

			if ( empty( $currency ) ) {
				$currency = get_woocommerce_currency();
			}

			$product_data = FnsPro::get_woocommerce_pricing( $wc_product->get_id() );

			if ( empty( $product_data ) || ! is_array( $product_data ) ) {
				return [];
			}

			$children = [];

			foreach ( $product_data as $value ) {
				$var_id    = $value['variation_id'] ?? 0;
				$var_title = $var_id ? get_the_title( $var_id ) : '';

				$children[] = [
					'@type'           => 'Offer',
					'description'     => $var_title,
					'price'           => wc_format_decimal( $value['price'], wc_get_price_decimals() ),
					'priceCurrency'   => $currency,
					'priceValidUntil' => $priceValidUntil,
					'availability'    => $value['availability'] ?? $availability,
					'url'             => get_permalink( $value['variation_id'] ?? $post_id ),
				];
			}

			$shippingDetails = $this->build_product_shipping_details( $metaData, $currency, $helper );
			$returnPolicy    = $this->build_product_return_policy( $metaData, $helper );

			$aggregate = [
				'@type'         => 'AggregateOffer',
				'lowPrice'      => wc_format_decimal( $wc_product->get_variation_price( 'min', false ), wc_get_price_decimals() ),
				'highPrice'     => wc_format_decimal( $wc_product->get_variation_price( 'max', false ), wc_get_price_decimals() ),
				'priceCurrency' => $currency,
				'offerCount'    => count( $product_data ),
				'availability'  => $availability,
			];

			$this->add_offer_seller_and_price_spec( $aggregate, $currency, $schemaObject );

			if ( ! empty( $shippingDetails ) ) {
				$aggregate['shippingDetails'] = $shippingDetails;
			}
			if ( ! empty( $returnPolicy ) ) {
				$aggregate['hasMerchantReturnPolicy'] = $returnPolicy;
			}

			$aggregate['offers'] = $children;

			return $aggregate;
		}

		return [];
	}

	/**
	 * Add seller (site entity reference) and a UnitPriceSpecification to an
	 * AggregateOffer, mirroring the single-price Offer branch.
	 *
	 * Keeps AggregateOffer offer detail on par with single Offers so quality
	 * scoring credits seller + priceSpecification. No-op for either field when it
	 * is already present or its source is unavailable.
	 *
	 * @param array  $aggregate    AggregateOffer node (by reference).
	 * @param string $currency     Price currency code.
	 * @param object $schemaObject Schema model instance (for site entity @id).
	 */
	private function add_offer_seller_and_price_spec( &$aggregate, $currency, $schemaObject ) {
		if ( empty( $aggregate['seller'] ) && is_object( $schemaObject ) && method_exists( $schemaObject, 'get_site_schema_id' ) ) {
			$site_schema_id = $schemaObject->get_site_schema_id();
			if ( ! empty( $site_schema_id ) ) {
				$aggregate['seller'] = [ '@id' => $site_schema_id ];
			}
		}

		if ( empty( $aggregate['priceSpecification'] ) && isset( $aggregate['lowPrice'] ) && '' !== $aggregate['lowPrice'] ) {
			$price_specification = [
				'@type' => 'UnitPriceSpecification',
				'price' => $aggregate['lowPrice'],
			];
			if ( ! empty( $currency ) ) {
				$price_specification['priceCurrency'] = $currency;
			}
			$aggregate['priceSpecification'] = $price_specification;
		}
	}

	/**
	 * Build OfferShippingDetails from metadata.
	 *
	 * Uses `isset` checks instead of `empty` so that '0' values
	 * (free shipping, 0-day handling) are not skipped.
	 * Falls back to global ecommerce settings when metadata is empty.
	 *
	 * @param array     $metaData Schema metadata.
	 * @param string    $currency Price currency code.
	 * @param Functions $helper   Helper instance.
	 *
	 * @return array OfferShippingDetails schema or empty array.
	 */
	private function build_product_shipping_details( $metaData, $currency, $helper ) {
		$override = ! empty( $metaData['override_shipping'] );

		// When override is OFF, load global settings for fallback.
		$ecommerce = $override ? [] : get_option( 'rtrs_schema_ecommerce_settings', [] );

		// Shipping rate: metadata → (global if no override) → default '0'.
		$rate = ! empty( $metaData['shippingRate'] ) ? $helper->sanitizeOutPut( $metaData['shippingRate'] ) : '0';

		// Shipping destination.
		$destination = '';
		if ( ! empty( $metaData['shippingDestination'] ) ) {
			$destination = $metaData['shippingDestination'];
		} elseif ( ! $override && ! empty( $ecommerce['return_policy_country'] ) ) {
			$destination = $ecommerce['return_policy_country'];
		} elseif ( ! $override && function_exists( 'WC' ) && WC()->countries ) {
			$destination = WC()->countries->get_base_country();
		}
		if ( empty( $destination ) ) {
			$destination = 'US';
		}

		$shippingDetails = [
			'shippingRate'        => [
				'@type'    => 'MonetaryAmount',
				'value'    => $rate,
				'currency' => $currency,
			],
			'shippingDestination' => [
				'@type'          => 'DefinedRegion',
				'addressCountry' => $destination,
			],
		];

		if ( ! empty( $metaData['addressRegion'] ) ) {
			$shippingDetails['shippingDestination']['addressRegion'] = $metaData['addressRegion'];
		}

		// Handling time: metadata → (global if no override) → defaults (0-1).
		$handling_min = isset( $metaData['handlingTimeMinimum'] ) && '' !== $metaData['handlingTimeMinimum']
			? absint( $metaData['handlingTimeMinimum'] )
			: ( ! $override && isset( $ecommerce['handling_time_min'] ) && '' !== $ecommerce['handling_time_min']
				? absint( $ecommerce['handling_time_min'] )
				: 0 );
		$handling_max = isset( $metaData['handlingTimeMaximum'] ) && '' !== $metaData['handlingTimeMaximum']
			? absint( $metaData['handlingTimeMaximum'] )
			: ( ! $override && isset( $ecommerce['handling_time_max'] ) && '' !== $ecommerce['handling_time_max']
				? absint( $ecommerce['handling_time_max'] )
				: 1 );

		// Transit time: metadata → (global if no override) → defaults (3-7).
		$transit_min = isset( $metaData['transitTimeMinimum'] ) && '' !== $metaData['transitTimeMinimum']
			? absint( $metaData['transitTimeMinimum'] )
			: ( ! $override && isset( $ecommerce['transit_time_min'] ) && '' !== $ecommerce['transit_time_min']
				? absint( $ecommerce['transit_time_min'] )
				: 3 );
		$transit_max = isset( $metaData['transitTimeMaximum'] ) && '' !== $metaData['transitTimeMaximum']
			? absint( $metaData['transitTimeMaximum'] )
			: ( ! $override && isset( $ecommerce['transit_time_max'] ) && '' !== $ecommerce['transit_time_max']
				? absint( $ecommerce['transit_time_max'] )
				: 7 );

		$shippingDetails['deliveryTime'] = [
			'@type'        => 'ShippingDeliveryTime',
			'handlingTime' => [
				'@type'    => 'QuantitativeValue',
				'minValue' => $handling_min,
				'maxValue' => $handling_max,
				'unitCode' => 'DAY',
			],
			'transitTime'  => [
				'@type'    => 'QuantitativeValue',
				'minValue' => $transit_min,
				'maxValue' => $transit_max,
				'unitCode' => 'DAY',
			],
		];

		return array_merge( [ '@type' => 'OfferShippingDetails' ], $shippingDetails );
	}

	/**
	 * Build MerchantReturnPolicy from metadata.
	 *
	 * Falls back to global ecommerce settings when metadata is empty.
	 *
	 * @param array     $metaData Schema metadata.
	 * @param Functions $helper   Helper instance.
	 *
	 * @return array MerchantReturnPolicy schema or empty array.
	 */
	private function build_product_return_policy( $metaData, $helper ) {
		$override = ! empty( $metaData['override_return_policy'] );

		// When override is OFF, load global settings for fallback.
		$ecommerce = $override ? [] : get_option( 'rtrs_schema_ecommerce_settings', [] );

		// Country: metadata → (global if no override) → WC base country → 'US'.
		$country = '';
		if ( ! empty( $metaData['applicableCountry'] ) ) {
			$country = $helper->sanitizeOutPut( $metaData['applicableCountry'] );
		} elseif ( ! $override && ! empty( $ecommerce['return_policy_country'] ) ) {
			$country = $ecommerce['return_policy_country'];
		} elseif ( ! $override && function_exists( 'WC' ) && WC()->countries ) {
			$country = WC()->countries->get_base_country();
		}
		if ( empty( $country ) ) {
			$country = 'US';
		}

		// Return policy category.
		if ( ! empty( $metaData['returnPolicyCategory'] ) ) {
			$category = $helper->sanitizeOutPut( $metaData['returnPolicyCategory'] );
		} elseif ( ! $override && ! empty( $ecommerce['return_policy_category'] ) ) {
			$category = 'https://schema.org/' . $ecommerce['return_policy_category'];
		} else {
			$category = 'https://schema.org/MerchantReturnFiniteReturnWindow';
		}

		// Return method.
		if ( ! empty( $metaData['returnMethod'] ) ) {
			$method = $helper->sanitizeOutPut( $metaData['returnMethod'] );
		} elseif ( ! $override && ! empty( $ecommerce['return_policy_method'] ) ) {
			$method = 'https://schema.org/' . $ecommerce['return_policy_method'];
		} else {
			$method = 'https://schema.org/ReturnByMail';
		}

		// Return fees.
		if ( ! empty( $metaData['returnFees'] ) ) {
			$fees = $helper->sanitizeOutPut( $metaData['returnFees'] );
		} elseif ( ! $override && ! empty( $ecommerce['return_policy_fees'] ) ) {
			$fees = 'https://schema.org/' . $ecommerce['return_policy_fees'];
		} else {
			$fees = 'https://schema.org/FreeReturn';
		}

		$policy = [
			'@type'                => 'MerchantReturnPolicy',
			'applicableCountry'    => $country,
			'returnPolicyCategory' => $category,
			'returnMethod'         => $method,
			'returnFees'           => $fees,
		];

		// Return shipping fees currency.
		if ( $override ) {
			$shipping_fees_currency = ! empty( $metaData['returnShippingFeesCurrency'] )
				? $helper->sanitizeOutPut( $metaData['returnShippingFeesCurrency'] )
				: ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD' );
		} else {
			$shipping_fees_currency = ! empty( $ecommerce['return_shipping_fees_currency'] )
				? $ecommerce['return_shipping_fees_currency']
				: ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD' );
		}

		// Return shipping fees amount.
		if ( false !== strpos( $fees, 'FreeReturn' ) ) {
			$policy['returnShippingFeesAmount'] = [
				'@type'    => 'MonetaryAmount',
				'value'    => 0,
				'currency' => esc_html( $shipping_fees_currency ),
			];
		} else {
			if ( $override ) {
				$shipping_fees_amount = isset( $metaData['returnShippingFeesAmount'] ) && '' !== $metaData['returnShippingFeesAmount']
					? floatval( $metaData['returnShippingFeesAmount'] )
					: 0;
			} else {
				$shipping_fees_amount = ! empty( $ecommerce['return_shipping_fees_amount'] )
					? floatval( $ecommerce['return_shipping_fees_amount'] )
					: 0;
			}

			$policy['returnShippingFeesAmount'] = [
				'@type'    => 'MonetaryAmount',
				'value'    => $shipping_fees_amount,
				'currency' => esc_html( $shipping_fees_currency ),
			];
		}

		// Return days for finite return window.
		if ( false !== strpos( $category, 'FiniteReturnWindow' ) ) {
			if ( ! empty( $metaData['merchantReturnDays'] ) ) {
				$days = absint( $metaData['merchantReturnDays'] );
			} elseif ( ! $override && isset( $ecommerce['return_policy_days'] ) && '' !== $ecommerce['return_policy_days'] ) {
				$days = absint( $ecommerce['return_policy_days'] );
			} else {
				$days = 30;
			}

			$policy['merchantReturnDays'] = $days;
		}

		// Return policy link.
		if ( $override ) {
			$link = ! empty( $metaData['returnPolicyLink'] ) ? esc_url( $metaData['returnPolicyLink'] ) : '';
		} else {
			$link = ! empty( $ecommerce['return_policy_link'] ) ? esc_url( $ecommerce['return_policy_link'] ) : '';
		}
		if ( $link ) {
			$policy['merchantReturnLink'] = $link;
		}

		return $policy;
	}

	/**
	 * Get Product SchemaEngine AI markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 *
	 * @return array|null Product SchemaEngine AI markup or null if not active.
	 */
	private function get_product_review_schema( $metaData, $schemaObject, $helper, $schema_key_id ) {
		if ( 'hide' === ( $metaData['review_active'] ?? '' ) ) {
			return null;
		}
		if ( empty( $metaData['ratingValue'] ) && empty( $metaData['reviewBestRating'] ) && empty( $metaData['reviewWorstRating'] ) ) {
			return null;
		}

		if ( empty( $metaData['review_body'] ) || empty( $metaData['reviewAuthor'] ) ) {
			return null;
		}

		$permalink      = get_permalink( get_the_ID() );
		$product_review = [
			'@type'        => 'Review',
			'reviewRating' => [
				'@type'       => 'Rating',
				'bestRating'  => absint( $metaData['reviewBestRating'] ?? 5 ),
				'worstRating' => absint( $metaData['reviewWorstRating'] ?? 1 ),
				'ratingValue' => esc_attr( $metaData['ratingValue'] ),
			],
			'author'       => [
				'@type' => 'Person',
				'name'  => $helper->sanitizeOutPut( $metaData['reviewAuthor'] ),
				'@id'   => $schemaObject->get_id_with_hash( 'person-' . sanitize_title( $metaData['reviewAuthor'] ) ),
			],
		];
		if ( ! empty( $metaData['review_datePublished'] ) ) {
			$product_review['datePublished'] = $helper->sanitizeOutPut( $metaData['review_datePublished'] );
		}

		$product_review['reviewBody'] = $helper->sanitizeOutPut( $metaData['review_body'], 'textarea' );

		if ( $permalink ) {
			$product_review['@id'] = $permalink . '#review-product' . $schema_key_id;
		}
		return apply_filters( 'rtseo_snippet_product_review', $product_review, $metaData );
	}

	/**
	 * Get Restaurant schema markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 *
	 * @return array Restaurant schema markup.
	 */
	private function get_restaurant_schema( $metaData, $schemaObject, $helper, $schema_key_id ) {
		$schema_id = $schemaObject->get_id_with_hash( 'Restaurant' . $schema_key_id );
		$output    = [
			'@type' => 'Restaurant',
			'@id'   => $schema_id,
		];
		if ( ! empty( $metaData['url'] ) ) {
			$output['url'] = $helper->sanitizeOutPut( $metaData['url'], 'url' );
		}
		// BASIC.
		if ( ! empty( $metaData['name'] ) ) {
			$output['name'] = $helper->sanitizeOutPut( $metaData['name'] );
		}
		if ( ! empty( $metaData['description'] ) ) {
			$output['description'] = $helper->sanitizeOutPut( $metaData['description'] );
		}
		if ( ! empty( $metaData['image'] ) ) {
			$img = $helper->imageInfo( absint( $metaData['image'] ) );
			if ( $img ) {
				$output['image'] = [
					'@type'       => 'ImageObject',
					'url'         => $helper->sanitizeOutPut( $img['url'], 'url' ),
					'description' => $helper->sanitizeOutPut( $img['title'] ),
					'height'      => $img['height'],
					'width'       => $img['width'],
				];
			}
		}

		if ( ! empty( $metaData['servesCuisine'] ) ) {
			$output['servesCuisine'] = $helper->sanitizeOutPut( $metaData['servesCuisine'] );
		}
		if ( ! empty( $metaData['priceRange'] ) ) {
			$output['priceRange'] = $helper->sanitizeOutPut( $metaData['priceRange'] );
		}
		if ( ! empty( $metaData['telephone'] ) ) {
			$output['telephone'] = $metaData['telephone'];
		}
		// IMAGE (gallery).
		if ( ! empty( $metaData['image'] ) && is_array( $metaData['image'] ) ) {
			$gallery = [];
			foreach ( $metaData['image'] as $img_id ) {
				$img       = $helper->imageInfo( absint( $img_id ) );
				$gallery[] = $helper->sanitizeOutPut( $img['url'], 'url' );
			}
			$output['image'] = $gallery;
		}
		// ADDRESS (group).
		if ( ! empty( $metaData['address'] ) && is_array( $metaData['address'] ) ) {
			$addressPart = [];
			foreach ( $metaData['address'] as $part ) {
				if ( ! empty( $part['streetAddress'] ) ) {
					$addressPart['streetAddress'] = $helper->sanitizeOutPut( $part['streetAddress'] );
				}
				if ( ! empty( $part['addressLocality'] ) ) {
					$addressPart['addressLocality'] = $helper->sanitizeOutPut( $part['addressLocality'] );
				}
				if ( ! empty( $part['addressRegion'] ) ) {
					$addressPart['addressRegion'] = $helper->sanitizeOutPut( $part['addressRegion'] );
				}
				if ( ! empty( $part['postalCode'] ) ) {
					$addressPart['postalCode'] = $helper->sanitizeOutPut( $part['postalCode'] );
				}
				if ( ! empty( $part['addressCountry'] ) ) {
					$addressPart['addressCountry'] = $helper->sanitizeOutPut( $part['addressCountry'] );
				}
			}
			if ( ! empty( $addressPart ) ) {
				$output['address'] = [ '@type' => 'PostalAddress' ] + $addressPart;
			}
		}
		// GEO COORDINATES.
		$geo = [];
		if ( ! empty( $metaData['latitude'] ) ) {
			$geo['latitude'] = $metaData['latitude'];
		}
		if ( ! empty( $metaData['longitude'] ) ) {
			$geo['longitude'] = $metaData['longitude'];
		}
		if ( ! empty( $geo ) ) {
			$output['geo'] = [ '@type' => 'GeoCoordinates' ] + $geo;
		}

		if ( ! empty( $metaData['menu'] ) ) {
			$output['menu'] = esc_url( $metaData['menu'] );
		}
		if ( isset( $metaData['acceptsReservations'] ) ) {
			$output['acceptsReservations'] = ( 'true' === $metaData['acceptsReservations'] );
		}
		// MENU SECTIONS.
		if ( isset( $metaData['menu_sections'] ) && is_array( $metaData['menu_sections'] ) ) {
			$menuSections = [];
			foreach ( $metaData['menu_sections'] as $section ) {
				$sectionSchema = [
					'@type' => 'MenuSection',
				];

				if ( ! empty( $section['name'] ) ) {
					$sectionSchema['name'] = $helper->sanitizeOutPut( $section['name'] );
				}

				if ( ! empty( $section['desc'] ) ) {
					$sectionSchema['description'] = $helper->sanitizeOutPut( $section['desc'], 'textarea' );
				}

				if ( ! empty( $section['images'] ) && is_array( $section['images'] ) ) {
					$sectionImages = [];
					foreach ( $section['images'] as $imgId ) {
						$img = $helper->imageInfo( absint( $imgId ) );
						if ( $img ) {
							$sectionImages[] = $helper->sanitizeOutPut( $img['url'], 'url' );
						}
					}
					if ( $sectionImages ) {
						$sectionSchema['image'] = $sectionImages;
					}
				}

				if ( ! empty( $section['availabilityStarts'] ) || ! empty( $section['availabilityEnds'] ) ) {
					$sectionSchema['offers'] = [
						'@type'              => 'Offer',
						'availabilityStarts' => $helper->sanitizeOutPut( $section['availabilityStarts'] ?? '' ),
						'availabilityEnds'   => $helper->sanitizeOutPut( $section['availabilityEnds'] ?? '' ),
					];
				}

				if ( isset( $section['menu_items'] ) && is_array( $section['menu_items'] ) ) {
					$menuItems = [];
					foreach ( $section['menu_items'] as $item ) {
						$itemSchema = [
							'@type' => 'MenuItem',
						];

						if ( ! empty( $item['name'] ) ) {
							$itemSchema['name'] = $helper->sanitizeOutPut( $item['name'] );
						}
						if ( ! empty( $item['desc'] ) ) {
							$itemSchema['description'] = $helper->sanitizeOutPut( $item['desc'] );
						}
						if ( ! empty( $item['image'] ) ) {
							$img = $helper->imageInfo( absint( $item['image'] ) );
							if ( $img ) {
								$itemSchema['image'] = $helper->sanitizeOutPut( $img['url'], 'url' );
							}
						}

						if ( ! empty( $item['price'] ) || ! empty( $item['priceCurrency'] ) ) {
							$itemSchema['offers'] = [
								'@type'         => 'Offer',
								'price'         => $helper->sanitizeOutPut( $item['price'] ?? '' ),
								'priceCurrency' => $helper->sanitizeOutPut( $item['priceCurrency'] ?? '' ),
							];
						}

						$nutrition     = [];
						$nutritionKeys = [
							'calories',
							'carbohydrateContent',
							'cholesterolContent',
							'fatContent',
							'fiberContent',
							'proteinContent',
							'saturatedFatContent',
							'servingSize',
							'sodiumContent',
							'sugarContent',
							'transFatContent',
							'unsaturatedFatContent',
						];
						foreach ( $nutritionKeys as $nKey ) {
							if ( ! empty( $item[ $nKey ] ) ) {
								$nutrition[ $nKey ] = $helper->sanitizeOutPut( $item[ $nKey ] );
							}
						}
						if ( ! empty( $nutrition ) ) {
							$itemSchema['nutrition'] = [ '@type' => 'NutritionInformation' ] + $nutrition;
						}

						if ( ! empty( $item['suitableForDiet'] ) ) {
							$itemSchema['suitableForDiet'] = $helper->sanitizeOutPut( $item['suitableForDiet'] );
						}

						$menuItems[] = $itemSchema;
					}
					if ( $menuItems ) {
						$sectionSchema['hasMenuItem'] = $menuItems;
					}
				}

				$menuSections[] = $sectionSchema;
			}
			if ( $menuSections ) {
				$output['hasMenu'] = [
					'@type'          => 'Menu',
					'hasMenuSection' => $menuSections,
				];
			}
		}
		if ( ! empty( $metaData['openingHours'] ) && is_array( $metaData['openingHours'] ) ) {
			$openingHoursSpecification = [];
			foreach ( $metaData['openingHours'] as $value ) {
				$specification = [];
				if ( ! empty( $value['dayOfWeek'] ) ) {
					$specification['dayOfWeek'] = $helper->sanitizeOutPut( $value['dayOfWeek'] );
				}
				if ( ! empty( $value['opens'] ) ) {
					$specification['opens'] = $helper->sanitizeOutPut( $value['opens'] );
				}
				if ( ! empty( $value['closes'] ) ) {
					$specification['closes'] = $helper->sanitizeOutPut( $value['closes'] );
				}
				$openingHoursSpecification[] = [ '@type' => 'OpeningHoursSpecification' ] + $specification;
			}
			$output['openingHoursSpecification'] = $openingHoursSpecification;
		}
		// REVIEW (single).
		if ( ! empty( $metaData['review'] ) ) {
			$reviewPart = [];
			foreach ( $metaData['review'] as $review ) {
				if ( ! empty( $review['author'] ) ) {
					$reviewPart['author'] = [
						'@type' => 'Person',
						'name'  => $helper->sanitizeOutPut( $review['author'] ),
						'url'   => $helper->sanitizeOutPut( $review['author_url'] ?? '#', 'url' ),
					];
				}
				$reviewRating = [];
				if ( ! empty( $review['ratingValue'] ) ) {
					$reviewRating['ratingValue'] = (float) $review['ratingValue'];
				}
				if ( ! empty( $reviewRating ) ) {
					$reviewPart['reviewRating'] = [ '@type' => 'Rating' ] + $reviewRating;
				}
			}
			if ( ! empty( $reviewPart ) ) {
				$output['review'] = [ '@type' => 'Review' ] + $reviewPart;
			}
		}
		$aggregateRating = [];
		if ( ! empty( $metaData['aggregate_value'] ) ) {
			$aggregateRating['ratingValue'] = (float) $metaData['aggregate_value'];
		}
		if ( ! empty( $metaData['bestRating'] ) ) {
			$aggregateRating['bestRating'] = absint( $metaData['bestRating'] );
		}
		if ( ! empty( $metaData['worstRating'] ) ) {
			$aggregateRating['worstRating'] = absint( $metaData['worstRating'] );
		}
		if ( ! empty( $metaData['aggregate_count'] ) ) {
			$aggregateRating['reviewCount'] = absint( $metaData['aggregate_count'] );
		}
		// AGGREGATE RATING.
		if ( ! empty( $aggregateRating ) ) {
			$output['aggregateRating'] = [ '@type' => 'AggregateRating' ] + $aggregateRating;
		}
		// SOCIAL PROFILES.
		if ( ! empty( $metaData['sameAs'] ) ) {
			// SameAs (multi-line textarea).
			$sameAs = Functions::get_same_as( $helper->sanitizeOutPut( $metaData['sameAs'], 'textarea' ) );
			if ( ! empty( $sameAs ) ) {
				$output['sameAs'] = $sameAs;
			}
		}

		return apply_filters( 'rtseo_snippet_for_restaurant', $output, $metaData );
	}

	/**
	 * Get Dataset schema markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 *
	 * @return array Dataset schema markup.
	 */
	private function get_dataset_schema( $metaData, $schemaObject, $helper, $schema_key_id ) {
		$schema_id = $schemaObject->get_id_with_hash( 'Dataset' . $schema_key_id );
		$output    = [
			'@type' => 'Dataset',
			'@id'   => $schema_id,
			'url'   => $schemaObject->get_id_with_hash(),
		];
		// Basic fields.
		if ( ! empty( $metaData['name'] ) ) {
			$output['name'] = $helper->sanitizeOutPut( $metaData['name'] );
		}
		if ( ! empty( $metaData['description'] ) ) {
			$output['description'] = $helper->sanitizeOutPut( $metaData['description'], 'textarea' );
		}

		// SameAs (multi-line textarea).
		$sameAs = Functions::get_same_as( $helper->sanitizeOutPut( $metaData['sameAs'], 'textarea' ) );
		if ( ! empty( $sameAs ) ) {
			$output['sameAs'] = $sameAs;
		}

		// identifier (group).
		if ( ! empty( $metaData['identifier'] ) && is_array( $metaData['identifier'] ) ) {
			$ids = [];
			foreach ( $metaData['identifier'] as $id_group ) {
				if ( ! empty( $id_group['id_url'] ) ) {
					$ids[] = $helper->sanitizeOutPut( $id_group['id_url'], 'url' );
				}
			}
			if ( ! empty( $ids ) ) {
				$output['identifier'] = $ids;
			}
		}
		// keywords (group).
		if ( ! empty( $metaData['keywords'] ) && is_array( $metaData['keywords'] ) ) {
			$keywords = [];
			foreach ( $metaData['keywords'] as $kw ) {
				if ( ! empty( $kw['keyword'] ) ) {
					$keywords[] = $helper->sanitizeOutPut( $kw['keyword'] );
				}
			}
			if ( ! empty( $keywords ) ) {
				$output['keywords'] = $keywords;
			}
		}
		// license.
		if ( ! empty( $metaData['license'] ) ) {
			$output['license'] = $helper->sanitizeOutPut( $metaData['license'], 'url' );
		}
		// isAccessibleForFree.
		$output['isAccessibleForFree'] = ! empty( $metaData['isAccessibleForFree'] ) ? true : false;
		// hasPart (subdatasets).
		if ( ! empty( $metaData['hasPart'] ) && is_array( $metaData['hasPart'] ) ) {
			$parts = [];
			foreach ( $metaData['hasPart'] as $part ) {
				$p = [ '@type' => 'Dataset' ];
				if ( ! empty( $part['name'] ) ) {
					$p['name'] = $helper->sanitizeOutPut( $part['name'] );
				}
				if ( ! empty( $part['description'] ) ) {
					$p['description'] = $helper->sanitizeOutPut( $part['description'], 'textarea' );
				}
				if ( ! empty( $part['license'] ) ) {
					$p['license'] = $helper->sanitizeOutPut( $part['license'], 'url' );
				}
				if ( ! empty( $part['creator_name'] ) ) {
					$p['creator'] = [
						'@type' => 'Organization',
						'name'  => $helper->sanitizeOutPut( $part['creator_name'] ),
					];
				}
				if ( count( $p ) > 1 ) {
					$parts[] = $p;
				}
			}
			if ( ! empty( $parts ) ) {
				$output['hasPart'] = $parts;
			}
		}
		/**
		 * ----------------------------------
		 * Creator INFORMATION
		 * ----------------------------------
		 */
		if ( ! empty( $metaData['creator'] ) && is_array( $metaData['creator'] ) ) {
			$creator = [];
			foreach ( $metaData['creator'] as $_creator ) {
				$creator['@type'] = 'Organization';
				if ( ! empty( $_creator['name'] ) ) {
					$creator['name'] = $helper->sanitizeOutPut( $_creator['name'] );
				}
				if ( ! empty( $_creator['url'] ) ) {
					$creator['url'] = $helper->sanitizeOutPut( $_creator['url'], 'url' );
				}
				$cp = [
					'@type' => 'ContactPoint',
				];
				if ( ! empty( $_creator['contactType'] ) ) {
					$cp['contactType'] = $helper->sanitizeOutPut( $_creator['contactType'] );
				}
				if ( ! empty( $_creator['telephone'] ) ) {
					$cp['telephone'] = $helper->sanitizeOutPut( $_creator['telephone'] );
				}
				if ( ! empty( $_creator['email'] ) ) {
					$cp['email'] = $helper->sanitizeOutPut( $_creator['email'] );
				}
				if ( ! empty( $cp ) ) {
					$creator['contactPoint'] = $cp;
				}
			}
			if ( count( $creator ) > 1 ) {
				$output['creator'] = $creator;
			}
		}
		// funder.
		if ( ! empty( $metaData['funder'] ) ) {
			$output['funder'] = [
				'@type' => 'Organization',
				'name'  => $helper->sanitizeOutPut( $metaData['funder'] ),
			];
			if ( ! empty( $metaData['funder_sameAs'] ) ) {
				$sameAs = Functions::get_same_as( $helper->sanitizeOutPut( $metaData['funder_sameAs'], 'textarea' ) );
				if ( ! empty( $sameAs ) ) {
					$output['funder']['sameAs'] = $sameAs;
				}
			}
		}
		// includedInDataCatalog.
		if ( ! empty( $metaData['includedInDataCatalog'] ) ) {
			$output['includedInDataCatalog'] = [
				'@type' => 'DataCatalog',
				'name'  => $helper->sanitizeOutPut( $metaData['includedInDataCatalog'] ),
			];
		}
		// distribution.
		if ( ! empty( $metaData['distribution'] ) && is_array( $metaData['distribution'] ) ) {
			$dist = [];
			foreach ( $metaData['distribution'] as $d ) {
				$di = [ '@type' => 'DataDownload' ];
				if ( ! empty( $d['encodingFormat'] ) ) {
					$di['encodingFormat'] = $helper->sanitizeOutPut( $d['encodingFormat'] );
				}
				if ( ! empty( $d['contentUrl'] ) ) {
					$di['contentUrl'] = $helper->sanitizeOutPut( $d['contentUrl'], 'url' );
				}
				if ( count( $di ) > 1 ) {
					$dist[] = $di;
				}
			}
			if ( ! empty( $dist ) ) {
				$output['distribution'] = $dist;
			}
		}
		// temporalCoverage.
		if ( ! empty( $metaData['temporalCoverage'] ) ) {
			$output['temporalCoverage'] = $helper->sanitizeOutPut( $metaData['temporalCoverage'] );
		}
		// spatialCoverage.
		if ( ! empty( $metaData['spatialCoverageBox'] ) ) {
			$output['spatialCoverage'] = [
				'@type' => 'Place',
				'geo'   => [
					'@type' => 'GeoShape',
					'box'   => $helper->sanitizeOutPut( $metaData['spatialCoverageBox'] ),
				],
			];
		}

		return apply_filters( 'rtseo_snippet_for_dataset', $output, $metaData );
	}

	/**
	 * Get DiscussionForumPosting schema markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 * @param  int       $post_id  The post ID.
	 * @param  string    $site_schema_id  The site schema ID.
	 *
	 * @return array DiscussionForumPosting schema markup.
	 */
	private function get_discussion_forum_posting_schema( $metaData, $schemaObject, $helper, $schema_key_id, $post_id, $site_schema_id ) {
		$schema_id = $schemaObject->get_id_with_hash( 'DiscussionForumPosting' . $schema_key_id );
		$output    = [
			'@type' => 'DiscussionForumPosting',
			'@id'   => $schema_id,
			'url'   => $schemaObject->get_id_with_hash(),
		];
		// Basic top-level fields.
		$has_webpage_schema = $schemaObject->has_schema( $post_id, 'web_page' );
		if ( $has_webpage_schema ) {
			$output['mainEntityOfPage'] = [
				'@type' => 'WebPage',
				'@id'   => $schemaObject->get_id_with_hash( 'webpage' ),
			];
		} else {
			$output['mainEntityOfPage'] = $schemaObject->get_id_with_hash();
		}

		if ( ! empty( $metaData['name'] ) ) {
			$output['headline'] = $helper->sanitizeOutPut( $metaData['name'] );
		}
		if ( ! empty( $metaData['text'] ) ) {
			$output['text'] = $helper->sanitizeOutPut( $metaData['text'], 'textarea' );
		}

		$output['datePublished'] = get_the_date( DATE_W3C, $post_id );

		$image_id = get_post_thumbnail_id( get_the_ID() );
		if ( $image_id ) {
			$img             = $helper->imageInfo( $image_id );
			$output['image'] = [
				'@type'  => 'ImageObject',
				'url'    => $helper->sanitizeOutPut( $img['url'], 'url' ),
				'height' => $img['height'],
				'width'  => $img['width'],
			];
		}
		// VideoObject (optional).
		if ( ! empty( $metaData['video_fields'] ) && is_array( $metaData['video_fields'] ) ) {
			$VideoObject = [];
			foreach ( $metaData['video_fields'] as $v ) {
				$video = [ '@type' => 'VideoObject' ];
				if ( ! empty( $v['contentUrl'] ) ) {
					$video['contentUrl'] = $helper->sanitizeOutPut( $v['contentUrl'], 'url' );
				}
				if ( ! empty( $v['embedUrl'] ) ) {
					$video['embedUrl'] = $helper->sanitizeOutPut( $v['embedUrl'], 'url' );
				}
				if ( ! empty( $v['name'] ) ) {
					$video['name'] = $helper->sanitizeOutPut( $v['name'] );
				}
				if ( ! empty( $v['uploadDate'] ) ) {
					$video['uploadDate'] = $helper->sanitizeOutPut( $v['uploadDate'] );
				}
				if ( ! empty( $v['thumbnailUrl'] ) ) {
					$video['thumbnailUrl'] = $helper->sanitizeOutPut( $v['thumbnailUrl'], 'url' );
				}
				if ( ! empty( $v['description'] ) ) {
					$video['description'] = $helper->sanitizeOutPut( $v['description'] );
				}
				$VideoObject[] = $video;
			}
			if ( count( $VideoObject ) > 0 ) {
				$output['video'] = $VideoObject;
			}
		}
		/**
		 * Helper: Build InteractionCounter array
		 *
		 * @param  array  $items  Array of interaction stats.
		 *
		 * @return array
		 */
		$buildInteractionStats = function ( $items ) use ( $helper ) {
			$result = [];
			if ( ! empty( $items ) && is_array( $items ) ) {
				foreach ( $items as $s ) {
					if ( ! is_array( $s ) ) {
						continue;
					}
					$stat = [ '@type' => 'InteractionCounter' ];
					if ( ! empty( $s['interactionType'] ) ) {
						$stat['interactionType'] = $helper->sanitizeOutPut( $s['interactionType'] );
					}
					if ( isset( $s['userInteractionCount'] ) ) {
						$stat['userInteractionCount'] = absint( $s['userInteractionCount'] );
					}
					if ( count( $stat ) > 1 ) {
						$result[] = $stat;
					}
				}
			}

			return $result;
		};

		// Author(s) with optional interaction stats.
		if ( ! empty( $metaData['author'] ) && is_array( $metaData['author'] ) ) {
			$authors = [];
			foreach ( $metaData['author'] as $a ) {
				if ( ! is_array( $a ) ) {
					continue;
				}
				$author = [ '@type' => 'Person' ];

				if ( ! empty( $a['name'] ) ) {
					$author['name'] = $helper->sanitizeOutPut( $a['name'] );
				}
				if ( ! empty( $a['url'] ) ) {
					$author['url'] = $helper->sanitizeOutPut( $a['url'], 'url' );
				}
				$agentStats = $buildInteractionStats( $a['agentInteractionStatistic'] ?? [] );
				if ( ! empty( $agentStats ) ) {
					$author['agentInteractionStatistic'] = $agentStats;
				}

				if ( count( $author ) > 1 ) {
					$authors[] = $author;
				}
			}
			if ( ! empty( $authors ) ) {
				// If only one author, keep it as object, otherwise use array
				$output['author'] = count( $authors ) === 1 ? $authors[0] : $authors;
			}
		}

		// Post interaction stats (likes/upvotes).
		$postStats = $buildInteractionStats( $metaData['interactionStatistic'] ?? [] );
		if ( ! empty( $postStats ) ) {
			$output['interactionStatistic'] = $postStats;
		}
		// Comments.
		if ( ! empty( $metaData['comment'] ) && is_array( $metaData['comment'] ) ) {
			$comments = [];
			foreach ( $metaData['comment'] as $key => $c ) {
				if ( ! is_array( $c ) ) {
					continue;
				}
				$comment = [
					'@type' => 'Comment',
					'@id'   => $schemaObject->get_id_with_hash( 'comment-' . $key . $schema_key_id ),
				];
				if ( ! empty( $c['text'] ) ) {
					$comment['text'] = $helper->sanitizeOutPut( $c['text'], 'textarea' );
				}
				if ( ! empty( $c['datePublished'] ) ) {
					$comment['datePublished'] = $helper->sanitizeOutPut( $c['datePublished'] );
				}

				// Comment author.
				if ( ! empty( $c['author'] ) && is_array( $c['author'] ) ) {
					$ca = [];
					foreach ( $c['author'] as $_a ) {
						if ( ! is_array( $_a ) ) {
							continue;
						}
						$ca_obj = [ '@type' => 'Person' ];
						if ( ! empty( $_a['name'] ) ) {
							$ca_obj['name'] = $helper->sanitizeOutPut( $_a['name'] );
						}
						if ( ! empty( $_a['url'] ) ) {
							$ca_obj['url'] = $helper->sanitizeOutPut( $_a['url'], 'url' );
						}
						$ca[] = $ca_obj;
					}
					if ( count( $ca ) > 0 ) {
						$comment['author'] = $ca[0];
					}
				}

				// Comment interaction stats.
				$c_stats = $buildInteractionStats( $c['interactionStatistic'] ?? [] );
				if ( ! empty( $c_stats ) ) {
					$comment['interactionStatistic'] = $c_stats;
				}
				if ( count( $comment ) > 1 ) {
					$comments[] = $comment;
				}
			}
			if ( ! empty( $comments ) ) {
				$output['comment'] = $comments;
			}
		}
		// Extra counters.
		if ( ! empty( $metaData['replyCount'] ) ) {
			$output['replyCount'] = absint( $metaData['replyCount'] );
		}
		if ( ! empty( $metaData['upvoteCount'] ) ) {
			$output['upvoteCount'] = absint( $metaData['upvoteCount'] );
		}
		/**
		 * ----------------------------------
		 * PUBLISHER INFORMATION
		 * ----------------------------------
		 */
		$output['publisher'] = [
			'@id' => $site_schema_id,
		];

		return apply_filters( 'rtseo_snippet_discussion_forum_posting', $output, $metaData );
	}

	/**
	 * Get PodcastEpisode schema markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 * @param  string    $site_schema_id  The site schema ID.
	 *
	 * @return array PodcastEpisode schema markup.
	 */
	private function get_podcast_episode_schema( $metaData, $schemaObject, $helper, $schema_key_id, $site_schema_id ) {
		$schema_id = $schemaObject->get_id_with_hash( 'PodcastEpisode' . $schema_key_id );
		$output    = [
			'@type' => 'PodcastEpisode',
			'@id'   => $schema_id,
		];
		/**
		 * ----------------------------------
		 * BASIC EPISODE INFORMATION
		 * ----------------------------------
		 */
		if ( ! empty( $metaData['name'] ) ) {
			$output['name'] = $helper->sanitizeOutPut( $metaData['name'] );
		}
		if ( ! empty( $metaData['episodeNumber'] ) ) {
			$output['episodeNumber'] = absint( $metaData['episodeNumber'] );
		}
		$permalink = get_permalink( get_the_ID() );
		if ( $permalink ) {
			$output['url'] = $permalink;
		}
		if ( ! empty( $metaData['description'] ) ) {
			$output['description'] = $helper->sanitizeOutPut( $metaData['description'], 'textarea' );
		}
		if ( ! empty( $metaData['thumbnailUrl'] ) ) {
			$output['thumbnailUrl'] = $helper->sanitizeOutPut( $metaData['thumbnailUrl'], 'url' );
		}
		$output['datePublished'] = get_the_date( DATE_W3C, get_the_ID() );

		if ( ! empty( $metaData['timeRequired'] ) ) {
			$output['timeRequired'] = $helper->sanitizeOutPut( $metaData['timeRequired'] );
		}
		/**
		 * ----------------------------------
		 * AUDIO INFORMATION
		 * ----------------------------------
		 */
		if ( ! empty( $metaData['audio_url'] ) ) {
			$audio_url = $helper->sanitizeOutPut( $metaData['audio_url'], 'url' );
			$format    = ! empty( $metaData['audio_encodingFormat'] )
					? $helper->sanitizeOutPut( $metaData['audio_encodingFormat'] )
					: 'audio/mpeg';
			// MediaObject for associatedMedia.
			$output['associatedMedia'] = [
				'@type'          => 'MediaObject',
				'contentUrl'     => $audio_url,
				'encodingFormat' => $format,
			];
			if ( ! empty( $metaData['duration'] ) ) {
				$output['associatedMedia']['duration'] = $helper->sanitizeOutPut( $metaData['duration'] );
			}
			// AudioObject.
			$output['audio'] = [
				'@type'          => 'AudioObject',
				'url'            => $audio_url,
				'encodingFormat' => $format,
			];
		}
		/**
		 * ----------------------------------
		 * VIDEO INFORMATION (OPTIONAL)
		 * ----------------------------------
		 */
		if (
				! empty( $metaData['video_name'] )
				||
				! empty( $metaData['video_description'] )
				||
				! empty( $metaData['video_embedUrl'] )
				||
				! empty( $metaData['video_contentUrl'] )
		) {
			$video = [
				'@type' => 'VideoObject',
			];
			if ( ! empty( $metaData['video_name'] ) ) {
				$video['name'] = $helper->sanitizeOutPut( $metaData['video_name'] );
			}
			if ( ! empty( $metaData['video_description'] ) ) {
				$video['description'] = $helper->sanitizeOutPut( $metaData['video_description'], 'textarea' );
			}
			if ( ! empty( $metaData['video_thumbnail'] ) ) {
				$video['thumbnailUrl'] = $helper->sanitizeOutPut( $metaData['video_thumbnail'], 'url' );
			}
			if ( ! empty( $metaData['video_embedUrl'] ) ) {
				$video['embedUrl'] = $helper->sanitizeOutPut( $metaData['video_embedUrl'], 'url' );
			}
			if ( ! empty( $metaData['video_contentUrl'] ) ) {
				$video['contentUrl'] = $helper->sanitizeOutPut( $metaData['video_contentUrl'], 'url' );
			}
			if ( ! empty( $metaData['video_uploadDate'] ) ) {
				$video['uploadDate'] = $helper->sanitizeOutPut( $metaData['video_uploadDate'] );
			}
			$output['video'] = $video;
		}
		/**
		 * ----------------------------------
		 * SERIES INFORMATION
		 * ----------------------------------
		 */
		if ( ! empty( $metaData['series_name'] ) || ! empty( $metaData['series_url'] ) ) {
			$series = [ '@type' => 'PodcastSeries' ];
			if ( ! empty( $metaData['series_name'] ) ) {
				$series['name'] = $helper->sanitizeOutPut( $metaData['series_name'] );
			}
			if ( ! empty( $metaData['series_url'] ) ) {
				$series['url'] = $helper->sanitizeOutPut( $metaData['series_url'], 'url' );
			}
			$output['partOfSeries'] = $series;
		}
		/**
		 * ----------------------------------
		 * HOSTS (REPEATER)
		 * ----------------------------------
		 */
		if ( ! empty( $metaData['hosts'] ) && is_array( $metaData['hosts'] ) ) {
			$hosts_output = [];
			foreach ( $metaData['hosts'] as $host ) {
				if ( empty( $host['name'] ) ) {
					continue;
				}
				$person = [
					'@type' => 'Person',
					'name'  => $helper->sanitizeOutPut( $host['name'] ),
				];
				if ( ! empty( $host['url'] ) ) {
					$person['url'] = $helper->sanitizeOutPut( $host['url'], 'url' );
				}
				$hosts_output[] = $person;
			}
			if ( ! empty( $hosts_output ) ) {
				$output['actor'] = $hosts_output; // ✔ Google-approved for podcast hosts
			}
		}
		/**
		 * ----------------------------------
		 * PUBLISHER INFORMATION
		 * ----------------------------------
		 */
		$output['publisher'] = [
			'@id' => $site_schema_id,
		];
		/**
		 * ----------------------------------
		 * TRANSCRIPT
		 * ----------------------------------
		 */
		if ( ! empty( $metaData['transcript'] ) ) {
			$output['transcript'] = $helper->sanitizeOutPut( $metaData['transcript'] );
		}

		return apply_filters( 'rtseo_snippet_podcast_episode', $output, $metaData );
	}

	/**
	 * Get TV Series schema markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 * @param  string    $site_schema_id  The site schema ID.
	 *
	 * @return array TV Series schema markup.
	 */
	private function get_tv_series_schema( $metaData, $schemaObject, $helper, $schema_key_id, $site_schema_id ) {
		$schema_id = $schemaObject->get_id_with_hash( 'tv_series' . $schema_key_id );
		$output    = [
			'@type' => 'TVSeries',
			'@id'   => $schema_id,
			'url'   => $schemaObject->get_id_with_hash(),
		];
		if ( ! empty( $metaData['name'] ) ) {
			$output['name'] = esc_html( $metaData['name'] );
		}
		$author_type = esc_html( $metaData['author-type'] ) ?? 'Person';
		if ( ! empty( $metaData['author'] ) ) {
			$output['author'] = [
				'@type' => $author_type,
				'name'  => esc_html( $metaData['author'] ),
			];
		}

		if ( ! empty( $metaData['actor'] ) ) {
			foreach ( $metaData['actor'] as $value ) {
				$actor = [];
				if ( ! empty( $value['actor-name'] ) ) {
					$inner_actor = [
						'@type' => 'Person',
						'name'  => esc_html( $value['actor-name'] ),
					];
					$actor       = [
						'@type' => 'PerformanceRole',
						'actor' => $inner_actor,
					];
					if ( ! empty( $value['characterName'] ) ) {
						$actor['characterName'] = esc_html( $value['characterName'] );
					}
				}
				if ( ! empty( $actor ) ) {
					$output['actor'][] = $actor;
				}
			}
		}
		if ( ! empty( $metaData['description'] ) ) {
			$output['description'] = esc_html( $metaData['description'] );
		}
		if ( ! empty( $metaData['season'] ) ) {
			foreach ( $metaData['season'] as $value ) {
				$tvsession = [
					'@type'            => 'TVSeason',
					'datePublished'    => esc_html( $value['date-published'] ),
					'name'             => esc_html( $value['season-name'] ),
					'numberOfEpisodes' => absint( $value['number-of-episodes'] ),
				];
				$episode   = [];
				foreach ( $value['episode'] as $epi ) {
					$episode[] = [
						'@type'         => 'TVEpisode',
						'name'          => esc_html( $epi['episode-name'] ),
						'episodeNumber' => absint( $epi['episode-number'] ),
					];
				}
				if ( ! empty( $episode ) ) {
					$tvsession['episode'] = $episode;
				}
				$output['containsSeason'][] = $tvsession;
			}
		}
		$output['publisher'] = [
			'@id' => $site_schema_id,
		];

		return apply_filters( 'rtseo_snippet_tv_series', $output, $metaData );
	}

	/**
	 * Get Collection Page schema markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 *
	 * @return array Collection Page schema markup.
	 */
	private function get_collection_page_schema( $metaData, $schemaObject, $helper, $schema_key_id ) {
		$schema_id       = $schemaObject->get_id_with_hash( 'collection_page' . $schema_key_id );
		$collection_page = [
			'@type' => 'CollectionPage',
			'@id'   => $schema_id,
			'url'   => $schemaObject->get_id_with_hash(),
		];
		if ( ! empty( $metaData['name'] ) ) {
			$collection_page['name'] = $helper->sanitizeOutPut( $metaData['name'] );
		}
		if ( ! empty( $metaData['webpage_url'] ) ) {
			$collection_page['url'] = $helper->sanitizeOutPut( $metaData['webpage_url'], 'url' );
		}
		if ( ! empty( $metaData['description'] ) ) {
			$collection_page['description'] = $helper->sanitizeOutPut( $metaData['description'], 'textarea' );
		}
		$image_id = get_post_thumbnail_id( get_the_ID() );
		if ( $image_id ) {
			$img                      = $helper->imageInfo( $image_id );
			$collection_page['image'] = [
				'@type'  => 'ImageObject',
				'url'    => $helper->sanitizeOutPut( $img['url'], 'url' ),
				'height' => $img['height'],
				'width'  => $img['width'],
			];
		}

		if ( ! empty( $metaData['itempage'] ) ) {
			foreach ( $metaData['itempage'] as $key => $has ) {
				$hasPart = [
					'@type'    => 'ItemPage',
					'position' => absint( $key ) + 1,
				];
				if ( ! empty( $has['itempage-name'] ) ) {
					$hasPart['name'] = $helper->sanitizeOutPut( $has['itempage-name'] );
				}
				if ( ! empty( $has['mainEntityOfPage'] ) ) {
					$hasPart['mainEntityOfPage'] = $helper->sanitizeOutPut( $has['mainEntityOfPage'], 'url' );
				}
				if ( ! empty( $has['itempage-description'] ) ) {
					$hasPart['description'] = $helper->sanitizeOutPut( $has['itempage-description'], 'textarea' );
				}
				$collection_page['hasPart'][] = $hasPart;
			}
		}

		return apply_filters( 'rtseo_snippet_collection_page', $collection_page, $metaData );
	}

	/**
	 * Get Vacation Rental schema markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 * @param  string    $site_schema_id  The site schema ID.
	 *
	 * @return array Vacation Rental schema markup.
	 */
	private function get_vacation_rental_schema( $metaData, $schemaObject, $helper, $schema_key_id, $site_schema_id ) {
		$schema_id      = $schemaObject->get_id_with_hash( 'vacation_rental' . $schema_key_id );
		$vacationRental = [
			'@id' => $schema_id,
			'url' => $schemaObject->get_id_with_hash(),
		];
		if ( ! empty( $metaData['additionalType'] ) ) {
			$vacationRental['additionalType'] = $helper->sanitizeOutPut( $metaData['additionalType'] ) ?: 'HolidayVillageRental';
		}
		if ( ! empty( $metaData['name'] ) ) {
			$vacationRental['name'] = $helper->sanitizeOutPut( $metaData['name'] );
		}
		if ( ! empty( $metaData['description'] ) ) {
			$vacationRental['description'] = $helper->sanitizeOutPut( $metaData['description'] );
		}
		if ( ! empty( $metaData['priceRange'] ) ) {
			$vacationRental['priceRange'] = $helper->sanitizeOutPut( $metaData['priceRange'] );
		}
		if ( ! empty( $metaData['telephone'] ) ) {
			$vacationRental['telephone'] = $helper->sanitizeOutPut( $metaData['telephone'] );
		}
		if ( ! empty( $metaData['identifier'] ) ) {
			$vacationRental['identifier'] = $helper->sanitizeOutPut( $metaData['identifier'] );
		}
		if ( ! empty( $metaData['latitude'] ) || ! empty( $metaData['longitude'] ) ) {
			$vacationRental['geo'] = [
				'@type'     => 'GeoCoordinates',
				'latitude'  => $helper->sanitizeOutPut( $metaData['latitude'], 'number' ),
				'longitude' => $helper->sanitizeOutPut( $metaData['longitude'], 'number' ),
			];
		}
		// Contains Place.
		$containsPlace = [];
		if ( ! empty( $metaData['containsPlaceType'] ) ) {
			$containsPlace['additionalType'] = $helper->sanitizeOutPut( $metaData['containsPlaceType'] );
		}
		if ( ! empty( $metaData['occupancy'] ) ) {
			$containsPlace['occupancy'] = [
				'@type' => 'QuantitativeValue',
				'value' => $helper->sanitizeOutPut( $metaData['occupancy'], 'number' ),
			];
		}
		if ( ! empty( $metaData['numberOfBathroomsTotal'] ) ) {
			$containsPlace['numberOfBathroomsTotal'] = $helper->sanitizeOutPut( $metaData['numberOfBathroomsTotal'], 'number' );
		}
		if ( ! empty( $metaData['numberOfBedrooms'] ) ) {
			$containsPlace['numberOfBedrooms'] = $helper->sanitizeOutPut( $metaData['numberOfBedrooms'], 'number' );
		}
		if ( ! empty( $metaData['numberOfRooms'] ) ) {
			$containsPlace['numberOfRooms'] = $helper->sanitizeOutPut( $metaData['numberOfRooms'], 'number' );
		}

		if ( ! empty( $metaData['floorSizeValue'] ) ) {
			$containsPlace['floorSize'] = [
				'@type'    => 'QuantitativeValue',
				'value'    => $helper->sanitizeOutPut( $metaData['floorSizeValue'], 'number' ),
				'unitCode' => $helper->sanitizeOutPut( $metaData['unitCode'] ),
			];
		}

		if ( ! empty( $metaData['beds'] ) ) {
			$beds = [];
			foreach ( $metaData['beds'] as $bed ) {
				$beds[] = [
					'@type'        => 'BedDetails',
					'numberOfBeds' => $helper->sanitizeOutPut( $bed['numberOfBeds'], 'number' ),
					'typeOfBed'    => $helper->sanitizeOutPut( $bed['typeOfBed'] ),
				];
			}
			if ( ! empty( $beds ) ) {
				$containsPlace['bed'] = $beds;
			}
		}

		if ( ! empty( $metaData['amenityFeature'] ) ) {
			$features = [];
			foreach ( $metaData['amenityFeature'] as $feature ) {
				$features[] = [
					'@type' => 'LocationFeatureSpecification',
					'name'  => $helper->sanitizeOutPut( $feature['feature'] ),
					'value' => ! empty( $feature['value'] ),
				];
			}
			if ( ! empty( $features ) ) {
				$containsPlace['amenityFeature'] = $features;
			}
		}

		if ( ! empty( $containsPlace ) ) {
			$vacationRental['containsPlace'] = [
				'@type' => 'Accommodation',
			] + $containsPlace;
		}
		// End Contains Place.
		if ( ! empty( $metaData['images'] ) ) {
			$images = [];
			foreach ( $metaData['images'] as $img ) {
				if ( empty( $img['image'] ) ) {
					continue;
				}
				$img      = $helper->imageInfo( absint( $img['image'] ) );
				$images[] = $helper->sanitizeOutPut( $img['url'], 'url' );
			}
			if ( ! empty( $images ) ) {
				$vacationRental['image'] = $images;
			}
		}

		$aggregateRating = [];
		if ( ! empty( $metaData['aggregate_bestRating'] ) ) {
			$aggregateRating['bestRating'] = absint( $metaData['aggregate_bestRating'] );
		}
		if ( ! empty( $metaData['aggregate_worstRating'] ) ) {
			$aggregateRating['worstRating'] = absint( $metaData['aggregate_worstRating'] );
		}
		if ( ! empty( $metaData['aggregate_ratingCount'] ) ) {
			$aggregateRating['reviewCount'] = absint( $metaData['aggregate_ratingCount'] );
		}
		if ( ! empty( $metaData['aggregate_ratingValue'] ) ) {
			$aggregateRating['ratingValue'] = esc_attr( $metaData['aggregate_ratingValue'] );
		}

		if ( ! empty( $aggregateRating ) ) {
			$vacationRental['aggregateRating'] = [ '@type' => 'AggregateRating' ] + $aggregateRating;
		}

		if ( ! empty( $metaData['reviews'] ) ) {
			$reviews = [];
			foreach ( $metaData['reviews'] as $review ) {
				$rvw = [
					'@type' => 'Review',
				];
				if ( ! empty( $review['datePublished'] ) ) {
					$rvw['datePublished'] = $helper->sanitizeOutPut( $review['datePublished'] );
				}
				if ( ! empty( $review['author'] ) ) {
					$rvw['author'] = [
						'@type' => 'Person',
						'name'  => $helper->sanitizeOutPut( $review['author'] ),
					];
				}
				$reviewRating = [];
				if ( ! empty( $review['ratingValue'] ) ) {
					$reviewRating['ratingValue'] = esc_attr( $review['ratingValue'] );
				}
				if ( ! empty( $metaData['aggregate_bestRating'] ) ) {
					$reviewRating['bestRating'] = absint( $metaData['aggregate_bestRating'] );
				}
				if ( ! empty( $metaData['aggregate_worstRating'] ) ) {
					$reviewRating['worstRating'] = absint( $metaData['aggregate_worstRating'] );
				}
				if ( ! empty( $reviewRating ) ) {
					$rvw['reviewRating'] = [
						'@type' => 'Rating',
					] + $reviewRating;
				}
				$reviews[] = $rvw;
			}

			if ( ! empty( $reviews ) ) {
				$vacationRental['review'] = $reviews;
			}
		}

		// Address Start.
		$address = [];
		if ( ! empty( $metaData['streetAddress'] ) ) {
			$address['streetAddress'] = $helper->sanitizeOutPut( $metaData['streetAddress'] );
		}
		if ( ! empty( $metaData['addressLocality'] ) ) {
			$address['addressLocality'] = $helper->sanitizeOutPut( $metaData['addressLocality'] );
		}
		if ( ! empty( $metaData['region'] ) ) {
			$address['addressRegion'] = $helper->sanitizeOutPut( $metaData['region'] );
		}
		if ( ! empty( $metaData['postalCode'] ) ) {
			$address['postalCode'] = $helper->sanitizeOutPut( $metaData['postalCode'] );
		}
		if ( ! empty( $metaData['addressCountry'] ) ) {
			$address['addressCountry'] = $helper->sanitizeOutPut( $metaData['addressCountry'] );
		}
		if ( ! empty( $address ) ) {
			$vacationRental['address'] = [ '@type' => 'PostalAddress' ] + $address;
		}
		$vacationRental = array_merge(
			[
				'@type' => 'VacationRental',
			],
			$vacationRental,
		);

		return apply_filters( 'rtseo_snippet_vacation_rental', $vacationRental, $metaData );
	}

	/**
	 * Get Vehicle Listing schema markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 * @param  string    $site_schema_id  The site schema ID.
	 *
	 * @return array Vehicle Listing schema markup.
	 */
	private function get_vehicle_listing_schema( $metaData, $schemaObject, $helper, $schema_key_id, $site_schema_id ) {
		$schema_id      = $schemaObject->get_id_with_hash( 'vehicle_listing' . $schema_key_id );
		$vehicleListing = [
			'@id' => $schema_id,
		];
		if ( ! empty( $metaData['type'] ) ) {
			$vehicleListing['@type'] = $helper->sanitizeOutPut( $metaData['type'] );
		} else {
			$vehicleListing['@type'] = 'Product';
		}
		if ( ! empty( $metaData['name'] ) ) {
			$vehicleListing['name'] = $helper->sanitizeOutPut( $metaData['name'] );
		}
		if ( ! empty( $metaData['IdentificationNumber'] ) ) {
			$vehicleListing['vehicleIdentificationNumber'] = $helper->sanitizeOutPut( $metaData['IdentificationNumber'] );
		}
		$permalink = get_permalink( get_the_ID() );
		if ( $permalink ) {
			$vehicleListing['url'] = $permalink;
		}
		if ( ! empty( $metaData['description'] ) ) {
			$vehicleListing['description'] = $helper->sanitizeOutPut( $metaData['description'] );
		}

		if ( ! empty( $metaData['offers_price'] ) ) {
			$vehicleListing['offers'] = [
				'@type' => 'Offer',
				'price' => $helper->sanitizeOutPut( $metaData['offers_price'], 'number' ),
			];

			if ( ! empty( $metaData['priceCurrency'] ) ) {
				$vehicleListing['offers']['priceCurrency'] = $helper->sanitizeOutPut( $metaData['priceCurrency'] );
			}
			if ( ! empty( $metaData['priceValidUntil'] ) ) {
				$vehicleListing['offers']['priceValidUntil'] = $helper->sanitizeOutPut( $metaData['priceValidUntil'] );
			}

			if ( ! empty( $metaData['availability'] ) ) {
				$vehicleListing['offers']['availability'] = $helper->sanitizeOutPut( $metaData['availability'] );
			}

			$MerchantReturnPolicy = [];
			if ( ! empty( $metaData['applicableCountry'] ) ) {
				$MerchantReturnPolicy['applicableCountry'] = $helper->sanitizeOutPut( $metaData['applicableCountry'] );
			}
			if ( ! empty( $metaData['merchantReturnDays'] ) ) {
				$MerchantReturnPolicy['merchantReturnDays'] = absint( $metaData['merchantReturnDays'] );
			}
			if ( ! empty( $MerchantReturnPolicy ) ) {
				$vehicleListing['offers']['hasMerchantReturnPolicy'] = array_merge(
					[
						'@type'                => 'MerchantReturnPolicy',
						'returnPolicyCategory' => 'https://schema.org/MerchantReturnFiniteReturnWindow',
						'returnMethod'         => 'https://schema.org/ReturnByMail',
						'returnFees'           => 'https://schema.org/FreeReturn',
					],
					$MerchantReturnPolicy,
				);
			}

			$shippingDetails = [];
			if ( ! empty( $metaData['shippingRate'] ) ) {
				$shippingDetails['shippingRate'] = [
					'@type'    => 'MonetaryAmount',
					'value'    => $helper->sanitizeOutPut( $metaData['shippingRate'], 'number' ),
					'currency' => $vehicleListing['offers']['priceCurrency'],
				];
			}
			if ( ! empty( $metaData['shippingDestination'] ) ) {
				$shippingDetails['shippingDestination'] = [
					'@type'          => 'DefinedRegion',
					'addressCountry' => $metaData['shippingDestination'],
				];
				if ( ! empty( $metaData['addressRegion'] ) ) {
					$shippingDetails['shippingDestination']['addressRegion'] = '[' . $metaData['addressRegion'] . ']';
				}
			}

			$shippingDeliveryTime = [];
			if ( ! empty( $metaData['handlingTimeMinimum'] ) ) {
				$shippingDeliveryTime['handlingTime'] = [
					'@type'    => 'QuantitativeValue',
					'minValue' => absint( $metaData['handlingTimeMinimum'] ),
					'maxValue' => absint( $metaData['handlingTimeMaximum'] ),
					'unitCode' => 'DAY',
				];
			}
			if ( ! empty( $metaData['transitTimeMinimum'] ) ) {
				$shippingDeliveryTime['transitTime'] = [
					'@type'    => 'QuantitativeValue',
					'minValue' => absint( $metaData['transitTimeMinimum'] ),
					'maxValue' => absint( $metaData['transitTimeMaximum'] ),
					'unitCode' => 'DAY',
				];
			}
			if ( ! empty( $shippingDeliveryTime ) ) {
				$shippingDetails['deliveryTime'] = array_merge(
					[
						'@type' => 'ShippingDeliveryTime',
					],
					$shippingDeliveryTime,
				);
			}

			if ( ! empty( $shippingDetails ) ) {
				$vehicleListing['offers']['shippingDetails'] = array_merge(
					[
						'@type' => 'OfferShippingDetails',
					],
					$shippingDetails,
				);
			}
		}

		if ( ! empty( $metaData['itemCondition'] ) ) {
			$vehicleListing['itemCondition'] = $helper->sanitizeOutPut( $metaData['itemCondition'] );
		}
		if ( ! empty( $metaData['brand'] ) ) {
			$vehicleListing['brand'] = [
				'@type' => 'Brand',
				'name'  => $helper->sanitizeOutPut( $metaData['brand'] ),
			];
		}
		if ( ! empty( $metaData['model'] ) ) {
			$vehicleListing['model'] = $helper->sanitizeOutPut( $metaData['model'] );
		}
		if ( ! empty( $metaData['vehicleConfiguration'] ) ) {
			$vehicleListing['vehicleConfiguration'] = $helper->sanitizeOutPut( $metaData['vehicleConfiguration'] );
		}
		if ( ! empty( $metaData['vehicleModelDate'] ) ) {
			$vehicleListing['vehicleModelDate'] = $helper->sanitizeOutPut( $metaData['vehicleModelDate'] );
		}
		if ( ! empty( $metaData['mileageFromOdometer'] ) ) {
			$vehicleListing['mileageFromOdometer'] = [
				'@type'    => 'QuantitativeValue',
				'value'    => $helper->sanitizeOutPut( $metaData['mileageFromOdometer'], 'number' ),
				'unitCode' => $helper->sanitizeOutPut( $metaData['unitCode'] ),
			];
		}
		if ( ! empty( $metaData['color'] ) ) {
			$vehicleListing['color'] = $helper->sanitizeOutPut( $metaData['color'] );
		}
		if ( ! empty( $metaData['color'] ) ) {
			$vehicleListing['color'] = $helper->sanitizeOutPut( $metaData['color'] );
		}
		if ( ! empty( $metaData['vehicleInteriorColor'] ) ) {
			$vehicleListing['vehicleInteriorColor'] = $helper->sanitizeOutPut( $metaData['vehicleInteriorColor'] );
		}
		if ( ! empty( $metaData['vehicleInteriorType'] ) ) {
			$vehicleListing['vehicleInteriorType'] = $helper->sanitizeOutPut( $metaData['vehicleInteriorType'] );
		}
		if ( ! empty( $metaData['bodyType'] ) ) {
			$vehicleListing['bodyType'] = $helper->sanitizeOutPut( $metaData['bodyType'] );
		}
		if ( ! empty( $metaData['driveWheelConfiguration'] ) ) {
			$vehicleListing['driveWheelConfiguration'] = $helper->sanitizeOutPut( $metaData['driveWheelConfiguration'] );
		}
		if ( ! empty( $metaData['fuelType'] ) ) {
			$vehicleListing['vehicleEngine'] = [
				'@type'    => 'EngineSpecification',
				'fuelType' => $helper->sanitizeOutPut( $metaData['fuelType'] ),
			];
		}

		if ( ! empty( $metaData['vehicleTransmission'] ) ) {
			$vehicleListing['vehicleTransmission'] = $helper->sanitizeOutPut( $metaData['vehicleTransmission'] );
		}

		if ( ! empty( $metaData['numberOfDoors'] ) ) {
			$vehicleListing['numberOfDoors'] = absint( $metaData['numberOfDoors'], 'number' );
		}
		if ( ! empty( $metaData['vehicleSeatingCapacity'] ) ) {
			$vehicleListing['vehicleSeatingCapacity'] = absint( $metaData['vehicleSeatingCapacity'] );
		}

		if ( ! empty( $metaData['images'] ) ) {
			$images = [];
			foreach ( $metaData['images'] as $img ) {
				if ( empty( $img['image'] ) ) {
					continue;
				}
				$img      = $helper->imageInfo( absint( $img['image'] ) );
				$images[] = [
					'@type'  => 'ImageObject',
					'url'    => $helper->sanitizeOutPut( $img['url'], 'url' ),
					'height' => $img['height'],
					'width'  => $img['width'],
				];
			}
			if ( ! empty( $images ) ) {
				$vehicleListing['image'] = $images;
			}
		}

		if ( ! empty( $metaData['ratingValue'] ) ) {
			$vehicleListing['aggregateRating'] = [
				'@type'       => 'AggregateRating',
				'ratingValue' => (float) $metaData['ratingValue'],
				'reviewCount' => absint( $metaData['reviewCount'] ),
				'bestRating'  => absint( $metaData['reviewBestRating'] ),
				'worstRating' => absint( $metaData['reviewWorstRating'] ),
			];
		}

		$review = [];
		if ( ! empty( $metaData['reviewRatingValue'] ) ) {
			$review['ratingValue'] = (float) $metaData['reviewRatingValue'];
		}
		if ( ! empty( $metaData['reviewBestRating'] ) ) {
			$review['bestRating'] = absint( $metaData['reviewBestRating'] );
		}
		if ( ! empty( $metaData['reviewWorstRating'] ) ) {
			$review['worstRating'] = absint( $metaData['reviewWorstRating'] );
		}
		if ( ! empty( $review ) ) {
			$vehicleListing['review'] = [
				'@type'        => 'Review',
				'reviewRating' => array_merge(
					[
						'@type' => 'Rating',
					],
					$review,
				),
			];
			if ( ! empty( $metaData['reviewAuthor'] ) ) {
				$vehicleListing['review']['author'] = [
					'@type' => 'Person',
					'name'  => $helper->sanitizeOutPut( $metaData['reviewAuthor'] ),
				];
			}
		}
		return apply_filters( 'rtseo_snippet_vehicle_listing', $vehicleListing, $metaData );
	}

	/**
	 * Get TaxiService schema markup.
	 *
	 * @param  array     $metaData  The metadata.
	 * @param  object    $schemaObject  The schema object.
	 * @param  Functions $helper  The helper object.
	 * @param  int       $schema_key_id  The schema key ID.
	 * @param  string    $site_schema_id  The site schema ID.
	 *
	 * @return array TaxiService schema markup.
	 */
	private function get_taxi_service_schema( $metaData, $schemaObject, $helper, $schema_key_id, $site_schema_id ) {
		$schema_id    = $schemaObject->get_id_with_hash( 'TaxiService' . $schema_key_id );
		$taxi_service = [
			'@type' => 'TaxiService',
			'@id'   => $schema_id,
		];
		if ( ! empty( $metaData['name'] ) ) {
			$taxi_service['name'] = $helper->sanitizeOutPut( $metaData['name'] );
		}
		if ( ! empty( $metaData['description'] ) ) {
			$taxi_service['description'] = $helper->sanitizeOutPut( $metaData['description'], 'textarea' );
		}
		$image_id = get_post_thumbnail_id( get_the_ID() );
		if ( $image_id ) {
			$img = $helper->imageInfo( $image_id );
			if ( $img ) {
				$taxi_service['image'] = [
					'@type'  => 'ImageObject',
					'url'    => $helper->sanitizeOutPut( $img['url'], 'url' ),
					'height' => $img['height'],
					'width'  => $img['width'],
				];
			}
		}
		// GEO COORDINATES.
		$taxi_service['provider'] = [
			'@id' => $site_schema_id,
		];

		// AREA SERVED (repeatable group).
		if ( ! empty( $metaData['areaServed'] ) && is_array( $metaData['areaServed'] ) ) {
			$areas = [];
			foreach ( $metaData['areaServed'] as $area ) {
				if ( ! empty( $area['name'] ) ) {
					$areas[] = [
						'@type' => 'City',
						'name'  => $helper->sanitizeOutPut( $area['name'] ),
					];
				}
			}
			if ( ! empty( $areas ) ) {
				$taxi_service['areaServed'] = $areas;
			}
		}
		// OFFERS (group).
		if ( ! empty( $metaData['offers'] ) && is_array( $metaData['offers'] ) ) {
			$offerPart = [];
			foreach ( $metaData['offers'] as $offer ) {
				if ( ! empty( $offer['description'] ) ) {
					$offerPart['description'] = $helper->sanitizeOutPut( $offer['description'] );
				}
				if ( ! empty( $offer['priceCurrency'] ) ) {
					$offerPart['priceCurrency'] = $helper->sanitizeOutPut( $offer['priceCurrency'] );
				}
				if ( ! empty( $offer['price'] ) ) {
					$offerPart['price'] = $helper->sanitizeOutPut( $offer['price'] );
				}
			}
			if ( ! empty( $offerPart ) ) {
				$taxi_service['offers'] = [ '@type' => 'Offer' ] + $offerPart;
			}
		}
		return apply_filters( 'rtseo_snippet_taxi_service', $taxi_service, $metaData );
	}

	/**
	 * Build TouristAttraction schema.
	 *
	 * @param  array  $metaData       Meta data.
	 * @param  Schema $schemaObject   Free schema model instance.
	 * @param  object $helper         Functions helper instance.
	 * @param  int    $schema_key_id  Schema key ID.
	 * @param  string $site_schema_id Site schema ID.
	 *
	 * @return array
	 */
	private function get_touristattraction_schema( $metaData, $schemaObject, $helper, $schema_key_id, $site_schema_id ) {
		$schema_id                  = $schemaObject->get_id_with_hash( 'touristattraction' . $schema_key_id );
		$touristAttraction          = [];
		$touristAttraction['@type'] = 'TouristAttraction';
		$touristAttraction['@id']   = $schema_id;
		$touristAttraction['url']   = $schemaObject->get_id_with_hash();
		if ( ! empty( $metaData['name'] ) ) {
			$touristAttraction['name'] = $helper->sanitizeOutPut( $metaData['name'] );
		}
		if ( ! empty( $metaData['description'] ) ) {
			$touristAttraction['description'] = $helper->sanitizeOutPut( $metaData['description'], 'textarea' );
		}
		if ( ! empty( $metaData['touristType'] ) ) {
			$touristAttraction['touristType'] = $helper->sanitizeOutPut( $metaData['touristType'] );
		}
		$image_id = get_post_thumbnail_id( get_the_ID() );
		if ( $image_id ) {
			$img = $helper->imageInfo( $image_id );
			if ( $img ) {
				$touristAttraction['image'] = [
					'@type'  => 'ImageObject',
					'url'    => $helper->sanitizeOutPut( $img['url'], 'url' ),
					'height' => $img['height'],
					'width'  => $img['width'],
				];
			}
		}
		if ( ! empty( $metaData['address'][0] ) ) {
			$touristAttraction['address']['@type'] = 'PostalAddress';
			$ta_address                            = $metaData['address'][0];
			if ( ! empty( $ta_address['address-country'] ) ) {
				$touristAttraction['address']['addressCountry'] = $helper->sanitizeOutPut( $ta_address['address-country'] );
			}
			if ( ! empty( $ta_address['address-locality'] ) ) {
				$touristAttraction['address']['addressLocality'] = $helper->sanitizeOutPut( $ta_address['address-locality'] );
			}
			if ( ! empty( $ta_address['address-region'] ) ) {
				$touristAttraction['address']['addressRegion'] = $helper->sanitizeOutPut( $ta_address['address-region'] );
			}
			if ( ! empty( $ta_address['postal-code'] ) ) {
				$touristAttraction['address']['postalCode'] = $helper->sanitizeOutPut( $ta_address['postal-code'] );
			}
		}
		if ( ! empty( $metaData['latitude'] ) && ! empty( $metaData['longitude'] ) ) {
			$touristAttraction['geo'] = [
				'@type'     => 'GeoCoordinates',
				'latitude'  => $helper->sanitizeOutPut( $metaData['latitude'] ),
				'longitude' => $helper->sanitizeOutPut( $metaData['longitude'] ),
			];
		}
		if ( ! empty( $metaData['openingHours'] ) && is_array( $metaData['openingHours'] ) ) {
			$openingHoursSpecification = [];
			foreach ( $metaData['openingHours'] as $value ) {
				$specification = [];
				if ( ! empty( $value['dayOfWeek'] ) ) {
					$specification['dayOfWeek'] = $helper->sanitizeOutPut( $value['dayOfWeek'] );
				}
				if ( ! empty( $value['opens'] ) ) {
					$specification['opens'] = $helper->sanitizeOutPut( $value['opens'] );
				}
				if ( ! empty( $value['closes'] ) ) {
					$specification['closes'] = $helper->sanitizeOutPut( $value['closes'] );
				}
				$openingHoursSpecification[] = [ '@type' => 'OpeningHoursSpecification' ] + $specification;
			}
			$touristAttraction['openingHoursSpecification'] = $openingHoursSpecification;
		}
		$touristAttraction['mainEntityOfPage'] = [
			'@id' => $schemaObject->get_id_with_hash( 'webpage' ),
		];
		if ( ! empty( $metaData['sameAs'] ) ) {
			$touristAttraction['sameAs'] = Functions::get_same_as( $helper->sanitizeOutPut( $metaData['sameAs'] ) );
		}

		return apply_filters( 'rtseo_snippet_touristattraction', $touristAttraction, $metaData );
	}

	/**
	 * Build OfferShippingDetails schema from SureCart shipping data.
	 *
	 * Queries SureCart shipping methods via API. Each method may contain
	 * rate/zone data.  Falls back to a basic entry from plugin settings
	 * when the API returns nothing.
	 *
	 * @param string $currency The currency code (uppercase).
	 *
	 * @return array Array of OfferShippingDetails or empty array.
	 */
	private function get_surecart_shipping_details( $currency ) {
		if ( ! defined( 'SURECART_PLUGIN_FILE' ) ) {
			return [];
		}

		$delivery_time = $this->get_surecart_delivery_time();

		// Collect flat list of [ rate_amount, countries[] ] pairs from SureCart API.
		$rate_entries = $this->get_surecart_shipping_rate_entries();

		// Fallback to plugin settings if API returned nothing.
		if ( empty( $rate_entries ) ) {
			return $this->get_default_shipping_details( $currency );
		}

		$shipping_details = [];
		$shipping_index   = 0;

		foreach ( $rate_entries as $entry ) {
			$rate_value = number_format(
				(float) \SureCart\Support\Currency::maybeConvertAmount( $entry['amount'], strtolower( $currency ) ),
				2,
				'.',
				''
			);

			$destinations = ! empty( $entry['countries'] ) ? $entry['countries'] : [ '' ];

			foreach ( $destinations as $country_code ) {
				$destination = [ '@type' => 'DefinedRegion' ];
				if ( ! empty( $country_code ) ) {
					$destination['addressCountry'] = strtoupper( $country_code );
				}

				$shipping_details[] = [
					'@type'               => 'OfferShippingDetails',
					'@id'                 => home_url( '#SCShipping-' . $shipping_index ),
					'shippingRate'        => [
						'@type'    => 'MonetaryAmount',
						'value'    => $rate_value ?? 0,
						'currency' => $currency,
					],
					'shippingDestination' => $destination,
					'deliveryTime'        => $delivery_time,
				];
				++$shipping_index;
			}
		}

		return $shipping_details;
	}

	private function get_surecart_delivery_time() {
		$settings = get_option( 'rtrs_schema_ecommerce_settings', [] );

		$handling_min = $settings['handling_time_min'] ?? '';
		$handling_max = $settings['handling_time_max'] ?? '';
		$transit_min  = $settings['transit_time_min'] ?? '';
		$transit_max  = $settings['transit_time_max'] ?? '';

		return [
			'@type'        => 'ShippingDeliveryTime',
			'handlingTime' => [
				'@type'    => 'QuantitativeValue',
				'minValue' => ( '' !== $handling_min ) ? absint( $handling_min ) : 0,
				'maxValue' => ( '' !== $handling_max ) ? absint( $handling_max ) : 1,
				'unitCode' => 'DAY',
			],
			'transitTime'  => [
				'@type'    => 'QuantitativeValue',
				'minValue' => ( '' !== $transit_min ) ? absint( $transit_min ) : 3,
				'maxValue' => ( '' !== $transit_max ) ? absint( $transit_max ) : 7,
				'unitCode' => 'DAY',
			],
		];
	}

	private function get_surecart_shipping_rate_entries() {
		$profiles = \SureCart\Models\ShippingProfile::with(
			[ 'shipping_zones', 'shipping_zone.shipping_rates' ]
		)->get();

		if ( is_wp_error( $profiles ) || empty( $profiles ) ) {
			return [];
		}

		$entries = [];

		foreach ( $profiles as $profile ) {
			$zones_data = $profile->shipping_zones ?? null;
			$zones      = is_object( $zones_data ) && isset( $zones_data->data ) ? $zones_data->data : [];
			foreach ( $zones as $zone ) {
				if ( ! is_object( $zone ) ) {
					continue;
				}

				// Countries from territories[*]->country.
				$countries   = [];
				$territories = $zone->territories ?? [];
				if ( is_array( $territories ) ) {
					foreach ( $territories as $territory ) {
						if ( is_object( $territory ) && ! empty( $territory->country ) ) {
							$countries[] = $territory->country;
						}
					}
				}

				$rates_data = $zone->shipping_rates ?? null;
				$rates      = is_object( $rates_data ) && isset( $rates_data->data ) ? $rates_data->data : [];

				foreach ( $rates as $rate ) {
					if ( ! is_object( $rate ) || ! isset( $rate->amount ) ) {
						continue;
					}

					$entries[] = [
						'amount'    => $rate->amount,
						'countries' => $countries,
					];
				}
			}
		}

		return $entries;
	}

	private function get_default_shipping_details( $currency ) {
		$settings = get_option( 'rtrs_schema_ecommerce_settings', [] );
		$country  = ! empty( $settings['return_policy_country'] ) ? $settings['return_policy_country'] : '';

		if ( empty( $country ) ) {
			return [];
		}

		$handling_min = ( '' !== ( $settings['handling_time_min'] ?? '' ) ) ? absint( $settings['handling_time_min'] ) : 0;
		$handling_max = ( '' !== ( $settings['handling_time_max'] ?? '' ) ) ? absint( $settings['handling_time_max'] ) : 1;
		$transit_min  = ( '' !== ( $settings['transit_time_min'] ?? '' ) ) ? absint( $settings['transit_time_min'] ) : 3;
		$transit_max  = ( '' !== ( $settings['transit_time_max'] ?? '' ) ) ? absint( $settings['transit_time_max'] ) : 7;

		return [
			[
				'@type'               => 'OfferShippingDetails',
				'@id'                 => home_url( '#DefaultShipping-0' ),
				'shippingRate'        => [
					'@type'    => 'MonetaryAmount',
					'value'    => '0.00',
					'currency' => $currency,
				],
				'shippingDestination' => [
					'@type'          => 'DefinedRegion',
					'addressCountry' => strtoupper( $country ),
				],
				'deliveryTime'        => [
					'@type'        => 'ShippingDeliveryTime',
					'handlingTime' => [
						'@type'    => 'QuantitativeValue',
						'minValue' => $handling_min,
						'maxValue' => $handling_max,
						'unitCode' => 'DAY',
					],
					'transitTime'  => [
						'@type'    => 'QuantitativeValue',
						'minValue' => $transit_min,
						'maxValue' => $transit_max,
						'unitCode' => 'DAY',
					],
				],
			],
		];
	}
}
