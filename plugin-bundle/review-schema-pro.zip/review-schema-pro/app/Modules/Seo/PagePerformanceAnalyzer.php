<?php
/**
 * Page Performance analyzer (Pro).
 *
 * Implements the real Page Performance dimension that the free plugin ships as
 * a locked placeholder. Wired in via the free `rtrs_seo_analysis` filter (see
 * SchemaInit), reusing the free AnalysisContext so it scores the same live or
 * saved content as every other dimension.
 *
 * Source: deterministic on-page (content) heuristics — image dimensions (CLS),
 * render-blocking inline scripts, heavy embeds and content HTML
 * weight. This runs instantly, with no external request, so it works on drafts
 * and during live editing. (A real PageSpeed Insights / Core Web Vitals deep
 * test — which needs a published URL, an API key and a slow async call — can be
 * layered on later as an optional on-demand check.)
 *
 * @package Rtrsp\Modules\Seo
 * @since   1.0.0
 */

namespace Rtrsp\Modules\Seo;

use Rtrs\Modules\Seo\Analysis\AnalysisContext;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class PagePerformanceAnalyzer
 */
class PagePerformanceAnalyzer {

	/**
	 * Content HTML weight (KB) above which it's flagged as heavy.
	 */
	const HTML_KB_MAX = 150;

	/**
	 * Embeds/iframes above which third-party weight is flagged.
	 */
	const IFRAME_MAX = 2;

	/**
	 * Analyze page performance using the shared AnalysisContext.
	 *
	 * @param AnalysisContext $context Shared content context.
	 * @return array Normalized dimension object.
	 */
	public static function analyze_context( AnalysisContext $context ) {
		$content    = (string) $context->content();
		$html_bytes = strlen( $content );
		$html_kb    = round( $html_bytes / 1024, 1 );

		$images        = preg_match_all( '/<img\b[^>]*>/i', $content, $im ) ? $im[0] : [];
		$image_count   = count( $images );
		$missing_dim   = 0;
		$missing_files = [];
		foreach ( $images as $tag ) {
			$has_w = preg_match( '/\bwidth\s*=/i', $tag );
			$has_h = preg_match( '/\bheight\s*=/i', $tag );
			if ( ! ( $has_w && $has_h ) ) {
				$missing_dim++;
				$name = self::img_src( $tag );
				if ( '' !== $name ) {
					$missing_files[] = $name;
				}
			}
		}

		$inline_scripts = (int) preg_match_all( '/<script\b(?![^>]*\bsrc=)[^>]*>/i', $content, $ms );
		$iframes        = (int) preg_match_all( '/<iframe\b/i', $content, $mf );

		$score  = 100;
		$issues = [];

		if ( $missing_dim > 0 ) {
			$lost     = min( 30, $missing_dim * 10 );
			$score   -= $lost;
			$issues[] = self::issue(
				/* translators: %d: number of images. */
				sprintf( __( '%d image(s) are missing width/height (causes layout shift).', 'review-schema-pro' ), $missing_dim ),
				'warning',
				-$lost,
				'low',
				$missing_files
			);
		}

		if ( $inline_scripts > 0 ) {
			$score   -= 15;
			$issues[] = self::issue(
				__( 'Inline scripts in the content can block rendering.', 'review-schema-pro' ),
				'warning',
				-15,
				'medium'
			);
		}

		if ( $iframes > self::IFRAME_MAX ) {
			$score   -= 10;
			$issues[] = self::issue(
				__( 'Several heavy embeds/iframes; consider lazy-loading or facades.', 'review-schema-pro' ),
				'warning',
				-10,
				'medium'
			);
		}

		if ( $html_kb > self::HTML_KB_MAX ) {
			$score   -= 15;
			$issues[] = self::issue(
				/* translators: %s: content size in kilobytes. */
				sprintf( __( 'Content HTML is large (%s KB); trim heavy markup.', 'review-schema-pro' ), $html_kb ),
				'warning',
				-15,
				'medium'
			);
		}

		$score = max( 0, min( 100, (int) $score ) );

		// Full checklist (passes + fails) for display.
		$dim_ok    = 0 === $missing_dim;
		$script_ok = 0 === $inline_scripts;
		$embed_ok  = $iframes <= self::IFRAME_MAX;
		$size_ok   = $html_kb <= self::HTML_KB_MAX;

		$checks = [
			self::check( $dim_ok ? __( 'Images include width & height', 'review-schema-pro' ) : __( 'Some images are missing width/height', 'review-schema-pro' ), $dim_ok ? 'pass' : 'warn' ),
			self::check( $script_ok ? __( 'No render-blocking inline scripts', 'review-schema-pro' ) : __( 'Render-blocking inline scripts present', 'review-schema-pro' ), $script_ok ? 'pass' : 'warn' ),
			self::check( $embed_ok ? __( 'Heavy embeds are limited', 'review-schema-pro' ) : __( 'Many heavy embeds/iframes', 'review-schema-pro' ), $embed_ok ? 'pass' : 'warn' ),
			self::check( $size_ok ? __( 'Content size is reasonable', 'review-schema-pro' ) : __( 'Content HTML is heavy', 'review-schema-pro' ), $size_ok ? 'pass' : 'warn' ),
		];

		return [
			'dimension' => 'page_performance',
			'score'     => $score,
			'status'    => self::band( $score ),
			'scored_by' => 'deterministic',
			'measured'  => [
				'images'                    => $image_count,
				'images_missing_dimensions' => $missing_dim,
				'inline_scripts'            => $inline_scripts,
				'iframes'                   => $iframes,
				'html_kb'                   => $html_kb,
			],
			'issues'    => $issues,
			'checks'    => $checks,
		];
	}

	/**
	 * Map a 0–100 score to an explicit band.
	 *
	 * @param int $score Score 0–100.
	 * @return string 'pass' | 'warn' | 'fail'.
	 */
	private static function band( $score ) {
		if ( $score >= 80 ) {
			return 'pass';
		}
		if ( $score >= 50 ) {
			return 'warn';
		}
		return 'fail';
	}

	/**
	 * Build a checklist entry.
	 *
	 * @param string $label  Human label.
	 * @param string $status 'pass' | 'warn'.
	 * @return array
	 */
	private static function check( $label, $status ) {
		return [
			'label'  => $label,
			'status' => $status,
		];
	}

	/**
	 * Build a normalized issue row.
	 *
	 * @param string $message  Human message.
	 * @param string $severity 'critical' | 'warning' | 'info'.
	 * @param int    $points   Points impact (negative = lost).
	 * @param string $effort   'low' | 'medium' | 'high'.
	 * @param array  $items    Optional list of specific offenders (e.g. image file names).
	 * @return array
	 */
	private static function issue( $message, $severity, $points, $effort, $items = [] ) {
		return [
			'message'  => $message,
			'severity' => $severity,
			'points'   => (int) $points,
			'effort'   => $effort,
			'items'    => array_values( array_unique( array_filter( (array) $items ) ) ),
		];
	}

	/**
	 * Extract a readable file name from an <img> tag's src attribute.
	 *
	 * Query strings and fragments are stripped and inline (data:) sources are
	 * ignored, so the result identifies the offending image to the user.
	 *
	 * @param string $tag Full <img ...> tag.
	 * @return string File name, or empty string when none is usable.
	 */
	private static function img_src( $tag ) {
		if ( ! preg_match( '/\bsrc\s*=\s*("|\')(.*?)\1/i', (string) $tag, $m ) ) {
			return '';
		}
		$src = trim( $m[2] );
		if ( '' === $src || 0 === stripos( $src, 'data:' ) ) {
			return '';
		}
		$src  = (string) preg_replace( '/[?#].*$/', '', $src );
		$name = wp_basename( $src );
		return '' !== $name ? $name : $src;
	}
}
