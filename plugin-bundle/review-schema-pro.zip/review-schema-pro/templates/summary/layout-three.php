<?php
/**
 * Review summary layout three template
 *
 * @author      RadiusTheme
 * @package     review-schema/templates/review
 * @version     1.0.0
 *
 * @var use Rtrs\Helpers\Functions
 */

use Rtrs\Modules\Review\Helpers\ReviewFns;

// Cross-page display: ShortcodesInit::review_summary() passes the post whose
// reviews are being summarised. A theme override predating this key simply does
// not receive it and falls back to the current post — the original behaviour.
$rtrs_summary_post_id = ! empty( $post_id ) ? absint( $post_id ) : get_the_ID();

// Free->Pro trust boundary: re-assert the visibility rule on an explicitly
// supplied source post rather than assuming the caller validated it. The free
// shortcode does validate (ReviewFns::resolveSourcePostId()), and no shipped
// caller reaches this template with an unvalidated id — this is defence in
// depth for template overrides, the rtrs_get_template_part filter and any
// future caller. method_exists() keeps an older free plugin from fatalling.
if ( ! empty( $post_id )
	&& method_exists( ReviewFns::class, 'isPublicReviewTarget' )
	&& ! ReviewFns::isPublicReviewTarget( $rtrs_summary_post_id ) ) {
	return;
}

?>
<div class="rtrs-summary-3">
	<div class="rtrs-rating-summary">
		<div class="rtrs-rating-item grid-span-2">
			<ul class="rtrs-rating-category">
				<?php
				foreach ( ReviewFns::getCriteriaAvgRatings( $rtrs_summary_post_id ) as $value ) {
					if ( ! $value['avg'] ) {
						continue;
					}
					?>
					<li>
						<label><?php echo esc_html( $value['title'] ); ?></label>
						<div class="rating-icon">
							<?php echo ReviewFns::review_stars( $value['avg'] ); ?>
						</div>
						<div class="rating-number">
							<span class="total-number"><?php echo esc_html( $value['avg'] ); ?> /</span>
							<span class="outof-number">5</span>
						</div>
					</li>
				<?php } ?> 
			</ul>
		</div> 
		
		<?php if ( $avg_rating = ReviewFns::getAvgRatings( $rtrs_summary_post_id, true ) ) { ?>
		<div class="rtrs-rating-item">
			<div class="rtrs-rating-overall">
				<div class="rating-percent"><?php echo esc_html( $avg_rating ); ?></div>
				<div class="rating-text"><?php esc_html_e( 'OVERALL',  'review-schema-pro' ); ?></div>
				<div class="rating-icon">
					<?php echo ReviewFns::review_stars( $avg_rating ); ?>
				</div>
				<p>
					<?php
						printf(
							esc_html( _n( 'Based on %d rating', 'Based on %d ratings', $total_rating,  'review-schema-pro' ) ),
							esc_html( $total_rating )
						);
					?>
				</p>
			</div>
		</div>
		<?php } ?> 
	</div>
</div>