<?php
/**
 * Edited AI schema save (Pro).
 *
 * Owns the server side of "Edit Schema": a dedicated REST route,
 * `POST rtrs-ai/v1/save-edited/{post_id}`, that stores schema the user edited
 * in the free plugin's schema editor. The free plugin's own /save route only
 * accepts the unchanged schema returned by /generate, so without Pro edited
 * schema cannot be saved at all.
 *
 * The free editor panels pick this route up through the
 * `rtrs_ai_schema_edit_rest_path` filter. Validation limits and persistence
 * (site-level node stripping, FAQPage split, type/confidence meta) reuse the
 * free plugin's shared RestApi helpers so both save paths store identically.
 *
 * @package Rtrsp\AI
 */

namespace Rtrsp\AI;

use Rtrs\AI\AIInit;
use Rtrs\AI\RestApi;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SchemaEditController
 */
class SchemaEditController {

	/**
	 * REST namespace shared with the free plugin's AI routes.
	 */
	const REST_NAMESPACE = 'rtrs-ai/v1';

	/**
	 * Route base (followed by the post ID).
	 */
	const ROUTE = 'save-edited';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register_hooks() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
		add_filter( 'rtrs_ai_schema_edit_rest_path', [ $this, 'edit_rest_path' ] );
	}

	/**
	 * Point the free editor panels' edit-save request at this route.
	 *
	 * @param string $path Default path (empty).
	 * @return string
	 */
	public function edit_rest_path( $path ) {
		return self::shared_helpers_available() ? '/' . self::REST_NAMESPACE . '/' . self::ROUTE . '/' : $path;
	}

	/**
	 * Register the edited-schema save route.
	 *
	 * @return void
	 */
	public function register_routes() {
		if ( ! self::shared_helpers_available() ) {
			return; // Free too old to provide the shared validation/persistence.
		}

		register_rest_route(
			self::REST_NAMESPACE,
			'/' . self::ROUTE . '/(?P<post_id>\d+)',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'save_edited' ],
				'permission_callback' => [ $this, 'check_permission' ],
				'args'                => [
					'post_id' => [
						'type'              => 'integer',
						'required'          => true,
						'sanitize_callback' => 'absint',
					],
				],
			]
		);
	}

	/**
	 * Permission: the user must be able to edit this specific post.
	 *
	 * Pro decides itself: edit_post on the post, or — for SureCart /
	 * FluentCart products, matching the free AI routes — the product
	 * capability. When the free plugin provides its own rule it must agree as
	 * well (AND, never OR), so a looser free rule can never widen this route.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return bool
	 */
	public function check_permission( $request ) {
		$post_id = absint( $request->get_param( 'post_id' ) );
		$post    = $post_id ? get_post( $post_id ) : null;
		if ( ! $post instanceof \WP_Post ) {
			return false;
		}

		$allowed = current_user_can( 'edit_post', $post_id )
			|| ( 'sc_product' === $post->post_type && current_user_can( 'edit_sc_products' ) )
			|| ( 'fluent-products' === $post->post_type && current_user_can( 'manage_options' ) );

		if ( $allowed && method_exists( RestApi::class, 'check_edit_permission' ) ) {
			$allowed = (bool) ( new RestApi() )->check_edit_permission( $request );
		}

		return $allowed;
	}

	/**
	 * Validate and store edited schema.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function save_edited( $request ) {
		$post_id = absint( $request->get_param( 'post_id' ) );
		$body    = $request->get_json_params();
		$body    = is_array( $body ) ? $body : [];
		$schemas = AIInit::normalizeSchemaData( $body['schemas'] ?? [] );

		if ( empty( $schemas ) || ! is_array( $schemas ) ) {
			return new \WP_Error( 'no_schema', __( 'No schema data provided.', 'review-schema-pro' ), [ 'status' => 400 ] );
		}

		$invalid = RestApi::validate_schema_payload( $schemas );
		if ( is_wp_error( $invalid ) ) {
			return $invalid;
		}

		$schema_type  = isset( $body['schema_type'] ) && is_scalar( $body['schema_type'] ) ? sanitize_text_field( (string) $body['schema_type'] ) : '';
		$schema_types = isset( $body['schema_types'] ) && is_array( $body['schema_types'] ) ? array_values( array_map( 'sanitize_text_field', array_map( 'strval', array_filter( $body['schema_types'], 'is_scalar' ) ) ) ) : [];
		$confidence   = isset( $body['confidence'] ) && is_numeric( $body['confidence'] ) ? (int) $body['confidence'] : 0;

		return rest_ensure_response( RestApi::persist_content_schemas( $post_id, $schemas, $schema_type, $schema_types, $confidence ) );
	}

	/**
	 * Whether the installed free plugin provides the shared helpers.
	 *
	 * @return bool
	 */
	private static function shared_helpers_available() {
		return class_exists( RestApi::class )
			&& method_exists( RestApi::class, 'validate_schema_payload' )
			&& method_exists( RestApi::class, 'persist_content_schemas' )
			&& class_exists( AIInit::class );
	}
}
