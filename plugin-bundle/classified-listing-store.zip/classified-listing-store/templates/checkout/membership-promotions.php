<?php
/**
 * Membership checkout
 *
 * @author     RadiusTheme
 * @package    classified-listing/templates
 * @version    1.0.0
 * @var array      $promotions
 * @var Membership $membership
 * @var int        $listing_id
 */

use Rtcl\Resources\Options;
use RtclStore\Models\Membership;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Icon map keyed by promotion type. Icons use `currentColor` so they inherit
// --rtcl-primary-color from the CSS. Unknown keys fall back to a generic icon.
$rtcl_promo_meta = [
	'featured' => [
		'icon' => '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2l2.9 6.1 6.6.9-4.8 4.6 1.2 6.6L12 18.2 6.1 20.2l1.2-6.6L2.5 9l6.6-.9z"/></svg>',
	],
	'_top'     => [
		'icon' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 19V5"/><path d="M5 12l7-7 7 7"/></svg>',
	],
	'_bump_up' => [
		'icon' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20V8"/><path d="M6 12l6-6 6 6"/><path d="M6 20h12"/></svg>',
	],
];
$rtcl_default_icon = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2l2.9 6.1 6.6.9-4.8 4.6 1.2 6.6L12 18.2 6.1 20.2l1.2-6.6L2.5 9l6.6-.9z"/></svg>';

?>
<div id="rtcl-membership-promotions-table">
    <div class="rtcl-checkout-pricing-wrapper rtcl-row rtcl-form-group">
		<?php if ( ! empty( $promotions ) ) :
			$all_promotions = Options::get_listing_promotions();
			foreach ( $promotions as $promotion_key => $promotion ) {
				$title = ! empty( $all_promotions[ $promotion_key ] ) ? $all_promotions[ $promotion_key ] : $promotion_key;
				$icon  = ! empty( $rtcl_promo_meta[ $promotion_key ]['icon'] ) ? $rtcl_promo_meta[ $promotion_key ]['icon'] : $rtcl_default_icon;
				$ads      = ! empty( $promotion['ads'] ) ? absint( $promotion['ads'] ) : 0;
				$days     = ! empty( $promotion['validate'] ) ? absint( $promotion['validate'] ) : 0;
				?>
                <div class="rtcl-col-md-4 rtcl-col-12">
                    <div class="rtcl-checkout-pricing">
                        <div class="rtcl-checkout-pricing-inner">
                            <?php if ( ! empty( $title ) ) : ?>
                                <div class="rtcl-promo-head">
                                    <span class="rtcl-promo-icon"><?php echo $icon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
                                        <span class="rtcl-promo-heading">
                                        <span class="rtcl-pricing-title"><?php echo esc_html( $title ); ?></span>
                                    </span>
                                </div>
                            <?php endif; ?>
                            <div class="rtcl-promo-meta">
                                <div class="rtcl-promo-row">
                                    <span class="rtcl-promo-label"><?php esc_html_e( 'Remaining ads', 'classified-listing-store' ); ?></span>
                                    <span class="rtcl-promo-value"><?php echo esc_html( $ads ); ?></span>
                                </div>
                                <div class="rtcl-promo-row">
                                    <span class="rtcl-promo-label"><?php esc_html_e( 'Validity', 'classified-listing-store' ); ?></span>
                                    <span class="rtcl-promo-value">
										<?php
										/* translators: %d: number of days the promotion stays valid. */
										printf( esc_html( _n( '%d day', '%d days', $days, 'classified-listing-store' ) ), esc_html( $days ) );
										?>
                                    </span>
                                </div>
                            </div>
                            <div class="rtcl-pricing-btn">
                                <input type="checkbox" name="_rtcl_membership_promotions[]" id="promotion_<?php echo esc_attr( $promotion_key ); ?>"
                                       value="<?php echo esc_attr( $promotion_key ); ?>" class="rtcl-membership-promotion-input" required/>
                                <label for="promotion_<?php echo esc_attr( $promotion_key ); ?>">
									<?php
									/* translators: %s: promotion name, e.g. Featured. */
									printf( esc_html__( 'Select %s', 'classified-listing-store' ), esc_html( $title ) );
									?>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
			<?php } ?>
		<?php endif; ?>
    </div>
</div>
