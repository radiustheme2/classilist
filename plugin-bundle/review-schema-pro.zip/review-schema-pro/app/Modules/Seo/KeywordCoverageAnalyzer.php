<?php
/**
 * Keyword Coverage analyzer (Pro).
 *
 * Implements the real Keyword Coverage dimension that the free plugin ships as
 * a locked placeholder. It is wired in via the free `rtrs_seo_analysis` filter
 * (see SchemaInit), reusing the free AnalysisContext so it scores the same live
 * or saved content as every other dimension.
 *
 * Returns the same normalized shape as the free analyzers, plus a `has_keyword`
 * flag so the filter can show a "set a focus keyword" prompt (and exclude the
 * dimension from the aggregate) when no focus keyword is configured.
 *
 * @package Rtrsp\Modules\Seo
 * @since   1.0.0
 */

namespace Rtrsp\Modules\Seo;

use Rtrs\Modules\Seo\Analysis\AnalysisContext;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class KeywordCoverageAnalyzer
 */
class KeywordCoverageAnalyzer {

	const DENSITY_MIN = 0.5;
	const DENSITY_MAX = 2.5;

	/**
	 * Analyze keyword coverage using the shared free AnalysisContext.
	 *
	 * @param AnalysisContext $context Shared content context.
	 * @return array Normalized dimension object with an added `has_keyword` flag.
	 */
	public static function analyze_context( AnalysisContext $context ) {
		$keyword = trim( (string) $context->focus_keyword() );

		if ( '' === $keyword ) {
			return [
				'dimension'   => 'keyword_coverage',
				'has_keyword' => false,
				'score'       => 0,
				'status'      => 'warn',
				'scored_by'   => 'deterministic',
				'measured'    => [ 'keyword' => '' ],
				'issues'      => [
					self::issue(
						__( 'Set a focus keyword to measure keyword coverage.', 'review-schema-pro' ),
						'info',
						0,
						'low',
						[ 'target' => 'focus_keyword' ]
					),
				],
				'checks'      => [
					self::check( __( 'Set a focus keyword to measure coverage', 'review-schema-pro' ), 'warn' ),
				],
			];
		}

		$title       = (string) $context->meta_title();
		$meta        = (string) $context->meta_description();
		$headings    = $context->headings();
		$body        = $context->plain_text();
		$words       = max( 0, (int) $context->word_count() );
		$first_para  = self::first_paragraph( $context->content(), $body );
		$kw_words    = max( 1, str_word_count( $keyword ) );
		$occurrences = self::count_occurrences( $body, $keyword );

		// Density is measured on the main-article prose only (headings, tables,
		// code blocks, captions and nav excluded) so structural markup does not
		// skew the percentage; keyword presence still uses the full body.
		$article_text  = $context->article_text();
		$article_words = max( 0, (int) $context->article_word_count() );
		$article_occ   = self::count_occurrences( $article_text, $keyword );
		$density       = $article_words > 0 ? round( ( $article_occ * $kw_words ) / $article_words * 100, 2 ) : 0.0;

		$in_title      = self::contains( $title, $keyword );
		$in_first_para = self::contains( $first_para, $keyword );
		$in_heading    = self::in_headings( $headings, $keyword );
		$in_meta       = '' !== $meta && self::contains( $meta, $keyword );

		$score  = 0;
		$issues = [];

		// In title (25).
		if ( $in_title ) {
			$score += 25;
		} else {
			$issues[] = self::issue( __( 'Focus keyword is not in the SEO title.', 'review-schema-pro' ), 'warning', -25, 'low', [ 'target' => 'title', 'post_title' => false ] );
		}

		// In first paragraph (20).
		if ( $in_first_para ) {
			$score += 20;
		} else {
			$issues[] = self::issue( __( 'Focus keyword is not in the first paragraph.', 'review-schema-pro' ), 'warning', -20, 'low', [ 'target' => 'first_paragraph' ] );
		}

		// In a subheading (15).
		if ( $in_heading ) {
			$score += 15;
		} else {
			$issues[] = self::issue( __( 'Focus keyword is not used in any subheading.', 'review-schema-pro' ), 'info', -15, 'low', [ 'target' => 'subheading' ] );
		}

		// In meta description (15).
		if ( $in_meta ) {
			$score += 15;
		} else {
			$issues[] = self::issue( __( 'Focus keyword is not in the meta description.', 'review-schema-pro' ), 'warning', -15, 'low', [ 'target' => 'meta' ] );
		}

		// Density (25).
		if ( 0 === $occurrences ) {
			$issues[] = self::issue( __( 'Focus keyword does not appear in the content.', 'review-schema-pro' ), 'warning', -25, 'medium' );
		} elseif ( $density < self::DENSITY_MIN ) {
			$score   += 12;
			$issues[] = self::issue(
				/* translators: %s: keyword density percentage. */
				sprintf( __( 'Keyword density is low (%s%%); aim for 0.5–2.5%%.', 'review-schema-pro' ), $density ),
				'info',
				-13,
				'low'
			);
		} elseif ( $density > self::DENSITY_MAX ) {
			$score   += 10;
			$issues[] = self::issue(
				/* translators: %s: keyword density percentage. */
				sprintf( __( 'The focus keyword repeats often (%s%% density). Consider replacing a few exact matches with natural variations.', 'review-schema-pro' ), $density ),
				'info',
				-10,
				'low',
				[ 'target' => 'keyword_density' ]
			);
		} else {
			$score += 25;
		}

		$score = max( 0, min( 100, (int) $score ) );

		// Full checklist (passes + fails) for display.
		$density_ok = $occurrences > 0 && $density >= self::DENSITY_MIN && $density <= self::DENSITY_MAX;
		if ( $density_ok ) {
			/* translators: %s: keyword density percentage. */
			$density_label = sprintf( __( 'Keyword density is healthy (%s%%)', 'review-schema-pro' ), $density );
		} elseif ( 0 === $occurrences ) {
			$density_label = __( 'Keyword does not appear in the content', 'review-schema-pro' );
		} elseif ( $density < self::DENSITY_MIN ) {
			/* translators: %s: keyword density percentage. */
			$density_label = sprintf( __( 'Keyword density is low (%s%%)', 'review-schema-pro' ), $density );
		} else {
			/* translators: %s: keyword density percentage. */
			$density_label = sprintf( __( 'Keyword density is high (%s%%)', 'review-schema-pro' ), $density );
		}

		$checks = [
			self::check( $in_title ? __( 'Keyword in the SEO title', 'review-schema-pro' ) : __( 'Keyword not in the SEO title', 'review-schema-pro' ), $in_title ? 'pass' : 'warn' ),
			self::check( $in_first_para ? __( 'Keyword in the first paragraph', 'review-schema-pro' ) : __( 'Keyword not in the first paragraph', 'review-schema-pro' ), $in_first_para ? 'pass' : 'warn' ),
			self::check( $in_heading ? __( 'Keyword in a subheading', 'review-schema-pro' ) : __( 'Keyword not in any subheading', 'review-schema-pro' ), $in_heading ? 'pass' : 'warn' ),
			self::check( $in_meta ? __( 'Keyword in the meta description', 'review-schema-pro' ) : __( 'Keyword not in the meta description', 'review-schema-pro' ), $in_meta ? 'pass' : 'warn' ),
			self::check( $density_label, $density_ok ? 'pass' : 'warn' ),
		];

		return [
			'dimension'   => 'keyword_coverage',
			'has_keyword' => true,
			'score'       => $score,
			'status'      => self::band( $score ),
			'scored_by'   => 'deterministic',
			'measured'    => [
				'keyword'            => $keyword,
				'in_title'           => $in_title,
				'in_heading'         => $in_heading,
				'in_first_paragraph' => $in_first_para,
				'in_meta'            => $in_meta,
				'occurrences'        => $occurrences,
				'article_occurrences' => $article_occ,
				'density'            => $density,
				'word_count'         => $words,
				'article_word_count' => $article_words,
			],
			'issues'      => $issues,
			'checks'      => $checks,
		];
	}

	/**
	 * Build a checklist entry.
	 *
	 * @param string $label  Human label.
	 * @param string $status 'pass' | 'warn'.
	 * @return array
	 */
	private static function check( $label, $status ) {
		return [
			'label'  => $label,
			'status' => $status,
		];
	}

	/**
	 * Case-insensitive phrase containment.
	 *
	 * @param string $haystack Text to search.
	 * @param string $needle   Keyword phrase.
	 * @return bool
	 */
	private static function contains( $haystack, $needle ) {
		if ( '' === $haystack || '' === $needle ) {
			return false;
		}
		return false !== stripos( $haystack, $needle );
	}

	/**
	 * Whether the keyword appears in any heading text.
	 *
	 * @param array[] $headings Headings.
	 * @param string  $keyword  Keyword.
	 * @return bool
	 */
	private static function in_headings( array $headings, $keyword ) {
		foreach ( $headings as $h ) {
			if ( ! empty( $h['text'] ) && self::contains( $h['text'], $keyword ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Count case-insensitive, whole-word phrase occurrences.
	 *
	 * @param string $body    Plain-text body.
	 * @param string $keyword Keyword phrase.
	 * @return int
	 */
	private static function count_occurrences( $body, $keyword ) {
		return self::count_exact( $body, $keyword );
	}

	/**
	 * Count case-insensitive, word-boundary keyword matches in a text.
	 *
	 * Uses whole-word matching so stems (e.g. "reviews" for "review") are not
	 * counted; falls back to a substring count only when the keyword cannot
	 * anchor on a word boundary (e.g. trailing punctuation), so a usable count
	 * is always returned.
	 *
	 * @param string $text    Plain text to search.
	 * @param string $keyword Keyword phrase.
	 * @return int
	 */
	public static function count_exact( $text, $keyword ) {
		if ( '' === $text || '' === $keyword ) {
			return 0;
		}
		$text_l = function_exists( 'mb_strtolower' ) ? mb_strtolower( $text ) : strtolower( $text );
		$kw_l   = function_exists( 'mb_strtolower' ) ? mb_strtolower( $keyword ) : strtolower( $keyword );

		$pattern = '/\b' . preg_quote( $kw_l, '/' ) . '\b/u';
		$count   = preg_match_all( $pattern, $text_l, $matches );
		if ( false === $count ) {
			return substr_count( $text_l, $kw_l );
		}
		return (int) $count;
	}

	/**
	 * Extract the first paragraph text, falling back to the first ~50 words.
	 *
	 * @param string $content Rendered HTML content.
	 * @param string $body    Plain-text body.
	 * @return string
	 */
	private static function first_paragraph( $content, $body ) {
		if ( '' !== $content && preg_match( '/<p\b[^>]*>(.*?)<\/p>/is', $content, $m ) ) {
			$text = trim( wp_strip_all_tags( $m[1] ) );
			if ( '' !== $text ) {
				return $text;
			}
		}
		return trim( wp_trim_words( $body, 50, '' ) );
	}

	/**
	 * Map a 0–100 score to an explicit band.
	 *
	 * @param int $score Score 0–100.
	 * @return string 'pass' | 'warn' | 'fail'.
	 */
	private static function band( $score ) {
		if ( $score >= 80 ) {
			return 'pass';
		}
		if ( $score >= 50 ) {
			return 'warn';
		}
		return 'fail';
	}

	/**
	 * Build a normalized issue row.
	 *
	 * @param string     $message  Human message.
	 * @param string     $severity 'critical' | 'warning' | 'info'.
	 * @param int        $points   Points impact (negative = lost).
	 * @param string     $effort   'low' | 'medium' | 'high'.
	 * @param array|null $apply    Optional "Apply with AI" hint, e.g. [ 'target' => 'title' ].
	 * @return array
	 */
	private static function issue( $message, $severity, $points, $effort, $apply = null ) {
		$issue = [
			'message'  => $message,
			'severity' => $severity,
			'points'   => (int) $points,
			'effort'   => $effort,
		];
		if ( null !== $apply ) {
			$issue['apply'] = $apply;
		}
		return $issue;
	}
}
