<?php
/**
 * REST controller for the Pro "Apply with AI" flow on the SEO report.
 *
 * Two routes under the plugin's existing `rtrs-ai/v1` namespace:
 *   - POST seo/{id}/ai-suggest → AI proposes a better title / meta description.
 *   - POST seo/{id}/ai-apply   → save an accepted value to the active SEO plugin
 *                                meta and return the refreshed SEO channel.
 * Both are Pro-only and require an AI key; the free plugin ships the buttons
 * locked behind a PRO upsell.
 *
 * @package Rtrsp\Modules\Seo
 * @since   1.0.0
 */

namespace Rtrsp\Modules\Seo;

use Rtrs\AI\AIClient;
use Rtrs\AI\AIInit;
use Rtrs\Modules\Aeo\Helpers\AeoContent;
use Rtrs\Modules\Schema\Hooks\SeoHooks;
use Rtrs\Modules\Seo\Analysis\AnalysisContext;
use Rtrs\Modules\Seo\Analyzers\SeoAnalyzer;
use Rtrs\Modules\Seo\Helpers\SeoMeta;
use Rtrsp\Traits\SingletonTrait;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SeoAiController
 */
class SeoAiController {

	use SingletonTrait;

	const REST_NAMESPACE = 'rtrs-ai/v1';

	/**
	 * Register the rest_api_init hook.
	 */
	private function __construct() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register the ai-suggest / ai-apply routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			self::REST_NAMESPACE,
			'/seo/(?P<post_id>\d+)/ai-suggest',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'ai_suggest' ],
				'permission_callback' => [ $this, 'check_permission' ],
				'args'                => [
					'post_id'         => [ 'required' => true, 'sanitize_callback' => 'absint' ],
					'target'          => [ 'required' => true, 'sanitize_callback' => 'sanitize_key' ],
					'title'           => [ 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ],
					'meta'            => [ 'required' => false, 'sanitize_callback' => 'sanitize_textarea_field' ],
					'content'         => [ 'required' => false, 'sanitize_callback' => 'wp_kses_post' ],
					'first_paragraph' => [ 'required' => false, 'sanitize_callback' => 'sanitize_textarea_field' ],
					'subheading'      => [ 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ],
					'section_heading' => [ 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ],
					'source'          => [ 'required' => false, 'sanitize_callback' => 'sanitize_textarea_field' ],
					// Live focus keyword from the active SEO plugin's editor state.
					// Optional: callers that omit it keep the saved-value behaviour.
					'focus_keyword'   => [ 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ],
				],
			]
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/seo/(?P<post_id>\d+)/ai-apply',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'ai_apply' ],
				'permission_callback' => [ $this, 'check_permission' ],
				'args'                => [
					'post_id'         => [ 'required' => true, 'sanitize_callback' => 'absint' ],
					'target'          => [ 'required' => true, 'sanitize_callback' => 'sanitize_key' ],
					'value'           => [ 'required' => true, 'sanitize_callback' => 'sanitize_textarea_field' ],
					'also_post_title' => [ 'required' => false, 'sanitize_callback' => 'rest_sanitize_boolean' ],
				],
			]
		);
	}

	/**
	 * Free's Elementor workflow guard: AI suggest/apply on an Elementor-built
	 * post belong in the Elementor editor. Runs inside the route callback, i.e.
	 * after check_permission() — it can only add a rejection, never grant
	 * access. No-op on an older free version without the helper.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_Error|null
	 */
	private static function elementor_guard( $request ) {
		if ( ! method_exists( AIInit::class, 'elementorEditorGuard' ) ) {
			return null;
		}

		return AIInit::elementorEditorGuard( $request, absint( $request['post_id'] ) );
	}

	/**
	 * Permission check — the user must be able to edit the target post.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return bool
	 */
	public function check_permission( $request ) {
		$post_id = absint( $request['post_id'] );
		return $post_id > 0 && current_user_can( 'edit_post', $post_id );
	}

	/**
	 * Generate an AI proposal for the title or meta description.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function ai_suggest( $request ) {
		$elementor_guard = self::elementor_guard( $request );
		if ( is_wp_error( $elementor_guard ) ) {
			return $elementor_guard;
		}

		$target = self::normalize_target( $request['target'] );
		if ( '' === $target ) {
			return new \WP_Error( 'invalid_target', __( 'Unsupported target.', 'review-schema-pro' ), [ 'status' => 400 ] );
		}
		if ( ! AIInit::hasApiKey() ) {
			return new \WP_Error( 'no_api_key', __( 'Configure an AI provider key in the AI settings first.', 'review-schema-pro' ), [ 'status' => 400 ] );
		}

		// Density fix has its own payload + response shape (rewrites the densest paragraph).
		if ( 'keyword_density' === $target ) {
			return self::suggest_keyword_density( $request );
		}

		// Section lead (AEO "Direct Answer Blocks") proposes a concise 20-75 word
		// answer for one heading; suggestion-only, so it has its own payload/shape.
		if ( 'section_lead' === $target ) {
			return self::suggest_section_lead( $request );
		}

		// Internal links proposes anchor → existing-page pairs the author can add,
		// drawn from a relevance-ranked shortlist of the site's own content.
		// Copy-only, so it has its own payload/shape.
		if ( 'internal_links' === $target ) {
			return self::suggest_internal_links( $request );
		}

		// Other AEO copy-only fixes: rewrite a too-long paragraph/sentence, or
		// generate a snippet heading/list/table/steps or FAQ pairs from content.
		if ( in_array( $target, [ 'tighten_paragraph', 'shorten_sentence' ], true ) ) {
			return self::suggest_aeo_rewrite( $request, $target );
		}
		if ( in_array( $target, [ 'snippet_heading', 'snippet_list', 'snippet_table', 'snippet_steps', 'faq_pairs' ], true ) ) {
			return self::suggest_aeo_generate( $request, $target );
		}

		$title   = isset( $request['title'] ) ? (string) $request['title'] : '';
		$meta    = isset( $request['meta'] ) ? (string) $request['meta'] : '';
		// Live content when the editor can read it (classic/Gutenberg); otherwise
		// fall back to the saved, rendered content so surfaces without an editable
		// content DOM (e.g. the Elementor panel) still get a useful proposal.
		$raw_content = isset( $request['content'] ) ? trim( (string) $request['content'] ) : '';
		if ( '' === $raw_content ) {
			$raw_content = ( new AnalysisContext( absint( $request['post_id'] ) ) )->content();
		}
		$content = trim( wp_trim_words( wp_strip_all_tags( $raw_content ), 200, '' ) );

		$first   = isset( $request['first_paragraph'] ) ? trim( wp_strip_all_tags( (string) $request['first_paragraph'] ) ) : '';
		$subhead = isset( $request['subheading'] ) ? trim( wp_strip_all_tags( (string) $request['subheading'] ) ) : '';
		$keyword = self::resolve_focus_keyword( $request );

		$client   = new AIClient();
		$response = $client->complete(
			self::suggest_system_prompt( $target ),
			wp_json_encode(
				[
					'current_title'            => $title,
					'current_meta_description' => '' !== $meta ? $meta : null,
					'current_first_paragraph'  => '' !== $first ? $first : null,
					'current_subheading'       => '' !== $subhead ? $subhead : null,
					'content'                  => $content,
					'focus_keyword'            => '' !== $keyword ? $keyword : null,
				]
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$proposal = is_array( $response ) && isset( $response['value'] ) ? trim( (string) $response['value'] ) : '';
		if ( '' === $proposal ) {
			return new \WP_Error( 'empty_proposal', __( 'The AI did not return a usable suggestion. Try again.', 'review-schema-pro' ), [ 'status' => 502 ] );
		}

		// Keep the meta description within the analyzer's ~160 char ceiling so the
		// applied value never re-triggers the "may be truncated beyond ~160" notice.
		if ( 'meta' === $target ) {
			$proposal = self::clamp_meta_length( $proposal );
		}

		// Title, subheading and focus keyword are single-line; meta / first paragraph allow line breaks.
		$single_line = ( 'title' === $target || 'subheading' === $target || 'focus_keyword' === $target );

		return rest_ensure_response(
			[
				'target'   => $target,
				'proposal' => $single_line ? sanitize_text_field( $proposal ) : sanitize_textarea_field( $proposal ),
			]
		);
	}

	/**
	 * Resolve the focus keyword to feed the prompt.
	 *
	 * Prefers the live value the editor sent, because an SEO plugin holds a
	 * newly-typed keyword in its own editor store and only flushes it to post
	 * meta on save — reading the database alone would build the suggestion
	 * around the previous keyword. Falls back to the saved value whenever the
	 * caller sends nothing (every pre-existing caller, and any surface that
	 * cannot read its plugin's store reliably).
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return string Focus keyword, or '' when none is set anywhere.
	 */
	private static function resolve_focus_keyword( $request ) {
		$live = isset( $request['focus_keyword'] ) ? trim( (string) $request['focus_keyword'] ) : '';
		if ( '' !== $live ) {
			return $live;
		}

		return trim( (string) SeoMeta::get_focus_keyword( absint( $request['post_id'] ) ) );
	}

	/**
	 * Clamp a meta-description proposal to the analyzer's ~160 character ceiling.
	 *
	 * Models do not count characters reliably, so an occasional overshoot (e.g. 168)
	 * would re-trigger the "may be truncated beyond ~160" suggestion right after the
	 * user applies it. This trims to the last word boundary within 160 characters and
	 * drops any dangling trailing punctuation, leaving the text natural and compliant.
	 *
	 * @param string $meta Proposed meta description.
	 * @return string
	 */
	private static function clamp_meta_length( $meta ) {
		$max = 160;
		if ( function_exists( 'mb_strlen' ) ) {
			if ( mb_strlen( $meta ) <= $max ) {
				return $meta;
			}
			$cut = mb_substr( $meta, 0, $max );
		} else {
			if ( strlen( $meta ) <= $max ) {
				return $meta;
			}
			$cut = substr( $meta, 0, $max );
		}

		$space = strrpos( $cut, ' ' );
		if ( false !== $space && $space > 0 ) {
			$cut = substr( $cut, 0, $space );
		}

		return rtrim( $cut, " \t\n\r\0\x0B,;:.-" );
	}

	/**
	 * Propose a rewrite of the single paragraph that over-repeats the keyword.
	 *
	 * Finds the densest paragraph in the live article content, asks the AI to
	 * reduce exact-match repetition while preserving meaning and at least one
	 * keyword use, and returns the proposal plus the original paragraph text so
	 * the editor can locate and replace the matching block.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	private static function suggest_keyword_density( $request ) {
		$post_id = absint( $request['post_id'] );
		$keyword = trim( (string) SeoMeta::get_focus_keyword( $post_id ) );
		if ( '' === $keyword ) {
			return new \WP_Error( 'no_keyword', __( 'Set a focus keyword first.', 'review-schema-pro' ), [ 'status' => 400 ] );
		}

		$html    = isset( $request['content'] ) ? (string) $request['content'] : '';
		$context = new AnalysisContext( $post_id, '' !== $html ? $html : null );

		$dense = '';
		$best  = 1;
		foreach ( $context->article_paragraphs() as $paragraph ) {
			$hits = KeywordCoverageAnalyzer::count_exact( $paragraph, $keyword );
			if ( $hits > $best ) {
				$best  = $hits;
				$dense = $paragraph;
			}
		}

		if ( '' === $dense ) {
			return new \WP_Error( 'no_dense_paragraph', __( 'No single paragraph over-repeats the keyword.', 'review-schema-pro' ), [ 'status' => 404 ] );
		}

		$content = trim( wp_trim_words( $context->article_text(), 200, '' ) );

		$client   = new AIClient();
		$response = $client->complete(
			self::suggest_system_prompt( 'keyword_density' ),
			wp_json_encode(
				[
					'current_paragraph' => $dense,
					'content'           => $content,
					'focus_keyword'     => $keyword,
				]
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$proposal = is_array( $response ) && isset( $response['value'] ) ? trim( (string) $response['value'] ) : '';
		if ( '' === $proposal ) {
			return new \WP_Error( 'empty_proposal', __( 'The AI did not return a usable suggestion. Try again.', 'review-schema-pro' ), [ 'status' => 502 ] );
		}

		return rest_ensure_response(
			[
				'target'   => 'keyword_density',
				'proposal' => sanitize_textarea_field( $proposal ),
				'original' => $dense,
			]
		);
	}

	/**
	 * Propose a concise 20-75 word lead answer for one content section.
	 *
	 * Locates the section by its heading in the live content, then asks the AI to
	 * write a self-contained direct answer to that heading using the section body
	 * as context. Suggestion-only: returns the proposal (and the current lead as
	 * `original`) for the editor to show; nothing is written to the post.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	private static function suggest_section_lead( $request ) {
		$post_id = absint( $request['post_id'] );
		$heading = isset( $request['section_heading'] ) ? trim( wp_strip_all_tags( (string) $request['section_heading'] ) ) : '';
		$html    = isset( $request['content'] ) ? (string) $request['content'] : '';

		$context  = new AnalysisContext( $post_id, '' !== $html ? $html : null );
		$sections = AeoContent::sections( $context->content() );

		$heading_ctx = $heading;
		$body        = '';
		$current     = '';

		if ( '' !== $heading ) {
			$needle = self::normalize_heading( $heading );
			foreach ( $sections as $section ) {
				if ( self::normalize_heading( (string) $section['heading'] ) === $needle ) {
					$body    = isset( $section['body'] ) ? (string) $section['body'] : '';
					$current = isset( $section['first_para'] ) ? (string) $section['first_para'] : '';
					break;
				}
			}
		}

		if ( '' === $body ) {
			// A NAMED section that cannot be located must NOT fall back to the
			// whole article — that produces a suggestion about an unrelated
			// topic (the article's dominant subject). This happens when the live
			// editor content no longer matches the analyzed section (e.g. edited
			// but unsaved). Fail honestly and tell the author to save.
			if ( '' !== $heading ) {
				return new \WP_Error(
					'section_not_found',
					__( 'Could not locate this section in the current content. Save the post and try again.', 'review-schema-pro' ),
					[ 'status' => 404 ]
				);
			}

			// Genuine whole-page lead (no heading supplied): the article opening
			// is the correct context and current lead.
			$paragraphs  = $context->article_paragraphs();
			$current     = ( '' === $current && isset( $paragraphs[0] ) ) ? (string) $paragraphs[0] : $current;
			$body        = trim( wp_trim_words( $context->article_text(), 160, '' ) );
			$heading_ctx = trim( wp_strip_all_tags( get_the_title( $post_id ) ) );
		} else {
			$body = trim( wp_trim_words( $body, 160, '' ) );
		}

		if ( '' === $body && '' === $current && '' === $heading_ctx ) {
			return new \WP_Error( 'no_section', __( 'Could not find this section to summarize. Try again after saving.', 'review-schema-pro' ), [ 'status' => 404 ] );
		}

		$client   = new AIClient();
		$response = $client->complete(
			self::suggest_system_prompt( 'section_lead' ),
			wp_json_encode(
				[
					'heading'      => '' !== $heading_ctx ? $heading_ctx : null,
					'current_lead' => '' !== $current ? $current : null,
					'section_body' => '' !== $body ? $body : null,
				]
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$proposal = is_array( $response ) && isset( $response['value'] ) ? trim( (string) $response['value'] ) : '';
		if ( '' === $proposal ) {
			return new \WP_Error( 'empty_proposal', __( 'The AI did not return a usable suggestion. Try again.', 'review-schema-pro' ), [ 'status' => 502 ] );
		}

		return rest_ensure_response(
			[
				'target'   => 'section_lead',
				'proposal' => sanitize_textarea_field( $proposal ),
				'original' => $current,
			]
		);
	}

	/**
	 * Propose internal links: anchor phrases in the current content mapped to
	 * relevant existing pages on the site.
	 *
	 * Feeds the AI a relevance-ranked shortlist of the site's own published
	 * content (from InternalLinkCandidates — capped and cached, never a full
	 * scan) plus the article text, and asks it to pick descriptive anchor →
	 * target-URL pairs. Copy-only: returns a formatted, paste-ready proposal;
	 * nothing is written to the post.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	private static function suggest_internal_links( $request ) {
		$post_id = absint( $request['post_id'] );

		$live_html  = isset( $request['content'] ) ? (string) $request['content'] : '';
		$discovery  = \Rtrs\Modules\Seo\Helpers\InternalLinkCandidates::discover( $post_id, \Rtrs\Modules\Seo\Helpers\InternalLinkCandidates::LIMIT, '' !== $live_html ? $live_html : null );
		$mode       = isset( $discovery['mode'] ) ? $discovery['mode'] : 'wp_query';
		$candidates = isset( $discovery['candidates'] ) ? $discovery['candidates'] : [];

		$client = new AIClient();

		if ( 'wp_query' !== $mode ) {
			$semantic = isset( $discovery['semantic'] ) ? $discovery['semantic'] : [];
			$content  = isset( $discovery['content'] ) ? (string) $discovery['content'] : '';

			// Diagnostic funnel counts (shown in the message when WP_DEBUG or the
			// rtrs_internal_link_debug filter is on): DB link candidates (natural
			// anchor present) vs semantic candidates (relevant, no anchor) → AI-kept.
			$il_debug = (bool) apply_filters( 'rtrs_internal_link_debug', defined( 'WP_DEBUG' ) && WP_DEBUG );
			$il_note  = function ( $stage ) use ( $il_debug, $candidates, $semantic ) {
				if ( ! $il_debug ) {
					return '';
				}
				return sprintf( ' [debug: link candidates %d · semantic %d · %s]', count( $candidates ), count( $semantic ), $stage );
			};

			// Neither a natural anchor nor a relevant semantic target → honestly zero.
			//
			// An empty result set is a SUCCESSFUL request, so it answers 200 with an
			// empty payload rather than 404. A 404 here made every "nothing to
			// suggest" click log a red console error indistinguishable from a
			// missing route. The panel already renders its own "no suggestions"
			// message when items and recommendations are both empty.
			if ( empty( $candidates ) && empty( $semantic ) ) {
				return rest_ensure_response(
					[
						'target'          => 'internal_links',
						'items'           => [],
						'recommendations' => [],
						'notice'          => __( 'No natural internal-link opportunities were found in this content.', 'review-schema-pro' ) . $il_note( 'no candidates before AI' ),
					]
				);
			}

			// link_candidates: strong local matches (a natural anchor already exists,
			// with its sentence). related_candidates: semantically-ranked targets with
			// no confirmed anchor — the AI decides link-opportunity vs recommendation.
			$link_candidates = [];
			foreach ( $candidates as $candidate ) {
				$link_candidates[] = [
					'url'     => $candidate['url'],
					'title'   => isset( $candidate['title'] ) ? $candidate['title'] : '',
					'context' => isset( $candidate['context'] ) ? $candidate['context'] : '',
				];
			}
			$related_candidates = [];
			foreach ( $semantic as $candidate ) {
				$related_candidates[] = [
					'url'     => $candidate['url'],
					'title'   => isset( $candidate['title'] ) ? $candidate['title'] : '',
					'excerpt' => isset( $candidate['excerpt'] ) ? $candidate['excerpt'] : '',
				];
			}

			$response = $client->complete(
				self::suggest_system_prompt( 'internal_links_context' ),
				wp_json_encode(
					[
						'content'            => $content,
						'link_candidates'    => $link_candidates,
						'related_candidates' => $related_candidates,
					]
				)
			);
			if ( is_wp_error( $response ) ) {
				return $response;
			}

			$result = self::sanitize_link_response( $response, $candidates, $semantic, $content );
			if ( empty( $result['items'] ) && empty( $result['recommendations'] ) ) {
				// Not an error — the AI simply found nothing worth suggesting.
				// Empty result, not a failure — see the note above.
				return rest_ensure_response(
					[
						'target'          => 'internal_links',
						'items'           => [],
						'recommendations' => [],
						'notice'          => __( 'No natural internal-link opportunities were found in this content.', 'review-schema-pro' ) . $il_note( 'AI kept 0' ),
					]
				);
			}

			return rest_ensure_response(
				[
					'target'          => 'internal_links',
					'items'           => $result['items'],
					'recommendations' => $result['recommendations'],
				]
			);
		}

		// ── wp_query fallback (no sitemap configured) ──────────────────────────
		if ( empty( $candidates ) ) {
			// Empty result, not a failure — see the note in the db-mode branch above.
			return rest_ensure_response(
				[
					'target'          => 'internal_links',
					'items'           => [],
					'recommendations' => [],
					'notice'          => __( 'No other published pages were found to link to. Publish more related content first.', 'review-schema-pro' ),
				]
			);
		}

		$html    = isset( $request['content'] ) ? (string) $request['content'] : '';
		$context = new AnalysisContext( $post_id, '' !== $html ? $html : null );
		$content = trim( wp_trim_words( $context->article_text(), 220, '' ) );
		if ( '' === $content ) {
			return new \WP_Error( 'no_content', __( 'Add some content first, then generate.', 'review-schema-pro' ), [ 'status' => 400 ] );
		}
		$keyword  = trim( (string) SeoMeta::get_focus_keyword( $post_id ) );
		$response = $client->complete(
			self::suggest_system_prompt( 'internal_links' ),
			wp_json_encode(
				[
					'content'         => $content,
					'title'           => trim( wp_strip_all_tags( (string) get_the_title( $post_id ) ) ),
					'focus_keyword'   => '' !== $keyword ? $keyword : null,
					'candidate_pages' => $candidates,
				]
			)
		);
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$items = self::sanitize_link_items( $response, $candidates, $mode );
		if ( empty( $items ) ) {
			return new \WP_Error( 'empty_proposal', __( 'The AI did not return a usable suggestion. Try again.', 'review-schema-pro' ), [ 'status' => 502 ] );
		}

		return rest_ensure_response(
			[
				'target' => 'internal_links',
				'items'  => $items,
			]
		);
	}

	/**
	 * Validate the two-outcome sitemap AI response into link opportunities and
	 * content recommendations.
	 *
	 * - Link opportunity: `anchor` must be a verbatim substring of the article
	 *   text or a candidate context (guards hallucination and guarantees the
	 *   anchor exists for insertion). Re-cased to match the source.
	 * - Content recommendation: a relevant target with NO natural anchor — never
	 *   linked automatically; carries a suggested phrase for the editor to weigh.
	 *
	 * @param mixed  $response  Parsed AI response.
	 * @param array  $local     Local (anchor-bearing) candidates.
	 * @param array  $semantic  Semantic candidates.
	 * @param string $content   Trimmed article text.
	 * @return array{items:array,recommendations:array}
	 */
	private static function sanitize_link_response( $response, array $local, array $semantic, $content ) {
		$titles   = [];
		$haystack = (string) $content;
		foreach ( $local as $c ) {
			if ( ! empty( $c['url'] ) ) {
				$titles[ $c['url'] ] = isset( $c['title'] ) ? (string) $c['title'] : '';
				if ( ! empty( $c['context'] ) ) {
					$haystack .= ' ' . $c['context'];
				}
			}
		}
		// Normalize whitespace (incl. non-breaking spaces common in page-builder
		// content) so an anchor with plain spaces still matches the source.
		$haystack = preg_replace( '/\s+/u', ' ', str_replace( "\xC2\xA0", ' ', $haystack ) );
		foreach ( $semantic as $c ) {
			if ( ! empty( $c['url'] ) ) {
				$titles[ $c['url'] ] = isset( $c['title'] ) ? (string) $c['title'] : '';
			}
		}

		$raw_items = is_array( $response ) && ! empty( $response['items'] ) && is_array( $response['items'] ) ? $response['items'] : [];
		$raw_recs  = is_array( $response ) && ! empty( $response['recommendations'] ) && is_array( $response['recommendations'] ) ? $response['recommendations'] : [];

		/**
		 * Minimum AI relevance score (0-100) a suggestion must have. The AI is the
		 * authority on relevance; anything it scores below this is dropped.
		 *
		 * @param int $min Minimum relevance (default 70).
		 */
		$min_relevance = (int) apply_filters( 'rtrs_internal_link_min_relevance', 70 );

		$items = [];
		$seen  = [];
		foreach ( $raw_items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			// AI relevance gate (absent score → keep, so it never zeroes results).
			if ( isset( $item['relevance'] ) && (int) $item['relevance'] < $min_relevance ) {
				continue;
			}
			$anchor = isset( $item['anchor'] ) ? trim( wp_strip_all_tags( (string) $item['anchor'] ) ) : '';
			$url    = isset( $item['url'] ) ? esc_url_raw( trim( (string) $item['url'] ) ) : '';
			$reason = isset( $item['reason'] ) ? trim( wp_strip_all_tags( (string) $item['reason'] ) ) : '';
			if ( '' === $anchor || '' === $url || ! isset( $titles[ $url ] ) || isset( $seen[ $url ] ) ) {
				continue;
			}
			// Anchor must exist verbatim in the article/context (anti-hallucination),
			// compared with normalized whitespace so nbsp/spacing never blocks it.
			$anchor_ws = preg_replace( '/\s+/u', ' ', str_replace( "\xC2\xA0", ' ', $anchor ) );
			$pos       = stripos( $haystack, $anchor_ws );
			if ( false === $pos ) {
				continue;
			}
			$anchor       = substr( $haystack, $pos, strlen( $anchor_ws ) );
			$seen[ $url ] = true;
			$items[]      = [
				'anchor' => sanitize_text_field( $anchor ),
				'url'    => $url,
				'title'  => sanitize_text_field( $titles[ $url ] ),
				'reason' => sanitize_text_field( $reason ),
			];
			if ( count( $items ) >= 6 ) {
				break;
			}
		}

		$recommendations = [];
		foreach ( $raw_recs as $rec ) {
			if ( ! is_array( $rec ) ) {
				continue;
			}
			// AI relevance gate — the AI decides which pages are truly relevant.
			if ( isset( $rec['relevance'] ) && (int) $rec['relevance'] < $min_relevance ) {
				continue;
			}
			$url      = isset( $rec['url'] ) ? esc_url_raw( trim( (string) $rec['url'] ) ) : '';
			$phrase   = isset( $rec['phrase'] ) ? trim( wp_strip_all_tags( (string) $rec['phrase'] ) ) : '';
			$sentence = isset( $rec['sentence'] ) ? trim( wp_strip_all_tags( (string) $rec['sentence'] ) ) : '';
			$reason   = isset( $rec['reason'] ) ? trim( wp_strip_all_tags( (string) $rec['reason'] ) ) : '';
			// Only relevant targets with a suggested phrase, never already a link.
			if ( '' === $url || '' === $phrase || ! isset( $titles[ $url ] ) || isset( $seen[ $url ] ) ) {
				continue;
			}
			$seen[ $url ]      = true;
			$recommendations[] = [
				'url'      => $url,
				'title'    => sanitize_text_field( $titles[ $url ] ),
				'phrase'   => sanitize_text_field( $phrase ),
				'sentence' => sanitize_text_field( $sentence ),
				'reason'   => sanitize_text_field( $reason ),
			];
			if ( count( $recommendations ) >= 3 ) {
				break;
			}
		}

		return [ 'items' => $items, 'recommendations' => $recommendations ];
	}

	/**
	 * Validate and clean the AI internal-link items.
	 *
	 * Only links whose URL is in the candidate whitelist survive (guards against
	 * hallucinated or off-site URLs); the page title is taken from the candidate,
	 * not the model. Deduplicated by URL and capped.
	 *
	 * @param mixed  $response   Parsed AI response (expects [ 'items' => [...] ]).
	 * @param array  $candidates Candidate pages from InternalLinkCandidates::discover().
	 * @param string $mode       'sitemap' | 'wp_query'.
	 * @return array<int,array{anchor:string,url:string,title:string,reason:string}>
	 */
	private static function sanitize_link_items( $response, array $candidates, $mode = 'wp_query' ) {
		$raw = is_array( $response ) && ! empty( $response['items'] ) && is_array( $response['items'] ) ? $response['items'] : [];
		if ( empty( $raw ) ) {
			return [];
		}

		// URL whitelist + per-URL title/context lookups.
		$allowed  = [];
		$contexts = [];
		foreach ( $candidates as $candidate ) {
			if ( empty( $candidate['url'] ) ) {
				continue;
			}
			$allowed[ $candidate['url'] ]  = isset( $candidate['title'] ) ? (string) $candidate['title'] : '';
			$contexts[ $candidate['url'] ] = isset( $candidate['context'] ) ? (string) $candidate['context'] : '';
		}

		$is_sitemap = ( 'sitemap' === $mode );
		$items      = [];
		$seen       = [];
		foreach ( $raw as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$anchor = isset( $item['anchor'] ) ? trim( wp_strip_all_tags( (string) $item['anchor'] ) ) : '';
			$url    = isset( $item['url'] ) ? esc_url_raw( trim( (string) $item['url'] ) ) : '';
			$reason = isset( $item['reason'] ) ? trim( wp_strip_all_tags( (string) $item['reason'] ) ) : '';

			// URL must be whitelisted, one link per destination, non-empty anchor.
			if ( '' === $anchor || '' === $url || ! isset( $allowed[ $url ] ) || isset( $seen[ $url ] ) ) {
				continue;
			}

			// Sitemap mode: the AI must explicitly keep it, and the anchor must be
			// a verbatim substring of that candidate's context — guards against
			// hallucination and guarantees the anchor exists for insertion. The
			// anchor is re-cased to exactly how it appears in the context.
			if ( $is_sitemap ) {
				if ( array_key_exists( 'keep', $item ) && ! filter_var( $item['keep'], FILTER_VALIDATE_BOOLEAN ) ) {
					continue;
				}
				$context = isset( $contexts[ $url ] ) ? $contexts[ $url ] : '';
				$pos     = ( '' !== $context ) ? stripos( $context, $anchor ) : false;
				if ( false === $pos ) {
					continue;
				}
				$anchor = substr( $context, $pos, strlen( $anchor ) );
			}

			$seen[ $url ] = true;
			$items[]      = [
				'anchor' => sanitize_text_field( $anchor ),
				'url'    => $url,
				'title'  => sanitize_text_field( $allowed[ $url ] ),
				'reason' => sanitize_text_field( $reason ),
			];

			if ( count( $items ) >= 6 ) {
				break;
			}
		}

		return $items;
	}

	/**
	 * Normalize a heading for matching (lower case, collapsed whitespace).
	 *
	 * @param string $heading Heading text.
	 * @return string
	 */
	private static function normalize_heading( $heading ) {
		$heading = trim( preg_replace( '/\s+/', ' ', (string) $heading ) );
		return function_exists( 'mb_strtolower' ) ? mb_strtolower( $heading ) : strtolower( $heading );
	}

	/**
	 * Rewrite a too-long paragraph or sentence into a tighter version.
	 *
	 * Suggestion-only: takes the source text and returns a shorter rewrite.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @param string           $target  'tighten_paragraph' | 'shorten_sentence'.
	 * @return \WP_REST_Response|\WP_Error
	 */
	private static function suggest_aeo_rewrite( $request, $target ) {
		$source = isset( $request['source'] ) ? trim( wp_strip_all_tags( (string) $request['source'] ) ) : '';
		if ( '' === $source ) {
			return new \WP_Error( 'no_source', __( 'Nothing to rewrite. Try again after saving.', 'review-schema-pro' ), [ 'status' => 400 ] );
		}

		$client   = new AIClient();
		$response = $client->complete( self::suggest_system_prompt( $target ), wp_json_encode( [ 'source' => $source ] ) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$proposal = is_array( $response ) && isset( $response['value'] ) ? trim( (string) $response['value'] ) : '';
		if ( '' === $proposal ) {
			return new \WP_Error( 'empty_proposal', __( 'The AI did not return a usable suggestion. Try again.', 'review-schema-pro' ), [ 'status' => 502 ] );
		}

		return rest_ensure_response(
			[
				'target'   => $target,
				'proposal' => sanitize_textarea_field( $proposal ),
				'original' => $source,
			]
		);
	}

	/**
	 * Generate snippet / FAQ structure text (heading, list, table, steps, Q&A)
	 * from the live content. Suggestion-only: returns text for the editor to copy.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @param string           $target  snippet_heading|snippet_list|snippet_table|snippet_steps|faq_pairs.
	 * @return \WP_REST_Response|\WP_Error
	 */
	private static function suggest_aeo_generate( $request, $target ) {
		$post_id = absint( $request['post_id'] );
		$html    = isset( $request['content'] ) ? (string) $request['content'] : '';
		$context = new AnalysisContext( $post_id, '' !== $html ? $html : null );
		$content = trim( wp_trim_words( $context->article_text(), 220, '' ) );

		if ( '' === $content ) {
			return new \WP_Error( 'no_content', __( 'Add some content first, then generate.', 'review-schema-pro' ), [ 'status' => 400 ] );
		}

		$keyword = trim( (string) SeoMeta::get_focus_keyword( $post_id ) );

		$client   = new AIClient();
		$response = $client->complete(
			self::suggest_system_prompt( $target ),
			wp_json_encode(
				[
					'content'       => $content,
					'title'         => trim( wp_strip_all_tags( (string) get_the_title( $post_id ) ) ),
					'focus_keyword' => '' !== $keyword ? $keyword : null,
				]
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$proposal = is_array( $response ) && isset( $response['value'] ) ? trim( (string) $response['value'] ) : '';
		if ( '' === $proposal ) {
			return new \WP_Error( 'empty_proposal', __( 'The AI did not return a usable suggestion. Try again.', 'review-schema-pro' ), [ 'status' => 502 ] );
		}

		return rest_ensure_response(
			[
				'target'   => $target,
				'proposal' => sanitize_textarea_field( $proposal ),
			]
		);
	}

	/**
	 * Save an accepted value to the active SEO plugin's meta, then re-analyze.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function ai_apply( $request ) {
		$elementor_guard = self::elementor_guard( $request );
		if ( is_wp_error( $elementor_guard ) ) {
			return $elementor_guard;
		}

		$post_id = absint( $request['post_id'] );
		$target  = self::normalize_target( $request['target'] );
		$value   = isset( $request['value'] ) ? trim( (string) $request['value'] ) : '';

		// Only the meta-field targets persist server-side here. The first-paragraph
		// fix is applied to the live editor content and re-scored via the SEO route.
		if ( 'title' !== $target && 'meta' !== $target && 'focus_keyword' !== $target ) {
			return new \WP_Error( 'invalid_target', __( 'Unsupported target.', 'review-schema-pro' ), [ 'status' => 400 ] );
		}

		if ( 'focus_keyword' === $target ) {
			$value = sanitize_text_field( $value );
			if ( '' === $value ) {
				return new \WP_Error( 'empty_value', __( 'No focus keyword to save.', 'review-schema-pro' ), [ 'status' => 400 ] );
			}
			$saved_to = self::save_focus_keyword( $post_id, $value );

			return rest_ensure_response(
				[
					'post_id'  => $post_id,
					'saved_to' => $saved_to,
					'seo'      => SeoAnalyzer::analyze( $post_id ),
				]
			);
		}

		$value    = 'title' === $target ? sanitize_text_field( $value ) : sanitize_textarea_field( $value );
		$also     = ! empty( $request['also_post_title'] );
		$saved_to = self::save_value( $post_id, $target, $value, $also );

		return rest_ensure_response(
			[
				'post_id'  => $post_id,
				'saved_to' => $saved_to,
				'seo'      => SeoAnalyzer::analyze( $post_id ),
			]
		);
	}

	/**
	 * Write the value to the active SEO plugin's meta (or the plugin's own).
	 *
	 * For a title with no SEO plugin active, the real post title is updated too,
	 * since that is the only visible title and the value the analyzer scores.
	 * When an SEO plugin is active, the post title is left alone unless the
	 * caller opts in via $also_post_title.
	 *
	 * @param int    $post_id         Post ID.
	 * @param string $target          'title' | 'meta'.
	 * @param string $value           Sanitized value.
	 * @param bool   $also_post_title Also update the real post title (title target only).
	 * @return string Destination key: 'yoast' | 'rank_math' | 'post_title' | 'plugin'.
	 */
	private static function save_value( $post_id, $target, $value, $also_post_title = false ) {
		$is_title = 'title' === $target;

		if ( SeoHooks::isYoastActive() ) {
			update_post_meta( $post_id, $is_title ? '_yoast_wpseo_title' : '_yoast_wpseo_metadesc', $value );
			if ( $is_title && $also_post_title ) {
				self::maybe_update_post_title( $post_id, $value );
			}
			return 'yoast';
		}

		if ( SeoHooks::isRankMathActive() ) {
			update_post_meta( $post_id, $is_title ? 'rank_math_title' : 'rank_math_description', $value );
			if ( $is_title && $also_post_title ) {
				self::maybe_update_post_title( $post_id, $value );
			}
			return 'rank_math';
		}

		if ( defined( 'AIOSEO_VERSION' ) ) {
			// AIOSEO v4 stores SEO data in its own table; update that and the
			// legacy post meta the report reads.
			update_post_meta( $post_id, $is_title ? '_aioseo_title' : '_aioseo_description', $value );
			self::maybe_update_aioseo( $post_id, $target, $value );
			if ( $is_title && $also_post_title ) {
				self::maybe_update_post_title( $post_id, $value );
			}
			return 'aioseo';
		}

		if ( defined( 'SEOPRESS_VERSION' ) ) {
			update_post_meta( $post_id, $is_title ? '_seopress_titles_title' : '_seopress_titles_desc', $value );
			if ( $is_title && $also_post_title ) {
				self::maybe_update_post_title( $post_id, $value );
			}
			return 'seopress';
		}

		if ( function_exists( 'genesis' ) || defined( 'PARENT_THEME_VERSION' ) ) {
			update_post_meta( $post_id, $is_title ? '_genesis_title' : '_genesis_description', $value );
			if ( $is_title && $also_post_title ) {
				self::maybe_update_post_title( $post_id, $value );
			}
			return 'genesis';
		}

		// No SEO plugin active.
		if ( $is_title ) {
			update_post_meta( $post_id, '_rtrs_seo_title', $value );
			self::maybe_update_post_title( $post_id, $value );
			return 'post_title';
		}

		update_post_meta( $post_id, '_rtrs_seo_desc', $value );
		return 'plugin';
	}

	/**
	 * Persist a title/description to AIOSEO's own storage (v4 custom table).
	 *
	 * Post meta alone does not reflect in AIOSEO v4, which reads from its
	 * `aioseo_posts` table via the Post model. Failures degrade silently since
	 * the legacy post meta has already been written by the caller.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $target  'title' | 'meta'.
	 * @param string $value   Sanitized value.
	 * @return void
	 */
	private static function maybe_update_aioseo( $post_id, $target, $value ) {
		if ( ! class_exists( '\AIOSEO\Plugin\Common\Models\Post' ) ) {
			return;
		}

		try {
			$aioseo_post = \AIOSEO\Plugin\Common\Models\Post::getPost( $post_id );
			if ( ! $aioseo_post ) {
				return;
			}
			if ( 'title' === $target ) {
				$aioseo_post->title = $value;
			} else {
				$aioseo_post->description = $value;
			}
			$aioseo_post->save();
		} catch ( \Throwable $e ) {
			// Post meta fallback already written; ignore AIOSEO model errors.
		}
	}

	/**
	 * Save an AI-suggested focus keyword to the active SEO plugin's meta.
	 *
	 * Writes to Yoast / Rank Math when active (so it shows in their UI), else to
	 * the plugin's own `_rtrs_focus_keyword` meta used by the Keyword Coverage step.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $value   Sanitized focus keyword.
	 * @return string Destination key: 'yoast' | 'rank_math' | 'plugin'.
	 */
	private static function save_focus_keyword( $post_id, $value ) {
		if ( SeoHooks::isYoastActive() ) {
			update_post_meta( $post_id, '_yoast_wpseo_focuskw', $value );
			return 'yoast';
		}

		if ( SeoHooks::isRankMathActive() ) {
			update_post_meta( $post_id, 'rank_math_focus_keyword', $value );
			return 'rank_math';
		}

		if ( defined( 'AIOSEO_VERSION' ) ) {
			self::save_aioseo_focus_keyword( $post_id, $value );
			return 'aioseo';
		}

		if ( defined( 'SEOPRESS_VERSION' ) ) {
			// SEOPress reads the focus keyword from its Content Analysis target
			// keyword meta (see SeoMeta::get_focus_keyword), so write there.
			update_post_meta( $post_id, '_seopress_analysis_target_kw', $value );
			return 'seopress';
		}

		update_post_meta( $post_id, '_rtrs_focus_keyword', $value );
		return 'plugin';
	}

	/**
	 * Persist a focus keyword to AIOSEO's storage.
	 *
	 * AIOSEO v4 keeps keyphrases in its own `aioseo_posts` table (JSON
	 * `keyphrases` column), which drives the Focus Keyword metabox field; the
	 * legacy `_aioseo_keyphrases` post meta is written too so the plugin's own
	 * reader stays in sync. Existing additional keyphrases are preserved.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $value   Sanitized focus keyword.
	 * @return void
	 */
	private static function save_aioseo_focus_keyword( $post_id, $value ) {
		$existing   = get_post_meta( $post_id, '_aioseo_keyphrases', true );
		$data       = is_string( $existing ) ? json_decode( $existing, true ) : $existing;
		$data       = is_array( $data ) ? $data : [];
		$additional = isset( $data['additional'] ) && is_array( $data['additional'] ) ? $data['additional'] : [];

		$keyphrases = [
			'focus'      => [
				'keyphrase' => $value,
				'score'     => 0,
				'analysis'  => new \stdClass(),
			],
			'additional' => $additional,
		];

		update_post_meta( $post_id, '_aioseo_keyphrases', wp_json_encode( $keyphrases ) );

		if ( ! class_exists( '\AIOSEO\Plugin\Common\Models\Post' ) ) {
			return;
		}

		try {
			$aioseo_post = \AIOSEO\Plugin\Common\Models\Post::getPost( $post_id );
			if ( ! $aioseo_post ) {
				return;
			}
			$aioseo_post->keyphrases = json_decode( wp_json_encode( $keyphrases ) );
			$aioseo_post->save();
		} catch ( \Throwable $e ) {
			// Post meta fallback already written; ignore AIOSEO model errors.
		}
	}

	/**
	 * Update the real post title when it differs from the given value.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $value   New post title.
	 * @return void
	 */
	private static function maybe_update_post_title( $post_id, $value ) {
		$post = get_post( $post_id );
		if ( $post instanceof \WP_Post && (string) $post->post_title !== $value ) {
			wp_update_post(
				[
					'ID'         => $post_id,
					'post_title' => $value,
				],
				true
			);
		}
	}

	/**
	 * System prompt for an "Apply with AI" generation.
	 *
	 * @param string $target 'title' | 'meta' | 'first_paragraph' | 'subheading' | 'keyword_density'.
	 * @return string
	 */
	private static function suggest_system_prompt( $target ) {
		if ( 'keyword_density' === $target ) {
			return implode(
				' ',
				[
					'You are an expert SEO copywriter. Rewrite the paragraph in the provided JSON',
					'(current_paragraph, content, focus_keyword) so the focus keyword no longer repeats excessively:',
					'replace some exact keyword occurrences with natural synonyms, pronouns, or rephrasing.',
					'Preserve the original meaning, tone and roughly the same length, and keep at least one natural use',
					'of the focus keyword for SEO. Return a single paragraph of plain text with no markup or surrounding',
					'quotation marks. Respond with STRICT JSON only, no prose: {"value": "<the paragraph>"}.',
				]
			);
		}

		if ( 'focus_keyword' === $target ) {
			return implode(
				' ',
				[
					'You are an expert SEO strategist. Read the page described by the provided JSON',
					'(current_title, content) and choose the single best focus keyword (keyphrase) that the',
					'page should rank for. Return a concise, natural search phrase of 1–4 words that a real',
					'user would type into Google — the main topic of the page, not a full sentence or question.',
					'Use lower case unless it is a proper noun, no quotation marks, no punctuation, no hashtags.',
					'Base it strictly on the actual content; do not invent topics the page does not cover.',
					'Respond with STRICT JSON only, no prose: {"value": "<the focus keyword>"}.',
				]
			);
		}

		if ( 'subheading' === $target ) {
			return implode(
				' ',
				[
					'You are an expert SEO copywriter. Rewrite the subheading of the page described by the provided JSON',
					'(current_subheading, content, focus_keyword) so it includes the focus keyword naturally.',
					'Keep it a concise, descriptive heading (not a full sentence), preserve the original intent, and return',
					'a single line of plain text with no markup or surrounding quotation marks.',
					'If "current_subheading" is empty, write a short, relevant subheading that includes the focus keyword.',
					'Respond with STRICT JSON only, no prose: {"value": "<the subheading>"}.',
				]
			);
		}

		if ( 'section_lead' === $target ) {
			return implode(
				' ',
				[
					'You are an expert SEO/AEO copywriter. Using the provided JSON (heading, current_lead, section_body),',
					'write the opening paragraph that should directly answer the heading. It MUST be a single,',
					'self-contained paragraph of 20 to 75 words that answers the heading first, before any supporting detail.',
					'Name the subject explicitly in the first sentence — do NOT start with a bare pronoun such as "It", "This",',
					'"They", or "These". Base it strictly on section_body; do not invent facts. Preserve the original tone.',
					'Return a single paragraph of plain text with no markup or surrounding quotation marks.',
					'Respond with STRICT JSON only, no prose: {"value": "<the paragraph>"}.',
				]
			);
		}

		if ( 'internal_links_context' === $target ) {
			return implode(
				' ',
				[
						'You are an expert SEO editor deciding internal links for the article in "content". You are given two lists:',
						'"link_candidates" (each has "url", "title", and "context" — a sentence from the article where a related phrase',
						'already appears) and "related_candidates" (each has "url", "title" and a short "excerpt" — pages that may be topically relevant).',
						'Produce TWO separate result types.',
						'(1) items = link opportunities where a NATURAL anchor ALREADY EXISTS: for a link_candidate pick "anchor" as a natural',
						'phrase that is a VERBATIM substring of its "context"; for a related_candidate include it ONLY if a natural phrase for it',
						'is a VERBATIM substring of "content". Copy the anchor exactly — never invent, alter, reorder, or force the whole slug.',
						'(2) recommendations = related_candidates that are SPECIFICALLY relevant to this article but have NO natural anchor present.',
						'STRICT relevance test: include a page ONLY if it covers the SAME specific subject or a direct sub-topic of THIS article.',
						'A shared broad platform, brand, or category is NOT enough — e.g. for an article about "schema markup", do NOT recommend a',
						'page about "hiding prices" or "shipping" merely because both mention WooCommerce. If you cannot honestly connect the page',
						'to what THIS article is actually about, REJECT it. For each kept page, based ONLY on the current "content", produce:',
						'"phrase" = a short topic to mention; "sentence" = a natural, ready-to-add sentence (about 15-30 words) that flows with',
						'THIS article\'s actual subject and mentions that topic (the editor pastes it in, then links it) — do not invent facts, do',
						'NOT introduce an off-topic tangent; and "reason" = why it is relevant to THIS article specifically. Never reuse a url or',
						'output one in both lists. Return AT MOST 3 recommendations, and prefer an EMPTY list over any loosely-related page.',
						'For EVERY item AND recommendation, add "relevance": an INTEGER 0-100 = how specifically the page matches THIS article\'s',
						'exact subject (same specific topic = 90-100; direct sub-topic = 75-89; merely same broad category/platform = 30 or less).',
						'Be honest and strict; you MUST omit anything you would score below 70. Respond with STRICT JSON only, no prose:',
						'{"items":[{"url":"","anchor":"<verbatim substring>","reason":"<one sentence>","relevance":0}],"recommendations":[{"url":"","phrase":"<topic>","sentence":"<ready-to-add sentence based on the content>","reason":"<why relevant>","relevance":0}]}.',
				]
			);
		}

		if ( 'internal_links' === $target ) {
			return implode(
				' ',
				[
					'You are an expert SEO editor improving internal linking. Using the provided JSON',
					'(content, title, focus_keyword, candidate_pages), suggest 3 to 6 internal links FROM this article',
					'TO the most relevant pages. You MUST only use a "url" that appears verbatim in candidate_pages — never',
					'invent a URL, and never link the page to itself. For each suggestion pick a short, descriptive anchor',
					'phrase (2-6 words) that appears verbatim in "content" (so it can be linked in place) — never generic',
					'text like "click here" or "read more". Choose the single most topically relevant candidate for each',
					'anchor and do not reuse the same url twice. Respond with STRICT JSON only, no prose, in exactly this',
					'shape: {"items":[{"anchor":"<phrase from content>","url":"<url from candidate_pages>","reason":"<one short sentence>"}]}.',
				]
			);
		}

		if ( 'tighten_paragraph' === $target ) {
			return implode(
				' ',
				[
					'You are an expert AEO copywriter. Rewrite the paragraph in the provided JSON (source) so it is a concise,',
					'answer-first paragraph of 90 words or fewer. Preserve the key facts, meaning and tone; remove filler and',
					'redundancy. Return a single paragraph of plain text with no markup or surrounding quotation marks.',
					'Respond with STRICT JSON only, no prose: {"value": "<the paragraph>"}.',
				]
			);
		}

		if ( 'shorten_sentence' === $target ) {
			return implode(
				' ',
				[
					'You are an expert AEO copywriter. Rewrite the overly long sentence in the provided JSON (source) as two or',
					'three short, conversational sentences of about 15-20 words each so a voice assistant can read a clean answer.',
					'Preserve the meaning and tone. Return plain text sentences only, no markup or surrounding quotation marks.',
					'Respond with STRICT JSON only, no prose: {"value": "<the sentences>"}.',
				]
			);
		}

		if ( 'snippet_heading' === $target ) {
			return implode(
				' ',
				[
					'You are an expert AEO copywriter. Based on the provided JSON (content, title, focus_keyword), write ONE',
					'question-style heading (H2) phrased the way a user would ask it, that the content answers. Keep it a concise',
					'question ending with a question mark, no markup or surrounding quotation marks.',
					'Respond with STRICT JSON only, no prose: {"value": "<the heading>"}.',
				]
			);
		}

		if ( 'snippet_list' === $target ) {
			return implode(
				' ',
				[
					'You are an expert AEO copywriter. Based on the provided JSON (content, title, focus_keyword), write a concise',
					'bulleted list of 3-6 items summarizing the key points the content covers, so it is eligible for a list snippet.',
					'Return plain text with one item per line, each starting with "- ". No markup other than the leading hyphens.',
					'Respond with STRICT JSON only, no prose: {"value": "<the list>"}.',
				]
			);
		}

		if ( 'snippet_steps' === $target ) {
			return implode(
				' ',
				[
					'You are an expert AEO copywriter. Based on the provided JSON (content, title, focus_keyword), write a concise',
					'numbered step-by-step list of 3-7 steps for the how-to the content describes, so it is eligible for a list snippet.',
					'Return plain text with one step per line, each starting with its number and a period (e.g. "1. "). No other markup.',
					'Respond with STRICT JSON only, no prose: {"value": "<the steps>"}.',
				]
			);
		}

		if ( 'snippet_table' === $target ) {
			return implode(
				' ',
				[
					'You are an expert AEO copywriter. Based on the provided JSON (content, title, focus_keyword), write a small',
					'comparison table of 2-4 columns and 2-5 rows capturing a comparison the content supports, so it is eligible for',
					'a table snippet. Return it as a GitHub-style Markdown table only (header row, separator row, data rows), no prose.',
					'Respond with STRICT JSON only, no prose: {"value": "<the markdown table>"}.',
				]
			);
		}

		if ( 'faq_pairs' === $target ) {
			return implode(
				' ',
				[
					'You are an expert AEO copywriter. Based on the provided JSON (content, title, focus_keyword), write 2-3',
					'frequently-asked question and answer pairs the content supports. Phrase each question the way users ask it and',
					'answer it directly in 1-2 sentences. Return plain text as "Q: ..." on one line then "A: ..." on the next, with a',
					'blank line between pairs. No markup or surrounding quotation marks.',
					'Respond with STRICT JSON only, no prose: {"value": "<the Q&A pairs>"}.',
				]
			);
		}

		if ( 'first_paragraph' === $target ) {
			return implode(
				' ',
				[
					'You are an expert SEO copywriter. Rewrite the opening paragraph of the page described by the',
					'provided JSON (current_first_paragraph, content, focus_keyword) so it includes the focus keyword',
					'naturally, preferably within the first sentence.',
					'Preserve the original meaning, tone, and roughly the same length; return a single paragraph of plain',
					'text with no markup or surrounding quotation marks.',
					'If "current_first_paragraph" is empty, write a concise, engaging opening paragraph for the content',
					'that includes the focus keyword.',
					'Respond with STRICT JSON only, no prose: {"value": "<the paragraph>"}.',
				]
			);
		}

		$spec = 'title' === $target
			? 'an SEO title of 30–60 characters'
			: 'a meta description of 120–160 characters that MUST NOT exceed 160 characters (count characters, not words; keep it under the limit even if you must shorten it)';

		$keyword_rule = 'title' === $target
			? 'If a non-empty "focus_keyword" is provided in the JSON, you MUST include it verbatim, preferably near the start.'
			: 'If a non-empty "focus_keyword" is provided in the JSON, you MUST include it verbatim (exact wording, no plural, synonym, or reordering) at least once so it reads naturally.';

		return implode(
			' ',
			[
				'You are an expert SEO copywriter. Write ' . $spec . ' for the page described by the',
				'provided JSON (current title, current meta description, content, and focus_keyword).',
				$keyword_rule,
				'Make it clear, compelling, and keyword-relevant; do not use quotation marks around the whole string.',
				'Respond with STRICT JSON only, no prose: {"value": "<the text>"}.',
			]
		);
	}

	/**
	 * Normalize a target to 'title' | 'meta' | 'first_paragraph' | 'subheading' (empty when unsupported).
	 *
	 * @param string $target Raw target.
	 * @return string
	 */
	private static function normalize_target( $target ) {
		$target = strtolower( (string) $target );
		if ( 'title' === $target ) {
			return 'title';
		}
		if ( 'meta' === $target || 'description' === $target ) {
			return 'meta';
		}
		if ( 'first_paragraph' === $target || 'first_para' === $target ) {
			return 'first_paragraph';
		}
		if ( 'subheading' === $target || 'heading' === $target ) {
			return 'subheading';
		}
		if ( 'keyword_density' === $target || 'density' === $target || 'paragraph' === $target ) {
			return 'keyword_density';
		}
		if ( 'section_lead' === $target || 'lead' === $target || 'section' === $target ) {
			return 'section_lead';
		}
		if ( 'internal_links' === $target || 'internal_link' === $target || 'links' === $target ) {
			return 'internal_links';
		}
		if ( 'tighten_paragraph' === $target || 'shorten_sentence' === $target ) {
			return $target;
		}
		if ( in_array( $target, [ 'snippet_heading', 'snippet_list', 'snippet_table', 'snippet_steps', 'faq_pairs' ], true ) ) {
			return $target;
		}
		if ( 'focus_keyword' === $target || 'keyword' === $target || 'focuskw' === $target ) {
			return 'focus_keyword';
		}
		return '';
	}
}
