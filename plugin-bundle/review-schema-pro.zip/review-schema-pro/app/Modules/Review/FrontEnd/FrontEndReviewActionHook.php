<?php

namespace Rtrsp\Modules\Review\FrontEnd;

use Rtrs\Helpers\Functions;
use Rtrs\Modules\Review\Helpers\ReviewFns;
use Rtrsp\Traits\SingletonTrait;

class FrontEndReviewActionHook {

	use SingletonTrait;

	function init() {
		add_action( 'rtrs_after_review_edit_form', [ $this, 'after_review_edit_form' ], 10, 2 );
		add_action( 'rtrs_before_review_comments_list', [ $this, 'before_review_comments_list' ], 10, 2 );
		add_action( 'rtrs_review_form_video_field', [ $this, 'review_form_video_field' ] );
		add_filter( 'rtrs_review_attachment_data', [ $this, 'review_video_attachment_data' ], 10, 2 );
		add_action( 'woocommerce_update_product', [ __CLASS__, 'on_product_save' ], 10, 2 );
		add_action( 'before_delete_post', [ __CLASS__, 'on_product_delete' ] );

		// Pro AJAX handlers.
		add_action( 'wp_ajax_rtrs_review_hightlight', [ $this, 'rtrs_review_hightlight' ] );
		add_action( 'wp_ajax_rtrs_review_helpful', [ $this, 'rtrs_review_helpful' ] );

		// Pro: save highlight & sticky review meta.
		add_action( 'rtrs_review_pro_meta_save', [ $this, 'save_highlight_sticky_meta' ], 10, 2 );

		// Pro: recommendation & anonymous form fields.
		add_action( 'rtrs_review_form_recommendation_field', [ $this, 'review_form_recommendation_field' ] );
		add_action( 'rtrs_review_form_anonymous_field', [ $this, 'review_form_anonymous_field' ] );

		// Pro: edit form fields.
		add_action( 'rtrs_review_edit_form_video_field', [ $this, 'review_edit_form_video_field' ], 10, 3 );
		add_action( 'rtrs_review_edit_form_recommendation_field', [ $this, 'review_edit_form_recommendation_field' ], 10, 3 );
		add_action( 'rtrs_review_edit_form_anonymous_field', [ $this, 'review_edit_form_anonymous_field' ], 10, 3 );

		// Pro: save meta on review edit.
		add_action( 'rtrs_review_edit_pro_meta_save', [ $this, 'save_edit_pro_meta' ] );

		// Pro: sort args for recommended/highlighted.
		add_filter( 'rtrs_review_sort_args', [ $this, 'review_sort_args' ], 10, 2 );
	}

	/**
	 * Render video review form field.
	 *
	 * @param array $p_meta Post meta data.
	 * @return void
	 */
	public function review_form_video_field( $p_meta ) {
		$video_review = ( isset( $p_meta['video_review'] ) && $p_meta['video_review'][0] == '1' );
		if ( ! $video_review ) {
			return;
		}
		// Guard against free/pro version skew: if pro is updated before the free
		// plugin ships canUploadMedia(), fall back to the previous behaviour
		// (login required) instead of fataling on an undefined method.
		$can_upload_media = method_exists( ReviewFns::class, 'canUploadMedia' )
			? ReviewFns::canUploadMedia()
			: is_user_logged_in();
		?>
		<div class="rtrs-video-media-groups">
			<div class="rtrs-form-group rtrs-media-form-group rtrs-hide-reply">
				<div class="rtrs-button-label">
					<label class="rtrs-input-video-label"><?php esc_html_e( 'Video', 'review-schema-pro' ); ?></label>
				</div>

				<div class="rtrs-video-source-selector">
					<select name="rt_video_source" id="rtrs-video-source" class="rtrs-form-control">
						<option value="self"><?php esc_html_e( 'Hosted Video', 'review-schema-pro' ); ?></option>
						<option value="external" <?php echo ! $can_upload_media ? 'selected' : ''; ?>><?php esc_html_e( 'External Video', 'review-schema-pro' ); ?></option>
					</select>
				</div>

				<?php if ( $can_upload_media ) { ?>
					<div class="rtrs-source-video">
						<div class="rtrs-multimedia-upload">
							<div class="rtrs-upload-box" id="rtrs-upload-box-video">
								<span><?php esc_html_e( 'Choose Video', 'review-schema-pro' ); ?></span>
							</div>
						</div>
						<input type="file" id="rtrs-video" accept="video/*" style="display:none">
						<div class="rtrs-video-error"></div>
					</div>
				<?php } else { ?>
					<div class="rtrs-source-video" style="display:none;">
						<p class="rtrs-login-message"><?php printf( wp_kses( __( 'Please <a href="%s">log in</a> to upload videos.', 'review-schema-pro' ), [ 'a' => [ 'href' => [] ] ] ), esc_url( wp_login_url( get_permalink() ) ) ); ?></p>
					</div>
				<?php } ?>
			</div>

			<?php if ( $can_upload_media ) { ?>
				<div class="rtrs-form-group rtrs-hide-reply">
					<div class="rtrs-preview-videos"></div>
				</div>
			<?php } ?>

			<div class="rtrs-form-group rtrs-source-external-video rtrs-hide-reply" <?php echo $can_upload_media ? 'style="display:none;"' : ''; ?>>
				<label class="rtrs-input-label" for="rt_external_video"><?php esc_html_e( 'External Video Link', 'review-schema-pro' ); ?></label>
				<input id="rt_external_video" class="rtrs-form-control" placeholder="https://www.youtube.com/watch?v=668nUCeBHyY" name="rt_external_video" type="url">
			</div>
		</div>
		<?php
	}

	/**
	 * Add video data to review attachment array.
	 *
	 * SECURITY: video IDs come from the review form and are attacker-controlled.
	 * absint() is a type cast, not authorization — it accepts any existing Media
	 * Library ID, and the free plugin's All Reviews "Delete Permanently" action
	 * consumes this array, so an unvalidated ID here becomes a destructive
	 * primitive. Validation and review binding are owned by the free plugin
	 * (ReviewFns) so a single rule governs images and videos alike; this filter
	 * never re-implements it.
	 *
	 * Fails closed: when the free helper is unavailable (version skew), the
	 * submitted IDs are dropped rather than trusted.
	 *
	 * @param array $attachments Existing attachment data.
	 * @param array $context     Validation context supplied by the free plugin.
	 * @return array Modified attachment data with video info.
	 */
	public function review_video_attachment_data( $attachments, $context = [] ) {
		if ( ! is_array( $attachments ) ) {
			$attachments = [];
		}

		// sanitize_key() calls strtolower(), which is a TypeError on an array, and
		// its own is_scalar() guard postdates the declared minimum WordPress. A
		// guest POSTing `rt_video_source[]=self` would otherwise fatal the request.
		// The free plugin ships sanitizeRequestKey() for exactly this; fall back to
		// a local scalar guard under version skew, matching the style used above.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Runs inside the free plugin's already nonce-verified review save/edit flow.
		$raw_video_source = isset( $_POST['rt_video_source'] ) ? wp_unslash( $_POST['rt_video_source'] ) : '';
		$video_source     = method_exists( ReviewFns::class, 'sanitizeRequestKey' )
			? ReviewFns::sanitizeRequestKey( $raw_video_source )
			: ( is_scalar( $raw_video_source ) ? sanitize_key( $raw_video_source ) : '' );

		if ( 'self' === $video_source ) {
			// Both helpers are required. Guarding only one would turn version
			// skew into a fatal error instead of a safe drop.
			if ( ! method_exists( ReviewFns::class, 'sanitizeReviewAttachmentIds' )
				|| ! method_exists( ReviewFns::class, 'getStoredAttachmentValues' ) ) {
				return $attachments;
			}

			// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Each value is validated and cast by ReviewFns::sanitizeReviewAttachmentIds().
			$submitted = isset( $_POST['rt_attachment']['videos'] ) ? wp_unslash( $_POST['rt_attachment']['videos'] ) : null;

			$context = is_array( $context ) ? $context : [];
			$result  = ReviewFns::sanitizeReviewAttachmentIds(
				$submitted,
				[
					'comment_id' => isset( $context['comment_id'] ) ? absint( $context['comment_id'] ) : 0,
					'preserve'   => ReviewFns::getStoredAttachmentValues(
						isset( $context['preserve'] ) ? $context['preserve'] : [],
						'videos'
					),
					'allowed'    => ! isset( $context['video_allowed'] ) || (bool) $context['video_allowed'],
				]
			);

			// method_exists() proves a name, not a return shape — check both.
			if ( is_array( $result ) && ! empty( $result['ids'] ) ) {
				$attachments['videos']       = $result['ids'];
				$attachments['video_source'] = 'self';
			}
		} elseif ( 'external' === $video_source ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			if ( ! empty( $_POST['rt_external_video'] ) ) {
				$external_url = esc_url_raw( wp_unslash( $_POST['rt_external_video'] ) );
				if ( filter_var( $external_url, FILTER_VALIDATE_URL ) && preg_match( '/^https?:\/\//i', $external_url ) ) {
					$attachments['videos']       = [ $external_url ];
					$attachments['video_source'] = 'external';
				}
			}
		}

		return $attachments;
	}

	/**
	 * Undocumented function
	 *
	 * @param [type] $p_meta Metabox.
	 * @param [type] $comment Current Comment
	 * @return void
	 */
	public function after_review_edit_form( $p_meta, $comment ) {
		?>
		<?php

		$video_review   = ( isset( $p_meta['video_review'] ) && $p_meta['video_review'][0] == '1' );
		$get_attachment = get_comment_meta( $comment->comment_ID, 'rt_attachment', true );
		if ( $video_review && isset( $get_attachment['videos'] ) ) {
			?>
			<tr>
				<td class="first"><label for="rt_video"><?php esc_html_e( 'Video', 'review-schema-pro' ); ?></label></td>
				<td>
					<div class="rtrs-review-item-media">
					<?php
					$video_source = isset( $get_attachment['video_source'] ) ? $get_attachment['video_source'] : 'self';
					$self_video   = $video_source === 'self';
					foreach ( $get_attachment['videos'] as $video ) {
						?>
							<div class="rtrs-media-item rtrs-media-video rtrs-preview-videos">
								<?php
								$youtube_video_id = '';
								if ( ! $self_video ) {
									$pattern = '#^(?:https?://)?(?:www\.)?(?:youtu\.be/|youtube\.com(?:/embed/|/v/|/watch\?v=|/watch\?.+&v=))([\w-]{11})(?:.+)?$#x';
									preg_match( $pattern, $video, $matches );
									$youtube_video_id = ( isset( $matches[1] ) ) ? $matches[1] : '';
								}
								$image_url = $self_video ? Functions::get_default_placeholder_url() : 'https://img.youtube.com/vi/' . $youtube_video_id . '/default.jpg';

								$video_url = $self_video ? wp_get_attachment_url( $video ) : 'https://www.youtube.com/embed/' . $youtube_video_id;
								?>
								<div class="rtrs-preview-video">
								<div style="display:none;">
									<select name="rt_video_source" id="rtrs-video-source" class="rtrs-form-control">
										<option <?php echo esc_attr( ! $self_video ? 'selected' : '' ); ?> value="external"><?php esc_html_e( 'External Video', 'review-schema-pro' ); ?></option>
										<option <?php echo esc_attr( $self_video ? 'selected' : '' ); ?> value="self"><?php esc_html_e( 'Hosted Video', 'review-schema-pro' ); ?></option>
									</select> 
								</div>
								
								<?php if ( $self_video ) { ?>
									<input type="hidden" name="rt_attachment[videos][]" value="<?php echo absint( $video ); ?>">
								<?php } else { ?>
									<input id="rt_external_video" class="rtrs-form-control" placeholder="<?php esc_attr_e( 'https://www.youtube.com/watch?v=668nUCeBHyY', 'review-schema-pro' ); ?>" name="rt_external_video" type="hidden" value="<?php echo esc_url( $video_url ); ?>">
								<?php } ?>
								
								<!-- .rtrs-preview-videos .rtrs-preview-video .rtrs-file-remove -->
								<a target="_blank" href="<?php echo esc_url( $video_url ); ?>"  class="rtrs-video-icon rtrs-play-self-video">
								<span class="name">
									<img src="<?php echo esc_url( $image_url ); ?>" style="width: 100%;" alt="<?php esc_attr_e( 'SchemaEngine AI', 'review-schema-pro' ); ?>">
								</span> 
								<i class="rtrs-play dashicons dashicons-controls-play"></i></a>
								<button class="rtrs-file-remove" data-id="<?php echo absint( $video ); ?>">x</button>
								</div> 
							</div>
						<?php
					}
					?>
					</div>
				</td>
			</tr>
			<?php
		}

		$highlight_review = ( isset( $p_meta['highlight_review'] ) && $p_meta['highlight_review'][0] == '1' );
		$sticky_review    = ( isset( $p_meta['sticky_review'] ) && $p_meta['sticky_review'][0] == '1' );
		if ( $highlight_review ) {
			?>
			<tr> 
				<td class="first"><label for="rt_highlight"><?php esc_html_e( 'Highlight?', 'review-schema-pro' ); ?></label></td>
				<td><input type="checkbox" 
				<?php
				if ( get_comment_meta( $comment->comment_ID, 'rt_highlight', true ) ) {
					echo 'checked';}
				?>
				name="rt_highlight" id="rt_highlight"></td>
			</tr>
			<?php
		}
		if ( $sticky_review ) {
			?>
			<tr> 
				<td class="first"><label for="rt_sticky_review"><?php esc_html_e( 'Sticky Review?', 'review-schema-pro' ); ?></label></td>
				<td><input type="checkbox" 
				<?php
				if ( get_comment_meta( $comment->comment_ID, 'rt_sticky_review', true ) ) {
					echo 'checked';}
				?>
				name="rt_sticky_review" id="rt_sticky_review"></td>
			</tr>
			<?php
		}
	}

	/**
	 * Undocumented function
	 *
	 * @param [type] $p_meta Metabox.
	 * @param [type] $comment Current Comment
	 * @return void
	 */
	public function before_review_comments_list( $p_meta, $post_id ) {
		$sticky_review = ( isset( $p_meta['sticky_review'] ) && $p_meta['sticky_review'][0] == '1' );
		if ( $sticky_review ) {
			$args     = [
				'post_id'    => $post_id,
				'status'     => 'approve', // Change this to the type of comments to be displayed.
				'meta_query' => [
					[
						'key'     => 'rt_sticky_review',
						'value'   => '1',
						'compare' => '==',
					],
				],
			];
			$comments = get_comments( $args );
			wp_list_comments(
				[
					'style'      => 'li',
					'short_ping' => true,
					'callback'   => [ ReviewFns::class, 'comment_list' ],
				],
				$comments
			);
		}
	}
	/**
	 * Review highlight AJAX handler.
	 *
	 * @return void
	 */
	public function rtrs_review_hightlight() {
		if ( ! wp_verify_nonce( Functions::get_nonce(), rtrs()->getNonceId() ) ) {
			wp_send_json_error( [ 'message' => 'Not allowed' ], 403 );
		}
		if ( current_user_can( 'administrator' ) ) {
			$comment_id = isset( $_REQUEST['comment_id'] ) ? absint( $_REQUEST['comment_id'] ) : null;
			$highlight  = ( isset( $_REQUEST['highlight'] ) && $_REQUEST['highlight'] == 'highlight' ) ? 1 : 0;
			if ( $comment_id ) {
				update_comment_meta( $comment_id, 'rt_highlight', $highlight );
			}
		}
		wp_send_json_success();
	}

	/**
	 * Vote values the endpoint accepts, matching what the helpful partial
	 * renders into `data-helpful` and `data-type`.
	 *
	 * @since 1.0.0
	 */
	const HELPFUL_ACTIONS = [ 'helpful', 'remove' ];
	const HELPFUL_TYPES   = [ 'like', 'dislike' ];

	/**
	 * Resolve a submitted comment ID to a review that may legitimately be voted on.
	 *
	 * SECURITY: `absint()` is a type cast, not validation. The handler previously
	 * passed the raw submitted ID straight to update_comment_meta(), so any
	 * authenticated user — a Subscriber — could write `rt_helpful_*` meta onto an
	 * ordinary WordPress comment, onto another plugin's comment, or onto a comment
	 * ID that does not exist at all, creating unbounded orphan commentmeta rows.
	 *
	 * The comment object loaded from the ID — never the ID itself — is the
	 * authority here. All of the following must hold:
	 *
	 *   1. the comment exists (this is what stops orphan-row creation);
	 *   2. it is a Review Schema review (`comment_type = 'review'`, the marker the
	 *      free plugin sets on save and queries by everywhere else);
	 *   3. its parent post exists and its post type is review-enabled.
	 *
	 * Deliberately NOT an ownership check: a helpful/dislike vote is meant to
	 * target somebody else's review, so requiring ownership would break the
	 * feature. The boundary is "authenticated caller + valid review target".
	 *
	 * Fails closed when the free helper is unavailable (version skew) rather than
	 * assuming the post type is eligible.
	 *
	 * @since 1.0.0
	 *
	 * @param int $comment_id Submitted comment ID.
	 * @return \WP_Comment|null The review, or null when it may not be voted on.
	 */
	private function get_votable_review( $comment_id ) {
		$comment_id = absint( $comment_id );
		if ( ! $comment_id ) {
			return null;
		}

		$comment = get_comment( $comment_id );
		if ( ! $comment instanceof \WP_Comment ) {
			return null;
		}

		if ( 'review' !== $comment->comment_type ) {
			return null;
		}

		// Only a publicly listed review is votable. The free review list queries
		// `status => approve`, so a pending, spam or trashed review is never
		// rendered with vote buttons — accepting a vote on one would both write
		// meta for a review nobody can see and turn the 403/200 response into an
		// oracle for what is sitting in the moderation queue.
		if ( '1' !== (string) $comment->comment_approved ) {
			return null;
		}

		$post = get_post( (int) $comment->comment_post_ID );
		if ( ! $post instanceof \WP_Post ) {
			return null;
		}

		// Post-type eligibility is owned by the free plugin. allReviewType() is
		// the same source the free admin review table uses, and unlike
		// isEnableReviewByPostType() it neither caches across post types nor
		// depends on the global $post — which is unset during admin-ajax.
		if ( ! method_exists( Functions::class, 'allReviewType' ) ) {
			return null;
		}

		$review_post_types = (array) Functions::allReviewType();
		if ( ! in_array( $post->post_type, $review_post_types, true ) ) {
			return null;
		}

		return $comment;
	}

	/**
	 * Normalise a stored helpful list into an array of user IDs.
	 *
	 * The meta is always written as an array, but a scalar left by older data or
	 * another plugin would make in_array()/array_search() raise a TypeError on
	 * PHP 8 and turn a vote into an HTTP 500.
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $value Raw meta value.
	 * @return array
	 */
	private function normalize_helpful_list( $value ) {
		return is_array( $value ) ? $value : [];
	}

	/**
	 * Review like/dislike AJAX handler.
	 *
	 * Authorization boundary: authenticated caller + valid nonce + a genuine
	 * Review Schema review target + a recognised vote value. Ownership of the
	 * review is deliberately not required — see {@see self::get_votable_review()}.
	 *
	 * @return void
	 */
	public function rtrs_review_helpful() {
		if ( ! wp_verify_nonce( Functions::get_nonce(), rtrs()->getNonceId() ) ) {
			wp_send_json_error( [ 'message' => 'Not allowed' ], 403 );
		}

		if ( ! is_user_logged_in() ) {
			wp_send_json_error( [ 'message' => 'Not allowed' ], 403 );
		}

		// Array-shaped input must be rejected before it reaches sanitize_key(),
		// which calls strtolower() and raises a TypeError on an array.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verified above.
		$raw_comment_id = isset( $_REQUEST['comment_id'] ) ? $_REQUEST['comment_id'] : null;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verified above.
		$raw_helpful = isset( $_REQUEST['helpful'] ) ? $_REQUEST['helpful'] : null;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verified above.
		$raw_type = isset( $_REQUEST['type'] ) ? $_REQUEST['type'] : null;

		if ( ! is_scalar( $raw_comment_id ) || ! is_scalar( $raw_helpful ) || ! is_scalar( $raw_type ) ) {
			wp_send_json_error( [ 'message' => 'Invalid request' ], 400 );
		}

		$helpful_action = sanitize_key( wp_unslash( $raw_helpful ) );
		$helpful_type   = sanitize_key( wp_unslash( $raw_type ) );

		if ( ! in_array( $helpful_type, self::HELPFUL_TYPES, true )
			|| ! in_array( $helpful_action, self::HELPFUL_ACTIONS, true ) ) {
			wp_send_json_error( [ 'message' => 'Invalid request' ], 400 );
		}

		$comment = $this->get_votable_review( $raw_comment_id );
		if ( null === $comment ) {
			wp_send_json_error( [ 'message' => 'Not allowed' ], 403 );
		}

		// Take the target from the validated object, never from the request.
		$comment_id = (int) $comment->comment_ID;
		$helpful    = ( 'helpful' === $helpful_action ) ? 1 : 0;

		$current_user = wp_get_current_user();
		$user_id      = $current_user->ID;

		$old_helpful = $this->normalize_helpful_list( get_comment_meta( $comment_id, 'rt_helpful_' . $helpful_type, true ) );
		if ( $old_helpful ) {
			if ( ! in_array( $user_id, $old_helpful ) ) {
				$old_helpful[] = $user_id;
				update_comment_meta( $comment_id, 'rt_helpful_' . $helpful_type, $old_helpful );
			} else {
				if ( ! $helpful ) {
					if ( ( $key = array_search( $user_id, $old_helpful ) ) !== false ) {
						unset( $old_helpful[ $key ] );
					}
				}
				update_comment_meta( $comment_id, 'rt_helpful_' . $helpful_type, $old_helpful );
			}
		} else {
			$new_helpful   = [];
			$new_helpful[] = $user_id;
			update_comment_meta( $comment_id, 'rt_helpful_' . $helpful_type, $new_helpful );
		}

		// decrement opposite type
		$decrement_type = ( 'like' === $helpful_type ) ? 'dislike' : 'like';
		$decrement      = $this->normalize_helpful_list( get_comment_meta( $comment_id, 'rt_helpful_' . $decrement_type, true ) );
		if ( $decrement ) {
			if ( in_array( $user_id, $decrement ) ) {
				if ( ( $key = array_search( $user_id, $decrement ) ) !== false ) {
					unset( $decrement[ $key ] );
				}
				update_comment_meta( $comment_id, 'rt_helpful_' . $decrement_type, $decrement );
			}
		}

		wp_send_json_success();
	}

	/**
	 * Save highlight and sticky review meta.
	 *
	 * @param int $comment_id The comment ID.
	 * @param int $post_id The post ID.
	 * @return void
	 */
	public function save_highlight_sticky_meta( $comment_id, $post_id ) {
		if ( current_user_can( 'administrator' ) ) {
			$highlight = isset( $_POST['rt_highlight'] ) ? 1 : 0;
			update_comment_meta( $comment_id, 'rt_highlight', $highlight );

			$rt_sticky_review = isset( $_POST['rt_sticky_review'] ) ? 1 : 0;
			update_comment_meta( $comment_id, 'rt_sticky_review', $rt_sticky_review );
		}

		// recommendation
		if ( isset( $_POST['rt_recommended'] ) && ( '' !== $_POST['rt_recommended'] ) ) {
			$meta_fn = did_action( 'comment_post' ) ? 'add_comment_meta' : 'update_comment_meta';
			$meta_fn( $comment_id, 'rt_recommended', intval( $_POST['rt_recommended'] ) );
		}

		// anonymous
		if ( isset( $_POST['rt_anonymous'] ) ) {
			$meta_fn = did_action( 'comment_post' ) ? 'add_comment_meta' : 'update_comment_meta';
			$meta_fn( $comment_id, 'rt_anonymous', 1 );
		}
	}

	/**
	 * Render recommendation form field.
	 *
	 * @param array $p_meta Post meta data.
	 */
	public function review_form_recommendation_field( $p_meta ) {
		$recommendation = ( isset( $p_meta['recommendation'] ) && $p_meta['recommendation'][0] == '1' );
		if ( ! $recommendation ) {
			return;
		}
		?>
		<div class="rtrs-form-group rtrs-hide-reply">
			<label class="rtrs-input-label"><?php esc_html_e( 'Recommendation', 'review-schema-pro' ); ?></label>
			<div class="rtrs-recomnd-check">
				<div class="rtrs-form-check rtrs-tooltip">
					<input type="radio" class="rtrs-form-checkbox" name="rt_recommended" value="1">
					<label class="rtrs-checkbox-label check-excelent"></label>
					<span class="rtrs-tooltiptext"><?php esc_html_e( 'Happy', 'review-schema-pro' ); ?></span>
				</div>
				<div class="rtrs-form-check rtrs-tooltip">
					<input type="radio" class="rtrs-form-checkbox" name="rt_recommended" value="-1">
					<label class="rtrs-checkbox-label check-good"></label>
					<span class="rtrs-tooltiptext"><?php esc_html_e( 'Sad', 'review-schema-pro' ); ?></span>
				</div>
				<div class="rtrs-form-check rtrs-tooltip">
					<input type="radio" class="rtrs-form-checkbox" name="rt_recommended" value="0">
					<label class="rtrs-checkbox-label check-bad"></label>
					<span class="rtrs-tooltiptext"><?php esc_html_e( 'Nothing', 'review-schema-pro' ); ?></span>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render anonymous review form field.
	 *
	 * @param array $p_meta Post meta data.
	 */
	public function review_form_anonymous_field( $p_meta ) {
		$anonymous_review = ( isset( $p_meta['anonymous_review'] ) && $p_meta['anonymous_review'][0] == '1' );
		if ( ! $anonymous_review ) {
			return;
		}
		?>
		<div class="rtrs-form-group rtrs-hide-reply">
			<div class="rtrs-form-check">
				<input type="checkbox" class="rtrs-form-checkbox" name="rt_anonymous" id="rtrs-anonymous">
				<label for="rtrs-anonymous" class="rtrs-checkbox-label"><?php esc_html_e( 'Review anonymously', 'review-schema-pro' ); ?></label>
			</div>
		</div>
		<?php
	}

	/**
	 * Render video edit form field.
	 *
	 * @param array $p_meta Post meta data.
	 * @param int   $comment_id Comment ID.
	 * @param array $review_edit_field Edit fields.
	 */
	public function review_edit_form_video_field( $p_meta, $comment_id, $review_edit_field ) {
		$video_review = ( isset( $p_meta['video_review'] ) && $p_meta['video_review'][0] == '1' );
		if ( ! $video_review || ! in_array( 'video', $review_edit_field ) ) {
			return;
		}
		?>
		<div class="rtrs-form-group rtrs-hide-reply">
			<div class="rtrs-preview-videos"></div>
		</div>

		<div class="rtrs-form-group rtrs-media-form-group rtrs-hide-reply">
			<div class="rtrs-button-label">
				<label class="rtrs-input-video-label"><?php esc_html_e( 'Upload Video', 'review-schema-pro' ); ?></label>
			</div>
			<div>
				<select name="rt_video_source" id="rtrs-video-source" class="rtrs-form-control">
					<option value="self"><?php esc_html_e( 'Hosted Video', 'review-schema-pro' ); ?></option>
					<option value="external"><?php esc_html_e( 'External Video', 'review-schema-pro' ); ?></option>
				</select>
			</div>
			<div class="rtrs-source-video">
				<div class="rtrs-multimedia-upload">
					<div class="rtrs-upload-box" id="rtrs-upload-box-video">
						<span><?php esc_html_e( 'Upload a Video', 'review-schema-pro' ); ?></span>
					</div>
				</div>
				<input type="file" id="rtrs-video" accept="video/*" style="display:none">
				<div class="rtrs-video-error"></div>
			</div>
		</div>

		<div class="rtrs-form-group rtrs-source-external-video rtrs-hide-reply">
			<label class="rtrs-input-label" for="rt_external_video"><?php esc_html_e( 'External Video Link', 'review-schema-pro' ); ?></label>
			<input id="rt_external_video" class="rtrs-form-control" placeholder="<?php esc_attr_e( 'https://www.youtube.com/watch?v=668nUCeBHyY', 'review-schema-pro' ); ?>" name="rt_external_video" type="url">
		</div>
		<?php
	}

	/**
	 * Render recommendation edit form field.
	 *
	 * @param array $p_meta Post meta data.
	 * @param int   $comment_id Comment ID.
	 * @param array $review_edit_field Edit fields.
	 */
	public function review_edit_form_recommendation_field( $p_meta, $comment_id, $review_edit_field ) {
		$recommendation = ( isset( $p_meta['recommendation'] ) && $p_meta['recommendation'][0] == '1' );
		if ( ! $recommendation || ! in_array( 'recommendation', $review_edit_field ) ) {
			return;
		}
		?>
		<div class="rtrs-form-group rtrs-hide-reply">
			<label class="rtrs-input-label"><?php esc_html_e( 'Recommendation', 'review-schema-pro' ); ?></label>
			<div class="rtrs-recomnd-check">
				<div class="rtrs-form-check rtrs-tooltip">
					<input type="radio" <?php checked( get_comment_meta( $comment_id, 'rt_recommended', true ), 1 ); ?> class="rtrs-form-checkbox" name="rt_recommended" value="1">
					<label class="rtrs-checkbox-label check-excelent"></label>
					<span class="rtrs-tooltiptext"><?php esc_html_e( 'Happy', 'review-schema-pro' ); ?></span>
				</div>
				<div class="rtrs-form-check rtrs-tooltip">
					<input type="radio" <?php checked( get_comment_meta( $comment_id, 'rt_recommended', true ), -1 ); ?> class="rtrs-form-checkbox" name="rt_recommended" value="-1">
					<label class="rtrs-checkbox-label check-good"></label>
					<span class="rtrs-tooltiptext"><?php esc_html_e( 'Sad', 'review-schema-pro' ); ?></span>
				</div>
				<div class="rtrs-form-check rtrs-tooltip">
					<input type="radio" <?php checked( get_comment_meta( $comment_id, 'rt_recommended', true ), 0 ); ?> class="rtrs-form-checkbox" name="rt_recommended" value="0">
					<label class="rtrs-checkbox-label check-bad"></label>
					<span class="rtrs-tooltiptext"><?php esc_html_e( 'Nothing', 'review-schema-pro' ); ?></span>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render anonymous edit form field.
	 *
	 * @param array $p_meta Post meta data.
	 * @param int   $comment_id Comment ID.
	 * @param array $review_edit_field Edit fields.
	 */
	public function review_edit_form_anonymous_field( $p_meta, $comment_id, $review_edit_field ) {
		$anonymous_review = ( isset( $p_meta['anonymous_review'] ) && $p_meta['anonymous_review'][0] == '1' );
		if ( ! $anonymous_review || ! in_array( 'anonymous', $review_edit_field ) ) {
			return;
		}
		?>
		<div class="rtrs-form-group rtrs-hide-reply">
			<div class="rtrs-form-check">
				<input type="checkbox" <?php checked( get_comment_meta( $comment_id, 'rt_anonymous', true ), 1 ); ?> class="rtrs-form-checkbox" name="rt_anonymous" id="rtrs-anonymous">
				<label for="rtrs-anonymous" class="rtrs-checkbox-label"><?php esc_html_e( 'Review anonymously', 'review-schema-pro' ); ?></label>
			</div>
		</div>
		<?php
	}

	/**
	 * Save pro meta on review edit (highlight, recommendation, anonymous, pros/cons).
	 *
	 * @param int $comment_id Comment ID.
	 */
	public function save_edit_pro_meta( $comment_id ) {
		// highlight
		if ( current_user_can( 'administrator' ) ) {
			$highlight = isset( $_POST['rt_highlight'] ) ? 1 : 0;
			update_comment_meta( $comment_id, 'rt_highlight', $highlight );
		}

		// recommendation
		if ( isset( $_POST['rt_recommended'] ) && ( '' !== $_POST['rt_recommended'] ) ) {
			update_comment_meta( $comment_id, 'rt_recommended', intval( $_POST['rt_recommended'] ) );
		}

		// pros & cons
		$rt_pros_cons = [];
		if ( isset( $_POST['rt_pros'] ) && ( '' !== $_POST['rt_pros'] ) ) {
			$rt_pros_cons['pros'] = array_map( 'sanitize_text_field', array_filter( $_POST['rt_pros'] ) );
		}
		if ( isset( $_POST['rt_cons'] ) && ( '' !== $_POST['rt_cons'] ) ) {
			$rt_pros_cons['cons'] = array_map( 'sanitize_text_field', array_filter( $_POST['rt_cons'] ) );
		}
		if ( isset( $_POST['rt_pros'] ) || isset( $_POST['rt_cons'] ) ) {
			update_comment_meta( $comment_id, 'rt_pros_cons', $rt_pros_cons );
		}

		// anonymous
		if ( isset( $_POST['rt_anonymous'] ) ) {
			update_comment_meta( $comment_id, 'rt_anonymous', 1 );
		}
	}

	/**
	 * Add recommended/highlighted sort args.
	 *
	 * @param array  $args    Query args.
	 * @param string $sort_by Sort key.
	 * @return array Modified args.
	 */
	public function review_sort_args( $args, $sort_by ) {
		switch ( $sort_by ) {
			case 'recommended':
				$args['meta_query'] = [
					'relation' => 'OR',
					[
						'key'     => 'rt_recommended',
						'value'   => '1',
						'compare' => '=',
					],
				];
				break;

			case 'highlighted':
				$args['meta_query'] = [
					'relation' => 'OR',
					[
						'key'     => 'rt_highlight',
						'value'   => '1',
						'compare' => '=',
					],
				];
				break;
		}

		// Exclude sticky reviews from paginated/filtered results since they are already pinned at the top.
		$post_id = isset( $_REQUEST['post_id'] ) ? absint( $_REQUEST['post_id'] ) : 0;
		if ( $post_id ) {
			$post_type = get_post_type( $post_id );
			$p_meta    = \Rtrs\Helpers\Functions::getMetaByPostType( $post_type );
			$sticky    = isset( $p_meta['sticky_review'] ) && $p_meta['sticky_review'][0] == '1';
			if ( $sticky ) {
				$sticky_query = [
					'relation' => 'OR',
					[
						'key'     => 'rt_sticky_review',
						'value'   => '1',
						'compare' => '!=',
					],
					[
						'key'     => 'rt_sticky_review',
						'compare' => 'NOT EXISTS',
						'value'   => '',
					],
				];
				if ( ! empty( $args['meta_query'] ) ) {
					$args['meta_query'] = [
						'relation' => 'AND',
						$args['meta_query'],
						$sticky_query,
					];
				} else {
					$args['meta_query'] = $sticky_query;
				}
			}
		}

		return $args;
	}

	/**
	 * Handle product delete - cleanup meta and cache.
	 *
	 * @param int $post_id The post ID.
	 *
	 * @return void
	 */
	public static function on_product_delete( $post_id ) {
		if ( 'product' !== get_post_type( $post_id ) ) {
			return;
		}

		self::clear_cache( $post_id );
		delete_post_meta( $post_id, '_rtrs_product_pricing_' . $post_id );
	}
	/**
	 * Handle product save - clear cache and save meta.
	 *
	 * @param int         $product_id The product ID.
	 * @param \WC_Product $product    The product object.
	 *
	 * @return void
	 */
	public static function on_product_save( $product_id, $product ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! $product->is_type( 'variable' ) ) {
			return;
		}
		self::clear_cache( $product_id );

		$pricing_data = self::build_pricing_data( $product );
		$meta_key     = '_rtrs_product_pricing_offer_schema';

		update_post_meta( $product_id, $meta_key, $pricing_data );
	}
	/**
	 * Build pricing data based on product type.
	 *
	 * @param \WC_Product $product The product object.
	 *
	 * @return array Pricing data.
	 */
	private static function build_pricing_data( $product ) {
		global $wpdb;

		$variation_ids = $product->get_children();

		if ( empty( $variation_ids ) ) {
			return [];
		}

		$ids_placeholder = implode( ',', array_fill( 0, count( $variation_ids ), '%d' ) );

		$results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT p.ID, pm_price.meta_value AS price, pm_stock.meta_value AS stock_status
			FROM {$wpdb->posts} p
			LEFT JOIN {$wpdb->postmeta} pm_price ON p.ID = pm_price.post_id AND pm_price.meta_key = '_price'
			LEFT JOIN {$wpdb->postmeta} pm_stock ON p.ID = pm_stock.post_id AND pm_stock.meta_key = '_stock_status'
			WHERE p.ID IN ($ids_placeholder)
			AND p.post_status = 'publish'",
				...$variation_ids
			),
			OBJECT_K
		);

		$variations_data = [];

		foreach ( $variation_ids as $variation_id ) {
			if ( ! isset( $results[ $variation_id ] ) ) {
				continue;
			}

			$row          = $results[ $variation_id ];
			$stock_status = $row->stock_status ?? 'instock';

			$variations_data[] = [
				'price'        => $row->price ?? '',
                'variation_id' => $variation_id,
				'availability' => 'instock' === $stock_status ? 'https:\/\/schema.org\/InStock' : 'https:\/\/schema.org\/OutOfStock',
			];
		}

		return $variations_data;
	}
	/**
	 * Clear pricing cache for a product.
	 *
	 * @param int $product_id The product ID.
	 *
	 * @return void
	 */
	public static function clear_cache( $product_id ) {
		delete_transient( 'rtrs_pricing_' . $product_id );
	}
}
