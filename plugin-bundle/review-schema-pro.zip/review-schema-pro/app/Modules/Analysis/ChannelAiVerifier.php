<?php
/**
 * Channel AI verification (Pro).
 *
 * Hooks the free `rtrs_{seo|aeo|geo}_ai_verify` filters: layers a bounded
 * qualitative AI audit on top of a deterministic analysis channel. The AI may
 * nudge each criterion's score within a small bounded range; the channel score
 * is then recomputed from the adjusted criteria so the number the UI shows
 * always agrees with the AI's per-criterion notes. The AI can never lift a
 * channel with a hard-failing required criterion into a passing band. No key or
 * a provider error returns the deterministic channel untouched.
 *
 * One channel-agnostic verifier serves SEO, AEO and GEO.
 *
 * @package Rtrsp\Modules\Analysis
 * @since   1.0.0
 */

namespace Rtrsp\Modules\Analysis;

use Rtrs\AI\AIClient;
use Rtrs\AI\AIInit;
use Rtrs\Modules\Seo\Analysis\AnalysisContext;
use Rtrs\Modules\Seo\Analysis\Grade;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ChannelAiVerifier
 */
class ChannelAiVerifier {

	/**
	 * Maximum number of points the AI may add or remove from a single
	 * criterion's deterministic score. Sized so a genuine AI re-assessment has
	 * room to diverge meaningfully from the plain score — the channel score (a
	 * weighted average of the criteria) can move well beyond 5 points from the
	 * deterministic baseline when the AI disagrees, so "Review with AI" reads as
	 * a real second opinion rather than a rounding nudge.
	 */
	const CRIT_BOUND = 15;

	/**
	 * A required criterion below this value is treated as a hard miss that AI
	 * may not promote into the passing band.
	 */
	const HARD_MISS = 50;

	/**
	 * Filter callback for `rtrs_seo_ai_verify` / `rtrs_aeo_ai_verify` /
	 * `rtrs_geo_ai_verify`.
	 *
	 * @param array $channel The deterministic channel object.
	 * @param int   $post_id Post ID (unused; the channel + context carry data).
	 * @param mixed $context Shared AnalysisContext for content signals.
	 * @return array|\WP_Error Verified channel (scored_by='ai'), the unchanged
	 *                         channel when AI is unavailable, or a WP_Error when
	 *                         the provider request fails.
	 */
	public static function verify( $channel, $post_id = 0, $context = null ) {
		if ( ! is_array( $channel ) || empty( $channel['criteria'] ) || ! AIInit::hasApiKey() ) {
			return $channel;
		}

		$client   = new AIClient();
		$response = $client->complete( self::system_prompt( $channel ), self::user_prompt( $channel, $context ) );

		// Surface provider failures to the caller so the editor can show the
		// error (invalid key, rate limit, provider down, unreadable JSON, …)
		// instead of silently returning the deterministic score.
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		if ( ! is_array( $response ) ) {
			return new \WP_Error(
				'ai_bad_response',
				__( 'The AI service returned an unexpected response. Please try again.', 'review-schema-pro' )
			);
		}

		// Deterministic (pre-AI) score — the number shown before the review.
		$deterministic_score = isset( $channel['score'] ) ? (int) $channel['score'] : 0;

		// Apply the AI's bounded per-criterion corrections + notes so each
		// criterion's displayed percentage reflects the AI's judgement.
		$channel['criteria'] = self::apply_criteria( $channel['criteria'], $response );

		// Recompute the channel score from the adjusted criteria (same weighted
		// average the deterministic analyzer uses) so the aggregate agrees with
		// the per-criterion numbers. Every criterion moves at most ±CRIT_BOUND,
		// giving the review enough room to land more than 5 points away from the
		// deterministic score when the AI genuinely disagrees.
		$score = self::weighted_score( $channel['criteria'] );

		// Guard: AI may never PROMOTE a hard-failing channel into the passing
		// (C/65+) band. Only applies when the deterministic score was itself
		// below passing — the review must never drag a channel the deterministic
		// analyzer already rated as passing down into a fail.
		if ( $deterministic_score < 65 && $score >= 65 && self::has_hard_miss( $channel['criteria'] ) ) {
			$score = 64;
		}

		$channel['score']     = $score;
		$channel['grade']     = Grade::from_score( $score );
		$channel['scored_by'] = 'ai';

		return $channel;
	}

	/**
	 * Apply the AI's per-criterion score correction and notes onto each row.
	 *
	 * The model returns a `criteria` map of `criterion key => {adjustment, notes}`.
	 * Each row's `value` is shifted by the bounded adjustment (and its `status`
	 * recomputed), and its sanitized notes are attached under `ai_notes`. Rows
	 * the model did not comment on keep their deterministic value with empty
	 * `ai_notes`. Locked (Pro-gated) rows are never adjusted.
	 *
	 * @param array[] $criteria Channel criteria rows.
	 * @param array   $response Decoded AI response.
	 * @return array[]
	 */
	private static function apply_criteria( array $criteria, array $response ) {
		$map = ( isset( $response['criteria'] ) && is_array( $response['criteria'] ) ) ? $response['criteria'] : [];

		foreach ( $criteria as $index => $criterion ) {
			$key   = isset( $criterion['key'] ) ? (string) $criterion['key'] : '';
			$entry = ( '' !== $key && isset( $map[ $key ] ) && is_array( $map[ $key ] ) ) ? $map[ $key ] : [];

			$criteria[ $index ]['ai_notes'] = self::sanitize_notes(
				[ 'notes' => isset( $entry['notes'] ) ? $entry['notes'] : [] ]
			);

			if ( ! empty( $criterion['locked'] ) ) {
				continue; // Locked rows carry no score and are never adjusted.
			}

			$adjustment = isset( $entry['adjustment'] ) ? (int) $entry['adjustment'] : 0;
			$adjustment = max( -self::CRIT_BOUND, min( self::CRIT_BOUND, $adjustment ) );

			$value = isset( $criterion['value'] ) ? (int) $criterion['value'] : 0;
			$value = max( 0, min( 100, $value + $adjustment ) );

			$criteria[ $index ]['value']  = $value;
			$criteria[ $index ]['status'] = Grade::status( $value );
		}

		return $criteria;
	}

	/**
	 * Weighted-average score over the scored (non-locked) criteria.
	 *
	 * Mirrors the deterministic analyzers so an AI-adjusted channel and a
	 * deterministic one are computed the same way.
	 *
	 * @param array[] $criteria Channel criteria rows.
	 * @return int Score 0-100.
	 */
	private static function weighted_score( array $criteria ) {
		$weighted_sum = 0;
		$weight_total = 0;

		foreach ( $criteria as $criterion ) {
			if ( ! empty( $criterion['locked'] ) ) {
				continue;
			}
			$value         = isset( $criterion['value'] ) ? (int) $criterion['value'] : 0;
			$weight        = isset( $criterion['weight'] ) ? (int) $criterion['weight'] : 0;
			$weighted_sum += $value * $weight;
			$weight_total += $weight;
		}

		return $weight_total > 0 ? (int) round( $weighted_sum / $weight_total ) : 0;
	}

	/**
	 * Whether any required (non-locked) criterion is a hard miss.
	 *
	 * @param array[] $criteria Channel criteria rows.
	 * @return bool
	 */
	private static function has_hard_miss( array $criteria ) {
		foreach ( $criteria as $criterion ) {
			if ( ! empty( $criterion['locked'] ) ) {
				continue;
			}
			if ( isset( $criterion['value'] ) && (int) $criterion['value'] < self::HARD_MISS ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * System prompt: a strict, bounded JSON audit.
	 *
	 * A shared skeleton (JSON shape, bounds, note rules) plus one short
	 * channel-specific focus block so the model reasons like an SEO / AEO / GEO
	 * expert instead of a generalist. The response contract is identical for all
	 * three channels.
	 *
	 * @param array $channel The deterministic channel object (for its `key`).
	 * @return string
	 */
	private static function system_prompt( array $channel = [] ) {
		$key = isset( $channel['key'] ) ? (string) $channel['key'] : '';

		return implode(
			' ',
			[
				'You audit a deterministic content-optimization score (SEO, Answer Engine',
				'Optimization, or Generative Engine Optimization). Given the per-criterion',
				'scores and the page text, judge whether each criterion\'s deterministic score',
				'over- or under-rates how well the page truly meets that criterion\'s goal.',
				'Reward genuine, specific, well-structured content; penalize keyword stuffing,',
				'padding and thin or vague content. Do NOT invent facts.',
				self::channel_focus( $key ),
				'Respond with STRICT JSON',
				'only, no prose, in this exact shape: {"criteria": {"<criterion key>":',
				'{"adjustment": <integer from -15 to 15>, "notes": [{"message": <string>,',
				'"severity": "info"|"warning"}]}}}. Key each entry by one of the exact criterion',
				'"key" values supplied in the input. "adjustment" is how many points (max ±15) to',
				'shift THAT criterion\'s score so it reflects the real content quality; use 0 when',
				'the deterministic score is already fair. Every note you write must be consistent',
				'with that criterion\'s adjusted score — never say a score is too high while leaving',
				'adjustment at 0. Give short, specific, actionable feedback only for the criteria',
				'that most need attention; omit criteria you have nothing useful to add for.',
				'When a note is about a specific section, heading or FAQ question, name it by',
				'quoting that heading\'s exact text (e.g. the FAQ "How do I install X?") so the',
				'user knows which one; use the "headings" list supplied in the input and never',
				'refer to an item vaguely as "the final question" without quoting it.',
				'The input carries a "faqs" list of {question, answer} pairs holding the page\'s',
				'COMPLETE FAQ answers — judge FAQ quality from that list, never from the',
				'"content" field alone. Never claim the FAQ answers are missing, truncated or',
				'"cut off" when the "faqs" list is non-empty; the "content" field may be trimmed',
				'for length but "faqs" always holds the full answers.',
				'Return at most 2 notes per criterion.',
			]
		);
	}

	/**
	 * Short channel-specific focus block appended to the shared system prompt.
	 *
	 * @param string $key Channel key: 'seo' | 'aeo' | 'geo'.
	 * @return string
	 */
	private static function channel_focus( $key ) {
		if ( 'seo' === $key ) {
			return 'This is the SEO channel: judge search-ranking signals — a compelling,'
				. ' accurate title and meta description, the focus keyword used naturally'
				. ' (not stuffed), a logical heading hierarchy, and useful internal linking.';
		}

		if ( 'aeo' === $key ) {
			return 'This is the Answer Engine Optimization channel: judge how ready the page'
				. ' is to be spoken or summarized by assistants — FAQ answers that are complete'
				. ' and self-contained, a direct answer stated up front, and short, conversational'
				. ' sentences a voice assistant can read aloud cleanly.';
		}

		if ( 'geo' === $key ) {
			return 'This is the Generative Engine Optimization channel: judge how citable the'
				. ' page is to an LLM — factual, specific, well-attributed statements, clearly'
				. ' structured self-contained passages, and content an AI could quote without'
				. ' distortion.';
		}

		return '';
	}

	/**
	 * User prompt: the channel scores plus content signals to assess.
	 *
	 * @param array $channel The deterministic channel object.
	 * @param mixed $context Shared AnalysisContext (may be null).
	 * @return string
	 */
	private static function user_prompt( array $channel, $context ) {
		$criteria = [];
		foreach ( $channel['criteria'] as $criterion ) {
			$criteria[] = [
				'key'    => isset( $criterion['key'] ) ? (string) $criterion['key'] : '',
				'name'   => isset( $criterion['name'] ) ? (string) $criterion['name'] : '',
				'value'  => isset( $criterion['value'] ) ? (int) $criterion['value'] : 0,
				'weight' => isset( $criterion['weight'] ) ? (int) $criterion['weight'] : 0,
			];
		}

		$payload = [
			'channel'  => isset( $channel['key'] ) ? (string) $channel['key'] : '',
			'label'    => isset( $channel['long'] ) ? (string) $channel['long'] : '',
			'score'    => isset( $channel['score'] ) ? (int) $channel['score'] : 0,
			'grade'    => isset( $channel['grade'] ) ? (string) $channel['grade'] : '',
			'criteria' => $criteria,
		];

		if ( $context instanceof AnalysisContext ) {
			$headings = $context->headings();

			// Give the model the exact heading/FAQ text (with an index) so a note
			// can name the specific section it refers to instead of "the final one".
			$heading_list = [];
			foreach ( array_slice( $headings, 0, 60 ) as $i => $heading ) {
				$heading_list[] = [
					'index' => $i,
					'level' => isset( $heading['level'] ) ? (int) $heading['level'] : 0,
					'text'  => isset( $heading['text'] ) ? (string) $heading['text'] : '',
				];
			}

			// FAQ answers are appended to the very end of the content, so on a long
			// page the 16k content truncation below would cut them off — making the
			// model wrongly report the FAQ answers as missing or "cut off". Pass the
			// Q&A pairs as their own field so the complete answers always reach the
			// model regardless of where the FAQ sits in the body.
			$faq_list = [];
			foreach ( array_slice( $context->faqs(), 0, 30 ) as $faq ) {
				$faq_list[] = [
					'question' => $faq['question'],
					'answer'   => self::truncate( $faq['answer'], 1200 ),
				];
			}

			$payload['focus_keyword']       = $context->focus_keyword();
			$payload['heading_count']       = count( $headings );
			$payload['headings']            = $heading_list;
			$payload['faq_count']           = count( $faq_list );
			$payload['faqs']                = $faq_list;
			$payload['internal_link_count'] = $context->internal_link_count();
			$payload['external_link_count'] = $context->external_link_count();
			$payload['content']             = self::truncate( $context->plain_text(), 16000 );
		}

		return wp_json_encode( $payload );
	}

	/**
	 * Truncate text to a maximum length on a word boundary.
	 *
	 * @param string $text Source text.
	 * @param int    $max  Maximum length in characters.
	 * @return string
	 */
	private static function truncate( $text, $max ) {
		$text = (string) $text;
		if ( strlen( $text ) <= $max ) {
			return $text;
		}

		return rtrim( substr( $text, 0, $max ) ) . '…';
	}

	/**
	 * Normalize AI "notes" into safe `{message, severity}` rows.
	 *
	 * @param array $response Decoded AI response.
	 * @return array[]
	 */
	private static function sanitize_notes( array $response ) {
		if ( empty( $response['notes'] ) || ! is_array( $response['notes'] ) ) {
			return [];
		}

		$allowed_sev = [ 'info', 'warning' ];
		$out         = [];

		foreach ( array_slice( $response['notes'], 0, 3 ) as $note ) {
			if ( empty( $note['message'] ) || ! is_string( $note['message'] ) ) {
				continue;
			}
			$severity = isset( $note['severity'] ) && in_array( $note['severity'], $allowed_sev, true ) ? $note['severity'] : 'info';

			$out[] = [
				'message'  => sanitize_text_field( $note['message'] ),
				'severity' => $severity,
			];
		}

		return $out;
	}
}
