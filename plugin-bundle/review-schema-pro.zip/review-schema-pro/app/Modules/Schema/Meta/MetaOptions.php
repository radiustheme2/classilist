<?php
/**
 * Main MetaOptions Class.
 *
 * The main class that initiates and runs the plugin.
 *
 * @package  review-schema-pro
 *
 * @since    1.0.0
 */

namespace Rtrsp\Modules\Schema\Meta;

use Rtrs\Helpers\Functions;
use Rtrsp\Traits\SingletonTrait;

/**
 * MetaOptions class
 */
class MetaOptions {

	use SingletonTrait;

	/**
	 * Prefix.
	 *
	 * @var string
	 */
	private $prefix = 'rtrs_';

	/**
	 * Init function.
	 *
	 * @return void
	 */
	private function __construct() {
		// Tab option filter .
		add_filter( 'rtrs_section_schema_fields', [ $this, 'section_schema_fields' ] );
	}
	/**
	 * Undocumented function
	 *
	 * @param array $schema_fields schema fields.
	 * @return array
	 */
	public function section_schema_fields( $schema_fields ) {
		$schema_fields[] = $this->tv_series_schema_fields();
		$schema_fields[] = $this->CollectionPageSchemaFields();
		$schema_fields[] = $this->vacationRentalSchemaFields();
		$schema_fields[] = $this->vehicleListingSchemaFields();
		$schema_fields[] = $this->podcastEpisodeSchemaFields();
		$schema_fields[] = $this->discussionForumPostingSchemaFields();
		$schema_fields[] = $this->datasetSchemaFields();
		$schema_fields[] = $this->restaurantSchemaFields();
		$schema_fields[] = $this->booksSchemaFields();
		$schema_fields[] = $this->realStateListingSchemaFields();
		$schema_fields[] = $this->courseSchemaFields();
		$schema_fields[] = $this->jobpostingSchemaFields();
		$schema_fields[] = $this->recipeSchemaFields();
		$schema_fields[] = $this->softwareAppSchemaFields();
		$schema_fields[] = $this->imageLicenseSchemaFields();
		$schema_fields[] = $this->specialAnnouncementSchemaFields();
		$schema_fields[] = $this->productSchemaFields();
		$schema_fields[] = $this->taxiServiceSchemaFields();
		$schema_fields[] = $this->touristAttractionSchemaFields();
		return $schema_fields;
	}

	/**
	 * Product Schema Fields
	 */
	public function productSchemaFields() {
		$settings_fields = [
			[
				'id'     => 'product',
				'type'   => 'auto-fill',
				'is_pro' => true,
				'label'  => esc_html__( 'Auto Fill', 'review-schema-pro' ),
			],
			[
				'type'    => 'tab',
				'name'    => 'status',
				'label'   => esc_html__( 'Status', 'review-schema-pro' ),
				'default' => 'show',
				'options' => [
					'show' => esc_html__( 'Show', 'review-schema-pro' ),
					'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
				],
			],
			[
				'name'     => 'name',
				'type'     => 'text',
				'label'    => esc_html__( 'Name', 'review-schema-pro' ),
				'required' => true,
			],
			[
				'name'  => 'description',
				'type'  => 'textarea',
				'label' => esc_html__( 'Description', 'review-schema-pro' ),
				'desc'  => esc_html__( 'Product description.', 'review-schema-pro' ),
			],
			[
				'name'  => 'identifier_section',
				'type'  => 'heading',
				'label' => esc_html__( 'Product Identifier', 'review-schema-pro' ),
			],
			[
				'name'        => 'sku',
				'type'        => 'text',
				'label'       => esc_html__( 'SKU', 'review-schema-pro' ),
				'recommended' => true,
			],
			[
				'name'     => 'brand',
				'type'     => 'text',
				'label'    => esc_html__( 'Brand', 'review-schema-pro' ),
				'required' => true,
				'desc'     => esc_html__( 'The brand of the product (Used globally).', 'review-schema-pro' ),
			],
			[
				'name'     => 'identifier_type',
				'type'     => 'select',
				'label'    => esc_html__( 'Identifier Type', 'review-schema-pro' ),
				'required' => true,
				'options'  => [
					'mpn'    => esc_html__( 'MPN', 'review-schema-pro' ),
					'isbn'   => esc_html__( 'ISBN', 'review-schema-pro' ),
					'gtin8'  => esc_html__( 'GTIN-8 (UPC, JAN)', 'review-schema-pro' ),
					'gtin12' => esc_html__( 'GTIN-12 (UPC)', 'review-schema-pro' ),
					'gtin13' => esc_html__( 'GTIN-13 (EAN,JAN)', 'review-schema-pro' ),
				],
				'desc'     => '<strong>MPN</strong><br>
		                    &#8594; MPN(Manufacturer Part Number) Used globally, Alphanumeric digits (various lengths)<br>
		                    <strong>GTIN</strong><br>
		                    &#8594; UPC(Universal Product Code) Used in primarily North America. 12 numeric digits. eg. 892685001003.<br>
		                    &#8594; EAN(European Article Number) Used primarily outside of North America. Typically 13 numeric digits (can occasionally be either eight or 14 numeric digits). eg. 4011200296908<br>
		                    &#8594; ISBN(International Standard Book Number) Used globally, ISBN-13 (recommended), 13 numeric digits 978-0747595823<br>
		                    &#8594; JAN(Japanese Article Number) Used only in Japan, 8 or 13 numeric digits.',
			],
			[
				'name'     => 'identifier',
				'type'     => 'text',
				'label'    => esc_html__( 'Identifier Value', 'review-schema-pro' ),
				'required' => true,
				'desc'     => esc_html__( 'Enter product unique identifier', 'review-schema-pro' ),
			],

			[
				'name'  => 'pricing_section',
				'type'  => 'heading',
				'label' => esc_html__( 'Product Pricing', 'review-schema-pro' ),
			],
			[
				'name'  => 'price',
				'type'  => 'float',
				'min'   => 0,
				'label' => esc_html__( 'Price', 'review-schema-pro' ),
				'desc'  => esc_html__( 'The lowest available price, including service charges and fees, of this type of ticket.', 'review-schema-pro' ),
			],
			[
				'name'  => 'priceCurrency',
				'type'  => 'text',
				'label' => esc_html__( 'Price currency', 'review-schema-pro' ),
				'desc'  => esc_html__( 'The 3-letter currency code. (USD)', 'review-schema-pro' ),
			],
			[
				'name'        => 'priceValidUntil',
				'type'        => 'text',
				'label'       => esc_html__( 'PriceValidUntil', 'review-schema-pro' ),
				'recommended' => true,
				'class'       => 'rtrs-date',
				'desc'        => sprintf( esc_html__( 'The date (in ISO 8601 date format) after which the price will no longer be available. Like this: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:sP' ) ),
			],
			[
				'name'    => 'availability',
				'type'    => 'select',
				'label'   => esc_html__( 'Availability', 'review-schema-pro' ),
				'empty'   => esc_html__( 'Select one', 'review-schema-pro' ),
				'options' => [
					'https://schema.org/InStock'      => esc_html__( 'InStock', 'review-schema-pro' ),
					'https://schema.org/InStoreOnly'  => esc_html__( 'InStoreOnly', 'review-schema-pro' ),
					'https://schema.org/OutOfStock'   => esc_html__( 'OutOfStock', 'review-schema-pro' ),
					'https://schema.org/SoldOut'      => esc_html__( 'SoldOut', 'review-schema-pro' ),
					'https://schema.org/OnlineOnly'   => esc_html__( 'OnlineOnly', 'review-schema-pro' ),
					'https://schema.org/LimitedAvailability' => esc_html__( 'LimitedAvailability', 'review-schema-pro' ),
					'https://schema.org/Discontinued' => esc_html__( 'Discontinued', 'review-schema-pro' ),
					'https://schema.org/PreOrder'     => esc_html__( 'PreOrder', 'review-schema-pro' ),
				],
				'desc'    => esc_html__( 'Select a availability type', 'review-schema-pro' ),
			],
			[
				'name'    => 'itemCondition',
				'type'    => 'select',
				'label'   => esc_html__( 'Product condition', 'review-schema-pro' ),
				'empty'   => esc_html__( 'Select one', 'review-schema-pro' ),
				'options' => [
					'https://schema.org/NewCondition'     => esc_html__( 'NewCondition', 'review-schema-pro' ),
					'https://schema.org/UsedCondition'    => esc_html__( 'UsedCondition', 'review-schema-pro' ),
					'https://schema.org/DamagedCondition' => esc_html__( 'DamagedCondition', 'review-schema-pro' ),
					'https://schema.org/RefurbishedCondition' => esc_html__( 'RefurbishedCondition', 'review-schema-pro' ),
				],
				'desc'    => esc_html__( 'Select a condition', 'review-schema-pro' ),
			],
			[
				'name'  => 'rating_section',
				'type'  => 'heading',
				'label' => esc_html__( 'Aggregate Rating', 'review-schema-pro' ),
			],
			[
				'name'        => 'reviewRatingValue',
				'type'        => 'float',
				'label'       => esc_html__( 'Rating average value', 'review-schema-pro' ),
				'recommended' => true,
				'min'         => 1,
				'desc'        => esc_html__( 'Rating value. (1, 2.5, 3, 5 etc)', 'review-schema-pro' ),
			],
			[
				'name'        => 'reviewBestRating',
				'type'        => 'float',
				'label'       => esc_html__( 'Best Rating ( Rating Scale Maximum)', 'review-schema-pro' ),
				'desc'        => esc_html__( 'Enter the highest possible rating value for this review. In most rating systems, the best rating is 5.', 'review-schema-pro' ),
				'recommended' => true,
				'min'         => 1,
			],
			[
				'name'        => 'reviewWorstRating',
				'type'        => 'float',
				'label'       => esc_html__( 'Worst rating ( Rating Scale minimum)', 'review-schema-pro' ),
				'recommended' => true,
				'min'         => 1,
			],
			[
				'name'  => 'reviewCount',
				'type'  => 'float',
				'min'   => 0,
				'label' => esc_html__( 'Total review count', 'review-schema-pro' ),
				'desc'  => wp_kses( __( "Review Count. <span class='required'>This is required if (Rating value) is given</span>", 'review-schema-pro' ), [ 'span' => [] ] ),
			],
			[
				'name'  => 'author_rating_section',
				'type'  => 'heading',
				'label' => esc_html__( 'Author Rating', 'review-schema-pro' ),
			],
			[
				'name'    => 'review_active',
				'type'    => 'tab',
				'label'   => esc_html__( 'Author Review Status', 'review-schema-pro' ),
				'default' => 'show',
				'options' => [
					'show' => esc_html__( 'Show', 'review-schema-pro' ),
					'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
				],
			],
			[
				'name'  => 'reviewAuthor',
				'type'  => 'text',
				'label' => esc_html__( 'Review author', 'review-schema-pro' ),
			],
			[
				'name'     => 'review_body',
				'type'     => 'textarea',
				'label'    => esc_html__( 'Review body', 'review-schema-pro' ),
				'required' => true,
				'desc'     => esc_html__( 'The actual body of the review.', 'review-schema-pro' ),
			],
			[
				'name'        => 'ratingValue',
				'type'        => 'float',
				'label'       => esc_html__( 'Rating value', 'review-schema-pro' ),
				'recommended' => true,
				'min'         => 1,
				'desc'        => esc_html__( 'Rating value. (1, 2.5, 3, 5 etc)', 'review-schema-pro' ),
			],
			[
				'name'  => 'review_datePublished',
				'type'  => 'text',
				'label' => esc_html__( 'Review published date', 'review-schema-pro' ),
				'class' => 'rtrs-date',
				'desc'  => sprintf( esc_html__( 'The date (in ISO 8601 date format), Like this: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:sP' ) ),
			],
			[
				'name'  => 'shipping_details',
				'type'  => 'heading',
				'label' => esc_html__( 'Shipping Details', 'review-schema-pro' ),
			],
			[
				'name'    => 'override_shipping',
				'type'    => 'switch',
				'label'   => esc_html__( 'Override Global Settings', 'review-schema-pro' ),
				'desc'    => esc_html__( 'Enable to use per-product shipping fields instead of global ecommerce settings.', 'review-schema-pro' ),
				'default' => '',
			],
			[
				'name'  => 'shippingRate',
				'type'  => 'float',
				'label' => esc_html__( 'Shipping Rate - Price', 'review-schema-pro' ),
				'desc'  => esc_html__( 'Shipping Cost.', 'review-schema-pro' ),
			],
			[
				'name'        => 'shippingDestination',
				'type'        => 'text',
				'placeholder' => 'US',
				'label'       => esc_html__( 'Shipping Destination', 'review-schema-pro' ),
				'desc'        => esc_html__( 'The two-letter country code, in ISO 3166-1 alpha-2 format.', 'review-schema-pro' ),
			],
			[
				'name'        => 'addressRegion',
				'type'        => 'text',
				'placeholder' => ' "NY", "AL", "AK"',
				'label'       => esc_html__( 'Address Region', 'review-schema-pro' ),
				'desc'        => esc_html__( 'If you include this property, the region must be a 2- or 3-digit ISO 3166-2 subdivision code, without country prefix. Currently, Google Search only supports the US, Australia, and Japan. Examples: "NY" (for US, state of New York), "NSW" (for Australia, state of New South Wales), or "03" (for Japan, Iwate prefecture).Example: "NY", "AL", "AK".', 'review-schema-pro' ),
			],
			[
				'name'  => 'handlingTime',
				'type'  => 'heading',
				'label' => esc_html__( 'Handling Time', 'review-schema-pro' ),
			],

			[
				'name'        => 'handlingTimeMinimum',
				'type'        => 'text',
				'placeholder' => '5',
				'label'       => esc_html__( 'Handling Time Minimum ( Days )', 'review-schema-pro' ),
				'desc'        => esc_html__( 'Minimum days for handling time.', 'review-schema-pro' ),
			],
			[
				'name'        => 'handlingTimeMaximum',
				'type'        => 'text',
				'placeholder' => '5',
				'label'       => esc_html__( 'Handling Time Maximum (Days)', 'review-schema-pro' ),
				'desc'        => esc_html__( 'Maximum days for handling time.', 'review-schema-pro' ),
			],

			[
				'name'        => 'transitTimeMinimum',
				'type'        => 'text',
				'placeholder' => '5',
				'label'       => esc_html__( 'Transit Time Minimum ( Days )', 'review-schema-pro' ),
				'desc'        => esc_html__( 'Minimum days for Transit Time.', 'review-schema-pro' ),
			],
			[
				'name'        => 'transitTimeMaximum',
				'type'        => 'text',
				'placeholder' => '10',
				'label'       => esc_html__( 'Transit Time Maximum ( Days )', 'review-schema-pro' ),
				'desc'        => esc_html__( 'Maximum days for Transit Time.', 'review-schema-pro' ),
			],

			[
				'name'  => 'MerchantReturnPolicy',
				'type'  => 'heading',
				'label' => esc_html__( 'Merchant Return Policy', 'review-schema-pro' ),
			],
			[
				'name'    => 'override_return_policy',
				'type'    => 'switch',
				'label'   => esc_html__( 'Override Global Settings', 'review-schema-pro' ),
				'desc'    => esc_html__( 'Enable to use per-product return policy fields instead of global ecommerce settings.', 'review-schema-pro' ),
				'default' => '',
			],
			[
				'name'        => 'applicableCountry',
				'type'        => 'text',
				'placeholder' => 'US',
				'label'       => esc_html__( 'Applicable Country', 'review-schema-pro' ),
				'desc'        => esc_html__( 'The two-letter country code, in ISO 3166-1 alpha-2 format.', 'review-schema-pro' ),
			],
			[
				'name'        => 'merchantReturnDays',
				'type'        => 'text',
				'placeholder' => '30',
				'label'       => esc_html__( 'Merchant Return Days', 'review-schema-pro' ),
				'desc'        => esc_html__( 'Number of days for return window.', 'review-schema-pro' ),
			],
			[
				'name'    => 'returnPolicyCategory',
				'type'    => 'select',
				'label'   => esc_html__( 'Return Policy Category', 'review-schema-pro' ),
				'empty'   => esc_html__( 'Select one', 'review-schema-pro' ),
				'options' => [
					'https://schema.org/MerchantReturnFiniteReturnWindow' => esc_html__( 'Finite Return Window', 'review-schema-pro' ),
					'https://schema.org/MerchantReturnNotPermitted'       => esc_html__( 'Return Not Permitted', 'review-schema-pro' ),
					'https://schema.org/MerchantReturnUnlimitedWindow'    => esc_html__( 'Unlimited Return Window', 'review-schema-pro' ),
				],
				'desc'    => esc_html__( 'Select the return policy category.', 'review-schema-pro' ),
			],
			[
				'name'    => 'returnMethod',
				'type'    => 'select',
				'label'   => esc_html__( 'Return Method', 'review-schema-pro' ),
				'empty'   => esc_html__( 'Select one', 'review-schema-pro' ),
				'options' => [
					'https://schema.org/ReturnByMail'  => esc_html__( 'Return By Mail', 'review-schema-pro' ),
					'https://schema.org/ReturnInStore' => esc_html__( 'Return In Store', 'review-schema-pro' ),
					'https://schema.org/ReturnAtKiosk' => esc_html__( 'Return At Kiosk', 'review-schema-pro' ),
				],
				'desc'    => esc_html__( 'Select the return method.', 'review-schema-pro' ),
			],
			[
				'name'    => 'returnFees',
				'type'    => 'select',
				'label'   => esc_html__( 'Return Fees', 'review-schema-pro' ),
				'empty'   => esc_html__( 'Select one', 'review-schema-pro' ),
				'options' => [
					'https://schema.org/FreeReturn' => esc_html__( 'Free Return', 'review-schema-pro' ),
					'https://schema.org/ReturnFeesCustomerResponsibility' => esc_html__( 'Customer Responsibility', 'review-schema-pro' ),
					'https://schema.org/ReturnShippingFees' => esc_html__( 'Return Shipping Fees', 'review-schema-pro' ),
				],
				'desc'    => esc_html__( 'Select the return fees type.', 'review-schema-pro' ),
			],
			[
				'name'        => 'returnShippingFeesAmount',
				'type'        => 'float',
				'placeholder' => '0',
				'label'       => esc_html__( 'Return Shipping Fees Amount', 'review-schema-pro' ),
				'desc'        => esc_html__( 'Amount for return shipping fees.', 'review-schema-pro' ),
			],
			[
				'name'        => 'returnShippingFeesCurrency',
				'type'        => 'text',
				'placeholder' => 'USD',
				'label'       => esc_html__( 'Return Shipping Fees Currency', 'review-schema-pro' ),
				'desc'        => esc_html__( 'ISO 4217 currency code (e.g., USD, EUR, GBP).', 'review-schema-pro' ),
			],
			[
				'name'        => 'returnPolicyLink',
				'type'        => 'url',
				'placeholder' => 'https://',
				'label'       => esc_html__( 'Return Policy Page URL', 'review-schema-pro' ),
				'desc'        => esc_html__( 'URL of the return policy page.', 'review-schema-pro' ),
			],
		];
		return [
			'type'        => 'group',
			'name'        => $this->prefix . 'product_schema',
			'is_pro'      => true,
			'id'          => 'rtrs-product_schema',
			'holderClass' => 'rtrs-hidden rtrs-schema-field',
			'label'       => esc_html__( 'Product schema', 'review-schema-pro' ),
			'fields'      => $settings_fields,
		];
	}
	/**
	 * Course Schema Fields
	 */
	public function specialAnnouncementSchemaFields() {
		$settings_fields = [
			[
				'id'     => 'special_announcement',
				'type'   => 'auto-fill',
				'is_pro' => true,
				'label'  => esc_html__( 'Auto Fill', 'review-schema-pro' ),
			],
			[
				'name'    => 'status',
				'type'    => 'tab',
				'label'   => esc_html__( 'Status', 'review-schema-pro' ),
				'default' => 'show',
				'options' => [
					'show' => esc_html__( 'Show', 'review-schema-pro' ),
					'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
				],
			],
			[
				'name'  => 'category',
				'type'  => 'text',
				'label' => esc_html__( 'Category OR Label', 'review-schema-pro' ),
				'desc'  => esc_html__(
					'Optional. Use a Schema.org URL or short label (e.g. Service Update, Public Notice). Not limited to COVID.',
					'review-schema-pro'
				),
			],
			[
				'name'     => 'name',
				'type'     => 'text',
				'label'    => esc_html__( 'Name', 'review-schema-pro' ),
				'desc'     => esc_html__( 'SpecialAnnouncement.name: Name of the announcement. This text should be present on the underlying page.', 'review-schema-pro' ),
				'required' => true,
			],
			[
				'name'        => 'expires',
				'type'        => 'text',
				'label'       => esc_html__( 'Expires date', 'review-schema-pro' ),
				'class'       => 'rtrs-date',
				'desc'        => sprintf( esc_html__( 'Like this: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:sP' ) ),
				'recommended' => true,
			],
			[
				'name'     => 'text',
				'type'     => 'textarea',
				'label'    => esc_html__( 'Text', 'review-schema-pro' ),
				'desc'     => esc_html__( 'SpecialAnnouncement.text: Text of the announcements.', 'review-schema-pro' ),
				'required' => true,
			],
		];
		return [
			'type'        => 'group',
			'name'        => $this->prefix . 'special_announcement_schema',
			'id'          => 'rtrs-special_announcement_schema',
			'holderClass' => 'rtrs-hidden rtrs-schema-field',
			'label'       => esc_html__( 'Special announcement schema', 'review-schema-pro' ),
			'fields'      => $settings_fields,
		];
	}
	/**
	 * Course Schema Fields
	 */
	public function imageLicenseSchemaFields() {
		$settings_fields = [
			[
				'name'    => 'status',
				'type'    => 'tab',
				'label'   => esc_html__( 'Status', 'review-schema-pro' ),
				'default' => 'show',
				'options' => [
					'show' => esc_html__( 'Show', 'review-schema-pro' ),
					'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
				],
			],
			[
				'name'  => 'name',
				'type'  => 'text',
				'label' => esc_html__( 'Name', 'review-schema-pro' ),
				'desc'  => esc_html__( 'Image Name', 'review-schema-pro' ),
			],
			[
				'name'  => 'description',
				'type'  => 'textarea',
				'label' => esc_html__( 'Description', 'review-schema-pro' ),
				'desc'  => esc_html__( 'The description of the video', 'review-schema-pro' ),
			],
			[
				'name'        => 'contentUrl',
				'type'        => 'url',
				'label'       => esc_html__( 'Content URL', 'review-schema-pro' ),
				'placeholder' => esc_html__( 'URL', 'review-schema-pro' ),
				'required'    => true,
				'desc'        => esc_html__( 'Image URL', 'review-schema-pro' ),
			],
			[
				'name'        => 'license',
				'type'        => 'url',
				'label'       => esc_html__( 'License URL', 'review-schema-pro' ),
				'placeholder' => esc_html__( 'URL', 'review-schema-pro' ),
				'required'    => true,
			],
			[
				'name'        => 'acquireLicensePage',
				'type'        => 'url',
				'label'       => esc_html__( 'Acquire license URL', 'review-schema-pro' ),
				'placeholder' => esc_html__( 'URL', 'review-schema-pro' ),
				'required'    => true,
			],
		];
		return [
			'type'        => 'group',
			'name'        => $this->prefix . 'image_license_schema',
			'is_pro'      => true,
			'id'          => 'rtrs-image_license_schema',
			'holderClass' => 'rtrs-hidden rtrs-schema-field',
			'label'       => esc_html__( 'Image License schema', 'review-schema-pro' ),
			'fields'      => $settings_fields,
		];
	}
	/**
	 * Course Schema Fields
	 */
	public function softwareAppSchemaFields() {
		$settings_fields = [
			[
				'id'     => 'software_app',
				'type'   => 'auto-fill',
				'is_pro' => true,
				'label'  => esc_html__( 'Auto Fill', 'review-schema-pro' ),
			],
			[
				'name'    => 'status',
				'type'    => 'tab',
				'label'   => esc_html__( 'Status', 'review-schema-pro' ),
				'default' => 'show',
				'options' => [
					'show' => esc_html__( 'Show', 'review-schema-pro' ),
					'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
				],
			],
			[
				'name'     => 'name',
				'type'     => 'text',
				'label'    => esc_html__( 'Name', 'review-schema-pro' ),
				'required' => true,
			],
			[
				'name'  => 'description',
				'type'  => 'textarea',
				'label' => esc_html__( 'Description', 'review-schema-pro' ),
			],
			[
				'name'  => 'price',
				'type'  => 'float',
				'min'   => 0,
				'label' => esc_html__( 'Price', 'review-schema-pro' ),
				'desc'  => esc_html__( 'The lowest available price, including service charges and fees, of this type of ticket.', 'review-schema-pro' ),
			],
			[
				'name'  => 'priceCurrency',
				'type'  => 'text',
				'label' => esc_html__( 'Price currency', 'review-schema-pro' ),
				'desc'  => esc_html__( 'The 3-letter currency code. (USD)', 'review-schema-pro' ),
			],
			[
				'name'        => 'applicationCategory',
				'type'        => 'select',
				'label'       => esc_html__( 'Application Category', 'review-schema-pro' ),
				'recommended' => true,
				'options'     => $this->getApplicationCategoryList(),
				'desc'        => esc_html__( 'The type of app (for example, BusinessApplication or GameApplication). The value must be a supported app type.', 'review-schema-pro' ),
			],
			[
				'name'  => 'operatingSystem',
				'type'  => 'text',
				'label' => esc_html__( 'Operating System', 'review-schema-pro' ),
				'desc'  => esc_html__( 'The operating(s) required to use the app (for example, Windows 7, OSX 10.6, Android 1.6, WordPress)', 'review-schema-pro' ),
			],
			[
				'name'  => 'softwareVersion',
				'type'  => 'text',
				'label' => esc_html__( 'Software Version', 'review-schema-pro' ),
				'desc'  => esc_html__( 'Version of the software (for example, 1.0.0, 2.5, 3.1.2)', 'review-schema-pro' ),
			],
			[
				'name'  => 'downloadUrl',
				'type'  => 'url',
				'label' => esc_html__( 'Download URL', 'review-schema-pro' ),
				'desc'  => esc_html__( 'The direct download link for the software application.', 'review-schema-pro' ),
			],
			[
				'type'  => 'heading',
				'label' => esc_html__( 'Aggregate Rating', 'review-schema-pro' ),
			],
			[
				'name'  => 'aggregate_ratingValue',
				'type'  => 'float',
				'label' => esc_html__( 'Average Rating', 'review-schema-pro' ),
				'min'   => 1,
				'desc'  => esc_html__( 'Rating value. (1, 2.5, 3, 5 etc)', 'review-schema-pro' ),
			],
			[
				'name'  => 'aggregate_bestRating',
				'type'  => 'float',
				'label' => esc_html__( 'Best Rating - Rating Scale Maximum', 'review-schema-pro' ),
				'min'   => 1,
				'desc'  => esc_html__( 'A numerical quality rating for the item.', 'review-schema-pro' ),
			],
			[
				'name'  => 'aggregate_worstRating',
				'type'  => 'number',
				'label' => esc_html__( 'Rating Scale Minimum - Worst Rating', 'review-schema-pro' ),
				'min'   => 1,
				'desc'  => esc_html__( 'A numerical quality rating for the item.', 'review-schema-pro' ),
			],
			[
				'name'  => 'aggregate_ratingCount',
				'type'  => 'float',
				'min'   => 0,
				'label' => esc_html__( 'Rating Count', 'review-schema-pro' ),
				'desc'  => esc_html__( 'A numerical quality rating for the item.', 'review-schema-pro' ),
			],
			[
				'name'  => 'review_section',
				'type'  => 'heading',
				'label' => esc_html__( 'Review', 'review-schema-pro' ),
				'desc'  => esc_html__( 'To add review schema for this type, complete fields below and enable, others live blank.', 'review-schema-pro' ),
			],
			[
				'name'    => 'review_active',
				'type'    => 'tab',
				'label'   => esc_html__( 'Author Review Status', 'review-schema-pro' ),
				'default' => 'show',
				'options' => [
					'show' => esc_html__( 'Show', 'review-schema-pro' ),
					'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
				],
			],
			[
				'name'     => 'review_author',
				'type'     => 'text',
				'label'    => esc_html__( 'Author Name', 'review-schema-pro' ),
				'required' => true,
			],
			[
				'name'        => 'review_author_sameAs',
				'type'        => 'textarea',
				'label'       => esc_html__( 'Author Same As profile link', 'review-schema-pro' ),
				'placeholder' => 'https://facebook.com/example&#10;https://twitter.com/example',
				'required'    => true,
				'desc'        => wp_kses( __( "A reference page that unambiguously indicates the item's identity; for example, the URL of the item's Wikipedia page, Freebase page, or official website.<br> Enter new line for every entry", 'review-schema-pro' ), [ 'br' => [] ] ),
			],
			[
				'name'     => 'review_body',
				'type'     => 'textarea',
				'label'    => esc_html__( 'Author Review body', 'review-schema-pro' ),
				'required' => true,
				'desc'     => esc_html__( 'The actual body of the review.', 'review-schema-pro' ),
			],
			[
				'name'  => 'review_datePublished',
				'type'  => 'text',
				'label' => esc_html__( 'Author Review published date', 'review-schema-pro' ),
				'class' => 'rtrs-date',
				'desc'  => sprintf( esc_html__( 'Like this: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:sP' ) ),
			],
			[
				'name'  => 'review_ratingValue',
				'type'  => 'float',
				'label' => esc_html__( 'Rating', 'review-schema-pro' ),
				'min'   => 1,
				'desc'  => esc_html__( 'Rating value. (1, 2.5, 3, 5 etc)', 'review-schema-pro' ),
			],
		];
		return [
			'type'        => 'group',
			'name'        => $this->prefix . 'software_app_schema',
			'is_pro'      => true,
			'id'          => 'rtrs-software_app_schema',
			'holderClass' => 'rtrs-hidden rtrs-schema-field',
			'label'       => esc_html__( 'Software app schema', 'review-schema-pro' ),
			'fields'      => $settings_fields,
		];
	}
	/**
	 * Course Schema Fields
	 */
	public function recipeSchemaFields() {
		$settings_fields = [
			[
				'id'     => 'recipe',
				'type'   => 'auto-fill',
				'is_pro' => true,
				'label'  => esc_html__( 'Auto Fill', 'review-schema-pro' ),
			],
			[
				'name'    => 'status',
				'type'    => 'tab',
				'label'   => esc_html__( 'Status', 'review-schema-pro' ),
				'default' => 'show',
				'options' => [
					'show' => esc_html__( 'Show', 'review-schema-pro' ),
					'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
				],
			],
			[
				'name'  => 'name',
				'type'  => 'text',
				'label' => esc_html__( 'Name', 'review-schema-pro' ),
			],
			[
				'name'  => 'author',
				'type'  => 'text',
				'label' => esc_html__( 'Author', 'review-schema-pro' ),
			],
			[
				'name'  => 'description',
				'type'  => 'textarea',
				'label' => esc_html__( 'Description', 'review-schema-pro' ),
			],
			[
				'name'        => 'keywords',
				'type'        => 'text',
				'label'       => esc_html__( 'Recipe keywords', 'review-schema-pro' ),
				'recommended' => true,
				'desc'        => esc_html__( 'Pizza, Nice, Testy', 'review-schema-pro' ),
			],
			[
				'name'        => 'recipeCategory',
				'type'        => 'text',
				'label'       => esc_html__( 'Recipe Category', 'review-schema-pro' ),
				'recommended' => true,
				'desc'        => esc_html__( 'example, appetizer, entree, etc.', 'review-schema-pro' ),
			],
			[
				'name'        => 'recipeCuisine',
				'type'        => 'text',
				'label'       => esc_html__( 'Recipe Cuisine', 'review-schema-pro' ),
				'recommended' => true,
				'desc'        => esc_html__( 'example, French or Ethiopian', 'review-schema-pro' ),
			],
			[
				'name'  => 'prepTime',
				'type'  => 'text',
				'label' => esc_html__( 'Prepare Time', 'review-schema-pro' ),
				'desc'  => esc_html__( 'PT15M', 'review-schema-pro' ),
			],
			[
				'name'  => 'cookTime',
				'type'  => 'text',
				'label' => esc_html__( 'Cook Time', 'review-schema-pro' ),
				'desc'  => esc_html__( 'PT1H', 'review-schema-pro' ),
			],
			[
				'type'   => 'group',
				'name'   => 'ingredient',
				'label'  => esc_html__( 'Recipe Ingredient', 'review-schema-pro' ),
				'fields' => [
					[
						'name'     => 'name',
						'type'     => 'text',
						'label'    => esc_html__( 'Name', 'review-schema-pro' ),
						'required' => true,
					],
				],
			],
			[
				'type'   => 'group',
				'name'   => 'instructions',
				'label'  => esc_html__( 'Recipe Instructions', 'review-schema-pro' ),
				'fields' => [
					[
						'name'  => 'name',
						'type'  => 'text',
						'label' => esc_html__( 'Name', 'review-schema-pro' ),
					],
					[
						'name'  => 'text',
						'type'  => 'textarea',
						'label' => esc_html__( 'Text', 'review-schema-pro' ),
					],
					[
						'name'  => 'image',
						'type'  => 'image',
						'label' => esc_html__( 'Image', 'review-schema-pro' ),
					],
					[
						'name'  => 'url',
						'type'  => 'url',
						'label' => esc_html__( 'URL', 'review-schema-pro' ),
					],
				],
			],
			[
				'name'  => 'calories',
				'type'  => 'text',
				'label' => esc_html__( 'Nutrition: calories', 'review-schema-pro' ),
				'desc'  => esc_html__( '240 calories', 'review-schema-pro' ),
			],
			[
				'name'  => 'fatContent',
				'type'  => 'text',
				'label' => esc_html__( 'Nutrition: Fat Content', 'review-schema-pro' ),
				'desc'  => esc_html__( '9 grams fat', 'review-schema-pro' ),
			],
			[
				'name'  => 'ratingValue',
				'type'  => 'float',
				'label' => esc_html__( 'Average Rating', 'review-schema-pro' ),
				'min'   => 1,
				'desc'  => esc_html__( 'Rating value. (1, 2.5, 3, 5 etc)', 'review-schema-pro' ),
			],
			[
				'name'  => 'reviewCount',
				'type'  => 'float',
				'label' => esc_html__( 'Review Count', 'review-schema-pro' ),
			],
			[
				'name'  => 'bestRating',
				'type'  => 'float',
				'label' => esc_html__( 'Best Rating ( Rating Scale Maximum)', 'review-schema-pro' ),
				'min'   => 1,
			],
			[
				'name'  => 'worstRating',
				'type'  => 'number',
				'label' => esc_html__( 'Worst Rating ( Rating Scale Minimum)', 'review-schema-pro' ),
				'min'   => 1,
			],
			[
				'name'  => 'recipeYield',
				'type'  => 'text',
				'label' => esc_html__( 'Recipe Yield', 'review-schema-pro' ),
				'desc'  => esc_html__( 'Example: 1 loaf. ', 'review-schema-pro' ) . " <a href='https://schema.org/recipeYield' target='_blank'>" . esc_html__( 'Details Here', 'review-schema-pro' ) . '</a>',
			],
			[
				'name'  => 'suitableForDiet',
				'type'  => 'text',
				'label' => esc_html__( 'Suitable ForDiet', 'review-schema-pro' ),
				'desc'  => esc_html__( 'https://schema.org/LowFatDiet', 'review-schema-pro' ),
			],
			[
				'type'      => 'group',
				'duplicate' => false,
				'name'      => 'video',
				'label'     => esc_html__( 'Video Info', 'review-schema-pro' ),
				'fields'    => [
					[
						'name'     => 'name',
						'type'     => 'text',
						'label'    => esc_html__( 'Name', 'review-schema-pro' ),
						'required' => true,
					],
					[
						'name'     => 'description',
						'type'     => 'textarea',
						'label'    => esc_html__( 'Description', 'review-schema-pro' ),
						'required' => true,
					],
					[
						'name'     => 'thumbnailUrl',
						'type'     => 'image',
						'label'    => esc_html__( 'Image', 'review-schema-pro' ),
						'required' => true,
					],
					[
						'name'     => 'contentUrl',
						'type'     => 'url',
						'label'    => esc_html__( 'Content URL', 'review-schema-pro' ),
						'required' => true,
					],
					[
						'name'     => 'embedUrl',
						'type'     => 'url',
						'label'    => esc_html__( 'Embed URL', 'review-schema-pro' ),
						'required' => true,
					],
					[
						'name'     => 'uploadDate',
						'type'     => 'text',
						'label'    => esc_html__( 'Upload Date', 'review-schema-pro' ),
						'class'    => 'rtrs-date',
						'desc'     => sprintf( esc_html__( 'The date (in ISO 8601 date format), Like this: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:sP' ) ),
						'required' => true,
					],
					[
						'name'     => 'duration',
						'type'     => 'text',
						'label'    => esc_html__( 'Duration', 'review-schema-pro' ),
						'desc'     => esc_html__( 'Runtime of the movie in ISO 8601 format (for example, "PT2H22M" (142 minutes)).', 'review-schema-pro' ),
						'required' => true,
					],
				],
			],
			[
				'name'  => 'review_section',
				'type'  => 'heading',
				'label' => esc_html__( 'Review', 'review-schema-pro' ),
				'desc'  => esc_html__( 'To add review schema for this type, complete fields below and enable, others live blank.', 'review-schema-pro' ),
			],
			[
				'name'    => 'review_active',
				'type'    => 'tab',
				'label'   => esc_html__( 'Review Status', 'review-schema-pro' ),
				'default' => 'show',
				'options' => [
					'show' => esc_html__( 'Show', 'review-schema-pro' ),
					'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
				],
			],
			[
				'name'     => 'review_author',
				'type'     => 'text',
				'label'    => esc_html__( 'Author', 'review-schema-pro' ),
				'required' => true,
			],
			[
				'name'        => 'review_author_sameAs',
				'type'        => 'textarea',
				'label'       => esc_html__( 'Author Same As profile link', 'review-schema-pro' ),
				'placeholder' => 'https://facebook.com/example&#10;https://twitter.com/example',
				'required'    => true,
				'desc'        => wp_kses( __( "A reference page that unambiguously indicates the item's identity; for example, the URL of the item's Wikipedia page, Freebase page, or official website.<br> Enter new line for every entry", 'review-schema-pro' ), [ 'br' => [] ] ),
			],
			[
				'name'     => 'review_body',
				'type'     => 'textarea',
				'label'    => esc_html__( 'Review body', 'review-schema-pro' ),
				'required' => true,
				'desc'     => esc_html__( 'The actual body of the review.', 'review-schema-pro' ),
			],
			[
				'name'  => 'review_datePublished',
				'type'  => 'text',
				'label' => esc_html__( 'Review published date', 'review-schema-pro' ),
				'class' => 'rtrs-date',
				'desc'  => sprintf( esc_html__( 'The date (in ISO 8601 date format), Like this: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:sP' ) ),
			],
			[
				'name'  => 'review_ratingValue',
				'type'  => 'float',
				'label' => esc_html__( 'Average Rating', 'review-schema-pro' ),
				'min'   => 1,
				'desc'  => esc_html__( 'Rating value. (1, 2.5, 3, 5 etc)', 'review-schema-pro' ),
			],
			[
				'name'  => 'review_bestRating',
				'type'  => 'float',
				'label' => esc_html__( 'Best Rating ( Rating Scale Maximum)', 'review-schema-pro' ),
				'min'   => 1,
				'desc'  => esc_html__( 'The highest value allowed in this rating.', 'review-schema-pro' ),
			],
			[
				'name'  => 'review_worstRating',
				'type'  => 'number',
				'label' => esc_html__( 'Worst Rating ( Rating Scale Minimum)', 'review-schema-pro' ),
				'min'   => 1,
				'desc'  => esc_html__( 'The lowest value allowed in this rating. * Required if the rating is not on a 5-point scale. If worstRating is omitted, 1 is assumed.', 'review-schema-pro' ),
			],
		];
		return [
			'type'        => 'group',
			'name'        => $this->prefix . 'recipe_schema',
			'is_pro'      => true,
			'id'          => 'rtrs-recipe_schema',
			'holderClass' => 'rtrs-hidden rtrs-schema-field',
			'label'       => esc_html__( 'Recipe schema', 'review-schema-pro' ),
			'fields'      => $settings_fields,
		];
	}

	/**
	 * Course Schema Fields
	 */
	public function jobpostingSchemaFields() {
		$settings_fields = [
			[
				'id'     => 'job_posting',
				'type'   => 'auto-fill',
				'is_pro' => true,
				'label'  => esc_html__( 'Auto Fill', 'review-schema-pro' ),
			],
			[
				'name'    => 'status',
				'type'    => 'tab',
				'label'   => esc_html__( 'Status', 'review-schema-pro' ),
				'default' => 'show',
				'options' => [
					'show' => esc_html__( 'Show', 'review-schema-pro' ),
					'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
				],
			],
			[
				'name'  => 'title',
				'type'  => 'text',
				'label' => esc_html__( 'Title', 'review-schema-pro' ),
			],
			[
				'name'  => 'salaryAmount',
				'type'  => 'float',
				'label' => esc_html__( 'Base Salary', 'review-schema-pro' ),
				'desc'  => esc_html__( '50.00', 'review-schema-pro' ),
			],
			[
				'name'  => 'currency',
				'type'  => 'text',
				'label' => esc_html__( 'Currency', 'review-schema-pro' ),
				'desc'  => esc_html__( 'USD', 'review-schema-pro' ),
			],
			[
				'name'    => 'salaryAt',
				'type'    => 'select',
				'label'   => esc_html__( 'Salary at', 'review-schema-pro' ),
				'options' => [
					'MONTH' => esc_html__( 'MONTH', 'review-schema-pro' ),
					'HOUR'  => esc_html__( 'HOUR', 'review-schema-pro' ),
					'WEEK'  => esc_html__( 'WEEK', 'review-schema-pro' ),
					'YEAR'  => esc_html__( 'YEAR', 'review-schema-pro' ),
				],
			],
			[
				'name'  => 'datePosted',
				'type'  => 'text',
				'label' => esc_html__( 'Job posted date', 'review-schema-pro' ),
				'class' => 'rtrs-date',
				'desc'  => sprintf( esc_html__( 'The date (in ISO 8601 date format), Like this: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:sP' ) ),
			],
			[
				'name'  => 'validThrough',
				'type'  => 'text',
				'label' => esc_html__( 'Valid date through', 'review-schema-pro' ),
				'class' => 'rtrs-date',
				'desc'  => sprintf( esc_html__( 'The date (in ISO 8601 date format), Like this: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:sP' ) ),
			],
			[
				'name'  => 'description',
				'type'  => 'textarea',
				'label' => esc_html__( 'Description', 'review-schema-pro' ),
			],
			[
				'name'    => 'employmentType',
				'type'    => 'select',
				'label'   => esc_html__( 'Employment Type', 'review-schema-pro' ),
				'options' => [
					'FULL_TIME'  => __( 'Full-time', 'review-schema-pro' ),
					'PART_TIME'  => __( 'Part-time', 'review-schema-pro' ),
					'CONTRACTOR' => __( 'Contractor', 'review-schema-pro' ),
					'TEMPORARY'  => __( 'Temporary', 'review-schema-pro' ),
					'INTERN'     => __( 'Internship', 'review-schema-pro' ),
					'VOLUNTEER'  => __( 'Volunteer', 'review-schema-pro' ),
					'PER_DIEM'   => __( 'Per diem', 'review-schema-pro' ),
					'OTHER'      => __( 'Other', 'review-schema-pro' ),
				],
			],
			[
				'name'  => 'workHours',
				'type'  => 'text',
				'label' => esc_html__( 'working Hours', 'review-schema-pro' ),
				'desc'  => esc_html__( '40 hours per week', 'review-schema-pro' ),
			],
			[
				'name'  => 'addressCountry',
				'label' => __( 'Country', 'review-schema-pro' ),
				'type'  => 'text',
				'desc'  => __( 'Ex: US ', 'review-schema-pro' ),
			],
			[
				'name'  => 'addressLocality',
				'type'  => 'text',
				'label' => esc_html__( 'Job location address', 'review-schema-pro' ),
				'desc'  => esc_html__( 'City (i.e Melbourne)', 'review-schema-pro' ),
			],
			[
				'name'  => 'addressRegion',
				'type'  => 'text',
				'label' => esc_html__( 'Job location region', 'review-schema-pro' ),
				'desc'  => esc_html__( 'State (i.e. Victoria)', 'review-schema-pro' ),
			],
			[
				'name'  => 'postalCode',
				'type'  => 'text',
				'label' => esc_html__( 'Location Postal code', 'review-schema-pro' ),
			],
			[
				'name'  => 'streetAddress',
				'type'  => 'text',
				'label' => esc_html__( 'Location street Address', 'review-schema-pro' ),
			],
			[
				'name'  => 'jobBenefits',
				'type'  => 'text',
				'label' => esc_html__( 'Job Benefits', 'review-schema-pro' ),
				'desc'  => esc_html__( 'Medical, Life, Dental', 'review-schema-pro' ),
			],
			[
				'name'  => 'educationRequirements',
				'type'  => 'text',
				'label' => esc_html__( 'Education Requirement.', 'review-schema-pro' ),
				'desc'  => esc_html__( 'Example: Bachelor Degree', 'review-schema-pro' ),
			],
			[
				'name'  => 'experienceRequirements',
				'type'  => 'number',
				'label' => esc_html__( 'Experience Requirements', 'review-schema-pro' ),
				'desc'  => esc_html__( 'Value will be number of month, Like: 2 years = 24', 'review-schema-pro' ),
			],
			[
				'name'        => 'incentiveCompensation',
				'type'        => 'text',
				'label'       => esc_html__( 'Incentive Compensation', 'review-schema-pro' ),
				'placeholder' => 'Example: Performance-based annual bonus plan, project-completion bonuses',
				'desc'        => esc_html__( 'Description of bonus and commission compensation aspects of the job. Supersedes incentives.', 'review-schema-pro' ),

			],
			[
				'name'  => 'industry',
				'type'  => 'text',
				'label' => esc_html__( 'Industry', 'review-schema-pro' ),
				'desc'  => esc_html__( 'The industry associated with the job position.', 'review-schema-pro' ),
			],
			[
				'name'  => 'occupationalCategory',
				'type'  => 'text',
				'label' => esc_html__( 'Occupational Category', 'review-schema-pro' ),
				'desc'  => esc_html__( 'A category describing the job, preferably using a term from a taxonomy such as BLS O*NET-SOC, ISCO-08 or similar', 'review-schema-pro' ),
			],
			[
				'name'  => 'qualifications',
				'type'  => 'textarea',
				'label' => esc_html__( 'Qualifications', 'review-schema-pro' ),
			],
			[
				'name'  => 'responsibilities',
				'type'  => 'textarea',
				'label' => esc_html__( 'Responsibilities', 'review-schema-pro' ),
			],
			[
				'name'  => 'skills',
				'type'  => 'textarea',
				'label' => esc_html__( 'Skills', 'review-schema-pro' ),
			],
		];
		return [
			'type'        => 'group',
			'name'        => $this->prefix . 'job_posting_schema',
			'is_pro'      => true,
			'id'          => 'rtrs-job_posting_schema',
			'holderClass' => 'rtrs-hidden rtrs-schema-field',
			'label'       => esc_html__( 'Job posting schema', 'review-schema-pro' ),
			'fields'      => $settings_fields,
		];
	}

	/**
	 * Course Schema Fields
	 */
	public function courseSchemaFields() {
		$id              = 'course';
		$settings_fields = [
			[
				'id'     => $id,
				'type'   => 'auto-fill',
				'is_pro' => true,
				'label'  => esc_html__( 'Auto Fill', 'review-schema-pro' ),
			],
			[
				'name'    => 'status',
				'type'    => 'tab',
				'label'   => esc_html__( 'Status', 'review-schema-pro' ),
				'default' => 'show',
				'options' => [
					'show' => esc_html__( 'Show', 'review-schema-pro' ),
					'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
				],
			],
			[
				'name'     => 'name',
				'type'     => 'text',
				'label'    => esc_html__( 'Name', 'review-schema-pro' ),
				'required' => true,
			],
			[
				'name'  => 'description',
				'type'  => 'textarea',
				'label' => esc_html__( 'Description', 'review-schema-pro' ),
			],
			[
				'name'  => 'provider',
				'type'  => 'text',
				'label' => esc_html__( 'Provider', 'review-schema-pro' ),
				'desc'  => esc_html__( 'Course Provider / Institute', 'review-schema-pro' ),
			],
			[
				'name'        => 'courseMode',
				'type'        => 'textarea',
				'label'       => esc_html__( 'Course Mode', 'review-schema-pro' ),
				'placeholder' => esc_html__( 'One item per line like bellow', 'review-schema-pro' ),
				'desc'        => wp_kses( __( 'MOOC<br>Online', 'review-schema-pro' ), [ 'br' => [] ] ),
			],

			[
				'name'  => 'duration',
				'label' => __( 'Course Duration', 'review-schema-pro' ),
				'type'  => 'text',
				'desc'  => __( 'Use the 8601 duration format. Ex: PT22H', 'review-schema-pro' ),
			],
			[
				'name'  => 'repeatFrequency',
				'label' => esc_html__( 'Repeat Frequency', 'review-schema-pro' ),
				'type'  => 'text',
				'desc'  => esc_html__( 'Ex: Daily', 'review-schema-pro' ),
			],
			[
				'name'  => 'repeatCount',
				'label' => esc_html__( 'Repeat Count', 'review-schema-pro' ),
				'type'  => 'text',
				'desc'  => esc_html__( 'Ex: 30', 'review-schema-pro' ),
			],

			[
				'name'  => 'startDate',
				'type'  => 'text',
				'label' => esc_html__( 'Start Date', 'review-schema-pro' ),
				'class' => 'rtrs-date',
				'desc'  => esc_html__( '2020-10-16', 'review-schema-pro' ),
			],
			[
				'name'  => 'endDate',
				'type'  => 'text',
				'label' => esc_html__( 'End Date', 'review-schema-pro' ),
				'class' => 'rtrs-date',
				'desc'  => esc_html__( '2020-10-16', 'review-schema-pro' ),
			],
			[
				'name'  => 'address_area',
				'label' => __( 'Address', 'review-schema-' ),
				'type'  => 'heading',
			],
			[
				'name'     => 'locationName',
				'type'     => 'text',
				'label'    => esc_html__( 'Location name', 'review-schema-pro' ),
				'required' => true,
			],
			[
				'name'     => 'locationAddress',
				'type'     => 'text',
				'label'    => esc_html__( 'Street Address', 'review-schema-pro' ),
				'required' => true,
			],
			[
				'name'  => 'addressLocality',
				'type'  => 'text',
				'label' => esc_html__( 'Address locality', 'review-schema-pro' ),
				'desc'  => esc_html__( 'City (i.e Melbourne)', 'review-schema-pro' ),
			],
			[
				'name'  => 'addressRegion',
				'type'  => 'text',
				'label' => esc_html__( 'Address region', 'review-schema-pro' ),
				'desc'  => esc_html__( 'State (i.e. Victoria)', 'review-schema-pro' ),
			],
			[
				'name'  => 'postalCode',
				'type'  => 'text',
				'label' => esc_html__( 'Postal code', 'review-schema-pro' ),
			],
			[
				'name'    => 'addressCountry',
				'label'   => esc_html__( 'Country', 'review-schema-pro' ),
				'type'    => 'select2',
				'options' => Functions::getCountryList(),
				'empty'   => esc_html__( 'Select One', 'review-schema-pro' ),
			],
			[
				'name'  => 'latitude',
				'type'  => 'text',
				'label' => esc_html__( 'GEO Latitude', 'review-schema-pro' ),
			],
			[
				'name'  => 'longitude',
				'type'  => 'text',
				'label' => esc_html__( 'GEO Longitude', 'review-schema-pro' ),
			],

			[
				'name'    => 'category',
				'label'   => 'Category',
				'type'    => 'select',
				'empty'   => 'Select one',
				'default' => 'Paid',
				'options' => [
					'Paid'           => 'Paid',
					'Free'           => 'Free',
					'Partially Free' => 'Partially Free',
					'Subscription'   => 'Subscription',
				],
				'desc'    => __( 'Select Course Category', 'review-schema-pro' ),
			],
			[
				'name'  => 'price',
				'type'  => 'float',
				'min'   => 0,
				'label' => esc_html__( 'Price', 'review-schema-pro' ),
			],
			[
				'name'  => 'priceCurrency',
				'type'  => 'text',
				'label' => esc_html__( 'Price Currency', 'review-schema-pro' ),
				'desc'  => esc_html__( 'The 3-letter currency code. (USD)', 'review-schema-pro' ),
			],
			[
				'name'    => 'availability',
				'type'    => 'select',
				'label'   => esc_html__( 'Availability', 'review-schema-pro' ),
				'empty'   => esc_html__( 'Select one', 'review-schema-pro' ),
				'options' => [
					'https://schema.org/InStock'      => esc_html__( 'InStock', 'review-schema-pro' ),
					'https://schema.org/InStoreOnly'  => esc_html__( 'InStoreOnly', 'review-schema-pro' ),
					'https://schema.org/OutOfStock'   => esc_html__( 'OutOfStock', 'review-schema-pro' ),
					'https://schema.org/SoldOut'      => esc_html__( 'SoldOut', 'review-schema-pro' ),
					'https://schema.org/OnlineOnly'   => esc_html__( 'OnlineOnly', 'review-schema-pro' ),
					'https://schema.org/LimitedAvailability' => esc_html__( 'LimitedAvailability', 'review-schema-pro' ),
					'https://schema.org/Discontinued' => esc_html__( 'Discontinued', 'review-schema-pro' ),
					'https://schema.org/PreOrder'     => esc_html__( 'PreOrder', 'review-schema-pro' ),
				],
				'desc'    => esc_html__( 'Select a availability type', 'review-schema-pro' ),
			],
			[
				'name'  => 'validFrom',
				'type'  => 'text',
				'label' => esc_html__( 'Valid From', 'review-schema-pro' ),
				'class' => 'rtrs-date',
				'desc'  => sprintf( esc_html__( 'The date when the item becomes valid. Like this: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:sP' ) ),
			],
			[
				'name'    => 'performerType',
				'type'    => 'select',
				'label'   => 'Performer Type',
				'options' => [ 'Organization', 'Person' ],
			],
			[
				'name'  => 'performerName',
				'type'  => 'text',
				'label' => esc_html__( 'Performer Name', 'review-schema-pro' ),
			],
			[
				'type'  => 'heading',
				'label' => esc_html__( 'Aggregate Rating', 'review-schema-pro' ),
			],
			[
				'name'  => 'aggregate_ratingValue',
				'type'  => 'float',
				'label' => esc_html__( 'Average Rating', 'review-schema-pro' ),
				'min'   => 1,
				'desc'  => esc_html__( 'Rating value. (1, 2.5, 3, 5 etc)', 'review-schema-pro' ),
			],
			[
				'name'  => 'aggregate_bestRating',
				'type'  => 'float',
				'label' => esc_html__( 'Best Rating ( Rating Scale Maximum)', 'review-schema-pro' ),
				'min'   => 1,
				'desc'  => esc_html__( 'A numerical quality rating for the item.', 'review-schema-pro' ),
			],
			[
				'name'  => 'aggregate_worstRating',
				'type'  => 'number',
				'label' => esc_html__( 'Worst Rating ( Rating Scale Minimum)', 'review-schema-pro' ),
				'min'   => 1,
				'desc'  => esc_html__( 'A numerical quality rating for the item.', 'review-schema-pro' ),
			],
			[
				'name'  => 'aggregate_ratingCount',
				'type'  => 'float',
				'min'   => 0,
				'label' => esc_html__( 'Rating Count', 'review-schema-pro' ),
				'desc'  => esc_html__( 'A numerical quality rating for the item.', 'review-schema-pro' ),
			],
			[
				'name'  => 'review_section',
				'type'  => 'heading',
				'label' => esc_html__( 'Review', 'review-schema-pro' ),
				'desc'  => esc_html__( 'To add review schema for this type, complete fields below and enable, others live blank.', 'review-schema-pro' ),
			],
			[
				'name'    => 'review_active',
				'type'    => 'tab',
				'label'   => esc_html__( 'Status', 'review-schema-pro' ),
				'default' => 'show',
				'options' => [
					'show' => esc_html__( 'Show', 'review-schema-pro' ),
					'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
				],
			],
			[
				'name'     => 'review_author',
				'type'     => 'text',
				'label'    => esc_html__( 'Author', 'review-schema-pro' ),
				'required' => true,
			],
			[
				'name'        => 'review_author_sameAs',
				'type'        => 'textarea',
				'label'       => esc_html__( 'Author Same As profile link', 'review-schema-pro' ),
				'placeholder' => 'https://facebook.com/example&#10;https://twitter.com/example',
				'required'    => true,
				'desc'        => wp_kses( __( "A reference page that unambiguously indicates the item's identity; for example, the URL of the item's Wikipedia page, Freebase page, or official website.<br> Enter new line for every entry", 'review-schema-pro' ), [ 'br' => [] ] ),
			],
			[
				'name'     => 'review_body',
				'type'     => 'textarea',
				'label'    => esc_html__( 'Review body', 'review-schema-pro' ),
				'required' => true,
				'desc'     => esc_html__( 'The actual body of the review.', 'review-schema-pro' ),
			],
			[
				'name'  => 'review_datePublished',
				'type'  => 'text',
				'label' => esc_html__( 'Review published date', 'review-schema-pro' ),
				'class' => 'rtrs-date',
				'desc'  => sprintf( esc_html__( 'The date (in ISO 8601 date format), Like this: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:sP' ) ),
			],
			[
				'name'  => 'review_ratingValue',
				'type'  => 'float',
				'label' => esc_html__( 'Average Rating', 'review-schema-pro' ),
				'min'   => 1,
				'desc'  => esc_html__( 'Rating value. (1, 2.5, 3, 5 etc)', 'review-schema-pro' ),
			],
		];
		return [
			'type'        => 'group',
			'name'        => $this->prefix . 'course_schema',
			'is_pro'      => true,
			'id'          => 'rtrs-course_schema',
			'holderClass' => 'rtrs-hidden rtrs-schema-field',
			'label'       => esc_html__( 'Course schema', 'review-schema-pro' ),
			'fields'      => $settings_fields,
		];
	}

	/**
	 * Real State Listing Fields
	 */
	public function realStateListingSchemaFields() {
		$id              = 'real_state_listing';
		$settings_fields = [
			[
				'id'     => $id,
				'type'   => 'auto-fill',
				'is_pro' => true,
				'label'  => esc_html__( 'Auto Fill', 'review-schema-pro' ),
			],
			[
				'name'    => 'status',
				'type'    => 'tab',
				'label'   => esc_html__( 'Status', 'review-schema-pro' ),
				'default' => 'show',
				'options' => [
					'show' => esc_html__( 'Show', 'review-schema-pro' ),
					'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
				],
			],
			[
				'name'     => 'headline',
				'type'     => 'text',
				'label'    => esc_html__( 'Title', 'review-schema-pro' ),
				'required' => true,
			],
			[
				'name'  => 'description',
				'type'  => 'textarea',
				'label' => esc_html__( 'Description', 'review-schema-pro' ),
				'desc'  => esc_html__( 'Short description', 'review-schema-pro' ),
			],
			[
				'name'     => 'author',
				'type'     => 'text',
				'label'    => esc_html__( 'Author Name', 'review-schema-pro' ),
				'desc'     => esc_html__( 'Author display name', 'review-schema-pro' ),
				'required' => true,
			],
			[
				'name'     => 'author_url',
				'type'     => 'text',
				'label'    => esc_html__( 'Author URL', 'review-schema-pro' ),
				'required' => true,
			],
			[
				'name'     => 'datePosted',
				'type'     => 'text',
				'label'    => esc_html__( 'Published date', 'review-schema-pro' ),
				'class'    => 'rtrs-date',
				'required' => true,
				'desc'     => sprintf( esc_html__( 'The date (in ISO 8601 date format), Like this: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:sP' ) ),
			],
			[
				'name'  => 'award',
				'label' => esc_html__( 'Award', 'review-schema-pro' ),
				'type'  => 'text',
				'desc'  => esc_html__( 'An award won by or for this listing.', 'review-schema-pro' ),
			],
			[
				'name'  => 'price',
				'type'  => 'number',
				'label' => esc_html__( 'Price', 'review-schema-pro' ),
			],
			[
				'name'  => 'priceCurrency',
				'type'  => 'text',
				'label' => esc_html__( 'Price Currency', 'review-schema-pro' ),
				'desc'  => esc_html__( 'The 3-letter currency code. (USD)', 'review-schema-pro' ),
			],
			[
				'name'    => 'availability',
				'type'    => 'select',
				'label'   => esc_html__( 'Availability', 'review-schema-pro' ),
				'empty'   => esc_html__( 'Select one', 'review-schema-pro' ),
				'options' => [
					'https://schema.org/InStock'      => esc_html__( 'InStock', 'review-schema-pro' ),
					'https://schema.org/InStoreOnly'  => esc_html__( 'InStoreOnly', 'review-schema-pro' ),
					'https://schema.org/OutOfStock'   => esc_html__( 'OutOfStock', 'review-schema-pro' ),
					'https://schema.org/SoldOut'      => esc_html__( 'SoldOut', 'review-schema-pro' ),
					'https://schema.org/OnlineOnly'   => esc_html__( 'OnlineOnly', 'review-schema-pro' ),
					'https://schema.org/LimitedAvailability' => esc_html__( 'LimitedAvailability', 'review-schema-pro' ),
					'https://schema.org/Discontinued' => esc_html__( 'Discontinued', 'review-schema-pro' ),
					'https://schema.org/PreOrder'     => esc_html__( 'PreOrder', 'review-schema-pro' ),
				],
				'desc'    => esc_html__( 'Select a availability type', 'review-schema-pro' ),
			],

			[
				'name'  => 'numberOfBedrooms',
				'label' => __( 'The Total number Number Of Bedrooms', 'review-schema-pro' ),
				'type'  => 'number',
				'attr'  => 'step="any"',
			],
			[
				'name'  => 'numberOfRooms',
				'label' => __( 'The Total number Number Of Rooms', 'review-schema-pro' ),
				'type'  => 'number',
				'attr'  => 'step="any"',
			],
			[
				'name'  => 'numberOfBathroomsTotal',
				'label' => __( 'The Total Number Of Bathrooms', 'review-schema-pro' ),
				'type'  => 'number',
				'attr'  => 'step="any"',
			],
			[
				'name'  => 'floorSize',
				'label' => __( 'Floor Size', 'review-schema-pro' ),
				'type'  => 'heading',
			],
			[
				'name'  => 'floorSizeValue',
				'label' => __( 'Value', 'review-schema-pro' ),
				'type'  => 'number',
				'attr'  => 'step="any"',
			],
			[
				'name'  => 'unitCode',
				'label' => __( 'UnitCode', 'review-schema-pro' ),
				'type'  => 'text',
				'desc'  => __( 'EX: MTK, SQF', 'review-schema-pro' ),
			],
			[
				'type'      => 'group',
				'duplicate' => false,
				'name'      => 'addresses',
				'label'     => esc_html__( 'Address', 'review-schema-pro' ),
				'fields'    => [
					[
						'name'  => 'streetAddress',
						'type'  => 'text',
						'label' => esc_html__( 'Street address', 'review-schema-pro' ),
					],
					[
						'name'  => 'addressLocality',
						'type'  => 'text',
						'label' => esc_html__( 'Address locality', 'review-schema-pro' ),
						'desc'  => esc_html__( 'City (i.e Melbourne)', 'review-schema-pro' ),
					],
					[
						'name'  => 'addressRegion',
						'type'  => 'text',
						'label' => esc_html__( 'Address region', 'review-schema-pro' ),
						'desc'  => esc_html__( 'State (i.e. Victoria)', 'review-schema-pro' ),
					],
					[
						'name'  => 'postalCode',
						'type'  => 'text',
						'label' => esc_html__( 'Postal code', 'review-schema-pro' ),
					],
					[
						'name'    => 'addressCountry',
						'label'   => esc_html__( 'Country', 'review-schema-pro' ),
						'type'    => 'select2',
						'options' => Functions::getCountryList(),
						'empty'   => esc_html__( 'Select One', 'review-schema-pro' ),
					],
				],
			],
			[
				'type'      => 'group',
				'duplicate' => false,
				'name'      => 'video',
				'label'     => esc_html__( 'Video Info', 'review-schema-pro' ),
				'fields'    => [
					[
						'name'  => 'name',
						'type'  => 'text',
						'label' => esc_html__( 'Name', 'review-schema-pro' ),
					],
					[
						'name'  => 'description',
						'type'  => 'textarea',
						'label' => esc_html__( 'Description', 'review-schema-pro' ),
					],
					[
						'name'  => 'thumbnailUrl',
						'type'  => 'image',
						'label' => esc_html__( 'Image', 'review-schema-pro' ),
					],
					[
						'name'  => 'contentUrl',
						'type'  => 'url',
						'label' => esc_html__( 'Content URL', 'review-schema-pro' ),
					],
					[
						'name'  => 'embedUrl',
						'type'  => 'url',
						'label' => esc_html__( 'Embed URL', 'review-schema-pro' ),
						'desc'  => esc_html__( 'A URL pointing to the actual video media file. This file should be in .mpg, .mpeg, .mp4, .m4v, .mov, .wmv, .asf, .avi, .ra, .ram, .rm, .flv, or other video file format.', 'review-schema-pro' ),
					],
					[
						'name'  => 'uploadDate',
						'type'  => 'text',
						'label' => esc_html__( 'Upload Date', 'review-schema-pro' ),
						'class' => 'rtrs-date',
						'desc'  => sprintf( esc_html__( 'The date (in ISO 8601 date format), Like this: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:sP' ) ),
					],
					[
						'name'  => 'duration',
						'type'  => 'text',
						'label' => esc_html__( 'Duration', 'review-schema-pro' ),
						'desc'  => esc_html__( 'Runtime of the movie in ISO 8601 format (for example, "PT2H22M" (142 minutes)).', 'review-schema-pro' ),
					],
				],
			],
			[
				'type'      => 'group',
				'duplicate' => false,
				'name'      => 'audio',
				'label'     => esc_html__( 'Audio Info', 'review-schema-pro' ),
				'fields'    => [
					[
						'name'  => 'name',
						'type'  => 'text',
						'label' => esc_html__( 'Name', 'review-schema-pro' ),
						'desc'  => esc_html__( 'The title of the audio', 'review-schema-pro' ),
					],
					[
						'name'  => 'description',
						'type'  => 'textarea',
						'label' => esc_html__( 'Description', 'review-schema-pro' ),
						'desc'  => esc_html__( 'The short description of the audio', 'review-schema-pro' ),
					],
					[
						'name'  => 'duration',
						'type'  => 'text',
						'label' => esc_html__( 'Duration', 'review-schema-pro' ),
						'desc'  => esc_html__( 'The duration of the audio in ISO 8601 format.(PT1M33S)', 'review-schema-pro' ),
					],
					[
						'name'        => 'contentUrl',
						'type'        => 'url',
						'label'       => esc_html__( 'Content URL', 'review-schema-pro' ),
						'placeholder' => esc_html__( 'URL', 'review-schema-pro' ),
						'desc'        => esc_html__( 'A URL pointing to the actual audio media file. This file should be in .mp3, .wav, .mpc or other audio file format.', 'review-schema-pro' ),
					],
					[
						'name'  => 'encodingFormat',
						'type'  => 'text',
						'label' => esc_html__( 'Encoding Format', 'review-schema-pro' ),
						'desc'  => esc_html__( "The encoding format of audio like: 'audio/mpeg'", 'review-schema-pro' ),
					],
				],
			],
		];
		return [
			'type'        => 'group',
			'name'        => $this->prefix . $id . '_schema',
			'id'          => 'rtrs-real_state_listing_schema',
			'is_pro'      => true,
			'holderClass' => 'rtrs-hidden rtrs-schema-field',
			'label'       => esc_html__( 'Real state listing schema', 'review-schema-pro' ),
			'fields'      => $settings_fields,
		];
	}
	/**
	 * Books schema fields.
	 *
	 * @return array
	 */
	public function booksSchemaFields() {
		$id              = 'book';
		$settings_fields = [
			[
				'id'     => $id,
				'type'   => 'auto-fill',
				'is_pro' => true,
				'label'  => esc_html__( 'Auto Fill', 'review-schema-pro' ),
			],
			[
				'name'    => 'status',
				'type'    => 'tab',
				'label'   => esc_html__( 'Status', 'review-schema-pro' ),
				'default' => 'show',
				'options' => [
					'show' => esc_html__( 'Show', 'review-schema-pro' ),
					'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
				],
			],
			[
				'name'     => 'name',
				'type'     => 'text',
				'label'    => esc_html__( 'Name', 'review-schema-pro' ),
				'required' => true,
			],
			[
				'name'     => 'datePublished',
				'type'     => 'text',
				'label'    => esc_html__( 'Published date', 'review-schema-pro' ),
				'class'    => 'rtrs-date',
				'required' => true,
				'desc'     => sprintf( esc_html__( 'The date (in ISO 8601 date format), Like this: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:sP' ) ),
			],
			[
				'name'     => 'author',
				'type'     => 'text',
				'label'    => esc_html__( 'Author', 'review-schema-pro' ),
				'required' => true,
			],
			[
				'name'        => 'author_sameAs',
				'type'        => 'textarea',
				'label'       => esc_html__( 'Author Same As profile link', 'review-schema-pro' ),
				'placeholder' => 'https://facebook.com/example&#10;https://twitter.com/example',
				'required'    => true,
				'desc'        => wp_kses( __( "A reference page that unambiguously indicates the item's identity; for example, the URL of the item's Wikipedia page, Freebase page, or official website.<br> Enter new line for every entry", 'review-schema-pro' ), [ 'br' => [] ] ),
			],
			[
				'name'     => 'bookFormat',
				'type'     => 'select',
				'label'    => esc_html__( 'Book Format', 'review-schema-pro' ),
				'options'  => [ 'EBook', 'Hardcover', 'Paperback', 'AudioBook' ],
				'required' => true,
			],
			[
				'name'     => 'isbn',
				'type'     => 'text',
				'label'    => esc_html__( 'ISBN', 'review-schema-pro' ),
				'required' => true,
				'desc'     => esc_html__( 'The ISBN of the tome. Use the ISBN of the print book instead if there is no ISBN for that edition, such as for a Kindle edition.', 'review-schema-pro' ),
			],
			[
				'name'     => 'workExample',
				'type'     => 'text',
				'label'    => esc_html__( 'Work Example', 'review-schema-pro' ),
				'desc'     => esc_html__( 'Example/instance/realization/derivation of the concept of this creative work. E.g. the paperback edition, first edition, or e-book. Inverse property:', 'review-schema-pro' ),
				'required' => true,
			],
			[
				'name'     => 'sameAs',
				'type'     => 'textarea',
				'label'    => esc_html__( 'Same As', 'review-schema-pro' ),
				'attr'     => 'placeholder="https://example.com/example&#10;https://example.com/example"',
				'required' => true,
				'desc'     => esc_html__( "A reference page that unambiguously indicates the item's identity; for example, the URL of the item's Wikipedia page, Freebase page, or official website.<br> Enter new line for every entry", 'review-schema-pro' ),
			],
			[
				'name'  => 'numberOfPages',
				'type'  => 'number',
				'label' => esc_html__( 'Number of Pages', 'review-schema-pro' ),
			],
			[
				'name'  => 'copyrightHolder',
				'type'  => 'text',
				'label' => esc_html__( 'Copyright Holder', 'review-schema-pro' ),
				'desc'  => esc_html__( 'Holt, Rinehart and Winston', 'review-schema-pro' ),
			],
			[
				'name'  => 'copyrightYear',
				'type'  => 'number',
				'label' => esc_html__( 'Copyright Year', 'review-schema-pro' ),
			],
			[
				'name'  => 'description',
				'type'  => 'textarea',
				'label' => esc_html__( 'Description', 'review-schema-pro' ),
			],
			[
				'name'  => 'genre',
				'type'  => 'text',
				'label' => esc_html__( 'Genre', 'review-schema-pro' ),
				'desc'  => esc_html__( 'Educational Materials', 'review-schema-pro' ),
			],
			[
				'name'  => 'inLanguage',
				'type'  => 'text',
				'label' => esc_html__( 'Language', 'review-schema-pro' ),
				'desc'  => esc_html__( 'en-US', 'review-schema-pro' ),
			],
			[
				'name'  => 'review_section',
				'type'  => 'heading',
				'label' => esc_html__( 'Aggregate Rating', 'review-schema-pro' ),
				'desc'  => esc_html__( 'To add review schema for this type, complete fields below and enable, others live blank.', 'review-schema-pro' ),
			],
			[
				'name'  => 'review_ratingValue',
				'type'  => 'float',
				'label' => esc_html__( 'Average Rating', 'review-schema-pro' ),
				'min'   => 1,
				'desc'  => esc_html__( 'Rating value. (1, 2.5, 3, 5 etc)', 'review-schema-pro' ),
			],
			[
				'name'  => 'review_bestRating',
				'type'  => 'float',
				'label' => esc_html__( 'Best Rating ( Rating Scale Maximum)', 'review-schema-pro' ),
				'min'   => 1,
				'desc'  => esc_html__( 'The highest value allowed in this rating.', 'review-schema-pro' ),
			],
			[
				'name'  => 'review_worstRating',
				'type'  => 'number',
				'label' => esc_html__( 'Worst Rating ( Rating Scale Minimum)', 'review-schema-pro' ),
				'min'   => 1,
				'desc'  => esc_html__( 'The lowest value allowed in this rating. * Required if the rating is not on a 5-point scale. If worstRating is omitted, 1 is assumed.', 'review-schema-pro' ),
			],
			[
				'name'  => 'aggregate_count',
				'type'  => 'number',
				'label' => esc_html__( 'Rating Count', 'review-schema-pro' ),
			],
			[
				'name'    => 'review_active',
				'type'    => 'tab',
				'label'   => esc_html__( 'Review status', 'review-schema-pro' ),
				'default' => 'show',
				'options' => [
					'show' => esc_html__( 'Show', 'review-schema-pro' ),
					'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
				],
			],
			[
				'name'     => 'review_author',
				'type'     => 'text',
				'label'    => esc_html__( 'Author', 'review-schema-pro' ),
				'required' => true,
			],
			[
				'name'  => 'author_ratingValue',
				'type'  => 'float',
				'label' => esc_html__( 'Author Rating', 'review-schema-pro' ),
				'min'   => 1,
				'desc'  => esc_html__( 'Rating value. (1, 2.5, 3, 5 etc)', 'review-schema-pro' ),
			],
			[
				'name'        => 'review_author_sameAs',
				'type'        => 'textarea',
				'label'       => esc_html__( 'Author Same As profile link', 'review-schema-pro' ),
				'placeholder' => 'https://facebook.com/example&#10;https://twitter.com/example',
				'required'    => true,
				'desc'        => wp_kses( __( "A reference page that unambiguously indicates the item's identity; for example, the URL of the item's Wikipedia page, Freebase page, or official website.<br> Enter new line for every entry", 'review-schema-pro' ), [ 'br' => [] ] ),
			],
			[
				'name'     => 'review_body',
				'type'     => 'textarea',
				'label'    => esc_html__( 'Review body', 'review-schema-pro' ),
				'required' => true,
				'desc'     => esc_html__( 'The actual body of the review.', 'review-schema-pro' ),
			],
			[
				'name'  => 'review_datePublished',
				'type'  => 'text',
				'label' => esc_html__( 'Review published date', 'review-schema-pro' ),
				'class' => 'rtrs-date',
				'desc'  => sprintf( esc_html__( 'The date (in ISO 8601 date format), Like this: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:sP' ) ),
			],
		];
		return [
			'type'        => 'group',
			'name'        => $this->prefix . $id . '_schema',
			'id'          => 'rtrs-book_schema',
			'holderClass' => 'rtrs-hidden rtrs-schema-field',
			'label'       => esc_html__( 'Book schema', 'review-schema-pro' ),
			'fields'      => $settings_fields,
		];
	}
	/**
	 * Restaurant Schema Fields
	 *
	 * @return array
	 */
	public function restaurantSchemaFields() {
		$id              = 'Restaurant';
		$settings_fields = [
			[
				'id'     => $id,
				'type'   => 'auto-fill',
				'is_pro' => true,
				'label'  => esc_html__( 'Auto Fill', 'review-schema-pro' ),
			],
			[
				'name'    => 'status',
				'type'    => 'tab',
				'label'   => esc_html__( 'Status', 'review-schema-pro' ),
				'default' => 'show',
				'options' => [
					'show' => esc_html__( 'Show', 'review-schema-pro' ),
					'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
				],
			],
			[
				'name'     => 'name',
				'type'     => 'text',
				'label'    => esc_html__( 'Restaurant Name', 'review-schema-pro' ),
				'required' => true,
			],
			[
				'name'  => 'description',
				'type'  => 'textarea',
				'label' => esc_html__( 'Description', 'review-schema-pro' ),
			],
			[
				'name'  => 'url',
				'type'  => 'text',
				'label' => esc_html__( 'Website URL', 'review-schema-pro' ),
			],
			[
				'name'  => 'image',
				'type'  => 'gallery',
				'label' => esc_html__( 'Gallery Images', 'review-schema-pro' ),
				'desc'  => esc_html__( 'Multiple Image Support', 'review-schema-pro' ),
			],

			[
				'name'  => 'servesCuisine',
				'type'  => 'textarea',
				'label' => esc_html__( 'Serves Cuisine', 'review-schema-pro' ),
			],
			[
				'name'  => 'priceRange',
				'type'  => 'text',
				'label' => esc_html__( 'Price Range', 'review-schema-pro' ),
			],
			[
				'name'  => 'telephone',
				'type'  => 'text',
				'label' => esc_html__( 'Telephone', 'review-schema-pro' ),
			],
			[
				'name'  => 'latitude',
				'type'  => 'text',
				'label' => esc_html__( 'Latitude', 'review-schema-pro' ),
			],
			[
				'name'  => 'longitude',
				'type'  => 'text',
				'label' => esc_html__( 'Longitude', 'review-schema-pro' ),
			],
			[
				'name'      => 'address',
				'type'      => 'group',
				'label'     => esc_html__( 'Address', 'review-schema-pro' ),
				'duplicate' => false,
				'fields'    => [
					[
						'name'  => 'streetAddress',
						'type'  => 'text',
						'label' => esc_html__( 'Street Address', 'review-schema-pro' ),
					],
					[
						'name'  => 'addressLocality',
						'type'  => 'text',
						'label' => esc_html__( 'City', 'review-schema-pro' ),
					],
					[
						'name'  => 'addressRegion',
						'type'  => 'text',
						'label' => esc_html__( 'State/Region', 'review-schema-pro' ),
					],
					[
						'name'  => 'postalCode',
						'type'  => 'text',
						'label' => esc_html__( 'Postal Code', 'review-schema-pro' ),
					],
					[
						'name'  => 'addressCountry',
						'type'  => 'text',
						'label' => esc_html__( 'Country', 'review-schema-pro' ),
					],
				],
			],
			[
				'name'  => 'menu',
				'type'  => 'text',
				'label' => esc_html__( 'Menu URL', 'review-schema-pro' ),
			],
			[
				'name'    => 'acceptsReservations',
				'type'    => 'select',
				'label'   => esc_html__( 'Accepts Reservations', 'review-schema-pro' ),
				'options' => [
					'true'  => esc_html__( 'Yes', 'review-schema-pro' ),
					'false' => esc_html__( 'No', 'review-schema-pro' ),
				],
			],
			[
				'type'   => 'group',
				'name'   => 'menu_sections',
				'label'  => esc_html__( 'Restaurant Menu Sections', 'review-schema-pro' ),
				'fields' => [
					[
						'name'  => 'name',
						'type'  => 'text',
						'label' => esc_html__( 'Name', 'review-schema-pro' ),
					],
					[
						'name'  => 'desc',
						'type'  => 'textarea',
						'label' => esc_html__( 'Description', 'review-schema-pro' ),
					],
					[
						'name'  => 'images',
						'type'  => 'gallery',
						'label' => esc_html__( 'Images', 'review-schema-pro' ),
					],
					[
						'name'  => 'availabilityStarts',
						'type'  => 'text',
						'label' => esc_html__( 'Availability Starts', 'review-schema-pro' ),
						'desc'  => sprintf( esc_html__( 'Like: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:s' ) ),
					],
					[
						'name'  => 'availabilityEnds',
						'type'  => 'text',
						'label' => esc_html__( 'Availability Ends', 'review-schema-pro' ),
						'desc'  => sprintf( esc_html__( 'Like: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:s' ) ),
					],
					[
						'type'   => 'group',
						'name'   => 'menu_items',
						'label'  => esc_html__( 'Menu Items', 'review-schema-pro' ),
						'fields' => [
							[
								'name'  => 'name',
								'type'  => 'text',
								'label' => esc_html__( 'Name', 'review-schema-pro' ),
							],
							[
								'name'  => 'image',
								'type'  => 'image',
								'label' => esc_html__( 'Image', 'review-schema-pro' ),
							],
							[
								'name'  => 'desc',
								'type'  => 'textarea',
								'label' => esc_html__( 'Description', 'review-schema-pro' ),
							],
							[
								'name'  => 'price',
								'type'  => 'text',
								'label' => esc_html__( 'Price', 'review-schema-pro' ),
							],
							[
								'name'  => 'priceCurrency',
								'type'  => 'text',
								'label' => esc_html__( 'Price Currency', 'review-schema-pro' ),
								'desc'  => esc_html__( 'The 3-letter currency code. (USD)', 'review-schema-pro' ),
							],
							[
								'name'  => 'calories',
								'type'  => 'text',
								'label' => esc_html__( 'Calories', 'review-schema-pro' ),
								'desc'  => esc_html__( 'The number of calories.', 'review-schema-pro' ),
							],
							[
								'name'  => 'carbohydrateContent',
								'type'  => 'text',
								'label' => esc_html__( 'Carbohydrates', 'review-schema-pro' ),
								'desc'  => esc_html__( 'The number of grams of carbohydrates.', 'review-schema-pro' ),
							],
							[
								'name'  => 'cholesterolContent',
								'type'  => 'text',
								'label' => esc_html__( 'Cholesterol', 'review-schema-pro' ),
								'desc'  => esc_html__( 'The number of milligrams of cholesterol.', 'review-schema-pro' ),
							],
							[
								'name'  => 'fatContent',
								'type'  => 'text',
								'label' => esc_html__( 'Fat Content', 'review-schema-pro' ),
								'desc'  => esc_html__( 'The number of grams of fat.', 'review-schema-pro' ),
							],
							[
								'name'  => 'fiberContent',
								'type'  => 'text',
								'label' => esc_html__( 'Fiber Content', 'review-schema-pro' ),
								'desc'  => esc_html__( 'The number of grams of fiber.', 'review-schema-pro' ),
							],
							[
								'name'  => 'proteinContent',
								'type'  => 'text',
								'label' => esc_html__( 'Protein Content', 'review-schema-pro' ),
								'desc'  => esc_html__( 'The number of grams of protein.', 'review-schema-pro' ),
							],
							[
								'name'  => 'saturatedFatContent',
								'type'  => 'text',
								'label' => esc_html__( 'Saturated Fat', 'review-schema-pro' ),
								'desc'  => esc_html__( 'The number of grams of saturated fat.', 'review-schema-pro' ),
							],
							[
								'name'  => 'servingSize',
								'type'  => 'text',
								'label' => esc_html__( 'Serving Size', 'review-schema-pro' ),
								'desc'  => esc_html__( 'The serving size, in terms of the number of volume or mass.', 'review-schema-pro' ),
							],
							[
								'name'  => 'sodiumContent',
								'type'  => 'text',
								'label' => esc_html__( 'Sodium', 'review-schema-pro' ),
								'desc'  => esc_html__( 'The number of milligrams of sodium.', 'review-schema-pro' ),
							],
							[
								'name'  => 'sugarContent',
								'type'  => 'text',
								'label' => esc_html__( 'Sugar', 'review-schema-pro' ),
								'desc'  => esc_html__( 'The number of grams of sugar.', 'review-schema-pro' ),
							],
							[
								'name'  => 'transFatContent',
								'type'  => 'text',
								'label' => esc_html__( 'Trans Fat', 'review-schema-pro' ),
								'desc'  => esc_html__( 'The number of grams of trans fat.', 'review-schema-pro' ),
							],
							[
								'name'  => 'unsaturatedFatContent',
								'type'  => 'text',
								'label' => esc_html__( 'Unsaturated Fat', 'review-schema-pro' ),
								'desc'  => esc_html__( 'The number of grams of unsaturated fat.', 'review-schema-pro' ),
							],
							[
								'name'  => 'suitableForDiet',
								'type'  => 'text',
								'label' => esc_html__( 'Suitable For Diet', 'review-schema-pro' ),
								'desc'  => esc_html__( 'Example: https://schema.org/GlutenFreeDiet', 'review-schema-pro' ),
							],
						],
					],
				],
			],
			[
				'type'   => 'group',
				'name'   => 'openingHours',
				'label'  => esc_html__( 'Opening Hours By Day', 'review-schema-pro' ),
				'fields' => [
					[
						'name'    => 'dayOfWeek',
						'type'    => 'select',
						'label'   => esc_html__( 'Day', 'review-schema-pro' ),
						'empty'   => esc_html__( 'Select one', 'review-schema-pro' ),
						'options' => [
							'Monday'    => esc_html__( 'Monday', 'review-schema-pro' ),
							'Tuesday'   => esc_html__( 'Tuesday', 'review-schema-pro' ),
							'Wednesday' => esc_html__( 'Wednesday', 'review-schema-pro' ),
							'Thursday'  => esc_html__( 'Thursday', 'review-schema-pro' ),
							'Friday'    => esc_html__( 'Friday', 'review-schema-pro' ),
							'Saturday'  => esc_html__( 'Saturday', 'review-schema-pro' ),
							'Sunday'    => esc_html__( 'Sunday', 'review-schema-pro' ),
						],
						'desc'    => esc_html__( "Don't add same day multiple time", 'review-schema-pro' ),
					],
					[
						'name'  => 'opens',
						'type'  => 'text',
						'label' => esc_html__( 'Opens Time', 'review-schema-pro' ),
						'desc'  => esc_html__( 'Times are specified using 24:00 time. For example, 3PM is specified as 15:00.', 'review-schema-pro' ),
					],
					[
						'name'  => 'closes',
						'type'  => 'text',
						'label' => esc_html__( 'Closes Time', 'review-schema-pro' ),
					],
				],
			],
			[
				'name'      => 'review',
				'type'      => 'group',
				'label'     => esc_html__( 'Review', 'review-schema-pro' ),
				'duplicate' => false,
				'fields'    => [
					[
						'name'  => 'author',
						'type'  => 'text',
						'label' => esc_html__( 'Review Author', 'review-schema-pro' ),
					],
					[
						'name'  => 'author_url',
						'type'  => 'text',
						'label' => esc_html__( 'Author Url', 'review-schema-pro' ),
					],
					[
						'name'  => 'ratingValue',
						'type'  => 'number',
						'label' => esc_html__( 'Rating Value', 'review-schema-pro' ),
						'min'   => 1,
					],
				],
			],
			[
				'name'  => 'aggregate_value',
				'type'  => 'number',
				'label' => esc_html__( 'Aggregate Rating Value', 'review-schema-pro' ),
			],
			[
				'name'    => 'bestRating',
				'type'    => 'number',
				'label'   => esc_html__( 'Best Rating ( Rating Scale Maximum)', 'review-schema-pro' ),
				'default' => 5,
				'min'     => 1,
			],
			[
				'name'  => 'worstRating',
				'type'  => 'number',
				'label' => esc_html__( 'Worst Rating ( Rating Scale Minimum)', 'review-schema-pro' ),
				'min'   => 1,
				'desc'  => esc_html__( 'The lowest value allowed in this rating. * Required if the rating is not on a 5-point scale. If worstRating is omitted, 1 is assumed.', 'review-schema-pro' ),
			],
			[
				'name'  => 'aggregate_count',
				'type'  => 'number',
				'label' => esc_html__( 'Rating Count', 'review-schema-pro' ),
			],
			[
				'name'        => 'sameAs',
				'type'        => 'textarea',
				'label'       => esc_html__( 'Social Profiles', 'review-schema-pro' ),
				'placeholder' => 'https://facebook.com/example&#10;https://twitter.com/example',
				'desc'        => wp_kses( __( "A reference page that unambiguously indicates the item's identity; for example, the URL of the item's Wikipedia page, Freebase page, or official website.<br> Enter new line for every entry", 'review-schema-pro' ), [ 'br' => [] ] ),
			],

		];

		return [
			'type'        => 'group',
			'name'        => $this->prefix . $id . '_schema',
			'id'          => 'rtrs-' . $id . '_schema',
			'holderClass' => 'rtrs-hidden rtrs-schema-field',
			'label'       => esc_html__( 'Restaurant Schema', 'review-schema-pro' ),
			'fields'      => $settings_fields,
		];
	}

	/**
	 * Dataset Schema Fields
	 *
	 * @return array
	 */
	public function datasetSchemaFields() {
		$id              = 'Dataset';
		$settings_fields = [
			[
				'id'     => $id,
				'type'   => 'auto-fill',
				'is_pro' => true,
				'label'  => esc_html__( 'Auto Fill', 'review-schema-pro' ),
			],
			[
				'name'    => 'status',
				'type'    => 'tab',
				'label'   => esc_html__( 'Status', 'review-schema-pro' ),
				'default' => 'show',
				'options' => [
					'show' => esc_html__( 'Show', 'review-schema-pro' ),
					'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
				],
			],
			[
				'name'     => 'name',
				'type'     => 'text',
				'label'    => esc_html__( 'Dataset Name', 'review-schema-pro' ),
				'required' => true,
			],
			[
				'name'  => 'description',
				'type'  => 'textarea',
				'label' => esc_html__( 'Description', 'review-schema-pro' ),
			],
			[
				'name'        => 'sameAs',
				'type'        => 'textarea',
				'label'       => esc_html__( 'Same As', 'review-schema-pro' ),
				'placeholder' => 'https://example.com/example1&#10;https://example.com/example2',
				'desc'        => esc_html__( "A reference page that unambiguously indicates the item's identity; for example, the URL of the item's Wikipedia page, Freebase page, or official website.<br> Enter new line for every entry", 'review-schema-pro' ),
			],
			[
				'name'      => 'identifier',
				'label'     => esc_html__( 'Identifier(s)', 'review-schema-pro' ),
				'desc'      => esc_html__( 'A unique ID or permanent URL for the dataset, such as a DOI or repository link.', 'review-schema-pro' ),
				'type'      => 'group',
				'duplicate' => true,
				'fields'    => [
					[
						'name'  => 'id_url',
						'type'  => 'url',
						'label' => esc_html__( 'Identifier URL', 'review-schema-pro' ),
					],
				],
			],
			[
				'name'      => 'keywords',
				'label'     => esc_html__( 'Keywords', 'review-schema-pro' ),
				'type'      => 'group',
				'duplicate' => true,
				'fields'    => [
					[
						'name'  => 'keyword',
						'type'  => 'text',
						'label' => esc_html__( 'Keyword', 'review-schema-pro' ),
					],
				],
			],
			[
				'name'  => 'license',
				'type'  => 'url',
				'label' => esc_html__( 'License URL', 'review-schema-pro' ),
			],
			[
				'name'    => 'isAccessibleForFree',
				'type'    => 'checkbox',
				'label'   => esc_html__( 'Is Accessible for Free?', 'review-schema-pro' ),
				'default' => true,
			],
			[
				'name'      => 'hasPart',
				'label'     => esc_html__( 'Sub Datasets', 'review-schema-pro' ),
				'type'      => 'group',
				'duplicate' => true,
				'fields'    => [
					[
						'name'  => 'name',
						'type'  => 'text',
						'label' => esc_html__( 'Sub Dataset Name', 'review-schema-pro' ),
					],
					[
						'name'  => 'description',
						'type'  => 'textarea',
						'label' => esc_html__( 'Sub Dataset Description', 'review-schema-pro' ),
					],
					[
						'name'  => 'license',
						'type'  => 'url',
						'label' => esc_html__( 'Sub Dataset License URL', 'review-schema-pro' ),
					],
					[
						'name'  => 'creator_name',
						'type'  => 'text',
						'label' => esc_html__( 'Creator Name', 'review-schema-pro' ),
					],
				],
			],
			[
				'name'      => 'creator',
				'label'     => esc_html__( 'Creator', 'review-schema-pro' ),
				'type'      => 'group',
				'duplicate' => false,
				'fields'    => [
					[
						'name'  => 'name',
						'type'  => 'text',
						'label' => esc_html__( 'Creator Name', 'review-schema-pro' ),
					],
					[
						'name'  => 'url',
						'type'  => 'url',
						'label' => esc_html__( 'Creator URL', 'review-schema-pro' ),
					],
					[
						'name'  => 'contactType',
						'type'  => 'text',
						'label' => esc_html__( 'Contact Type', 'review-schema-pro' ),
					],
					[
						'name'  => 'telephone',
						'type'  => 'text',
						'label' => esc_html__( 'Telephone', 'review-schema-pro' ),
					],
					[
						'name'  => 'email',
						'type'  => 'text',
						'label' => esc_html__( 'Email', 'review-schema-pro' ),
					],

				],
			],
			[
				'name'  => 'funder',
				'type'  => 'text',
				'label' => esc_html__( 'Funder Name', 'review-schema-pro' ),
			],
			[
				'name'        => 'funder_sameAs',
				'type'        => 'textarea',
				'label'       => esc_html__( 'Funder SameAs URL', 'review-schema-pro' ),
				'placeholder' => 'https://example.com/example1&#10;https://example.com/example2',
			],
			[
				'name'  => 'includedInDataCatalog',
				'type'  => 'text',
				'label' => esc_html__( 'Data Catalog Name', 'review-schema-pro' ),
			],
			[
				'name'      => 'distribution',
				'label'     => esc_html__( 'Distributions', 'review-schema-pro' ),
				'type'      => 'group',
				'duplicate' => true,
				'fields'    => [
					[
						'name'  => 'encodingFormat',
						'type'  => 'text',
						'label' => esc_html__( 'Encoding Format', 'review-schema-pro' ),
					],
					[
						'name'  => 'contentUrl',
						'type'  => 'url',
						'label' => esc_html__( 'Download URL', 'review-schema-pro' ),
					],
				],
			],
			[
				'name'  => 'temporalCoverage',
				'type'  => 'text',
				'label' => esc_html__( 'Temporal Coverage', 'review-schema-pro' ),
				'desc'  => esc_html__( 'Example: 1950-01-01/2013-12-18', 'review-schema-pro' ),
			],
			[
				'name'  => 'spatialCoverageBox',
				'type'  => 'text',
				'label' => esc_html__( 'Geo Box', 'review-schema-pro' ),
				'desc'  => esc_html__( 'Format: Latitude1 Longitude1 Latitude2 Longitude2. Example: 20.59 88.01 26.63 92.67 ', 'review-schema-pro' ),
			],
		];
		return [
			'type'        => 'group',
			'name'        => $this->prefix . $id . '_schema',
			'id'          => 'rtrs-' . $id . '_schema',
			'holderClass' => 'rtrs-hidden rtrs-schema-field',
			'label'       => esc_html__( 'Dataset Schema', 'review-schema-pro' ),
			'fields'      => $settings_fields,
		];
	}

	/**
	 * DiscussionForumPosting Schema Fields
	 *
	 * Returns the settings fields array used to render the DiscussionForumPosting meta fields
	 * in the admin. Fields are organised to match your plugin conventions (group, duplicate, rtrs-date).
	 *
	 * @return array Settings fields for DiscussionForumPosting schema.
	 */
	public function discussionForumPostingSchemaFields() {
		$id              = 'DiscussionForumPosting';
		$settings_fields = [
			[
				'id'     => $id,
				'type'   => 'auto-fill',
				'is_pro' => true,
				'label'  => esc_html__( 'Auto Fill', 'review-schema-pro' ),
			],
			[
				'name'    => 'status',
				'type'    => 'tab',
				'label'   => esc_html__( 'Status', 'review-schema-pro' ),
				'default' => 'show',
				'options' => [
					'show' => esc_html__( 'Show', 'review-schema-pro' ),
					'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
				],
			],
			[
				'name'     => 'name',
				'type'     => 'text',
				'label'    => esc_html__( 'Headline', 'review-schema-pro' ),
				'required' => true,
			],
			// Basic post info.
			[
				'name'  => 'text',
				'label' => esc_html__( 'Post Text', 'review-schema-pro' ),
				'type'  => 'textarea',
			],
			// VideoObject.
			[
				'name'   => 'video_fields',
				'label'  => esc_html__( 'Video', 'review-schema-pro' ),
				'type'   => 'group',
				'fields' => [
					[
						'name'  => 'contentUrl',
						'label' => esc_html__( 'Video URL', 'review-schema-pro' ),
						'desc'  => esc_html__( 'Google expects a direct link to a video file (like .mp4) for that property.', 'review-schema-pro' ),
						'type'  => 'url',
					],
					[
						'name'  => 'embedUrl',
						'label' => esc_html__( 'Embed Video URL', 'review-schema-pro' ),
						'type'  => 'url',
						'desc'  => esc_html__( 'Example: https://www.youtube.com/embed/iUtnZpzkbG8', 'review-schema-pro' ),
					],
					[
						'name'  => 'name',
						'label' => esc_html__( 'Video Name', 'review-schema-pro' ),
						'type'  => 'text',
					],
					[
						'name'  => 'uploadDate',
						'label' => esc_html__( 'Video Upload Date', 'review-schema-pro' ),
						'type'  => 'text',
						'desc'  => sprintf( esc_html__( 'ISO 8601 date format. Like: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:sP' ) ),
					],
					[
						'name'  => 'thumbnailUrl',
						'label' => esc_html__( 'Thumbnail URL', 'review-schema-pro' ),
						'type'  => 'url',
					],
					[
						'name'  => 'description',
						'type'  => 'textarea',
						'label' => esc_html__( 'Description', 'review-schema-pro' ),
					],
				],
			],

			// Author.
			[
				'name'      => 'author',
				'label'     => esc_html__( 'Author', 'review-schema-pro' ),
				'type'      => 'group',
				'duplicate' => false,
				'fields'    => [
					[
						'name'  => 'name',
						'label' => esc_html__( 'Author Name', 'review-schema-pro' ),
						'type'  => 'text',
					],
					[
						'name'  => 'url',
						'label' => esc_html__( 'Author URL', 'review-schema-pro' ),
						'type'  => 'url',
					],
					// agentInteractionStatistic.
					[
						'name'   => 'agentInteractionStatistic',
						'label'  => esc_html__( 'Agent Interaction Statistic', 'review-schema-pro' ),
						'type'   => 'group',
						'fields' => [
							[
								'name'  => 'interactionType',
								'label' => esc_html__( 'Interaction Type', 'review-schema-pro' ),
								'type'  => 'text',
								'desc'  => esc_html__( 'Example: https://schema.org/CommentAction', 'review-schema-pro' ) . ' <a target="_blank" href="https://schema.org/CommunicateAction">View Details</a>',
							],
							[
								'name'  => 'userInteractionCount',
								'label' => esc_html__( 'User Interaction Count', 'review-schema-pro' ),
								'type'  => 'number',
							],
						],
					],
				],
			],

			// Post InteractionStatistic.
			[
				'name'   => 'interactionStatistic',
				'label'  => esc_html__( 'Post Interaction Statistic', 'review-schema-pro' ),
				'type'   => 'group',
				'fields' => [
					[
						'name'  => 'interactionType',
						'label' => esc_html__( 'Interaction Type', 'review-schema-pro' ),
						'type'  => 'text',
						'desc'  => esc_html__( 'Example: https://schema.org/CommentAction', 'review-schema-pro' ) . ' <a target="_blank" href="https://schema.org/CommunicateAction">View Details</a>',
					],
					[
						'name'  => 'userInteractionCount',
						'label' => esc_html__( 'User Interaction Count', 'review-schema-pro' ),
						'type'  => 'number',
						'desc'  => esc_html__( 'Important: This number must match the number of comment objects provided below. If you only list 1 comment in the schema, set this count to 1 to avoid Google validation errors.', 'review-schema-pro' ),
					],
				],
			],

			// Comments (repeatable).
			[
				'name'      => 'comment',
				'label'     => esc_html__( 'Comments', 'review-schema-pro' ),
				'desc'      => esc_html__( 'Ensure this matches the number of comments listed below.', 'review-schema-pro' ),
				'type'      => 'group',
				'duplicate' => true,
				'fields'    => [

					// Comment text.
					[
						'name'  => 'text',
						'label' => esc_html__( 'Comment Text', 'review-schema-pro' ),
						'type'  => 'textarea',
					],

					// Comment author.
					[
						'name'      => 'author',
						'label'     => esc_html__( 'Comment Author', 'review-schema-pro' ),
						'type'      => 'group',
						'duplicate' => false,
						'fields'    => [
							[
								'name'  => 'name',
								'label' => esc_html__( 'Author Name', 'review-schema-pro' ),
								'type'  => 'text',
							],
							[
								'name'  => 'url',
								'label' => esc_html__( 'Author URL', 'review-schema-pro' ),
								'type'  => 'url',
							],
						],
					],

					// Comment date.
					[
						'name'  => 'datePublished',
						'label' => esc_html__( 'Comment Date Published', 'review-schema-pro' ),
						'type'  => 'text',
						'desc'  => sprintf( esc_html__( 'ISO 8601 date format. Like: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:sP' ) ),
					],

					// Comment interaction stats (optional).
					[
						'name'   => 'interactionStatistic',
						'label'  => esc_html__( 'Comment Interaction Statistic', 'review-schema-pro' ),
						'type'   => 'group',
						'fields' => [
							[
								'name'  => 'interactionType',
								'label' => esc_html__( 'Interaction Type', 'review-schema-pro' ),
								'type'  => 'text',
								'desc'  => esc_html__( 'Example: https://schema.org/CommentAction', 'review-schema-pro' ) . ' <a target="_blank" href="https://schema.org/CommunicateAction">View Details</a>',
							],
							[
								'name'  => 'userInteractionCount',
								'label' => esc_html__( 'User Interaction Count', 'review-schema-pro' ),
								'type'  => 'number',
							],
						],
					],

				],
			],

		];
		return [
			'type'        => 'group',
			'name'        => $this->prefix . $id . '_schema',
			'id'          => 'rtrs-' . $id . '_schema',
			'holderClass' => 'rtrs-hidden rtrs-schema-field',
			'label'       => esc_html__( 'Discussion Forum Posting Schema', 'review-schema-pro' ),
			'fields'      => $settings_fields,
		];
	}

	/**
	 * Undocumented function
	 *
	 * @return array
	 */
	public function tv_series_schema_fields() {
		$id = 'tv_series';
		// Collection page.
		$settings_fields = [
			'type'        => 'group',
			'name'        => $this->prefix . $id . '_schema',
			'id'          => 'rtrs-' . $id . '_schema',
			'holderClass' => 'rtrs-hidden rtrs-schema-field',
			'label'       => esc_html__( 'TV Series schema', 'review-schema-pro' ),
			'fields'      => [
				[
					'id'     => $id,
					'type'   => 'auto-fill',
					'is_pro' => true,
					'label'  => esc_html__( 'Auto Fill', 'review-schema-pro' ),
				],
				[
					'name'    => 'status',
					'type'    => 'tab',
					'label'   => esc_html__( 'Status', 'review-schema-pro' ),
					'default' => 'show',
					'options' => [
						'show' => esc_html__( 'Show', 'review-schema-pro' ),
						'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
					],
				],
				[
					'name'     => 'name',
					'type'     => 'text',
					'label'    => esc_html__( 'Name', 'review-schema-pro' ),
					'required' => true,
				],
				[
					'name'    => 'author-type',
					'type'    => 'select',
					'label'   => esc_html__( 'Author Type', 'review-schema-pro' ),
					'empty'   => esc_html__( 'Select one', 'review-schema-pro' ),
					'options' => [
						'Person'       => esc_html__( 'Person', 'review-schema-pro' ),
						'Organization' => esc_html__( 'Organization', 'review-schema-pro' ),
					],
				],
				[
					'name'        => 'author',
					'type'        => 'text',
					'label'       => esc_html__( 'Author', 'review-schema-pro' ),
					'placeholder' => esc_html__( 'Author Name', 'review-schema-pro' ),
				],
				[
					'type'   => 'group',
					'name'   => 'actor',
					'label'  => esc_html__( 'Actor\'s', 'review-schema-pro' ),
					'fields' => [
						[
							'name'  => 'actor-name',
							'type'  => 'text',
							'label' => esc_html__( 'Actor Name', 'review-schema-pro' ),
						],
						[
							'name'  => 'characterName',
							'type'  => 'text',
							'label' => esc_html__( 'Character Name', 'review-schema-pro' ),
						],
					],
				],
				[
					'name'     => 'description',
					'type'     => 'textarea',
					'label'    => esc_html__( 'Description', 'review-schema-pro' ),
					'required' => true,
				],
				[
					'type'   => 'group',
					'name'   => 'season',
					'label'  => esc_html__( 'Season', 'review-schema-pro' ),
					'fields' => [
						[
							'name'  => 'season-name',
							'type'  => 'text',
							'label' => esc_html__( 'Season Name', 'review-schema-pro' ),
						],
						[
							'name'  => 'date-published',
							'type'  => 'text',
							'label' => esc_html__( 'Published Date', 'review-schema-pro' ),
							'class' => 'rtrs-date',
							'desc'  => sprintf( esc_html__( 'ISO 8601 date format. Like: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:sP' ) ),
						],
						[
							'name'  => 'number-of-episodes',
							'type'  => 'number',
							'label' => esc_html__( 'Number Of Episodes', 'review-schema-pro' ),
						],
						[
							'type'   => 'group',
							'name'   => 'episode',
							'label'  => esc_html__( 'Episode', 'review-schema-pro' ),
							'fields' => [
								[
									'name'  => 'episode-name',
									'type'  => 'text',
									'label' => esc_html__( 'Episode Name', 'review-schema-pro' ),
								],
								[
									'name'  => 'episode-number',
									'type'  => 'number',
									'label' => esc_html__( 'Episode Number', 'review-schema-pro' ),
								],
							],
						],
					],
				],
			],
		];
		return $settings_fields;
	}
	/**
	 * Collection Page Schema Fields
	 */
	public function CollectionPageSchemaFields() {
		$id = 'collection_page';
		// Collection page.
		$settings_fields = [
			'type'        => 'group',
			'name'        => $this->prefix . $id . '_schema',
			'id'          => 'rtrs-' . $id . '_schema',
			'holderClass' => 'rtrs-hidden rtrs-schema-field',
			'label'       => esc_html__( 'Collection Page', 'review-schema-pro' ),
			'fields'      => [
				[
					'id'     => $id,
					'type'   => 'auto-fill',
					'is_pro' => true,
					'label'  => esc_html__( 'Auto Fill', 'review-schema-pro' ),
				],
				[
					'name'    => 'status',
					'type'    => 'tab',
					'label'   => esc_html__( 'Status', 'review-schema-pro' ),
					'default' => 'show',
					'options' => [
						'show' => esc_html__( 'Show', 'review-schema-pro' ),
						'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
					],
				],
				[
					'name'     => 'name',
					'type'     => 'text',
					'label'    => esc_html__( 'Headline', 'review-schema-pro' ),
					'desc'     => esc_html__( 'Title', 'review-schema-pro' ),
					'required' => true,
				],
				[
					'name'  => 'description',
					'label' => __( 'Description', 'review-schema-pro' ),
					'type'  => 'textarea',
					'desc'  => __( 'Short description. New line is not supported.', 'review-schema-pro' ),
				],
				[
					'type'   => 'group',
					'name'   => 'itempage',
					'label'  => esc_html__( 'Item page', 'review-schema-pro' ),
					'fields' => [
						[
							'name'     => 'itempage-name',
							'type'     => 'text',
							'label'    => esc_html__( 'Name', 'review-schema-pro' ),
							'desc'     => esc_html__( 'Title', 'review-schema-pro' ),
							'required' => true,
						],
						[
							'name'  => 'itempage-description',
							'type'  => 'textarea',
							'label' => esc_html__( 'Description', 'review-schema-pro' ),
						],
						[
							'name'  => 'mainEntityOfPage',
							'label' => __( 'Main Entity Page url', 'review-schema-pro' ),
							'type'  => 'url',
						],
					],
				],
			],
		];
		return $settings_fields;
	}

	/**
	 * Vacation Rental Schema Fields
	 *
	 * Defines admin fields used to generate VacationRental structured data
	 * according to schema.org and Google Vacation Rental guidelines.
	 *
	 * @return array
	 */
	public function vacationRentalSchemaFields() {
		// Vacation Rental.
		$id              = 'vacation_rental';
		$settings_fields = [
			'type'        => 'group',
			'name'        => $this->prefix . $id . '_schema',
			'id'          => 'rtrs-' . $id . '_schema',
			'holderClass' => 'rtrs-hidden rtrs-schema-field',
			'label'       => esc_html__( 'Vacation Rental', 'review-schema-pro' ),
			'fields'      => [
				[
					'id'     => $id,
					'type'   => 'auto-fill',
					'is_pro' => true,
					'label'  => esc_html__( 'Auto Fill', 'review-schema-pro' ),
					'desc'   => esc_html__( 'Automatically populate schema fields from post content when possible.', 'review-schema-pro' ),
				],
				[
					'name'    => 'status',
					'type'    => 'tab',
					'label'   => esc_html__( 'Status', 'review-schema-pro' ),
					'default' => 'show',
					'desc'    => esc_html__( 'Show or hide Vacation Rental schema output on the page.', 'review-schema-pro' ),
					'options' => [
						'show' => esc_html__( 'Show', 'review-schema-pro' ),
						'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
					],
				],
				[
					'name'     => 'name',
					'type'     => 'text',
					'label'    => esc_html__( 'Headline', 'review-schema-pro' ),
					'desc'     => esc_html__( 'The official name of the vacation rental listing.', 'review-schema-pro' ),
					'required' => true,
				],
				[
					'name'        => 'additionalType',
					'label'       => __( 'Additional Type', 'review-schema-pro' ),
					'type'        => 'text',
					'recommended' => true,
					'desc'        => __( 'Optional subtype such as HolidayVillageRental or ApartmentRental.', 'review-schema-pro' ) .
						' <a target="_blank" href="https://developers.google.com/search/docs/appearance/structured-data/vacation-rental">Docs</a>',
				],
				[
					'name'        => 'description',
					'label'       => __( 'Description', 'review-schema-pro' ),
					'type'        => 'text',
					'recommended' => true,
					'desc'        => __( 'A concise summary describing the vacation rental and its main features.', 'review-schema-pro' ),
				],

				[
					'name'  => 'priceRange',
					'label' => __( 'Price Range', 'review-schema-pro' ),
					'type'  => 'text',
					'desc'  => __( 'Typical nightly price range. Example: $200 - $500 per night.', 'review-schema-pro' ),
				],

				[
					'name'  => 'telephone',
					'label' => __( 'Telephone', 'review-schema-pro' ),
					'type'  => 'text',
					'desc'  => __( 'Primary contact phone number for inquiries or bookings.', 'review-schema-pro' ),
				],
				[
					'name'     => 'identifier',
					'label'    => __( 'Identifier', 'review-schema-pro' ),
					'type'     => 'text',
					'required' => true,
					'desc'     => __( 'A unique identifier for this rental (internal ID, SKU, or reference code).', 'review-schema-pro' ),
				],
				[
					'name'     => 'latitude',
					'label'    => __( 'Latitude', 'review-schema-pro' ),
					'type'     => 'text',
					'required' => true,
					'desc'     => __( 'Geographic latitude of the rental location.', 'review-schema-pro' ),
				],
				[
					'name'     => 'longitude',
					'label'    => __( 'Longitude', 'review-schema-pro' ),
					'type'     => 'text',
					'required' => true,
					'desc'     => __( 'Geographic longitude of the rental location.', 'review-schema-pro' ),
				],
				[
					'name'  => 'containsPlace',
					'label' => __( 'Contains Place', 'review-schema-pro' ),
					'type'  => 'heading',
					'desc'  => __( 'Details about the accommodation included in this vacation rental.', 'review-schema-pro' ),
				],
				[
					'name'    => 'containsPlaceType',
					'label'   => __( 'Accommodation Type', 'review-schema-pro' ),
					'type'    => 'select',
					'empty'   => 'Select one',
					'desc'    => __( 'Specify whether guests rent the entire place, a private room, or a shared room.', 'review-schema-pro' ),
					'options' => [
						'EntirePlace' => 'EntirePlace',
						'PrivateRoom' => 'PrivateRoom',
						'SharedRoom'  => 'SharedRoom',
					],
				],
				[
					'name'  => 'occupancy',
					'label' => __( 'Occupancy Value', 'review-schema-pro' ),
					'type'  => 'number',
					'attr'  => 'step="any"',
					'desc'  => __( 'Maximum number of guests allowed to stay.', 'review-schema-pro' ),
				],
				[
					'name'  => 'numberOfBathroomsTotal',
					'label' => __( 'Total Bathrooms', 'review-schema-pro' ),
					'type'  => 'number',
					'attr'  => 'step="any"',
					'desc'  => __( 'Total number of bathrooms available to guests.', 'review-schema-pro' ),
				],
				[
					'name'  => 'numberOfBedrooms',
					'label' => __( 'Total Bedrooms', 'review-schema-pro' ),
					'type'  => 'number',
					'attr'  => 'step="any"',
					'desc'  => __( 'Total number of bedrooms in the rental.', 'review-schema-pro' ),
				],
				[
					'name'  => 'numberOfRooms',
					'label' => __( 'Total Rooms', 'review-schema-pro' ),
					'type'  => 'number',
					'attr'  => 'step="any"',
					'desc'  => __( 'Total number of rooms including bedrooms and common areas.', 'review-schema-pro' ),
				],
				[
					'name'  => 'floorSize',
					'label' => __( 'Floor Size', 'review-schema-pro' ),
					'type'  => 'heading',
					'desc'  => __( 'Physical size of the accommodation.', 'review-schema-pro' ),
				],
				[
					'name'  => 'floorSizeValue',
					'label' => __( 'Floor Size Value', 'review-schema-pro' ),
					'type'  => 'number',
					'attr'  => 'step="any"',
					'desc'  => __( 'Numeric value representing the floor size.', 'review-schema-pro' ),
				],
				[
					'name'  => 'unitCode',
					'label' => __( 'Unit Code', 'review-schema-pro' ),
					'type'  => 'text',
					'desc'  => __( 'Measurement unit such as MTK (square meters).', 'review-schema-pro' ),
				],
				[
					'name'      => 'beds',
					'required'  => true,
					'type'      => 'group',
					'label'     => esc_html__( 'Beds', 'review-schema-pro' ),
					'duplicate' => true,
					'fields'    => [
						[
							'name'  => 'review_heading',
							'label' => __( 'Bed', 'review-schema-pro' ),
							'type'  => 'heading',
						],
						[
							'name'  => 'numberOfBeds',
							'label' => __( 'Number Of Beds', 'review-schema-pro' ),
							'type'  => 'number',
							'attr'  => 'step="any" min="1"',
							'desc'  => __( 'Total number of beds of this type.', 'review-schema-pro' ),
						],
						[
							'name'  => 'typeOfBed',
							'label' => __( 'Bed Type', 'review-schema-pro' ),
							'type'  => 'text',
							'desc'  => __( 'Type of bed (e.g. Queen, King, Bunk bed).', 'review-schema-pro' ),
						],
					],
				],
				[
					'name'      => 'amenityFeature',
					'required'  => true,
					'type'      => 'group',
					'label'     => esc_html__( 'Amenity Feature', 'review-schema-pro' ),
					'duplicate' => true,
					'fields'    => [
						[
							'name'  => 'review_heading',
							'label' => __( 'Amenity Feature', 'review-schema-pro' ),
							'type'  => 'heading',
						],
						[
							'name'  => 'feature',
							'label' => __( 'Feature', 'review-schema-pro' ),
							'type'  => 'text',
							'desc'  => __( 'Name of the amenity (e.g. WiFi, Parking, Air Conditioning).', 'review-schema-pro' ),
						],
						[
							'name'  => 'value',
							'label' => __( 'Available?', 'review-schema-pro' ),
							'type'  => 'checkbox',
							'desc'  => __( 'Check if this amenity is available to guests.', 'review-schema-pro' ),
						],
					],
				],

				[
					'name'  => 'aggregate_rating_section',
					'label' => __( 'Aggregate Rating', 'review-schema-pro' ),
					'type'  => 'heading',
					'desc'  => __( 'Overall rating based on multiple reviews.', 'review-schema-pro' ),
				],
				[
					'name'  => 'aggregate_ratingValue',
					'label' => __( 'Rating Value', 'review-schema-pro' ),
					'type'  => 'number',
					'attr'  => 'step="any"',
					'min'   => 1,
					'desc'  => __( 'Average rating score.', 'review-schema-pro' ),
				],
				[
					'name'  => 'aggregate_bestRating',
					'label' => __( 'Best Rating ( Rating Scale Maximum)', 'review-schema-pro' ),
					'type'  => 'number',
					'attr'  => 'step="any"',
					'min'   => 1,
					'desc'  => __( 'Highest possible rating value.', 'review-schema-pro' ),
				],
				[
					'name'  => 'aggregate_worstRating',
					'label' => __( 'Worst Rating ( Rating Scale Minimum)', 'review-schema-pro' ),
					'type'  => 'number',
					'attr'  => 'step="any"',
					'min'   => 1,
					'desc'  => __( 'Lowest possible rating value.', 'review-schema-pro' ),
				],
				[
					'name'  => 'aggregate_ratingCount',
					'label' => __( 'Rating Count', 'review-schema-pro' ),
					'type'  => 'number',
					'min'   => 0,
					'attr'  => 'step="any"',
					'desc'  => __( 'Total number of ratings received.', 'review-schema-pro' ),
				],
				[
					'name'      => 'reviews',
					'required'  => true,
					'type'      => 'group',
					'label'     => esc_html__( 'Reviews', 'review-schema-pro' ),
					'duplicate' => true,
					'fields'    => [
						[
							'name'  => 'review_heading',
							'label' => __( 'Review', 'review-schema-pro' ),
							'type'  => 'heading',
						],
						[
							'name'     => 'author',
							'label'    => __( 'Author', 'review-schema-pro' ),
							'type'     => 'text',
							'required' => true,
							'desc'     => __( 'Name of the reviewer.', 'review-schema-pro' ),
						],
						[
							'name'  => 'ratingValue',
							'label' => __( 'Rating Value', 'review-schema-pro' ),
							'type'  => 'number',
							'attr'  => 'step="any"',
							'min'   => 1,
							'desc'  => __( 'Rating given by the reviewer.', 'review-schema-pro' ),
						],
						[
							'name'     => 'datePublished',
							'label'    => __( 'Published Date', 'review-schema-pro' ),
							'type'     => 'text',
							'class'    => 'kcseo-date',
							'desc'     => sprintf( __( 'ISO 8601 date format. Example: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:sP' ) ),
							'required' => true,
						],
					],
				],
				[
					'name'  => 'PostalAddress',
					'label' => __( 'Address', 'review-schema-pro' ),
					'type'  => 'heading',
					'desc'  => __( 'Physical address of the vacation rental.', 'review-schema-pro' ),
				],
				[
					'name'  => 'streetAddress',
					'label' => __( 'Street Address', 'review-schema-pro' ),
					'type'  => 'text',
				],
				[
					'name'  => 'addressLocality',
					'label' => __( 'Address Locality', 'review-schema-pro' ),
					'type'  => 'text',
				],
				[
					'name'  => 'region',
					'label' => __( 'Region', 'review-schema-pro' ),
					'type'  => 'text',
					'desc'  => __( 'State or region code. Example: CA.', 'review-schema-pro' ),
				],
				[
					'name'  => 'postalCode',
					'label' => __( 'Postal Code', 'review-schema-pro' ),
					'type'  => 'text',
				],
				[
					'name'  => 'addressCountry',
					'label' => __( 'Country', 'review-schema-pro' ),
					'type'  => 'text',
					'desc'  => __( 'Country code. Example: US.', 'review-schema-pro' ),
				],
				[
					'name'  => 'images_heading',
					'label' => __( 'Images', 'review-schema-pro' ),
					'type'  => 'heading',
					'desc'  => __( 'Upload multiple images of the property. Google recommends at least 8 images.', 'review-schema-pro' ),
				],
				[
					'name'      => 'images',
					'required'  => true,
					'type'      => 'group',
					'label'     => esc_html__( 'Images', 'review-schema-pro' ),
					'duplicate' => true,
					'fields'    => [
						[
							'name'  => 'image',
							'label' => __( 'Upload Image', 'review-schema-pro' ),
							'type'  => 'image',
						],
					],
				],
			],
		];
		return $settings_fields;
	}

	/**
	 * Vehicle Listing Schema Fields
	 *
	 * @return array
	 */
	public function vehicleListingSchemaFields() {
		// Vacation Rental.
		$id              = 'vehicle_listing';
		$settings_fields = [
			'type'        => 'group',
			'name'        => $this->prefix . $id . '_schema',
			'id'          => 'rtrs-' . $id . '_schema',
			'holderClass' => 'rtrs-hidden rtrs-schema-field',
			'label'       => esc_html__( 'Vehicle Listing', 'review-schema-pro' ),
			'fields'      => [
				[
					'id'     => $id,
					'type'   => 'auto-fill',
					'is_pro' => true,
					'label'  => esc_html__( 'Auto Fill', 'review-schema-pro' ),
				],
				[
					'name'    => 'status',
					'type'    => 'tab',
					'label'   => esc_html__( 'Status', 'review-schema-pro' ),
					'default' => 'show',
					'options' => [
						'show' => esc_html__( 'Show', 'review-schema-pro' ),
						'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
					],
				],
				[
					'name'     => 'name',
					'label'    => __( 'Name', 'review-schema-pro' ),
					'type'     => 'text',
					'required' => true,
				],
				[
					'name'     => 'type',
					'label'    => __( 'Vehicle Type', 'review-schema-pro' ),
					'type'     => 'text',
					'required' => true,
					'desc'     => esc_html__( 'Type Look like: BusOrCoach, Car, Motorcycle, MotorizedBicycle. Ex: Car.  More Details:', 'review-schema-pro' ) . "<a href='https://schema.org/Vehicle' target='_blank'>" . esc_html__( 'Vehicle', 'review-schema-pro' ) . '</a>',
				],
				[
					'name'     => 'IdentificationNumber',
					'label'    => __( 'Identification Number (VIN)', 'review-schema-pro' ),
					'type'     => 'text',
					'required' => true,
					'desc'     => esc_html__( 'The Vehicle Identification Number (VIN), which is a unique alphanumeric identifier for each vehicle.', 'review-schema-pro' ) . "<a href='https://schema.org/Vehicle' target='_blank'>" . esc_html__( 'Vehicle', 'review-schema-pro' ) . '</a>',
				],
				[
					'name'  => 'description',
					'type'  => 'textarea',
					'label' => esc_html__( 'Description', 'review-schema-pro' ),
				],
				[
					'name'  => 'pricing_section_heading',
					'label' => __( 'Offer', 'review-schema-pro' ),
					'type'  => 'heading',
				],
				[
					'name'  => 'offers_price',
					'label' => __( 'Price', 'review-schema-pro' ),
					'type'  => 'number',
				],
				[
					'name'  => 'priceCurrency',
					'label' => __( 'Price Currency', 'review-schema-pro' ),
					'type'  => 'text',
					'desc'  => __( 'The 3-letter currency code. Example: USD', 'review-schema-pro' ),
				],
				[
					'name'        => 'priceValidUntil',
					'type'        => 'text',
					'label'       => esc_html__( 'Price Valid Until', 'review-schema-pro' ),
					'recommended' => true,
					'class'       => 'rtrs-date',
					'desc'        => sprintf( esc_html__( 'The date (in ISO 8601 date format) after which the price will no longer be available. Like this: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:sP' ) ),
				],
				[
					'name'    => 'availability',
					'label'   => 'Availability',
					'type'    => 'select',
					'empty'   => 'Select one',
					'options' => [
						'https://schema.org/InStock'      => 'InStock',
						'https://schema.org/InStoreOnly'  => 'InStoreOnly',
						'https://schema.org/OutOfStock'   => 'OutOfStock',
						'https://schema.org/SoldOut'      => 'SoldOut',
						'https://schema.org/OnlineOnly'   => 'OnlineOnly',
						'https://schema.org/LimitedAvailability' => 'LimitedAvailability',
						'https://schema.org/Discontinued' => 'Discontinued',
						'https://schema.org/PreOrder'     => 'PreOrder',
					],
					'desc'    => __( 'Select a availability type', 'review-schema-pro' ),
				],
				[
					'name'     => 'itemCondition',
					'label'    => __( 'Item Condition', 'review-schema-pro' ),
					'type'     => 'select',
					'required' => true,
					'options'  => [
						'https://schema.org/NewCondition'  => 'New',
						'https://schema.org/UsedCondition' => 'Used',
					],
				],
				[
					'name'     => 'brand',
					'label'    => __( 'Brand', 'review-schema-pro' ),
					'type'     => 'text',
					'required' => true,
					'desc'     => __( 'The brand of the product (Used globally).', 'review-schema-pro' ),
				],
				[
					'name'     => 'model',
					'label'    => __( 'Model', 'review-schema-pro' ),
					'type'     => 'text',
					'required' => true,
				],
				[
					'name'     => 'vehicleConfiguration',
					'label'    => __( 'Configuration', 'review-schema-pro' ),
					'type'     => 'text',
					'required' => true,
					'desc'     => __( 'The trim of the model, such as S, SV, or SL..', 'review-schema-pro' ),
				],
				[
					'name'     => 'vehicleModelDate',
					'label'    => __( 'Model Date', 'review-schema-pro' ),
					'type'     => 'text',
					'required' => true,
					'desc'     => __( 'EX: 1999', 'review-schema-pro' ),
				],
				[
					'name'  => 'Mileage',
					'label' => __( 'Mileage', 'review-schema-pro' ),
					'type'  => 'heading',
				],
				[
					'name'     => 'mileageFromOdometer',
					'label'    => __( 'Mileage From Odometer', 'review-schema-pro' ),
					'type'     => 'text',
					'required' => true,
				],
				[
					'name'  => 'unitCode',
					'label' => __( 'Unit Code', 'review-schema-pro' ),
					'type'  => 'text',
					'desc'  => __( 'Use one of the following values: ( For miles: SMI For kilometers: KMT ).', 'review-schema-pro' ),
				],

				[
					'name'  => 'color',
					'label' => __( 'Color', 'review-schema-pro' ),
					'type'  => 'text',
					'desc'  => __( 'The OEM-specified exterior color, such as White, Platinum, or Metallic Tri-Coat.', 'review-schema-pro' ),
				],
				[
					'name'  => 'vehicleInteriorColor',
					'label' => __( 'Interior Color', 'review-schema-pro' ),
					'type'  => 'text',
					'desc'  => __( 'The OEM-specified interior color, such as Brown or Ivory.', 'review-schema-pro' ),
				],
				[
					'name'  => 'vehicleInteriorType',
					'label' => __( 'Interior Type', 'review-schema-pro' ),
					'type'  => 'text',
					'desc'  => __( 'The type or material of the interior of the vehicle (for example, synthetic fabric, leather, wood).', 'review-schema-pro' ),
				],
				[
					'name'  => 'bodyType',
					'label' => __( 'Body Type', 'review-schema-pro' ),
					'type'  => 'text',
					'desc'  => __( 'Check Bodytype: ', 'review-schema-pro' ) . "<a href='https://developers.google.com/search/docs/appearance/structured-data/vehicle-listing' target='_blank'>" . esc_html__( 'Body Type', 'review-schema-pro' ) . '</a>',
				],
				[
					'name'     => 'driveWheelConfiguration',
					'label'    => __( 'Drive Wheel Configuration', 'review-schema-pro' ),
					'type'     => 'select',
					'required' => true,
					'options'  => [
						'https://schema.org/AllWheelDriveConfiguration'  => 'AllWheel',
						'https://schema.org/FourWheelDriveConfiguration'  => 'FourWheel',
						'https://schema.org/FrontWheelDriveConfiguration'  => 'FrontWheel',
						'https://schema.org/RearWheelDriveConfiguration'  => 'RearWheel',
					],
				],
				[
					'name'  => 'fuelType',
					'label' => __( 'Engine Fuel Type', 'review-schema-pro' ),
					'type'  => 'text',
					'desc'  => __( 'The type of fuel that\'s suitable for the engine of the vehicle.', 'review-schema-pro' ),
				],
				[
					'name'  => 'vehicleTransmission',
					'label' => __( 'Transmission', 'review-schema-pro' ),
					'type'  => 'text',
					'desc'  => __( 'The transmission specification. For example, 9-speed automatic or manual.', 'review-schema-pro' ),
				],
				[
					'name'  => 'numberOfDoors',
					'label' => __( 'Number Of Doors', 'review-schema-pro' ),
					'type'  => 'number',
				],
				[
					'name'  => 'vehicleSeatingCapacity',
					'label' => __( 'Seating Capacity', 'review-schema-pro' ),
					'type'  => 'number',
				],
				[
					'name'  => 'images_heading',
					'label' => __( 'Images', 'review-schema-pro' ),
					'type'  => 'heading',
					'desc'  => __( 'One or more images of the listing. The listing must have a minimum of 8 photos (at least 1 image of each of the following: bedroom, bathroom, and common area)', 'review-schema-pro' ),
				],
				[
					'required'  => true,
					'type'      => 'group',
					'label'     => esc_html__( 'Images', 'review-schema-pro' ),
					'name'      => 'images',
					'duplicate' => true,
					'fields'    => [
						[
							'name'  => 'image',
							'label' => __( 'Upload Images', 'review-schema-pro' ),
							'type'  => 'image',
						],
					],
				],

				[
					'name'  => 'MerchantReturnPolicy',
					'type'  => 'heading',
					'label' => esc_html__( 'Merchant Return Policy', 'review-schema-pro' ),
				],
				[
					'name'        => 'applicableCountry',
					'type'        => 'text',
					'placeholder' => 'US',
					'label'       => esc_html__( 'Applicable Country', 'review-schema-pro' ),
					'desc'        => esc_html__( 'The two-letter country code, in ISO 3166-1 alpha-2 format.', 'review-schema-pro' ),
				],
				[
					'name'        => 'merchantReturnDays',
					'type'        => 'text',
					'placeholder' => '10',
					'label'       => esc_html__( 'Merchant Return Days', 'review-schema-pro' ),
				],
				[
					'name'  => 'shipping_details',
					'type'  => 'heading',
					'label' => esc_html__( 'Shipping Details', 'review-schema-pro' ),
				],
				[
					'name'  => 'shippingRate',
					'type'  => 'float',
					'label' => esc_html__( 'Shipping Rate ( Price )', 'review-schema-pro' ),
					'desc'  => esc_html__( 'Shipping Cost.', 'review-schema-pro' ),
				],
				[
					'name'        => 'shippingDestination',
					'type'        => 'text',
					'placeholder' => 'US',
					'label'       => esc_html__( 'Shipping Destination', 'review-schema-pro' ),
					'desc'        => esc_html__( 'The two-letter country code, in ISO 3166-1 alpha-2 format.', 'review-schema-pro' ),
				],
				[
					'name'        => 'addressRegion',
					'type'        => 'text',
					'placeholder' => ' "NY", "AL", "AK"',
					'label'       => esc_html__( 'Address Region', 'review-schema-pro' ),
					'desc'        => esc_html__( 'If you include this property, the region must be a 2- or 3-digit ISO 3166-2 subdivision code, without country prefix. Currently, Google Search only supports the US, Australia, and Japan. Examples: "NY" (for US, state of New York), "NSW" (for Australia, state of New South Wales), or "03" (for Japan, Iwate prefecture).Example: "NY", "AL", "AK".', 'review-schema-pro' ),
				],
				[
					'name'  => 'handlingTime',
					'type'  => 'heading',
					'label' => esc_html__( 'Handling Time', 'review-schema-pro' ),
				],

				[
					'name'        => 'handlingTimeMinimum',
					'type'        => 'text',
					'placeholder' => '5',
					'label'       => esc_html__( 'Handling Time Minimum ( Days )', 'review-schema-pro' ),
					'desc'        => esc_html__( 'Minimum days for handling time.', 'review-schema-pro' ),
				],
				[
					'name'        => 'handlingTimeMaximum',
					'type'        => 'text',
					'placeholder' => '5',
					'label'       => esc_html__( 'Handling Time Maximum (Days)', 'review-schema-pro' ),
					'desc'        => esc_html__( 'Maximum days for handling time.', 'review-schema-pro' ),
				],

				[
					'name'        => 'transitTimeMinimum',
					'type'        => 'text',
					'placeholder' => '5',
					'label'       => esc_html__( 'Transit Time Minimum ( Days )', 'review-schema-pro' ),
					'desc'        => esc_html__( 'Minimum days for Transit Time.', 'review-schema-pro' ),
				],
				[
					'name'        => 'transitTimeMaximum',
					'type'        => 'text',
					'placeholder' => '10',
					'label'       => esc_html__( 'Transit Time Maximum ( Days )', 'review-schema-pro' ),
					'desc'        => esc_html__( 'Maximum days for Transit Time.', 'review-schema-pro' ),
				],

				[
					'name'  => 'rating_section',
					'label' => __( 'Aggregate Rating', 'review-schema-pro' ),
					'type'  => 'heading',
				],
				[
					'name'        => 'ratingValue',
					'label'       => __( 'Aggregate Rating value', 'review-schema-pro' ),
					'type'        => 'number',
					'recommended' => true,
					'attr'        => 'step="any"',
					'min'         => 1,
					'desc'        => __( 'Rating value. (1 , 2.5, 3, 5 etc)', 'review-schema-pro' ),
				],
				[
					'name'  => 'reviewCount',
					'label' => __( 'Aggregate Total review count', 'review-schema-pro' ),
					'type'  => 'number',
					'min'   => 0,
					'attr'  => 'step="any"',
					'desc'  => __( "Review Count. <span class='required'>This is required if (Rating value) is given</span>", 'review-schema-pro' ),
				],
				[
					'name'        => 'reviewBestRating',
					'label'       => __( 'Best rating Range', 'review-schema-pro' ),
					'type'        => 'number',
					'recommended' => true,
					'attr'        => 'step="any"',
					'min'         => 1,
				],
				[
					'name'        => 'reviewWorstRating',
					'label'       => __( 'Worst rating Range', 'review-schema-pro' ),
					'type'        => 'number',
					'recommended' => true,
					'attr'        => 'step="any"',
					'min'         => 1,
				],
				[
					'name'  => 'review_heading',
					'label' => __( 'Review', 'review-schema-pro' ),
					'type'  => 'heading',
				],
				[
					'name'  => 'reviewAuthor',
					'label' => __( 'Review author', 'review-schema-pro' ),
					'type'  => 'text',
				],
				[
					'name'        => 'reviewRatingValue',
					'label'       => __( 'Review rating value', 'review-schema-pro' ),
					'type'        => 'number',
					'recommended' => true,
					'attr'        => 'step="any"',
					'min'         => 1,
					'desc'        => __( 'Rating value. (1 , 2.5, 3, 5 etc)', 'review-schema-pro' ),
				],

			],
		];
		return $settings_fields;
	}
	/**
	 * Podcast Episode Schema Fields
	 *
	 * @return array
	 */
	public function podcastEpisodeSchemaFields() {
		$id              = 'PodcastEpisode';
		$settings_fields = [
			'type'        => 'group',
			'name'        => $this->prefix . $id . '_schema',
			'id'          => 'rtrs-' . $id . '_schema',
			'holderClass' => 'rtrs-hidden rtrs-schema-field',
			'label'       => esc_html__( 'Podcast Episode', 'review-schema-pro' ),
			'fields'      => [

				// Auto-fill.
				[
					'id'     => $id,
					'type'   => 'auto-fill',
					'is_pro' => true,
					'label'  => esc_html__( 'Auto Fill', 'review-schema-pro' ),
				],
				// Status.
				[
					'name'    => 'status',
					'type'    => 'tab',
					'label'   => esc_html__( 'Status', 'review-schema-pro' ),
					'default' => 'show',
					'options' => [
						'show' => esc_html__( 'Show', 'review-schema-pro' ),
						'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
					],
				],
				// Basic Info.
				[
					'name'     => 'name',
					'type'     => 'text',
					'label'    => esc_html__( 'Episode Title', 'review-schema-pro' ),
					'required' => true,
				],
				[
					'name'     => 'description',
					'type'     => 'textarea',
					'label'    => esc_html__( 'Description', 'review-schema-pro' ),
					'required' => true,
				],
				[
					'name'  => 'episodeNumber',
					'type'  => 'number',
					'label' => esc_html__( 'Episode Number', 'review-schema-pro' ),
				],
				[
					'name'  => 'thumbnailUrl',
					'type'  => 'url',
					'label' => esc_html__( 'Thumbnail URL', 'review-schema-pro' ),
				],
				[
					'name'  => 'timeRequired',
					'type'  => 'text',
					'label' => esc_html__( 'Time Required (ISO Duration)', 'review-schema-pro' ),
					'desc'  => esc_html__( 'Example: PT45M30S', 'review-schema-pro' ),
				],

				// AUDIO SECTION.
				[
					'name'  => 'audio_heading',
					'label' => esc_html__( 'Audio Info', 'review-schema-pro' ),
					'type'  => 'heading',
				],
				[
					'name'  => 'audio_url',
					'type'  => 'url',
					'label' => esc_html__( 'Audio URL (mp3)', 'review-schema-pro' ),
				],
				[
					'name'  => 'audio_encodingFormat',
					'type'  => 'text',
					'label' => esc_html__( 'Encoding Format', 'review-schema-pro' ),
					'desc'  => esc_html__( 'Default: audio/mpeg', 'review-schema-pro' ),
				],
				[
					'name'  => 'duration',
					'type'  => 'text',
					'label' => esc_html__( 'Audio Duration', 'review-schema-pro' ),
					'desc'  => esc_html__( 'Example: PT48M20S', 'review-schema-pro' ),
				],

				// YOUTUBE / VIDEO SECTION.
				[
					'name'  => 'video_heading',
					'label' => esc_html__( 'Video (Optional)', 'review-schema-pro' ),
					'type'  => 'heading',
				],
				[
					'name'  => 'video_name',
					'type'  => 'text',
					'label' => esc_html__( 'Video Title', 'review-schema-pro' ),
				],
				[
					'name'  => 'video_description',
					'type'  => 'textarea',
					'label' => esc_html__( 'Video Description', 'review-schema-pro' ),
				],
				[
					'name'  => 'video_thumbnail',
					'type'  => 'url',
					'label' => esc_html__( 'Video Thumbnail URL', 'review-schema-pro' ),
				],
				[
					'name'  => 'video_embedUrl',
					'type'  => 'url',
					'label' => esc_html__( 'Video Embed URL (YouTube)', 'review-schema-pro' ),
					'desc'  => esc_html__( 'Example: https://www.youtube.com/embed/abc123', 'review-schema-pro' ),
				],
				[
					'name'  => 'video_contentUrl',
					'type'  => 'url',
					'label' => esc_html__( 'Video URL', 'review-schema-pro' ),
					'desc'  => esc_html__( 'Example: https://youtube.com/watch?v=xxx', 'review-schema-pro' ),
				],
				[
					'name'  => 'video_uploadDate',
					'type'  => 'text',
					'class' => 'rtrs-date',
					'label' => esc_html__( 'Video Upload Date', 'review-schema-pro' ),
					'desc'  => sprintf( esc_html__( 'ISO 8601 format: %s', 'review-schema-pro' ), wp_date( 'Y-m-d\TH:i:sP' ) ),
				],

				// SERIES INFORMATION.
				[
					'name'  => 'series_heading',
					'label' => esc_html__( 'Series Information', 'review-schema-pro' ),
					'type'  => 'heading',
				],
				[
					'name'     => 'series_name',
					'type'     => 'text',
					'label'    => esc_html__( 'Series Name', 'review-schema-pro' ),
					'required' => true,
				],
				[
					'name'     => 'series_url',
					'type'     => 'url',
					'label'    => esc_html__( 'Series URL', 'review-schema-pro' ),
					'required' => true,
				],
				// HOSTS.
				[
					'name'  => 'host_heading',
					'label' => esc_html__( 'Hosts (People)', 'review-schema-pro' ),
					'type'  => 'heading',
				],
				[
					'name'      => 'hosts',
					'label'     => esc_html__( 'Hosts', 'review-schema-pro' ),
					'type'      => 'group',
					'duplicate' => true,
					'fields'    => [
						[
							'name'  => 'name',
							'type'  => 'text',
							'label' => esc_html__( 'Host Name', 'review-schema-pro' ),
						],
						[
							'name'  => 'url',
							'type'  => 'url',
							'label' => esc_html__( 'Host URL', 'review-schema-pro' ),
						],
					],
				],

				// TRANSCRIPT.
				[
					'name'  => 'transcript_heading',
					'label' => esc_html__( 'Transcript', 'review-schema-pro' ),
					'type'  => 'heading',
				],
				[
					'name'  => 'transcript',
					'type'  => 'textarea',
					'label' => esc_html__( 'Transcript Text', 'review-schema-pro' ),
					'desc'  => esc_html__( 'Optional. Google uses this for better indexing.', 'review-schema-pro' ),
				],
			],
		];

		return $settings_fields;
	}
	/**
	 * Taxi Service Schema Fields
	 *
	 * @return array
	 */
	public function taxiServiceSchemaFields() {
		$id              = 'TaxiService';
		$settings_fields = [
			[
				'id'     => $id,
				'type'   => 'auto-fill',
				'is_pro' => true,
				'label'  => esc_html__( 'Auto Fill', 'review-schema-pro' ),
			],
			[
				'name'    => 'status',
				'type'    => 'tab',
				'label'   => esc_html__( 'Status', 'review-schema-pro' ),
				'default' => 'show',
				'options' => [
					'show' => esc_html__( 'Show', 'review-schema-pro' ),
					'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
				],
			],
			[
				'name'     => 'name',
				'type'     => 'text',
				'label'    => esc_html__( 'Service Name', 'review-schema-pro' ),
				'required' => true,
			],
			[
				'name'  => 'description',
				'type'  => 'textarea',
				'label' => esc_html__( 'Description', 'review-schema-pro' ),
			],
			[
				'name'      => 'areaServed',
				'type'      => 'group',
				'label'     => esc_html__( 'Area Served', 'review-schema-pro' ),
				'duplicate' => true,
				'desc'      => esc_html__( 'The geographic area where the taxi service operates.', 'review-schema-pro' ),
				'fields'    => [
					[
						'name'  => 'name',
						'type'  => 'text',
						'label' => esc_html__( 'City Name', 'review-schema-pro' ),
					],
				],
			],
			[
				'name'      => 'offers',
				'type'      => 'group',
				'label'     => esc_html__( 'Offers', 'review-schema-pro' ),
				'duplicate' => false,
				'fields'    => [
					[
						'name'  => 'description',
						'type'  => 'text',
						'label' => esc_html__( 'Offer Description', 'review-schema-pro' ),
					],
					[
						'name'  => 'priceCurrency',
						'type'  => 'text',
						'label' => esc_html__( 'Price Currency', 'review-schema-pro' ),
						'desc'  => esc_html__( 'e.g. USD, EUR, GBP', 'review-schema-pro' ),
					],
					[
						'name'  => 'price',
						'type'  => 'text',
						'label' => esc_html__( 'Price', 'review-schema-pro' ),
					],
				],
			],
		];

		return [
			'type'        => 'group',
			'name'        => $this->prefix . $id . '_schema',
			'id'          => 'rtrs-' . $id . '_schema',
			'holderClass' => 'rtrs-hidden rtrs-schema-field',
			'label'       => esc_html__( 'Taxi Service Schema', 'review-schema-pro' ),
			'fields'      => $settings_fields,
		];
	}

	/**
	 * TouristAttraction Schema Fields.
	 *
	 * @return array
	 */
	public function touristAttractionSchemaFields() {
		$id              = 'touristattraction';
		$settings_fields = [
			[
				'id'     => $id,
				'type'   => 'auto-fill',
				'is_pro' => true,
				'label'  => esc_html__( 'Auto Fill', 'review-schema-pro' ),
			],
			[
				'name'    => 'status',
				'type'    => 'tab',
				'label'   => esc_html__( 'Status', 'review-schema-pro' ),
				'default' => 'show',
				'options' => [
					'show' => esc_html__( 'Show', 'review-schema-pro' ),
					'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
				],
			],
			[
				'name'     => 'name',
				'type'     => 'text',
				'label'    => esc_html__( 'Name', 'review-schema-pro' ),
				'required' => true,
			],
			[
				'name'     => 'description',
				'type'     => 'textarea',
				'label'    => esc_html__( 'Description', 'review-schema-pro' ),
				'required' => true,
			],
			[
				'name'        => 'touristType',
				'type'        => 'text',
				'label'       => esc_html__( 'Tourist Type', 'review-schema-pro' ),
				'placeholder' => esc_html__( 'e.g. Family, Hikers, History lovers', 'review-schema-pro' ),
				'desc'        => esc_html__( 'The type of tourist this attraction suits (audience or category).', 'review-schema-pro' ),
			],
			[
				'name'        => 'sameAs',
				'type'        => 'textarea',
				'label'       => esc_html__( 'Same As (Profile Link)', 'review-schema-pro' ),
				'placeholder' => 'https://www.official-website.com&#10;https://www.facebook.com/the-page',
				'desc'        => wp_kses( __( "A reference page that unambiguously indicates the item's identity; for example, the URL of the item's Wikipedia page, Freebase page, or official website.<br> Enter new line for every entry", 'review-schema-pro' ), [ 'br' => [] ] ),
			],
			[
				'type'      => 'group',
				'duplicate' => false,
				'name'      => 'address',
				'label'     => esc_html__( 'Address Info', 'review-schema-pro' ),
				'fields'    => [
					[
						'name'    => 'address-country',
						'label'   => esc_html__( 'Country', 'review-schema-pro' ),
						'type'    => 'select',
						'options' => Functions::getCountryList(),
						'empty'   => esc_html__( 'Select One', 'review-schema-pro' ),
					],
					[
						'name'  => 'address-locality',
						'type'  => 'text',
						'label' => esc_html__( 'Locality', 'review-schema-pro' ),
					],
					[
						'name'  => 'address-region',
						'type'  => 'text',
						'label' => esc_html__( 'Region', 'review-schema-pro' ),
					],
					[
						'name'  => 'postal-code',
						'type'  => 'text',
						'label' => esc_html__( 'Postal Code', 'review-schema-pro' ),
					],
				],
			],
			[
				'name'        => 'latitude',
				'type'        => 'text',
				'label'       => esc_html__( 'Latitude', 'review-schema-pro' ),
				'placeholder' => esc_html__( 'e.g. 40.7128', 'review-schema-pro' ),
			],
			[
				'name'        => 'longitude',
				'type'        => 'text',
				'label'       => esc_html__( 'Longitude', 'review-schema-pro' ),
				'placeholder' => esc_html__( 'e.g. -74.0060', 'review-schema-pro' ),
			],
			[
				'type'   => 'group',
				'name'   => 'openingHours',
				'label'  => esc_html__( 'Opening Hours By Day', 'review-schema-pro' ),
				'fields' => [
					[
						'name'    => 'dayOfWeek',
						'type'    => 'select',
						'label'   => esc_html__( 'Day', 'review-schema-pro' ),
						'empty'   => esc_html__( 'Select one', 'review-schema-pro' ),
						'options' => [
							'Monday'    => esc_html__( 'Monday', 'review-schema-pro' ),
							'Tuesday'   => esc_html__( 'Tuesday', 'review-schema-pro' ),
							'Wednesday' => esc_html__( 'Wednesday', 'review-schema-pro' ),
							'Thursday'  => esc_html__( 'Thursday', 'review-schema-pro' ),
							'Friday'    => esc_html__( 'Friday', 'review-schema-pro' ),
							'Saturday'  => esc_html__( 'Saturday', 'review-schema-pro' ),
							'Sunday'    => esc_html__( 'Sunday', 'review-schema-pro' ),
						],
						'desc'    => esc_html__( "Don't add same day multiple time", 'review-schema-pro' ),
					],
					[
						'name'  => 'opens',
						'type'  => 'text',
						'label' => esc_html__( 'Opens Time', 'review-schema-pro' ),
						'desc'  => esc_html__( 'Times are specified using 24:00 time. For example, 3PM is specified as 15:00.', 'review-schema-pro' ),
					],
					[
						'name'  => 'closes',
						'type'  => 'text',
						'label' => esc_html__( 'Closes Time', 'review-schema-pro' ),
					],
				],
			],
		];

		return [
			'type'        => 'group',
			'name'        => $this->prefix . $id . '_schema',
			'id'          => 'rtrs-' . $id . '_schema',
			'holderClass' => 'rtrs-hidden rtrs-schema-field',
			'label'       => esc_html__( 'TouristAttraction Schema', 'review-schema-pro' ),
			'fields'      => $settings_fields,
		];
	}


	/**
	 * Returns a comprehensive list of Schema.org SoftwareApplication categories.
	 * * @return array
	 */
	public function getApplicationCategoryList() {
		$list = [
			'BusinessApplication',
			'DeveloperApplication',
			'EducationalApplication',
			'EntertainmentApplication',
			'FinanceApplication',
			'GameApplication',
			'HealthApplication',
			'LifestyleApplication',
			'MultimediaApplication',
			'ReferenceApplication',
			'SocialNetworkingApplication',
			'UtilitiesApplication',
			'TravelApplication',
			'ShoppingApplication',
			'SportsApplication',
			'DesignApplication',
			'DriverApplication',
			'SecurityApplication',
			'BrowserApplication',
			'CommunicationApplication',
			'DesktopEnhancementApplication',
			'HomeApplication',
			'PhotographyApplication',
			'MedicalApplication',
			'MapsApplication',
			'ProductivityApplication',
			'NewsApplication',
			'WeatherApplication',
		];

		// Sort alphabetically to make the UI dropdown easier to navigate
		asort( $list );

		$new_list = [];
		foreach ( $list as $value ) {
			$new_list[ $value ] = $value;
		}

		return apply_filters( 'rtseo_application_category_list', $new_list );
	}
}
